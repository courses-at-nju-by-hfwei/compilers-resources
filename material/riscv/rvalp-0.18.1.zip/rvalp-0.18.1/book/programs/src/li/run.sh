prompt="$" 
cmd="rvddt -f li.bin"
echo "$prompt $cmd"
$cmd <<!
d 0 16
t 0 1000
!
