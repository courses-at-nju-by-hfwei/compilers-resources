prompt="$" 
cmd="rvddt -f mv.bin"
echo "$prompt $cmd"
$cmd <<!
a
d 0 16
t 0 1000
!
