#include <QtGui/QKeyEvent>
#include <QtGui/QRegExpValidator>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

#include "AtmtExec.h"
#include "InputSelector.h"

QValidator::State ValidateChars::validate( QString& inputQStr, int &pos ) const {
  astrbuf input; int invalid_chars, invalid_escapes;
  invalid_chars = fromQString(inputQStr,&input); if( invalid_chars ) return QValidator::Invalid;
  invalid_escapes = unescape_chars(&input);
  //cout << input << aux::endl << IOFlush();
  //if( input.length <= maxlen ) inputSelector->charparams_cached.moveFrom(&input);
  return input.length <= maxlen ? ( invalid_escapes ? QValidator::Intermediate : QValidator::Acceptable ) : QValidator::Invalid;
}

InputSelector::InputSelector( TapeWatch *tapeWatch ) {
  this->tapeWatch = tapeWatch;
  QVBoxLayout *mainLayout = new QVBoxLayout();
  predefInputsListWidget = new QListWidget();
   connect( predefInputsListWidget, SIGNAL(currentRowChanged(int)), this, SLOT(listItemSelected(int)) );
   mainLayout->addWidget(predefInputsListWidget);
  QHBoxLayout *hboxlyo = new QHBoxLayout(); QLabel *label;
   label = new QLabel(tr("&tape:")); tapeEdit = new QLineEdit(); label->setBuddy(tapeEdit); 
   hboxlyo->addWidget(label); hboxlyo->addWidget(tapeEdit); mainLayout->addLayout(hboxlyo);
  hboxlyo = new QHBoxLayout();
   charParamLabel = new QLabel(tr("&character parameters:")); charparam_validator = NULL; 
   charParamEdit = new QLineEdit(); charParamLabel->setBuddy(charParamEdit); 
   hboxlyo->addWidget(charParamLabel); hboxlyo->addWidget(charParamEdit); mainLayout->addLayout(hboxlyo);
  hboxlyo = new QHBoxLayout();
   valParamLabel = new QLabel(tr("&value parameters:")); 
   valParamEdit = new QLineEdit(); valParamLabel->setBuddy(valParamEdit); 
   QRegExp valParamRegExp("([+-]?[0-9][0-9]*,?)*"); valparam_validator = new QRegExpValidator(valParamRegExp,this); valParamEdit->setValidator(valparam_validator);
   hboxlyo->addWidget(valParamLabel); hboxlyo->addWidget(valParamEdit); mainLayout->addLayout(hboxlyo);
  connect( tapeEdit, SIGNAL(editingFinished()), this, SLOT(listItemTapeEdited()) );
  connect( charParamEdit, SIGNAL(editingFinished()), this, SLOT(listItemCharParamEdited()) );
  connect( valParamEdit, SIGNAL(editingFinished()), this, SLOT(listItemValParamEdited()) );
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
   mainLayout->addWidget(dialogButtons);
  setLayout(mainLayout);
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(accept()) );
  connect( dialogButtons, SIGNAL(rejected()), this, SLOT(reject()) );
  connect( predefInputsListWidget, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this , SLOT(accept()) );
  predefInputsListWidget->installEventFilter(this);
  setWindowTitle("Select Input");
  //currentlyUsedIndex = -1;
}

void InputSelector::listItemEdited( int setwhat ) {
  QListWidgetItem *item = predefInputsListWidget->currentItem(); 
  if(!item) { item = predefInputsListWidget->item(predefInputsListWidget->count()-1); if(!item) return; predefInputsListWidget->setCurrentItem(item); }
  int idx = item->data(Qt::UserRole).toInt();
  if( idx < 0 ) {
    predefInputsList->push_back(RuntimeParams{ });
    //if( currentlyUsedIndex >= 0 ) { // list may have become reallocated by insert  // no action no more needed since tapeWatch->* are cpy-bufs rather than references
    //  RuntimeParams *params = &(*predefInputsList)[currentlyUsedIndex];
    //  tapeWatch->tape = params->tape; tapeWatch->charparams = params->charparams; tapeWatch->valparams = params->valparams;
    //}
    item->setData( Qt::UserRole, idx = predefInputsList->size()-1 );
    QListWidgetItem *new_item = new QListWidgetItem( "", predefInputsListWidget );
    new_item->setData( Qt::UserRole, -1 );
    setwhat = SetWhat::Tape || SetWhat::CharParam || SetWhat::ValParam;
  }
  RuntimeParams *params = &(*predefInputsList)[idx];
  if( setwhat & SetWhat::Tape ) {
    fromQString( tapeEdit->text(), &params->tape ); //SymbolTable::normalize(&params->tape,SymbolMode::mode_anySubscript); 
    unescape_chars(&params->tape);
  }
  if( setwhat & SetWhat::CharParam ) {
    fromQString( charParamEdit->text(), &params->charparams );
    unescape_chars(&params->charparams);
  }
  if( setwhat & SetWhat::ValParam ) {
    params->valparams.length = 0; QString val_list = valParamEdit->text();
    params->valparams.reserve( val_list.count(',') + (val_list.length()?1:0) );
    int i = 0, j = val_list.indexOf(",",i), num;
    while( j >= 0 ) {
      num = val_list.mid(i,j-i).toInt();
      params->valparams.append(inta_const( &num, 1 )); 
      i = j + 1; j = val_list.indexOf(",",i);
    }
    if( i < val_list.length() ) {
      num = val_list.mid(i).toInt();
      params->valparams.append(inta_const( &num, 1 )); 
    }
  }
  item->setText( itemRepr4List(params) );
}

void InputSelector::listItemTapeEdited() { listItemEdited(SetWhat::Tape); }
void InputSelector::listItemCharParamEdited() { listItemEdited(SetWhat::CharParam); }
void InputSelector::listItemValParamEdited() { listItemEdited(SetWhat::ValParam); }

void InputSelector::swapEntries( int idxa, int idxb ) {
  QListWidget *widget = predefInputsListWidget;
  if( idxa < 0 || idxa >= widget->count()-1 || idxb < 0 || idxb >= widget->count()-1 ) return;
  if( idxa > idxb ) { int tmp = idxa; idxa = idxb; idxb = tmp; }
  // swap visible items
  QListWidgetItem *itemb = widget->takeItem(idxb), *itema = widget->takeItem(idxa);
  widget->insertItem( idxa, itemb ); widget->insertItem( idxb, itema );
  // swap underlying items (takes effect when saving the file)
  int ia = widget->item(idxa)->data(Qt::UserRole).toInt(); int ib = widget->item(idxb)->data(Qt::UserRole).toInt();
  RuntimeParams *pa = &(*predefInputsList)[ia], *pb = &(*predefInputsList)[ib];
  astrbuf tape; astrbuf charparams; intabuf valparams; 
  tape.moveFrom(&pa->tape); charparams.moveFrom(&pa->charparams); valparams.moveFrom(&pa->valparams);
  pa->tape.moveFrom(&pb->tape); pa->charparams.moveFrom(&pb->charparams); pa->valparams.moveFrom(&pb->valparams);
  pb->tape.moveFrom(&tape); pb->charparams.moveFrom(&charparams); pb->valparams.moveFrom(&valparams);
  // change references to underlying items
  widget->item(idxa)->setData(Qt::UserRole,ib);
  widget->item(idxb)->setData(Qt::UserRole,ia);
}

void InputSelector::keyPressEvent(QKeyEvent *event) {
  switch(event->key()) {
    case Qt::Key_Delete:  {
       QListWidgetItem *item = predefInputsListWidget->currentItem(); 
       int idx = item->data(Qt::UserRole).toInt();
       if( idx >= 0 ) { // && idx != currentlyUsedIndex ) { // may also delete currently selected element since tapeWatch->* are cpy-bufs rather than references
	 delete item;
	 predefInputsList->erase(predefInputsList->begin()+idx);
	 //if( currentlyUsedIndex > idx ) {   // no more needed since tapeWatch->* are cpy-bufs rather than references
	 //  currentlyUsedIndex--; // everything after the erased index becomes reallocated, so refresh the result
	 //  RuntimeParams *params = &(*predefInputsList)[currentlyUsedIndex];
	 //  tapeWatch->tape = params->tape; tapeWatch->charparams = params->charparams; tapeWatch->valparams = params->valparams;
	 //}
	 for( int i = idx; i < predefInputsListWidget->count(); i++ ) {
	   QListWidgetItem *item = predefInputsListWidget->item(i);
	   int item_idx = item->data(Qt::UserRole).toInt();
	   if( item_idx > 0 ) item->setData( Qt::UserRole, item_idx - 1 );
	 }
      } }; break;
    case Qt::Key_Up: if( event->modifiers() & Qt::AltModifier ) { 
	QListWidget *widget = predefInputsListWidget;
        int currow = widget->currentRow(); 
	swapEntries(currow-1,currow); 
	int newpos = qMax(0,currow-1);
	widget->setCurrentRow(newpos); 
	if(widget->item(newpos)) widget->scrollToItem( widget->item(newpos), QAbstractItemView::PositionAtBottom ); 
      } else QDialog::keyPressEvent(event); break;
    case Qt::Key_Down: if( event->modifiers() & Qt::AltModifier ) { 
	QListWidget *widget = predefInputsListWidget;
	int currow = widget->currentRow(); 
	swapEntries(currow,currow+1); 
	int newpos = qMin(currow+1,widget->count()-2);
	widget->setCurrentRow(newpos); 
	if(widget->item(newpos)) widget->scrollToItem( widget->item(newpos), QAbstractItemView::PositionAtTop ); 
      } else QDialog::keyPressEvent(event); break;
    default: QDialog::keyPressEvent(event);
  }
}

bool InputSelector::eventFilter(QObject *target,QEvent *event) {
  if( event->type() == QEvent::KeyPress ) {
    QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
    if( target == predefInputsListWidget && keyEvent->modifiers() & Qt::AltModifier ) { 
      if( keyEvent->key() == Qt::Key_Up) { keyPressEvent(keyEvent); return true; }
      else if( keyEvent->key() == Qt::Key_Down ) { keyPressEvent(keyEvent); return true; }
  } }
  return QDialog::eventFilter(target,event);
}


QString inta2QStr( inta_const vals ) {
  QString result;
  for(int i=0; i < vals.length; i++ )
    result = result + (i>0?",":"") +  QString::number(vals.chars[i]); 
  return result;
}

void InputSelector::listItemSelected( int currentRow ) {
  if( currentRow < 0 || currentRow >= predefInputsListWidget->count() ) {
    tapeEdit->clear(); charParamEdit->clear(); valParamEdit->clear();
    return;
  }
  int idx = predefInputsListWidget->item(currentRow)->data(Qt::UserRole).toInt();
  if( idx >= 0 ) {
    RuntimeParams *params = &(*predefInputsList)[idx];
    tapeEdit->setText( toQString( params->tape ) );
    charParamEdit->setText( toQString( params->charparams ) );
    valParamEdit->setText( inta2QStr( params->valparams ) );
    //charparams_cached = invalid_astr;
  } else {
    tapeEdit->clear(); charParamEdit->clear(); valParamEdit->clear();
  }
}

QString InputSelector::itemRepr4List( RuntimeParams *params ) {
  QString repr; if(params->charparams.length) repr += toQString(params->charparams);
  if(params->valparams.length) { 
    if(params->charparams.length) repr += "/"; 
    repr += inta2QStr(params->valparams);
  };
  if( params->charparams.length || params->valparams.length ) repr += ", "; 
  repr += toQString(params->tape);
  return repr;
}

void InputSelector::setInputList( std::vector<RuntimeParams> *params ) {
  predefInputsListWidget->clear();
  predefInputsList = params;
  for( int i = 0; i < (int)params->size(); i++ ) {
    QListWidgetItem *item = new QListWidgetItem( itemRepr4List(&(*params)[i]), predefInputsListWidget );
    item->setData( Qt::UserRole, i );
  }
  QListWidgetItem *item = new QListWidgetItem( "", predefInputsListWidget );
  item->setData( Qt::UserRole, -1 );
  //currentlyUsedIndex = -1;
  setFormalParams();
  predefInputsListWidget->setCurrentRow(0);
}

void InputSelector::setFormalParams() {
  charParamLabel->setText(tr("&character parameters (%1):").arg(variableTextAsQString(tapeWatch->atmt->charFormalParams))); 
   if(!charparam_validator) { charparam_validator = new ValidateChars(tapeWatch->atmt->charFormalParamCount,this); charParamEdit->setValidator(charparam_validator); }
   else charparam_validator->maxlen = tapeWatch->atmt->charFormalParamCount;
  valParamLabel->setText(tr("&value parameters: (%1)").arg(variableTextAsQString(tapeWatch->atmt->valFormalParams))); 
   int vpCount = tapeWatch->atmt->valFormalParamCount;
   QString regstr = ""; if(vpCount>1) { regstr.append("([+-]?[0-9][0-9]*,){0,"); regstr.append(QString::number(vpCount-1)); regstr.append("}"); }
   if(vpCount>0) regstr.append("[+-]?[0-9][0-9]*");
   QRegExp valParamRegExp(regstr); QRegExpValidator *new_validator = new QRegExpValidator(valParamRegExp,this);
   valParamEdit->setValidator(new_validator); delete valparam_validator; valparam_validator = new_validator;
}

void InputSelector::pickLast() {
  int currentlyUsedIndex = predefInputsList->size()-1;
  if( currentlyUsedIndex >= 0 ) {
    RuntimeParams *params = &(*predefInputsList)[currentlyUsedIndex];
    tapeWatch->tape = params->tape;
    tapeWatch->charparams = params->charparams;
    tapeWatch->valparams = params->valparams;
    predefInputsListWidget->setCurrentRow(currentlyUsedIndex);
  } else {
    tapeWatch->tape = empty_astr; tapeWatch->charparams = empty_astr; tapeWatch->valparams = empty_inta;
    predefInputsListWidget->setCurrentRow(0);
  }
}

void InputSelector::done( int result ) {
  if( result == QDialog::Accepted ) {
    bool done = false; QListWidgetItem *item = predefInputsListWidget->currentItem();
    if( item ) {
      int idx = item->data(Qt::UserRole).toInt();
      if( idx >= 0 ) {
	RuntimeParams *params = &(*predefInputsList)[idx];
	tapeWatch->tape = params->tape;
	tapeWatch->charparams = params->charparams;
	tapeWatch->valparams = params->valparams;
	//currentlyUsedIndex = idx;
	done = true;
    } }
    if(!done) {
      tapeWatch->tape = empty_astr; tapeWatch->charparams = empty_astr; tapeWatch->valparams = empty_inta;
    }
    tapeWatch->update();
  }
  QDialog::done(result);
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


