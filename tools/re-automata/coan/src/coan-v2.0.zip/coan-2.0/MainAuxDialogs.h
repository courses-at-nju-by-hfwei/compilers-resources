#ifndef MAIN_AUX_DIALOGS_H
#define MAIN_AUX_DIALOGS_H
#include <QtWidgets/QDialog>
#include <QtWidgets/QRadioButton>
class QPlainTextEdit; class QTextBrowser;

/*
class ViewCFSL : public QDialog {
public:
  ViewCFSL();
protected:
  QPlainTextEdit *plainTextEdit;
  void keyPressEvent(QKeyEvent *event);
  QSize sizeHint() const;
};
*/

class ViewQuickHelp : public QDialog {
public:
  ViewQuickHelp();
protected:
  QTextBrowser *browser;
  void keyPressEvent(QKeyEvent *event);
  QSize sizeHint() const;
};

class StrValRadioButton : public QRadioButton {
public:
  int type, flags;
  StrValRadioButton( QString displayText, int type, int flags, QWidget *parent ) : QRadioButton(displayText,parent), type(type), flags(flags) {};
};

class SelectNewAtmt : public QDialog {
  Q_OBJECT
public:
  int type, flags;
  SelectNewAtmt();
protected slots:
  void radioSelected();
};


#endif
