#ifndef SYMTAB_H
#define SYMTAB_H
#ifdef QT_CORE_LIB
 #include <QtCore/QString>
#endif
#include <string.h>
#include "auxtypes.h"

using namespace aux;

extern const echar echars_epsilon[2], echars_neq_char[2], echars_eq_char[2], echars_empty_set_char[2]; 
extern const estr_const estr_epsilon, estr_neq_char, estr_eq_char, estr_empty_set_char;

__pure_const bool input_char_allowed( wchar c ); // setminus_4_editing_char is allowed but needs to be checked for separately, chars for and within subscripts may still return false (still almost anything is allowed within a subscript)!

extern void*(*alloc)(size_t);		// defaults to malloc
extern void(*dealloc)(void*,size_t);   // defaults to demalloc = free

class SymbolTable;
extern SymbolTable emptySymbolTable;

enum SymbolMode { mode_greekvars, mode_greekvars_convert_slash, mode_TM, mode_MS, mode_anySubscript, mode_grVarList, mode_latVarList };
template<class xchar> wchar DecodeBackSlash( register xchar **src_ptr, register int &len, int &run_ahead, int escape_L_and_R );
int unescape_chars( astrbuf *buf ); // returns number of invalid_escapes (output is '?')
#ifdef QT_CORE_LIB
QString unescape_html( QString text );
#endif

class SymbolTable {
public:
  enum VarSetMode { set_always, set_if_undefined, set_if_defined };
  struct Entry { const echar *index; unsigned int content; achar varlen, varbstb; echar first_index_char; };  // not to be used directly except by symtab.cpp
  typedef void(*ReadVarProc)( SymbolTable *home, estr_const var, int value, void *data );
  typedef void(*ProcessVarProc)( SymbolTable *home, estr_const var, int *value, void *data );
  static const int initial_greekVar_value = '#';
  static const int initial_latVar_value = 0;
  static inline int initialValue( echar firstChar ) { return firstChar <= 0xFF ? initial_latVar_value : initial_greekVar_value; }
  static const achar unknown_achar = '?';
  static const echar unknown_echar = 0x2E2E;  // reversed question mark
  static const long long var_is_undefined = (long long)1<<32;
protected:
//public:
  struct Entry *entry; int entry_num, table_size; mutable int usage_count;
protected:
  static SymbolTable* allocate_new( int num_entries, int table_size );
  inline static bool maySet( echar first_letter ) { return ( first_letter >= first_greek_letter && first_letter <= last_greek_letter ) || ( first_letter >= 'A' && first_letter <= 'z' );  };
  inline static achar varbstb2num( echar first_character ) { return first_character - ( first_character > 0xFF ? ( first_greek_letter - 1 ) : ( 'A' - 1 - greek_letter_num ) ); }
  inline int hash( achar var_num, const echar *variable, int *var_len, int *jump_len ) const;
private:
  void CopyToNewTable( SymbolTable *new_table, Entry new_entry ) const;
  SymbolTable* set_and_copy_by_index( int index, int is_a_new_var, Entry new_e ) const;
public:
  SymbolTable( Entry *entries, int num_entries, int size ) : entry(entries), entry_num(num_entries), table_size(size), usage_count(1) {};
  long long lookUp( const echar *variable ) const;     // return value:  var_value = (int)res, var_length = res >> 33;  bad lookup ~ bit 32 of res is set
  // may return a freshly allocated SymbolTable; reference to the old SymbolTable is then invalid unless anotherInstance() had been used on the previous table
  __warn_unused_result SymbolTable* set( const echar *variable, int value, int *pos_inc = NULL, enum VarSetMode mode = set_always, int *true_len = NULL );
  int lookUpEntry( const echar *variable, int **content_ptr, int *true_len = NULL );     // return value:  var_length(length2skip);  bad lookup ~ content_ptr == NULL
  void removeEntry( int *content_ptr );
  void forall( ReadVarProc proc, void *data = NULL );
  void forallEntry( ProcessVarProc proc, void *data = NULL );
  SymbolTable* print( IOStreamRef out, const char *sep = ", " );
  int compare( SymbolTable* another ) const;
  inline static bool isEmpty( const SymbolTable *s ) { return !s || s->entry_num <= 0; }
  inline bool isEmpty() const { return entry_num <= 0; }

  inline static bool isGreekVariable( echar first_character ) { return first_character >= first_greek_letter && first_character <= last_greek_letter && first_character != omikron_letter && first_character != epsilon_letter; }
  static int varLength( const echar *variable, int *true_len = NULL );   // returns solely var_length but does not perform a lookup
  static int normalize( estrbuf *s, enum SymbolMode mode = mode_greekvars );   // returns position of first non-expected character or -1; still always normalizes the whole string
  // normalize with mode_grVarList, mode_latVarList: eliminates all non-var characters, duplicate vars and returns the number of vars left over
  static int countVariables( astrbuf *buf_for_translation, estr_const s );
  static int translate( astrbuf *dest, estr_const src, SymbolTable *local, SymbolTable *global );    // result = -1: untranslatable utf-8 character, result = -2: undefined variable

  inline SymbolTable* anotherInstance() { usage_count++; return this; }
  inline int getUsageCount() const { return usage_count; }
  static __warn_unused_result SymbolTable* reserveEmpty( int prospective_entry_num );
  __warn_unused_result SymbolTable* set_and_copy( const echar *variable, int value ) const;
  __warn_unused_result SymbolTable* copy_acquireSymsFrom( const SymbolTable *overrideSyms );  // currently just invokes set_and_copy for every variable in overrideSyms
  __warn_unused_result SymbolTable* copy() const;
  static void freeMem( SymbolTable *symtab );
  static void free( SymbolTable **symtab );
  ~SymbolTable() { if( !this || this == &emptySymbolTable ) return; cerr << "error: tried to auto-deallocate SymbolTable object; use SymbolTable::free[Mem] instead." << aux::endl; abort(); };
};

#endif
