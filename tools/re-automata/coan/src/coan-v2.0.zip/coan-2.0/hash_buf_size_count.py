#!/usr/bin/python
# -*- coding: utf8

v = 255; n=1;
while v*3+255 <= 1<<16 - 1:
  v = v*3+255; n+=1;

print "16 bit capacity: ", n

v = 255; n=1;
while v*3+255 <= 1<<32 - 1:
  v = v*3+255; n+=1;

print "32 bit capacity: ", n

v = 255; n=1;
while v*3+255 <= 1<<64 - 1:
  v = v*3+255; n+=1;

print "64 bit capacity: ", n


