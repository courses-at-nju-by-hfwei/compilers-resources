#ifdef QT_CORE_LIB
  #include <QtGui/QPaintDevice>
#endif
#include "auxtypes.h"
#include "automatdef.h"
#include "FiniteAutomata.h"
#include "TuringMachine.h"
#include "LoadSaveAtmt.h"

//AtmtTreeNode *atmtTree = NULL;
//AtmtIndex atmtIndex; // (astr_compare_less());
//std::vector<RuntimeParams> globalRuntimeParams;

Automaton* nullAtmt = new NullAtmt();
Edge* nullEdge = new NullEdge();
Node* nullNode = new NullNode();

Automaton* CreateAutomaton( struct AtmtTreeBase *base, estr_const atmtType ) {
  if( atmtType == (achar*)"FA" ) return new FA();
  if( atmtType == (achar*)"PDA" ) return new PDA();
  if( atmtType == (achar*)"TM" ) return new TM();
  if( atmtType == (achar*)"MS" ) { MS *newMS = new MS(); newMS->atmtIndex = &base->atmtIndex; return newMS; }
  return nullAtmt;
}


Automaton* CreateAutomaton( struct AtmtTreeBase *base, int atmtType ) {
  switch(atmtType) {
    case AtmtType::Type_FA: return new FA();
    case AtmtType::Type_PDA: return new PDA();
    case AtmtType::Type_TM: return new TM();
    case AtmtType::Type_MS: { MS *newMS = new MS(); newMS->atmtIndex = &base->atmtIndex; return newMS; }
    default: return NULL;
  }
}

void insertTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *pnode, AtmtTreeNode *nnode ) {
  AtmtTreeNode *firstnode = NULL, *lastnode; nnode->parent = pnode; 
  if( pnode == NULL ) { if(!base->atmtTree) base->atmtTree = nnode; else firstnode = base->atmtTree; }
  else { if(!pnode->child) pnode->child = nnode; else firstnode = pnode->child; }
  if( firstnode ) {
    lastnode = firstnode->prev;
    lastnode->next = nnode; firstnode->prev = nnode;
    nnode->prev = lastnode; nnode->next = firstnode;
  } else {
    nnode->prev = nnode; nnode->next = nnode;
  }
}

void filePError( IOStream file, const char *message ) {
 cerr  << "line #" << file.getLineNum() << ", col "<< file.getCol() <<", token " << file.getTokenNum() << ": "; 
 file.perror(message); file.clear();
}

bool isPredefinedIdentifier( estr_const ident ) {
  if( ident == (achar*)"Copy" ) return true;
  else if( ident == (achar*)"Erase" ) return true;
  else if( ident == (achar*)"SL" ) return true;
  else if( ident == (achar*)"SR" ) return true;
  return false;
}

AtmtTreeNode* insertIndexNode( struct AtmtTreeBase *base, AtmtTreeNode *node, estr_const atmtName ) {
  AtmtIndex::iterator insertPos; bool duplicate = false, secondIsPredef = false;
  AtmtIndex::iterator preferredPos, prevPos, nextPos; preferredPos = base->atmtIndex.end();
  estrbuf atmtNameAlternative; atmtNameAlternative.referenceFrom( atmtName );
  do { 
    if(preferredPos == base->atmtIndex.end() ) insertPos = base->atmtIndex.insert( std::make_pair( atmtNameAlternative, node ) ); 
    else insertPos = base->atmtIndex.insert( preferredPos, std::make_pair( atmtNameAlternative, node ) ); 
    duplicate = false; secondIsPredef = false;
    prevPos = insertPos; nextPos = insertPos; if(insertPos!=base->atmtIndex.begin()) prevPos--; else prevPos = base->atmtIndex.end(); nextPos++;
    if( isPredefinedIdentifier(atmtNameAlternative) ) { duplicate = true; preferredPos = nextPos; secondIsPredef = true; }
    else if( prevPos != base->atmtIndex.end() && prevPos->first == atmtNameAlternative ) { duplicate = true; preferredPos = prevPos; }
    else if( nextPos != base->atmtIndex.end() && nextPos->first == atmtNameAlternative ) { duplicate = true; preferredPos = nextPos; }
    if( !duplicate ) break;
    // next if: both are directories; new name is principially legal but look if the other node is not the same as the new one; if so delete the new one
    if( !node->atmt && !preferredPos->second->atmt && !secondIsPredef ) { 
      bool isGoodDuplicate =  preferredPos->second->parent == node->parent;
      if( !isGoodDuplicate && prevPos != base->atmtIndex.end() ) 
	while(true) { 
	  if( prevPos->first != atmtNameAlternative ) break; 
	  if( prevPos->second->parent == node->parent ) { isGoodDuplicate = true; preferredPos = prevPos; break; }
	  if( prevPos == base->atmtIndex.begin() ) break;
	  prevPos--;
	};
      if( !isGoodDuplicate && nextPos != base->atmtIndex.end() ) 
	do { 
	  if( nextPos->first != atmtNameAlternative ) break; 
	  if( nextPos->second->parent == node->parent ) { isGoodDuplicate = true; preferredPos = nextPos; break; }
	  nextPos++;
	} while ( nextPos != base->atmtIndex.end() );
      if( isGoodDuplicate ) { base->atmtIndex.erase(insertPos); unlinkAtmtTreeNode(base,node); delete node; node = preferredPos->second; insertPos = preferredPos; }
      break;
    }
    base->atmtIndex.erase(insertPos);
    cerr << "an automaton/directory with name '" << atmtNameAlternative << "' does already exist; renaming to ";
    atmtNameAlternative.append("I"); 
    cerr << atmtNameAlternative << endl;
  } while(true);
  node->ident = insertPos->first;
  return node;
}

bool LoadAllAtmts( struct AtmtTreeBase *base, const char *filename, AtmtTreeNode *parentNode ) {
  astrbuf inputline, next_inputline; int factor_dd = 2, factor_ds = 3;
  IOStream file; base->globalRuntimeParams.clear(); bool newFileType = true;
  if( file.open( filename, ios_base::in ) ) {
    file.setCharset(Charset::utf8);
    file >> &inputline >> endl >> &next_inputline >> endl;
    int pos1 = inputline.find_first_of(' '), pos2 = inputline.find_last_of(' ');
    bool isEmpty = next_inputline.find_first_not_of((achar*)" \t") >= next_inputline.length;
    // cout << "&&" << inputline.sub(0,pos1) << "&&" << inputline.sub(pos2+1) << "&&" << endl;
    if( inputline.sub(0,pos1) != (achar*)"CoAn" || !isEmpty ) { file.close(); cerr << "unsupported file type" << endl; return false; }
    if( inputline.sub( pos2+1, 3 ) == (achar*)"v1." ) {
      file.setCharset(Charset::asciiext); newFileType = false; int len;
      do { 
	file >> &inputline >> endl; len = inputline.length;
	if( len ) { 
	  base->globalRuntimeParams.push_back( RuntimeParams{ } ); // .tape = inputline, .charparams = empty_astr, .valparams = empty_inta } );  
	  base->globalRuntimeParams.back().tape.moveFrom(&inputline);
	  base->globalRuntimeParams.back().charparams = empty_astr;
	  base->globalRuntimeParams.back().valparams = empty_inta;
	}
      } while(len);
      //for( std::list<astrbuf>::const_iterator li = base->globalRuntimeParams.begin(); li!=base->globalRuntimeParams.end(); li++ ) cout << li->tape << endl;
    }
    estrbuf hdr; strsize idx, nxidx, bidx, typeidx; estr_const atmtName, atmtType; int skipline = 0;
    Automaton *a; int nodes;
    do {
      //
      //  read header (skipping blank lines first)
      //
      file.clear(); do { file >> &hdr >> endl; if(file.anyerr()) break; bidx = hdr.find_last_not_of((achar*)" \t"); } while( bidx < 0 && !file.eof() );
      if( ( !hdr.length && file.eof() ) || file.anyerr() ) break;
      // hdr.moveFrom( estrb("[Kellerautomten.Hug.Has.Hoppel.InfixPDA:PDA]") );bidx = hdr.find_last_not_of((achar*)" \t");
      //cout << hdr << endl;
      if( hdr.length < 2 || hdr.chars[0] != '[' || hdr.chars[bidx] != ']' ) { 
	if(!skipline) cerr << "line #" << file.getLineNum() << ": file format error; expected [atmtname:type] line; skipping line." << endl; 
	else if(skipline == 1 ) cerr << "skipping line #" << file.getLineNum(); else cerr << ", " << file.getLineNum();
	skipline++;
	continue; 
      }; 
      if( skipline >= 2 ) cerr << endl;
      skipline = 0;
      typeidx = hdr.find_last_of((achar*)":.",bidx);  
      if( typeidx > 0 && hdr.chars[typeidx] == ':' ) {
	typeidx++;
	atmtType = hdr.sub( typeidx, bidx-typeidx ); 
	typeidx--; bidx = hdr.find_last_of('.',typeidx-1); if( bidx < 0 ) bidx = 0;
	atmtName = hdr.sub( bidx+1, typeidx-bidx-1 );
      } else {
	if( typeidx < 0 ) typeidx = 0; typeidx++;
	atmtName = hdr.sub( typeidx, bidx-typeidx );
	atmtType = empty_estr; 
	bidx = typeidx;
      };
      estr_const directoryName; AtmtTreeNode *pnode = parentNode, *nnode; std::pair<AtmtIndex::iterator,AtmtIndex::iterator> range;
      idx = 1; while( idx < bidx ) { 
	nxidx = hdr.find_first_of('.',idx); 
	directoryName = hdr.sub(idx,nxidx-idx);
	range = base->atmtIndex.equal_range(directoryName); nnode = NULL;
	for( AtmtIndex::iterator ii = range.first; ii != range.second; ii++ )
	  if( ii->second->parent == pnode ) nnode = ii->second;
	if(!nnode) {
	  nnode = new AtmtTreeNode; nnode->child = NULL; nnode->atmt = NULL; 
	  insertTreeNode( base, pnode, nnode );
	  //AtmtIndex::iterator insertPos = base->atmtIndex.insert( std::make_pair(directoryName,nnode) );
	  //nnode->ident = insertPos->first;
	  nnode = insertIndexNode( base, nnode, directoryName );
	} 
	//cout << hdr.sub(idx,nxidx-idx) << endl; 
	idx = nxidx + 1; pnode = nnode;
      }
      //cout << atmtType << "," << atmtName << endl;
      AtmtTreeNode *node = new AtmtTreeNode; node->child = NULL;
      insertTreeNode( base, pnode, node );
      if(newFileType) {
	estrbuf line; file >> &line >> endl;
	while( line != (achar*)"EOQ;" ) {
#ifdef QT_CORE_LIB
	  if(!node->description.isEmpty()) node->description.append("\n");
	  node->description.append(toQString(line));
#endif
	  if(!file) break;
	  file >> &line >> endl;
      } }
      if( atmtType.isEmpty() ) {
	node->atmt = NULL;
	//AtmtIndex::iterator insertPos = base->atmtIndex.insert( std::make_pair( atmtName, node ) );
	//node->ident = insertPos->first;
	node = insertIndexNode( base, node, atmtName );
	continue;
      }
      a = CreateAutomaton(base,atmtType);
      node->atmt = a;
      assert( node == insertIndexNode( base, node, atmtName ) );
      if(newFileType) {
	//cerr << "((NewFileType))\n";
	// read automaton flags
	estrbuf flags; file >> &flags >> endl; int unknown_count = 0;
	for( int i=0; i < flags.length; i++ ) switch (flags.chars[i]) {
	  case 'd': a->flags |= Automaton::isDeterministic; break; 
	  case 'v': a->charsetCheckFlags |= ExtCharSet::allow_var_ranges; break;
	  case '-': break;
	  default: if( ++unknown_count <= 3 ) cerr << "line #" << file.getLineNum()  << ": unknown automaton flag '" << EChar(flags.chars[i]) << "'." << endl; break;
        }; flags = invalid_estr;
	estrbuf formalParams; estrbuf heading; 
	do {
	  file >> TermChars(":\n") >> &heading >> skip_sep; 
	  if( !file && heading.length ) { cerr << "line #" << file.getLineNum()  << ": error reading character or value formal params (introduce with cf: or vf:)" << endl; } 
	  if( !file ) break;
	  file >> TermChars("\n") >> &formalParams >> endl; 
	  if( heading == (achar*)"cf" && !a->charFormalParamCount ) a->setFormalCharParams(&formalParams);
	  else if( heading == (achar*)"vf" && !a->valFormalParamCount ) a->setFormalValParams(&formalParams);
	  else { cerr << "line #" << file.getLineNum()  << ": error reading character or value formal params (introduce with cf: or vf:)" << endl; }  
	} while(file); file.clear_failbit();
	file >> endl; if(!file) { cerr << "line #" << file.getLineNum()  << ": error reading newline after char and value formal params (cf:,vf:)" << endl; file.clear_swerr(); };
	do {
	  file >> TermChars(":\n") >> &heading >> skip_sep; 
	  if( ( !file && heading.length ) || ( file && heading.length != 1 ) ) { cerr << !file << "line #" << file.getLineNum()  << ": error reading tape/param configuration (t:/c:/v:) - unknown long heading '" <<  heading << "'" << endl; } 
	  if( !file ) break;
	  file >> TermChars("\n"); 
	  if( heading.length != 1 ) { file >> endl; file.clear_spuriousbit(); continue; }
	  switch( heading.chars[0] ) {
	    case 't':
	       node->default_inputs.push_back( RuntimeParams{ } ); // .tape = inputline, .charparams = empty_astr, .valparams = empty_inta } );  
	       file >> &(node->default_inputs.back().tape) >> endl;
	      break;
	    case 'c':
	       file >> &(node->default_inputs.back().charparams) >> endl;
	      break;
	    case 'v': {
	       int value; intabuf *valparams = &(node->default_inputs.back().valparams); *valparams = empty_inta;
	       do { file >> &value; if(file) { valparams->append(inta_const(&value,1)); } file >> skip_space; } while(file); file.clear_failbit(); file >> endl;
	      break; }; 
	    default:
               file >> endl; file.clear_spuriousbit(); 
	       cerr << "line #" << file.getLineNum()  << ": error reading tape/param configuration (t:/c:/v:) - unknown heading '" << heading << "'" << endl;
	      break;
	  }
	  //cerr << "read charparams("<< file.getLineNum() << "):" << (node->default_inputs.back().charparams) << endl;
	  //cerr << "read valparams("<< file.getLineNum() << ")" << endl; file.perror("fileerr"); file.clear();
	} while(file); file.clear_failbit();
	file >> endl >> TermChars("\n"); if(!file) { cerr << "line #" << file.getLineNum()  << ": error reading newline after tape/param configurations (t:/c:/v:)" << endl; file.clear_swerr(); };
	//if(!file) break;
	// read until empty line - skip charset
        do { file >> &inputline >> endl; if(!file) break; bidx = inputline.find_last_not_of((achar*)" \t"); } while( bidx >= 0 );
      } else {
	if(!atmtType.isEmpty()) node->default_inputs.assign( base->globalRuntimeParams.begin(), base->globalRuntimeParams.end() );
        //  read character set line - first non-null line after header
        do { file >> &inputline >> endl; if(!file) break; bidx = inputline.find_last_not_of((achar*)" \t"); } while( bidx < 0 );
        if( !file || bidx < 0 ) break; //cout << inputline << endl; // the character set line
      }
      //
      //  read in nodes
      //
      file >> &nodes >> endl; if(file.anyerr()) { filePError(file,"line with number of nodes expected"); continue; }
      { Node** node = (Node**)alloca(nodes*sizeof(Node*)); int i, nodeNum, x, y; astrbuf flags; estrbuf label; int tokNum = -1;
	memset(node,0,nodes*sizeof(Node*));
	for( i=0; i < nodes; i++ ) {
	  file >> TermChars(" \n") >> &nodeNum >> skip_space >> &x >> skip_space >> &y >> skip_space >> &flags >> skip_space >> TermChars("\n") >> &label >> endl;
	  if(!newFileType) { x += x*factor_dd/factor_ds; y += y*factor_dd/factor_ds; }
	  if(file.anyerr()) { if( !( tokNum = file.getTokenNum() ) || file.bad() ) break; else { filePError(file,"node read err"); continue; } }
	  nodeNum--; if( nodeNum < 0 || nodes <= nodeNum ) { cerr << "line #" << file.getLineNum() << ": invalid node number " << nodeNum+1 << endl; }  else 
	    if( node[nodeNum] ) { cerr  << "line #" << file.getLineNum() << ": node number " << nodeNum+1 << " already defined; skipping def." << endl; } else {
	      //aux_assert( nodeNum == i );
	      node[nodeNum] = a->createNode()->setCoords(QPointF(x,y))->assignContent(a,&label);
#ifdef QT_CORE_LIB
	      node[nodeNum]->nodenum = nodeNum+1;
#endif
	      if( flags.find_first_of('s') < flags.length ) {
		if( a->startNode == NULL ) a->startNode = node[nodeNum]; else { 
		  cerr << "line #" << file.getLineNum()  << ": two startnodes: #" << nodeNum+1 << " '" << node[nodeNum]->getContent() << "' and '" << a->startNode->getContent() << "'" << endl; 
	      } }
	      if( flags.find_first_of('e') < flags.length ) 
		if(!node[nodeNum]->setFinalNode(true)) cerr << "line #" << file.getLineNum() << ": error setting node #" << nodeNum+1 << " '" << node[nodeNum]->getContent() << "' as final node." << endl;
	      int errpos = flags.find_first_not_of((achar*)"se-");
	      if( errpos < flags.length ) cerr << "line #" << file.getLineNum() << ": unknown node flag '" << AChar(flags.chars[errpos]) << "'" << endl;
	}   }
	//for( i=0; i < nodes; i++ ) cout << (u_iword)node[i] << ":" << node[i]->getContent() << endl;
	if( !tokNum && i < nodes ) { cerr << "line #" << file.getLineNum() << ": expected " << nodes << " definitions of nodes" << endl; }
	else if( tokNum ) do {  // read until and including an empty line
	  file >> &inputline >> endl; if(!file) break; 
	  idx = inputline.find_first_not_of((achar*)" \t"); 
	  if( idx  < inputline.length ) { cerr << "ignoring line #" << file.getLineNum() << "; all nodes have been read and a newline should follow." << endl; }
	} while( idx < inputline.length ); file.clear();
	//
	//  read in edges
	//
	Edge *e; int from, to, value; std::vector<int> track;
	do {
	  file >> &x >> skip_space >> &y >> skip_space >> &label >> endl; if( x == -1 && y == -1 ) file.clear_failbit(); if(!file.getTokenNum()) break; if(file.anyerr()) filePError(file,"edge label line");
	  if( !newFileType && x >= 0 && y >= 0 ) { x += x*factor_dd/factor_ds; y += y*factor_dd/factor_ds; }
	  file >> &from >> skip_space >> &to >> endl; if(file.anyerr()) filePError(file,"edge from/to line");
	  if( x == -1 && y == -1 && from == 0 && to == 0 ) break;
	  track.clear(); do { file >> &value; if(file) { if(!newFileType) value += value*factor_dd/factor_ds; track.push_back(value); } file >> skip_space; } while(file); file.clear_failbit(); file >> endl;
	  // cout << trace.size() << endl;
	  if(file.anyerr()) { filePError(file,"edge track line"); break; }
	  if( from < 1 || nodes < from ) { cerr << "edge in line #" << file.getLineNum() << " has an invalid predecesssor/from node number." << endl; continue; }
	  if( to < 1 || nodes < to ) { cerr << "edge in line #" << file.getLineNum() << " has an invalid successor/to node number." << endl; continue; }
	  from--; to--;
	  if( node[from] && node[to] ) { int errpos;
            e = a->createEdge(node[from],node[to])->setCoords(QPointF(x,y)); 
	    if(newFileType) errpos = e->setTrack(&track); else errpos = e->setLinearTrack(&track);
	    if( errpos >= 0 ) cerr << "error with edge in line #" << file.getLineNum()  << ", tracetoken " << errpos << endl;
	    errpos = e->setContent(a,&label);
	    if( errpos >= 0 ) {
	      estrbuf content = e->getContent();
	      cerr << "error with edge in line #" << file.getLineNum()  << ": " << content.sub(0,errpos) << "|" << content.sub(errpos) << endl; 
	    }
	  } else cerr << "edge in line #" << file.getLineNum()-2 << " has undefined from/to node";
	  do { file >> &inputline >> endl; if(!file) break; idx = inputline.find_first_not_of((achar*)" \t"); 
	    if( idx  < inputline.length ) { cerr << "ignoring line #" << file.getLineNum() << "; all edge data has been read and a newline should follow." << endl; }
	  } while( idx < inputline.length );
	} while(!file.eof());
      }
      if( a != nullAtmt ) {
	//delete a;
      }
      nullAtmt->startNode = NULL;
    } while( !file.eof() && !file.bad() );
    if(file.bad()) cerr << "I/O error reading from file at line #" << file.getLineNum() << endl;
   //    cout << "&&" << inputline.sub(0,pos1) << "&&" << endl;
    file.close();
    return true;
  } else return false;
}

#ifdef QT_CORE_LIB

void PrintAtmtRefName( IOStreamRef file, struct AtmtTreeNode *node ) {
  bool first = true;
  if(node->parent) { PrintAtmtRefName(file,node->parent); first = false; }
  if(!first) file << ".";
  file << node->ident;
}
 

bool SaveAtmt( IOStreamRef file, struct AtmtTreeNode *node ) {
  Automaton *atmt = node->atmt;
  if( !atmt && node->description.isEmpty() ) return true; int nodenum = 0; bool flagWritten;
  file << "["; PrintAtmtRefName(file,node); if(atmt) file << ":" << atmt->typeStr();  file << "]" << endl;
  if(!node->description.isEmpty()) foreach(QString line, node->description.split("\n") ) if(line!="EOQ;") file << line << endl; else file << " EOQ;" << endl;
  file << "EOQ;" << endl;
  if(!atmt) { file << endl; return true; }
  flagWritten = false; if( atmt->flags && Automaton::isDeterministic ) { file << AChar('d'); flagWritten = true; }
  if( atmt->charsetCheckFlags && ExtCharSet::allow_var_ranges ) { file << AChar('v'); flagWritten = true; }
  if(!flagWritten) file << AChar('-'); file << endl;
  file << "cf:" << atmt->charFormalParams << endl;
  file << "vf:" << atmt->valFormalParams << endl << endl;
  for( RuntimeParamVector::const_iterator ci = node->default_inputs.begin(); ci != node->default_inputs.end(); ci++ ) {
    file << "t:" << ci->tape << endl;
    if(ci->charparams.length) file << "c:" << ci->charparams << endl;
    if(ci->valparams.length) {
      file << "v:"; { for( int j=0; j < ci->valparams.length; j++ ) file << (j>0?" ":"") << ci->valparams.chars[j]; }; file << endl;
  } }
  file << endl << endl; // write out the alphabet of the automaton succeeded by a blank line
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) (*in)->nodenum = ++nodenum;
  file << nodenum << endl;
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) { Node *n = *in;
    file << n->nodenum << " " << (int)n->pos.x() << " " << (int)n->pos.y() << " ";
    flagWritten = false;
    if( n == atmt->startNode ) { file << AChar('s'); flagWritten = true; }
    if( n->isFinalNode() ) { file << AChar('e'); flagWritten = true; }
    if(!flagWritten) file << AChar('-');
    file << " " << n->getContent() << endl;
  }
  file << endl;
  bool escapeSlash = atmt->edgeEscapeSlash(); if(escapeSlash) file << IOChangeVal( IOAttr::EscapeChars, estr_slash ); 
  for(std::list<Edge*>::const_iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ ) { Edge *e = *ie;
    file << (int)e->pos.x() << " " << (int)e->pos.y() << " " << e->getContent() << endl;
    file << e->from->nodenum << " " << e->to->nodenum << endl;
    int i; bool first; for( i=0,first=true; i < (int)e->track.size(); i++, first=false )
      file << (first?"":" ") << (int)e->track[i].x() << " " << (int)e->track[i].y();
    file << endl << endl;
  }
  file << endl;
  file << IOChangeVal( IOAttr::EscapeChars, empty_estr );
  return true;
}

bool doSaveAllAtmts( IOStreamRef file, struct AtmtTreeNode *node ) {
  AtmtTreeNode *first_node = node; bool result; if(!node) return true;
  do {
    result = SaveAtmt(file,node);
    if( node->child && result ) result = doSaveAllAtmts(file,node->child);
    node = node->next;
  } while( node != first_node && result );
  return result;
}

bool SaveAllAtmts( struct AtmtTreeBase *base, const char *filename ) {
  IOStream file; bool result;
  if(! file.open( filename, ios_base::out|ios_base::trunc ) ) { cerr << "error opening file " << filename << " for writing." << endl; return false; }
  file << "CoAn v2.0" << endl << endl;
  result = doSaveAllAtmts( file, base->atmtTree );
  file.close();
  return result;
}

#endif

	  //cout << "inputsvec: " << IOChangeVal(IOAttr::NumberBaseNextOne,16) << default_inputs.back().bufParams << endl;
	  //cout << "inputline: " << IOChangeVal(IOAttr::NumberBaseNextOne,16) << inputline.bufParams << endl;

void doPrintAtmtTree(  int indent, AtmtTreeNode *node ) {
  AtmtTreeNode *first = node; if(!first) return;
  AtmtTreeNode *parent = first->parent; parent = parent;
  do {
    cout << utf8str_const("| ") * (indent-1);
    if( indent ) cout << ( node->next != first ? "+-" : "\\-" );
    //cout << (u_iword)node->ident.chars << "," << node->ident.length << endl;
    cout << node->ident << endl;
    //if(node->child) aux_assert( node->child->parent == node );
    if(node->child) {
      assert( node->child->parent == node );
      doPrintAtmtTree( indent+1, node->child );
    }
    assert( node->next->prev == node ); assert( node->parent == parent );
    node = node->next;
  } while( node != first );
}

void PrintAtmtTree( struct AtmtTreeBase *base ) {
  if(base->atmtTree) doPrintAtmtTree(0,base->atmtTree);
  else cout << "automaton tree is empty";
  cout << endl;
}

void setAtmtIndexName( struct AtmtTreeBase *base, AtmtTreeNode *node, estr_const new_ident ) {
  node->ident = base->atmtIndex.insert(std::make_pair(new_ident,node))->first;
}

AtmtTreeNode* unlinkAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *node ) {
  if( node->next != node ) {
    node->prev->next = node->next;
    node->next->prev = node->prev;
    if( node->parent && node->parent->child == node ) node->parent->child = node->next;
    else if( !node->parent && base->atmtTree == node ) base->atmtTree = node->next;
  } else {
    if( node->parent && node->parent->child == node ) node->parent->child = NULL;
    else if( !node->parent && base->atmtTree == node ) base->atmtTree = NULL;
  }
  return node;
} 

void insertAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *parent, AtmtTreeNode *previous, AtmtTreeNode *node, bool insertFirst ) {
  if( previous ) { // insert after previous
    node->next = previous->next;
    node->prev = previous;
    node->parent = previous->parent;
    previous->next->prev = node;
    previous->next = node;
  } else if( parent ) {
    node->parent = parent;
    if( parent->child == NULL ) { // insert as only node of parent
      node->next = node; node->prev = node;
      parent->child = node;
    } else {  // insert as first/last node of parent
      node->next = parent->child;
      node->prev = parent->child->prev;
      parent->child->prev->next = node;
      parent->child->prev = node;
      if(insertFirst) parent->child = node;
    }
  } else {
    node->parent = NULL;
    if( base->atmtTree == NULL ) {  // insert as only node of tree
      node->next = node; node->prev = node;
      base->atmtTree = node;
    } else {  // insert as first/last node of tree
      node->next = base->atmtTree;
      node->prev = base->atmtTree->prev;
      base->atmtTree->prev->next = node;
      base->atmtTree->prev = node;
      if(insertFirst) base->atmtTree = node;
    }
  }
}

void unlinkIndexEntry( struct AtmtTreeBase *base, AtmtTreeNode *node ) {
  if(node->atmt) base->atmtIndex.erase(node->ident);  // no duplicate entries for automata
  else {
    std::pair<AtmtIndex::iterator,AtmtIndex::iterator> range = base->atmtIndex.equal_range(node->ident);
    for( AtmtIndex::iterator ir = range.first; ir != range.second; ir++ )
      if( ir->second == node ) { base->atmtIndex.erase(ir); break; }
  }
}

void deleteAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *node ) {
  unlinkIndexEntry( base, node );
  delete(node->atmt); node->default_inputs.~RuntimeParamVector();
  unlinkAtmtTreeNode( base, node );
  free(node);
}

void doDeleteAtmtTree( AtmtTreeNode *node ) {
  AtmtTreeNode *first_node = node, *next_node; if(!node) return;
  do {
    if(node->child) doDeleteAtmtTree(node->child);
    delete(node->atmt); node->default_inputs.~RuntimeParamVector();
    next_node = node->next; free(node);
    node = next_node;
  } while( node != first_node );
}

void deleteAtmtTree( struct AtmtTreeBase *base ) {
  doDeleteAtmtTree(base->atmtTree); base->atmtTree = NULL;
  base->atmtIndex.clear();
  base->globalRuntimeParams.clear();
}

#ifdef QT_CORE_LIB

void updateAllAutomataGeometry( struct AtmtTreeNode *node, QPaintDevice *device ) {
  AtmtTreeNode *first = node; if(!node) return;
  do {
    //cerr << node->ident << endl;
    if(node->atmt) node->atmt->updateGeometry(device);
    if(node->child) updateAllAutomataGeometry( node->child, device );
    node = node->next;
  } while( node != first );
}

#endif
