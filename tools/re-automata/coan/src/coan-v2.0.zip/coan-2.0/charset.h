#ifndef CHARSET_H
#define CHARSET_H
#include <assert.h>
#include "auxtypes.h"
#include "symtab.h"

#define words (256/((int)sizeof(u_iword)*8))
#define bits_per_word ((int)sizeof(u_iword)*8)
#define word_idx_shift ( sizeof(u_iword)==8 ? 6 : sizeof(u_iword)==4 ? 5 : 5000 )       // 5000 shall produce an error: "right shift count >= width of type"
#define sub_word_mask ((1<<word_idx_shift)-1)


// evtl.: entsprechend alignen & xmm-Register verwenden

typedef void(*ElmPrnFunc)( aux::IOStreamRef, unsigned char );

void print_numeric( aux::IOStreamRef out, unsigned char val );
void print_as_achar( aux::IOStreamRef out, unsigned char val );

extern aux::echar ColonChars[3];

class StaticCharSet {
  u_iword word[words];
public:
  inline StaticCharSet() {};
  inline StaticCharSet(bool filled) { register u_iword val = 0; if(filled) val=~val; for(register int i=0; i<words; i++) word[i] = val; };
  inline void clear() { for(register int i=0; i<words; i++) word[i] = 0; };
  inline void fill() { register u_iword val = ~0; for(register int i=0; i<words; i++) word[i] = val; };

  inline bool isEmpty() const { for(register int i=0; i<words; i++) if(word[i]) return false; return true; };
  inline bool isDisjointWith( const StaticCharSet& other ) const { for(register int i=0; i<words; i++) if( word[i] & other.word[i] ) return false; return true; };
  inline bool isSubSet( const StaticCharSet& other ) const { for(register int i=0; i<words; i++) if( word[i] & ~other.word[i] ) return false; return true; };
  int count() const;
  bool hasAtLeastCountElements( int min_count ) const;

  inline void union_with( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] |= other.word[i]; };
  inline void intersect_with( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] &= other.word[i]; };
  inline void setdiff_with( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] &= ~other.word[i]; };
  inline void add_complement( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] |= ~other.word[i]; };
  inline void delta_with( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] ^= other.word[i]; };
  inline void complement_over( const StaticCharSet& base_set ) { for(register int i=0; i<words; i++) word[i] = base_set.word[i] & ~word[i]; };
  inline void complement() { for(register int i=0; i<words; i++) word[i] = ~word[i]; };

  inline void set_union_of( const StaticCharSet& first, const StaticCharSet& second ) { for(register int i=0; i<words; i++) word[i] = first.word[i] | second.word[i]; };
  inline void set_intersect_of( const StaticCharSet& first, const StaticCharSet& second ) { for(register int i=0; i<words; i++) word[i] = first.word[i] & second.word[i]; };
  inline void set_diff_of( const StaticCharSet& first, const StaticCharSet& second ) { for(register int i=0; i<words; i++) word[i] = first.word[i] & ~second.word[i]; };
  inline void set_delta_of( const StaticCharSet& first, const StaticCharSet& second ) { for(register int i=0; i<words; i++) word[i] = first.word[i] ^ second.word[i]; };
  inline void set_complement_of( const StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] = ~other.word[i]; };

  inline StaticCharSet operator + ( const StaticCharSet& second ) { StaticCharSet result; for(register int i=0; i<words; i++) result.word[i] = word[i] | second.word[i]; return result; };
  inline StaticCharSet operator * ( const StaticCharSet& second ) { StaticCharSet result; for(register int i=0; i<words; i++) result.word[i] = word[i] & second.word[i]; return result; };
  inline StaticCharSet operator - ( const StaticCharSet& second ) { StaticCharSet result; for(register int i=0; i<words; i++) result.word[i] = word[i] & ~second.word[i]; return result; };
  inline StaticCharSet operator ^ ( const StaticCharSet& second ) { StaticCharSet result; for(register int i=0; i<words; i++) result.word[i] = word[i] ^ second.word[i]; return result; };
  inline bool operator == ( const StaticCharSet& second ) { for(register int i=0; i<words; i++) if( word[i] != second.word[i] ) return false; return true; };
  inline bool operator != ( const StaticCharSet& second ) { return !( *this == second ); };

  inline bool elm_in( unsigned char elm ) const { register int i = elm >> word_idx_shift; assert(i<words&&i>=0); return ( word[i] >> ( elm & sub_word_mask ) ) & (1); }
  inline void set_elm( unsigned char elm ) { register int i = elm >> word_idx_shift; assert(i<words&&i>=0); word[i] |= (u_iword)1 << ( elm & sub_word_mask ); }
  inline void unset_elm( unsigned char elm ) { register int i = elm >> word_idx_shift; word[i] &= ~( (u_iword)1 << ( elm & sub_word_mask ) ); }
  inline void invert_elm( unsigned char elm ) { register int i = elm >> word_idx_shift; word[i] ^= ( (u_iword)1 << ( elm & sub_word_mask ) ); }
  void set_range( unsigned char first, unsigned char last );
  void unset_range( unsigned char elm, unsigned char last  );
  void invert_range( unsigned char elm, unsigned char last  );

  bool print( aux::IOStreamRef out, ElmPrnFunc prn_elm = print_as_achar, aux::estr_const elm_sep = aux::estr_const(ColonChars,1) ) const;

  //void set_elm( unsigned char elm );
  //void union_with( StaticCharSet& other );
};

using namespace aux;

extern const echar echars_backslash[2], echars_quote[2], echars_comma[2], echars_open_curly_bracket[2], echars_close_curly_bracket[2];
extern const estr_const estr_backslash, estr_quote, estr_comma, estr_open_curly_bracket, estr_close_curly_bracket; 

typedef void(*TextCallBack)(int baseline,int subscriptcount,bool overlined,estr_const text,void *data);
void cbPrintSubscripted( TextCallBack cb, int baseline, bool overlined, estr_const text, void *data );

class ExtCharSet {
private:
  static void do_lookUp( int &j, echar &c, estr_const &set, SymbolTable *local, SymbolTable *global, bool *undefined_variable );
public:
  // estr_const character set specifiers will never read beyond set.length except iff there is a variable which starts before the end of set.length
  // the *undefined_variable boolean needs to be initialized with false when it is used
  static bool elm_in( achar elm, estr_const set, SymbolTable *local = NULL, SymbolTable *global = NULL, bool *undefined_variable = NULL );

  enum ErrCheckFlags { allow_var_ranges = 1, allow_empty_ranges = 2, allow_dot_dot = 4, \
		       is_a_simple_range = 8, exactly_one_character = 16, has_variables = 32 };
  static int first_error_position( estr_const set, int inFlags = 0, int *outFlags = 0 );   // ok: returns -1, error: returns position < set.length

  static bool print( IOStreamRef out, estr_const set, bool negated = false, bool print_as_set = true );
  static void cbPrint( TextCallBack cb, estr_const set, bool negated, bool print_as_set, void *data );

  // collectSymbolsAndVars: adds the characters and variables of set or its complement to positive_set, used_set and collect_variables
  //   positive_set: characters that may for sure appear in the input alphabet, used_set: characters used in any other way (for set deduction or complement)
  // handling of variables ( collect_variables != NULL ):
  //   value of newly collected variable > 0:  it was found in the positive side of a set (i.e. contributes to the input alphabet)
  //   value of newly collected variable < 0:  it was used in another way: found in the deduction or negation side of a set (but not yet in the positive side of a set)
  //   * round_value may be left NULL if no SymbolTable is given; it becomes set-above-zero and auto-incremented (currently by two) before it is used internally
  //     it should not be necessary to intialize *round_value; the values for different invocations need to differ though (at least by two)
  //   (*collect_variables) may already contain a valid SymbolTable, otherwise if it is set to NULL a fresh SymbolTable will be created
  enum CollectionFlags { open_lowerbound = 1, open_upperbound = 2, /* var_complemented = 4, */ keep_all_and_only_deduction_vars = 8, manifest_open_ranges_as_char_values = 16 };
  //   flags will remain the same if no variables have appeared in a range specifier and no variable was complemented; 
  //           for ranges like "δ…x" the open_lowerbound bit will be set (and the open_upperbound bit for ranges like "x…δ")
  //   keep_all_and_only_deduction_vars, manifest_open_ranges_as_char_values, add_complement: change the behaviour, mainly interesting for the implementation of alwaysDisjoint
  //   keep_all_and_only_deduction_vars: with multiple rounds positive vars can still overwrite a deduction var; set is complemented: there are no deduction vars
  //   add_complement: any character value that could possibly result out of a complementation is added to positive_set
  //   manifest_open_ranges_as_char_values: adds possible character values but does not deduct possible character values
  static void collectSymbolsAndVars( estr_const set, bool set_is_complemented, int *round_value,
                                     StaticCharSet *positive_set, StaticCharSet *used_set = NULL, SymbolTable **collect_variables = NULL, int *flags = NULL );

  enum DisjointFlags { complement_set_a = 1, complement_set_b = 2 };  // deterministic automata: assert that two character sets are disjoint
  static bool alwaysDisjoint( estr_const set_a, estr_const set_b, StaticCharSet *base_set = NULL, int flags = 0, bool *may_still_always_be_disjoint = NULL );
   // *may_still_always_be_disjoint becomes true: set_a or set_b has contained a variable range; false has been returned though true may have in deed been accurate

};


#endif
