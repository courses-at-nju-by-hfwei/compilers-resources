#ifndef SVG_EXPORT_H
#define SVG_EXPORT_H

#include <QtCore/QString>

class Automaton; 
class AtmtWatch;

// must call setAutomaton(atmt) first so that atmtWatch->atmt == atmt
bool createSVG( Automaton *atmt, QString title, QString filename, AtmtWatch *atmtWatch );


#endif
