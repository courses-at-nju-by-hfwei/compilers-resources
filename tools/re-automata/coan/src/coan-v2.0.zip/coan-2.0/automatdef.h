#ifndef AUTOMATDEF_H
#define AUTOMATDEF_H

#include <vector>
#include <list>
#include <set>
#include <algorithm>
//#include <utility>
#include <string.h>
#include <assert.h>
#ifdef QT_CORE_LIB
  #include <QtCore/QPointF>
  #include <QtCore/QRectF>
  #include <QtGui/QFont>
  #include <QtGui/QPainterPath>
  #include <QtGui/QPen>
  #include <QtGui/QBrush>
#endif
#include "auxtypes.h"
#include "symtab.h"
#include "charset.h"

#ifdef QT_CORE_LIB
 class QFontMetrics;
 class QPainter;
 class QWidget;
#endif

using namespace aux;

extern bool debug;

#ifdef _MSC_VER
 #pragma warning(disable:4722)   // destructor never returns a value; possible memory loss - why? the destr. do in deed not return a value
#endif

class Element;
class Data { protected: ~Data() { cerr << "error: tried to deallocate Data object by itself instead of the runtime." << aux::endl; abort(); } };

enum Status { no_successor, internal_error, stepDone, fatal_error, hanging, halted, dismissed, accepted };
extern const char *Status2Chars[];
extern const int numStatus2Chars;

struct PrintOptions {
  utf8str_const separator[4], introSub[2], finalizeSub[2], msgForNoStates;
  utf8str_const rightArrow, doubleArrow, backArrow, errorEltIndicator, cursor_left, cursor_right;
  enum OptionCategory { TransitionFreq = 0x3, Precedence = 0x4, VarPrintage = 0x18, LineBreaks = 0x60 };
  static const int Bits4Spacing = 3;
  enum ShiftedOptions { outerSpacing = 7, midSpacing = 7 + Bits4Spacing, innerSpacing = 7 + 2*Bits4Spacing };
  static const int SpacingMask = (1<<Bits4Spacing)-1;
  enum TransitionFreq { oneCompoundTransition = 0x1, oneTransitionPerLevel1Data = 0x2, oneTransitionByElement = 0x3 };
  enum Precedence { dataOriented = 0x0, stateOriented = 0x4 };
  enum VarPrintage { printAlways = 0x0, printBeforeRead = 0x8, printAfterWrite = 0x10 }; 
  enum LineBreaks { oneLine = 0x0, multiLine = 0x20, indentedLines = 0x40 };
  static const int defaultModeFields = oneCompoundTransition | stateOriented | printBeforeRead | printAfterWrite | oneLine | ( 2 & SpacingMask ) << outerSpacing | ( 1 & SpacingMask ) << midSpacing;
  //static const int defaultModeFields = oneTransitionPerLevel1Data | stateOriented | printBeforeRead | printAfterWrite | multiLine | ( 2 & SpacingMask ) << outerSpacing | ( 1 & SpacingMask ) << midSpacing;
  int modeFields;
};

class Runtime_Base {
public:
  virtual Data* duplicateData( Data *d ) const { if(!d) return NULL; cerr << "duplicateData called for abstract base class Runtime_Base; stop." << aux::endl; abort(); }
  virtual void freeData( Data *d ) const { if(!d) return; cerr << "freeData called for abstract base class Runtime_Base; stop." << aux::endl; abort(); }
  virtual Status getResultStatus( Element *e, Data *d ) = 0;
  virtual void printData( IOStreamRef out, Data *d, bool shallPrintVars ) const { out << ( d ? "?" : "NULL" ); };
  virtual int compareData( Data *a, Data *b ) const { if(a||b) abort(); return 0; }
  virtual SymbolTable* getDataSymTab( Data *d ) const { return NULL; }
};

struct State {
  Element *elm;
  Data *data;
  State( Element *e, Data *d ) : elm(e), data(d) {};
  void print( IOStreamRef out, const Runtime_Base *r, int debugLevel = 0, bool isLookAhead = false, bool shallPrintVars = false ) const;
};

struct IntermedState : public State {
  SymbolTable *tmpSmbls;
  IntermedState( Element *e, Data *d, SymbolTable *s ) : State(e,d), tmpSmbls(s) {};
  //static SymbolTable *OtherDataForSameTransition;
  //inline bool isaDifferentTransition() const { return tmpSmbls != OtherDataForSameTransition; };
  //class anotherTransitionpred : public std::unary_function<const IntermedState&,bool> { public: bool operator()( const IntermedState& itst ) const { return itst.tmpSmbls != OtherDataForSameTransition; }; };
};

struct FinalState : public State {
  enum Status status; int step_num;
  FinalState( Element *e, Data *d, enum Status status, int step ) : State(e,d), status(status), step_num(step) {};
};

class State_compare_less : public std::binary_function<State,State,bool> {
public:
  Runtime_Base *runtime;
  State_compare_less( Runtime_Base *r ) { runtime = r; }
  bool operator()(const State &x, const State &y) const {
    if( x.data != y.data ) {
      int result = runtime->compareData( x.data, y.data );
      if( result ) return result < 0;
    }
    return x.elm < y.elm;  // if( x.elm != y.elm ) return x.elm < y.elm; //return false;
  }
};

#ifdef QT_CORE_LIB
  extern QFont elmLabelFont;
  enum Modus { normal = 0, selected = 1, erroneous = 2, erroneous_selected = 3, inexec = 4, inexec_selected = 5, inexec_erroneous = 6, inexec_erroneous_selected = 7, moving = 8, creating_edge = 9 };
  extern struct PaintSettings { QPen pen; QBrush brush; } paintsettings[10];
  struct TextExtent { qreal ascent, descent, width; };
  qreal vector_length( QPointF vec );

  struct TextExtent getVariableTextExtent( QPainter *painter, estr_const text );
  void drawVariableText( QPainter *painter, QPointF pos, estr_const text );
  QString variableTextAsQString( estr_const text );
#else 
  class QPointF { public: double xpos, ypos; QPointF(double xpos,double ypos) : xpos(xpos), ypos(ypos) {} };
#endif

class Automaton;
class Runtime;


class Element {
public:
  virtual int setContent( Automaton *a, estrbuf *acceptation ) = 0;
public:
  virtual estr_const getContent() const = 0;
  virtual astr_const getType() const = 0;
  virtual void print( IOStreamRef out, int debuglevel = 0, bool isLookAhead = false, int relpos = 0 ) const;
  virtual bool isFinalNode() const = 0;
  virtual void lookAhead( Runtime *r, Data *d, int relpos = 0 ) = 0;
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos = 0 ) = 0;
  virtual int relpos() const { return 0; }
  virtual int execLength() const { return 1; }
  virtual Element* mainElement() { return this; }
  virtual ~Element() {}
};

#ifdef QT_CORE_LIB
extern u_iword emptyCursor[1+(65537-1)/(sizeof(u_iword)*4)];
#endif

class GraphElement : public Element { 
public:
  inline Element* assignContent( Automaton *a, estrbuf* acceptation ) {
    int errpos = setContent( a, acceptation );
    setErrorPos( errpos, getContent() );
#ifdef QT_CORE_LIB
    if( errpos >= 0 ) {
      modus = Modus::erroneous | modus & 1; // &1 ~ keep selection
    } else {
      if( modus == Modus::erroneous || modus == Modus::erroneous_selected ) modus = modus & 1;
    }
#endif
    return this;
  }
  inline Element* assignContent( Automaton *a, const char *acceptation ) {
    estrbuf strbuf( acceptation );
    return assignContent( a, &strbuf );
  }
#ifndef QT_CORE_LIB
  inline Element* setCoords(QPointF newpos) { return this; };   // call of updateGeometry required thereAfter
  void setErrorPos( int errpos, estr_const newContent ) {
    if( errpos < 0 ) return;
    aux::cerr << "error assigning content '" << newContent.sub(0,errpos) << "|" << newContent.sub(errpos) << "' to " << getType() << " element." << aux::endl;
  }
};
#else
public:
  QPointF pos, relTextPos; qreal a, b; int modus; int errpos; 
  union { u_iword val; u_iword *ref; } cursorSet; 
  void setErrorPos( int errpos, estr_const newContent ) {
    this->errpos = errpos; if( errpos < 0 ) return;
    aux::cerr << "error assigning content '" << newContent.sub(0,errpos) << "|" << newContent.sub(errpos) << "' to " << getType() << " element." << aux::endl;
  }
  void setNormalModus();
#define CursorPack (4*sizeof(u_iword))
  void setCursor( int relpos, int type ); void resetCursor();
  struct CursorCounter { u_iword val; const u_iword *ref; int j; };
  inline void InitCursorCounter( struct CursorCounter *cc ) const { cc->j = 0;
    if( execLength() < CursorPack ) { cc->val = cursorSet.val; cc->ref = &cursorSet.val; } 
    else { if(!cursorSet.ref) cc->ref = emptyCursor; else cc->ref = cursorSet.ref; cc->val = *cc->ref; } 
  }
  //inline int currentCursor( struct CursorCounter *cc ) { return cc->val & 3; }
  inline int nextCursor( struct CursorCounter *cc ) const { int val = cc->val & 3; cc->val >>= 2; cc->j++; if( cc->j >= CursorPack ) { cc->val = *++cc->ref; cc->j=0; }; return val; }
protected:
  void drawText( QPainter *painter ) const;
  virtual void doUpdateGeometry( QPaintDevice *d, struct TextExtent ext );
public:
  GraphElement() { relTextPos = QPointF(0,0); modus = Modus::normal; cursorSet.ref = 0; errpos = -1; }
  inline GraphElement* setCoords(QPointF newpos) { pos = newpos; return this; };   // call of updateGeometry required thereAfter
  virtual void callbackPrint( TextCallBack cb, void *data ) const {}; 
  struct TextExtent getTextExtent( QPaintDevice *device ) const;
  virtual void draw( QPainter *painter, Automaton *atmt ) const { drawText(painter); };
  void updateGeometry( QPaintDevice *d ) { struct TextExtent ext = getTextExtent(d); doUpdateGeometry(d,ext); }
  virtual QRectF boundingRect() const { return QRectF( pos.x()-a, pos.y()-b, 2*a, 2*b ); }
  virtual bool isThere( QPointF pos ) const { return false; };
};
#endif

inline GraphElement* gelm(Element* e) { return (GraphElement*)e->mainElement(); }


class ElementProxy : public Element {
public:
  Element *main; short int relative_runtime_position;
protected:
  virtual int setContent( Automaton *, estrbuf* ) { cerr << "setContent called on ElementProxy" << aux::endl; abort(); }
public:
  ElementProxy( Element *e, short runtime_pos ) : main(e), relative_runtime_position(runtime_pos) {};
  virtual estr_const getContent() const { return main->getContent(); }
  virtual astr_const getType() const { return main->getType(); }
  virtual void print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos = 0 ) const { main->print(out,debuglevel,isLookAhead,relative_runtime_position); };
  //virtual void callbackPrint( TextCallBack cb, void *data ) const { main->callbackPrint(cb,data); }
  virtual bool isFinalNode() const { return main->isFinalNode(); }
  virtual void lookAhead( Runtime *r, Data *d, int relpos = 0 ) { main->lookAhead(r,d,relative_runtime_position); }
  virtual void next( Runtime *r, Data *d, SymbolTable *s, int relpos = 0 ) { return main->next(r,d,s,relative_runtime_position); }
  virtual int relpos() const { return relative_runtime_position; }
  virtual Element* mainElement() { return main; };
  virtual ~ElementProxy() {}
};

/*class ProxyTable {
public:
  std::vector<ElementProxy> next_proxy;
  Element* getTheSame( Element *main, int pos ) { if( pos <= 0 ) return main; if( pos <= (int)next_proxy.size() ) return &next_proxy[pos-1]; assert(false); }
  inline Element* getNext( Element *main, int pos ) { assert( pos >= 0 && pos < (int)next_proxy.size() ); return &next_proxy[pos]; }
  //int getNextPosition( int curpos );
  //void createEntry4LongVar( Element *main, int curpos, int nextpos );
};*/

extern estrbuf dangling_node_buf;

class Node; extern const astr_const node_as_text;
class Edge; extern const astr_const edge_as_text;

typedef std::vector<Edge*> Edges;
typedef std::vector<Node*> Nodes;

class Node : public GraphElement {
public:
  Edges pred, succ; int epsilonSucc;
  Nodes epsilonClosure; 
  Node() { epsilonSucc = 0; }
  virtual void zeroReadLookAhead( Runtime *r, Data *d ) { };
  virtual bool setFinalNode(bool isFinalNode) =  0;
  inline Node* assignContent( Automaton *a, estrbuf *acceptation ) { return (Node*)GraphElement::assignContent(a,acceptation); }
  inline Node* assignContent( Automaton *a, const char *acceptation ) { return (Node*)GraphElement::assignContent(a,acceptation); }
  inline Node* setCoords( QPointF newpos ) { return (Node*)GraphElement::setCoords(newpos); };
#ifdef QT_CORE_LIB
  int nodenum;  // node number - used as reference when safing a file
  Node* assignParams( Node *other ) {  pos = other->pos; a = other->a; b = other->b; return this; }
  virtual void doUpdateGeometry( QPaintDevice *d, struct TextExtent ext );
  virtual QPointF getSecant( QPointF from ) const { return QPointF(0,0); }; // = 0;
#endif
  virtual astr_const getType() const { return node_as_text; }
  virtual ~Node();
};


const int isThereRadius = 8;
const int handleRadius = 8;

class Edge : public GraphElement {
public:
  Node *from, *to;
#ifdef QT_CORE_LIB
  static const int arrowLen = 10;
  std::vector<QPointF> track;
  QPainterPath painterPath() const;
  QPainterPath doublePainterPath() const;
  virtual void draw( QPainter *painter, Automaton *atmt ) const;
  virtual QRectF boundingRect() const;
  virtual bool isThere( QPointF pos ) const;
  virtual bool atLabel( QPointF pos ) const { return GraphElement::boundingRect().contains(pos); };
  virtual void doUpdateGeometry( QPaintDevice *d, struct TextExtent ext );
  void trackEdges( QPointF *newpos );
  void trackNodes( QPointF fromNodePos, QPointF toNodePos );
#endif
  Edge( Node *a, Node *b ) {
    from = a; to = b; 
    if(from) from->succ.push_back(this);
    if(to) to->pred.push_back(this);
  }
  inline Edge* assignContent( Automaton *a, estrbuf *acceptation ) { return (Edge*)GraphElement::assignContent(a,acceptation); }
  inline Edge* assignContent( Automaton *a, const char *acceptation ) { return (Edge*)GraphElement::assignContent(a,acceptation); }
  inline Edge* setCoords( QPointF newpos ) { return (Edge*)GraphElement::setCoords(newpos); };
  int setTrack( const std::vector<int> *data );
  void addLinearTrackNode( QPointF pos );
  int setLinearTrack( const std::vector<int> *data );
  virtual bool isFinalNode() const { return false; };
  virtual bool isEpsilon() const { return false; };
  virtual astr_const getType() const { return edge_as_text; }
  static void removeUniqueFromVector( Edges *vec, Edge *elm );
  virtual ~Edge();
};


typedef std::set<State,State_compare_less> States;
typedef std::vector<IntermedState> ImStateVector;
typedef std::vector<Element*> ViewOnlyElements;
typedef std::vector<FinalState> FinalStates;

class Runtime: public Runtime_Base {
public:
  enum Condition { undefined_variable_during_lookahead = 1, undefined_variable_during_next = 2, had_an_illegal_epsilon_loop = 4, no_startNode = 8, out_of_memory = 16, \
                   undefined_automaton = 32, endless_search = 64, \
                   is_the_initial_step = 128, all_done = 256, adding_zeroreads = 512, at_lookAhead = 1024, \
		   will_read_variable = 2048, will_write_variable = 4096 };
  // will_read_variable: any condition (whether executed or not) checks for a character stored in a variable, or: write value of an existing variable to the tape
  // will_write_variable: the current character will be remembered in any of the variables after this step has been completed
  static const int ExecStateFlags = is_the_initial_step | all_done | adding_zeroreads | at_lookAhead;
  static const int InfoFlags = will_read_variable | will_write_variable;
  static const int NotAnError = InfoFlags | ExecStateFlags;
  static const int IsAnError = ~NotAnError;
  static const int FatalErrors = no_startNode | endless_search;
  static const int NextStepErrors = undefined_variable_during_next | no_startNode; // | had_an_illegal_epsilon_loop;
  static const int LookAheadErrors = IsAnError & ~NextStepErrors;
  struct TraceStep {
    TraceStep(State_compare_less& cmp) : states(cmp) { }
    States states;
    ImStateVector lookahead;
    ViewOnlyElements viewOnlyElements; int zeroReadEdgeNum;
    Status status; int conditions;
    struct StatePos { 
      States::const_iterator state_pos; 
      ImStateVector::const_iterator lhd_pos;    // lookahead_pos
    };
    typedef std::vector<StatePos> StatePosVec;
    StatePosVec new_data_pos;
    static void freeMemSub( Runtime *r, struct TraceStep *tr );
  };
  struct TraceStep *prev, *cur; int cur_step;
  FinalStates finalStates;
  virtual void rememberOutcome( Element *e, Data *d, enum Status status );   // see also rememberOnceNoState, status_4_no_successor
  int numOutcomes() { return finalStates.size(); }
  virtual void getOutcome( int idx, astr_shared **tape, int *pos, enum Status *status, int *step_num ) = 0;  // step_num may be NULL; all other pointers are required
protected:
  struct TraceStep *trace;
  int tlen, tpos; State_compare_less state_compare; 
private:
  void resetTraceStep( struct TraceStep *cur );
protected:
  virtual void finalizeStep() {};       // default: no action, Finite Automata: progress for one position on the tape
public:    
  // addState: true iff State has been inserted successfully (i.e. it was not a dup), if it was a dup then r->freeData(next.data) will be executed by addState
  //           only allowed during next operation (when elm.next or elm.zeroReadLookAhead is called)
  bool addState( State next );
  // addLookAhead: always allowed (during next & during lookAhead); though up to now only of use during lookAhead
  inline void addLookAhead( IntermedState lh ) { cur->lookahead.push_back( lh ); }  // data object given here is not an independent instance and will never need to be freed with r->freeData()
public:  // two possible types of viewOnlyElements may be added: each type either in the addState or addLookAhead mode
  void addZeroReadEdge( Element *edge );      // call currently only allowed from node.zeroReadLookAhead(...) which occurs on addState during next (would basically always work during next)
  void addErrorWithElement( Element *edge );  // call only allowed during lookAhead (when element.lookAhead(...) is called)
  // remark: zeroReadEdgeNum will contain the number of previously added zero-read-edges when already progressed to LookAhead mode
protected:
  Runtime( Automaton *a, astr_const charParam, inta_const valParam, int trace_len );
  enum Status lookAhead( bool prepareStatePos );   // prepareStatePos is true => cur->new_data_pos will be populated (otherwise it can be populated by init_new_data_pos with hindsight)
public:
  virtual Status status_4_no_consecutive_state() { return no_successor; }
  virtual Status status_4_no_successor( const State *state ) { return no_successor; }   // used to remember the outcome with machine schemata
  virtual bool rememberOnceNoState() { return false; }    // if true rememberOutcome will only be called once with the NULL element and NULL data
  enum Status nextStep( bool prepareStatePos = true );   // calls next on each element in the current lookAhead and then computes the new lookAhead (does nothing if mightContinue() yields false)
  bool exec( bool stopOnResult = false, int maxsteps = -1 );    // calls nextStep until the automaton halts, till an unrecoverable error occurs or till a condition indicated by stopOnErrorMask is met.
  Runtime* exec_traced( IOStreamRef out, bool stopOnResult = false, int debuglevel = 2, int maxsteps = -1 );
  inline bool mightContinue() const { return !( trace[tpos].conditions & all_done ); };   // if( trace[tpos].status == stepDone ) assert( !( accruedConditions & FatalErrors ) );
  enum Status getStatus() const { return trace[tpos].status; };
private: 
  // some internal procedures currently only used by addState
  inline bool needed2AddEpsilonEdgesOf( Node *node );
  inline bool lookForSameElement( States::iterator pos, Node *elm );
  inline void addEpsilonEdgesOf( Node *node );
private:
  void freeLookAheadElements( struct TraceStep *ctr );    // currently just frees tmpSmbls if present
  void lookAhead_simple();          // may be called by lookAhead()
  void lookAhead_with_StatePos(bool remember);   // may be called by lookAhead() with remember=true or init_new_data_pos() with remember=false
public:  // to also be read by Nodes and Edges
  SymbolTable *paramSymTab;
  protected: template<class Base> int InitVars( estr_const formalParams, xstr_const<Base> actualParams, Base zeroparam, int formalParamCount );
protected:
  void init_new_data_pos();
  void prnTape( IOStreamRef out );
  void prnStates( IOStreamRef out, struct TraceStep *ctr, int debuglevel ) const;
  void prnLookAhead( IOStreamRef out, struct TraceStep *ctr, int debuglevel, bool justPrintErrorElts = false ) const;
protected: 
  int accruedConditions; Status accruedStatus; int stopOnErrorMask; 
  public: inline void setCondition( int newConditions ) { trace[tpos].conditions |= newConditions; }
public:
  static void printConditions( IOStreamRef out, int conditions );
  inline int getConditions() const { return accruedConditions | trace[tpos].conditions; };
  inline int getConditionsFromLastStep() const { return trace[tpos].conditions; };
  inline int getErrorConditions() const { return ( accruedConditions | trace[tpos].conditions ) & IsAnError; };
  inline int getErrorConditionsFromLastStep() const { return ( trace[tpos].conditions ) & IsAnError; };
  inline Runtime* printErrorConditions( IOStreamRef out ) { printConditions(out, getErrorConditions() ); return this; };
  inline Runtime* printErrorConditionsFromLastStep( IOStreamRef out ) { printConditions(out, getErrorConditionsFromLastStep() ); return this; };
  inline Runtime* setIgnoreErrorMask( int ignoreErrorMask ) { stopOnErrorMask = ( ~ignoreErrorMask | FatalErrors ) & IsAnError; return this; };
  inline int getIgnoreErrorMask() const { return ~stopOnErrorMask; };
public:
  class ParentTapeIndex { public: 
    int topidx; 
    inline ParentTapeIndex( int topidx = -1 ) : topidx(topidx) {}; 
    inline bool isRootAnchor() const { return topidx == -1; };
    inline bool operator== ( ParentTapeIndex i ) const { return topidx == i.topidx; };
  };
  class TapeIndex : public ParentTapeIndex { public: 
    int subidx; 
    inline TapeIndex( int topidx = 0, int subidx = -1 ) : ParentTapeIndex(topidx), subidx(subidx) {}; 
    inline TapeIndex( ParentTapeIndex i ) : ParentTapeIndex(i), subidx(-1) {}; 
    inline bool isRootAnchor() const { return topidx == -1 && subidx == -1; };
    inline bool operator== ( TapeIndex i ) const { return topidx == i.topidx && subidx == i.subidx; };
    inline bool operator!= ( TapeIndex i ) const { return topidx != i.topidx || subidx != i.subidx; };
  };
  // TapePos - values with special meaning: -1: hanging at the left, -2: tape is a stack (current position always at the very right), -3: other/error
  virtual int numTapes( ParentTapeIndex idx  = ParentTapeIndex() ) = 0;    // top-level: topidx = -1, sub-level: topidx >= 0
  // getTape.pos: -3 ~ non-existant tape, -2 ~ stack, ¿ -1 ~ hanging ?
  virtual int getTape( astr_const *content, int *pos, SymbolTable **symTab, TapeIndex idx = TapeIndex() ) = 0;   // returns -1 on error
  struct StatesAndLookAhead { 
    States::const_iterator first_state, last_state;
    ImStateVector::const_iterator first_lookahead, last_lookahead;
  };
  virtual void getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i = TapeIndex() ) = 0;   // -1,-1: shall get all
  struct ViewOnlyElementRange { ViewOnlyElements::iterator begin, end; };
  inline void getZeroReadEdges( ViewOnlyElementRange *ZRE_range  ) { ZRE_range->begin = cur->viewOnlyElements.begin(); ZRE_range->end = cur->viewOnlyElements.begin() + cur->zeroReadEdgeNum; }
  inline void getActiveErrorElements( ViewOnlyElementRange *AEE_range  ) { AEE_range->begin = cur->viewOnlyElements.begin() + cur->zeroReadEdgeNum;; AEE_range->end = cur->viewOnlyElements.end(); }
protected:
  int nonExistantTape( astr_const *content, int *pos, SymbolTable **symTab );
  void getEmptyStatesAndLookAhead( struct StatesAndLookAhead *sl );
public:
  void getAllStatesWithLookAhead( struct StatesAndLookAhead *standlh );
  inline astr_const getTapeContent( TapeIndex idx = TapeIndex() ) { astr_const result; getTape(&result,NULL,NULL,idx); return result; }
  inline int getTapePos( TapeIndex idx = TapeIndex() ) { int result; getTape(NULL,&result,NULL,idx); return result; }
  inline SymbolTable* getSymTab( TapeIndex idx = TapeIndex() ) { if(idx.isRootAnchor()) return paramSymTab; SymbolTable *result; getTape(NULL,NULL,&result,idx); return result; }
  static int initPrintOptions( struct PrintOptions *prnopts, int printMode = PrintOptions::defaultModeFields, int charset = -1 /* like aux::CharSet */ ); 
  Runtime* printCurState( IOStreamRef out, const struct PrintOptions *prnopts );
public:
  static void freeMem( Automaton *a, Runtime *r ) { r->freeMemSub(a); free(r); }
protected:
  virtual void freeMemSub( Automaton *a );
  virtual ~Runtime() { cerr << "error: tried to auto-deallocate Runtime object by itself; you need to use automaton->creatRuntime(...) together with automaton->free[Mem]Runtime()." << aux::endl; abort(); };
};

typedef struct Runtime::ParentTapeIndex ParTpIdx;
typedef struct Runtime::TapeIndex TpIdx;

class Automaton {
public:  // protected:
  //std::list<Element*> allElements;
  std::list<Node*> allNodes;
  std::list<Edge*> allEdges;
  template<class Element> bool typedRemoveElement( Element *elm, std::list<Element*> *allElementsOfThisType );
  virtual const char* typeStr() = 0;
  virtual bool edgeEscapeSlash() { return false; }
public:   // to be written by the Rutime class, only
  estrbuf charFormalParams, valFormalParams;
  int charFormalParamCount, valFormalParamCount;
  int setFormalCharParams( estrbuf *formalParams );    // both functions will return the number of accepted params
  int setFormalValParams( estrbuf *formalParams );     // estrbuf will contain an estr_const to the estrbuf initially passed in (iff not reallocated by noramlization)
  inline int setFormalCharParams( const char *formalParams ) { estrbuf strbuf( formalParams ); return setFormalCharParams( &strbuf ); }
  inline int setFormalValParams( const char *formalParams ) { estrbuf strbuf( formalParams ); return setFormalValParams( &strbuf ); }
public:
  enum Flags { reallyDeterministic = 1, isDeterministic = 2, hasErrors = 4 };
  Node* startNode; int flags; int charsetCheckFlags;
  void refreshEpsilonClosure();
  virtual Node* createNode() = 0;
  virtual Edge* createEdge( Node *a, Node *b ) = 0;
#ifdef QT_CORE_LIB
  void updateGeometry( QPaintDevice *device );
  QString description;
#endif
  bool removeNode( Node *node ); bool removeEdge( Edge *edge );
  bool removeElement( GraphElement *e );  // returns true on successful removal
  template<class Element> inline bool removeElement( Element **e ) { bool removedOk = removeElement(*e); if(removedOk) *e = NULL; return removedOk; };
  bool elementIsPartOf( GraphElement *e );  // returns true if Element belongs to this automaton (and thus can be removed by calling one of the instance methods of this automaton)
  int removeDanglingEdges();   // shall return zero: as implemented now no dangling edges shall ever be found
  virtual Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) = 0;
  inline Runtime* createRuntime( astr_const input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) {
    astr_shared *input_strbuf = astr_shared::copyFrom(input);
    return createRuntime( input_strbuf, pos, charParam, valParam, tracelen, prepareStatePos );
  }
  inline Runtime* createRuntime( const char *input, int pos = -1, const char *charParam = "", inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) {
    astr_shared *input_strbuf = astr_shared::copyFrom(astr_const((achar*)input,strlen(input)));
    return createRuntime( input_strbuf, pos, astr_const((achar*)charParam,strlen(charParam)), valParam, tracelen, prepareStatePos );
  }
  inline void freeRuntime( Runtime **r ) { if(!*r) return; Runtime::freeMem(this,*r); *r = NULL; }
  inline void freeRuntime( Runtime *r ) { if(!r) return; Runtime::freeMem(this,r); }
  virtual bool posTapeCursorAtBegin() = 0;
  //static void initRuntime( Runtime *r );
  Automaton();
  virtual ~Automaton();
};

#endif
