#include "Settings.h"
#include <QtGui/QPainter>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QApplication>
#include <QtCore/QtMath>
#include <QtWidgets/QStyleOptionButton>
#include "automatdef.h"
#include "symtab.h"

AtmtSettings::AtmtSettings(QWidget *parent) : QDialog(parent) {
  QVBoxLayout *vlayout; QHBoxLayout *hlayout; QLabel *label;
  QVBoxLayout *mainlayout = new QVBoxLayout;
  QHBoxLayout *horizlayout = new QHBoxLayout;
  QGroupBox *charpaletteGpBx = new QGroupBox("character palette",this);
  //QGroupBox *charsetGpBx = new QGroupBox("character set",this);
  QGroupBox *generalGpBx = new QGroupBox("general settings",this);
   QGridLayout *charpalLayout = new QGridLayout(); int i=0, j=0; QPushButton *butt;
   QChar chars[] = { QChar(subscript_char), QChar(close_subscripts_char), QChar(range_char), QChar(setminus_char), QChar(unicode_space) };
   for( int c = 0; c < sizeof(chars)/sizeof(QChar); c++ ) {
     butt = new QuadrPushButton(QString(chars[c])); butt->setFocusPolicy(Qt::NoFocus);
     connect( butt, SIGNAL(clicked()), this, SLOT(unicodeLetterButtonClicked()) );
     charpalLayout->addWidget( butt, i, j );
     j++; if( j > 14 ) { i++; j=0; }
   }
   for( echar c = first_greek_letter; c < first_greek_letter + greek_letter_num; c++ ) {
     if( !SymbolTable::isGreekVariable(c) && c != epsilon_letter ) continue;
     butt = new QuadrPushButton(QString(QChar(c))); butt->setFocusPolicy(Qt::NoFocus);
     connect( butt, SIGNAL(clicked()), this, SLOT(unicodeLetterButtonClicked()) );
     charpalLayout->addWidget( butt, i, j );
     j++; if( j > 14 ) { i++; j=0; }
   }
   charpaletteGpBx->setLayout(charpalLayout);
  mainlayout->addWidget(charpaletteGpBx);
  //horizlayout->addWidget(charsetGpBx);
  vlayout = new QVBoxLayout;
  allowVarRanges = new QCheckBox("allow variables to start or end a range specification"); vlayout->addWidget(allowVarRanges);
  isDeterministic = new QCheckBox("automaton is deterministic"); vlayout->addWidget(isDeterministic);
  hlayout = new QHBoxLayout();
  hlayout->addWidget( label = new QLabel("formal character parameters:") ); charFormalParams = new QLineEdit(); label->setBuddy(charFormalParams); 
  hlayout->addWidget(charFormalParams); vlayout->addLayout(hlayout);
  hlayout = new QHBoxLayout(); hlayout->addStretch();
  displayCharFormals = new DisplayVars(SymbolMode::mode_grVarList,this); hlayout->addWidget(displayCharFormals); vlayout->addLayout(hlayout);
  hlayout = new QHBoxLayout();
  hlayout->addWidget( label = new QLabel("formal value parameters:") ); valFormalParams = new QLineEdit(); label->setBuddy(valFormalParams); 
  hlayout->addWidget(valFormalParams); vlayout->addLayout(hlayout);
  hlayout = new QHBoxLayout(); hlayout->addStretch();
  displayValFormals = new DisplayVars(SymbolMode::mode_latVarList,this); hlayout->addWidget(displayValFormals); vlayout->addLayout(hlayout);
  connect( charFormalParams, SIGNAL(textChanged(const QString&)), this, SLOT(charFormalParamsChanged(const QString&)) );
  connect( valFormalParams, SIGNAL(textChanged(const QString&)), this, SLOT(valFormalParamsChanged(const QString&)) );
  generalGpBx->setLayout(vlayout);
  horizlayout->addWidget(generalGpBx);
  mainlayout->addLayout(horizlayout);
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(accept()) );
  connect( dialogButtons, SIGNAL(rejected()), this, SLOT(reject()) );
  mainlayout->addWidget(dialogButtons);
  setLayout(mainlayout);
  setWindowTitle("Machine Settings");
  atmt = NULL;
}

// void QuadrPushButton::resizeEvent(QResizeEvent *event) { setMaximumWidth(event->size().height()); } // this will take effect too late; the gridlayout will already have expanded the parent widgets size
// it would still be possible to work like this if the parent is resized after the first show to a very small width; then it will calculate the minimum width again

QuadrPushButton::QuadrPushButton(const QString & text, QWidget * parent ) : QPushButton(text,parent) {
  QStyleOptionButton styleOption; styleOption.initFrom(this); 
  //setMaximumWidth(styleOption.rect.height());
  setMaximumWidth(styleOption.fontMetrics.height()*qSqrt(2));
};

void AtmtSettings::unicodeLetterButtonClicked() {
  QPushButton *pushbutton = qobject_cast<QPushButton*>(sender()); if(!pushbutton) return; 
  QWidget *focusWidget = QApplication::focusWidget(); QLineEdit * lineEdit;
  if( focusWidget == charFormalParams || focusWidget == valFormalParams ) lineEdit = (QLineEdit*)focusWidget;
  else return;
  QString instext = pushbutton->text();
  QString newtext = lineEdit->text(); int pos = lineEdit->cursorPosition();
  newtext.insert( pos, instext );
  lineEdit->setText(newtext);
  lineEdit->setFocus(Qt::FocusReason::TabFocusReason);
  lineEdit->setCursorPosition( pos + instext.length() );
}

DisplayVars::DisplayVars( enum SymbolMode symbolMode, QWidget *parent ) : QWidget(parent), symbolMode(symbolMode) { 
  varFont.setPointSize(10); varFont.setFamily("Helvetica");   
  xvirtual = min_xvirtual; yvirtual = min_yvirtual; 
};

void DisplayVars::paintEvent(QPaintEvent *event) {
  QPainter painter(this); int i, j, len; int xpos = 0, ypos = 0;
  struct TextExtent txtext; QFontMetrics varFontMetrics(varFont,this); painter.setFont(varFont); ypos += varFontMetrics.ascent(); int maxdescent = varFontMetrics.descent();
  i=0; j=0; while( j < variables.length ) {
     len = qMax( qMin( SymbolTable::varLength( variables.chars + j ), variables.length - j ), 1);
     txtext = getVariableTextExtent( &painter, variables.sub(j,len) );
     if( txtext.descent > maxdescent ) maxdescent = txtext.descent;
     drawVariableText( &painter, QPointF(xpos,ypos), variables.sub(j,len) ); xpos += txtext.width;
     if( j + len < variables.length ) {
       painter.drawText( xpos, ypos, ", " );
       xpos += varFontMetrics.width(", ");
     }
     j += len; i++; 
  }
  ypos += maxdescent;  xpos = qMax(xpos,min_xvirtual); ypos = qMax(ypos,min_yvirtual);
  setMinimumSize( xpos, ypos );
  if( xvirtual != xpos || yvirtual != ypos ) updateGeometry();
  xvirtual = xpos; yvirtual = ypos;
}

void DisplayVars::setVariables(const QString& newcontent) {
  variables = newcontent;
  SymbolTable::normalize( &variables, symbolMode );
  //cout << variables << aux::endl;
  update();
}

void AtmtSettings::charFormalParamsChanged(const QString& newcontent) { displayCharFormals->setVariables(newcontent); }
void AtmtSettings::valFormalParamsChanged(const QString& newcontent) { displayValFormals->setVariables(newcontent); }


void AtmtSettings::setAutomaton( Automaton *a ) { 
  atmt = a;  if(!a) return;
  isDeterministic->setChecked( a->flags & Automaton::isDeterministic );
  allowVarRanges->setChecked( a->charsetCheckFlags & ExtCharSet::allow_var_ranges );
  charFormalParams->setText( toQString(a->charFormalParams) ); displayCharFormals->variables.referenceFrom( a->charFormalParams ); // charFormalParamsChanged(charFormalParams->text());
  valFormalParams->setText( toQString(a->valFormalParams) ); displayValFormals->variables.referenceFrom( a->valFormalParams ); // valFormalParamsChanged(valFormalParams->text());
};

void AtmtSettings::done( int result ) {
  if( result == QDialog::Accepted ) {
    if(isDeterministic->isChecked()) atmt->flags |= Automaton::isDeterministic; else atmt->flags &= ~Automaton::isDeterministic;
    if(allowVarRanges->isChecked()) atmt->charsetCheckFlags |= ExtCharSet::allow_var_ranges; else atmt->charsetCheckFlags &= ~ExtCharSet::allow_var_ranges; 
    atmt->setFormalCharParams(&displayCharFormals->variables); displayCharFormals->variables = invalid_estr;
    atmt->setFormalValParams(&displayValFormals->variables); displayValFormals->variables = invalid_estr;
  }
  QDialog::done(result);
}


