#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QPushButton>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QTextEdit>
#include "LoadSaveAtmt.h"
#include "TreeWidget.h"

class MainWindow; class AtmtWatch; class TapeWatch; class ExecEnv; class AtmtCanvas; class AtmtTreeWidget; class Automaton;
class ViewQuickHelp; class SelectNewAtmt; class AtmtSettings; // class ViewCFSL; 
class QSplitter; class QFrame; class QLabel; class QStackedWidget; class QPushButton; class QAction; class QPlainTextEdit; class QTextEdit;

enum { MS_predef_machine_count = 5 };

struct SubscriptedText {
  SubscriptedText( const char *bt, const char *uit, const char *lit ) : baseText(bt), upperIdxText(uit), lowerIdxText(lit) { };
  const char *baseText, *upperIdxText, *lowerIdxText;
};

extern const char *MS_predef_machine[MS_predef_machine_count];
extern const struct SubscriptedText MS_predef_machine_fmt[MS_predef_machine_count];

class SubscriptedPushButton : public QPushButton {
public:
  SubscriptedPushButton( const struct SubscriptedText *st, QString resultText, QFont baseFont, QWidget *parent );
  QString getResultText() { return resultText; }
protected:
  void paintEvent(QPaintEvent *e);
  QString resultText, baseText, upperIdxText, lowerIdxText;
  QFont baseFont, sub1Font;
};

class ButtonSidebar : public QWidget {
public:
  SubscriptedPushButton *MS_predef_machines_button[MS_predef_machine_count];
  ButtonSidebar( QWidget *receiver );
};

extern QStringList recentFiles;

class MainWindow;

class ButtonDockWidget : public QWidget {
public:
  ButtonDockWidget(MainWindow *mainWin);
};

class FTextEdit : public QTextEdit {
public:
  FTextEdit( MainWindow *mainwin, QWidget * parent = 0 ) : QTextEdit(parent), mainWindow(mainwin) {};
  MainWindow *mainWindow;
protected:
  void focusInEvent(QFocusEvent * event);
};

class FPlainTextEdit : public QPlainTextEdit {
public:
  FPlainTextEdit( MainWindow *mainwin, QWidget * parent = 0 ) : QPlainTextEdit(parent), mainWindow(mainwin) {};
  MainWindow *mainWindow;
  void lostFocus(QWidget *lost_to);
protected:
  bool event(QEvent *event);
};

class MainWindow : public QMainWindow {
  Q_OBJECT
public:
  MainWindow();
  QStackedWidget *leftstack, *mainstack, *descriptionStack;
  AtmtWatch *viewOnlyAtmt, *viewAtmt; TapeWatch *viewTape, *addTapeView; ExecEnv *execEnv;
  AtmtCanvas *editAtmt; AtmtTreeWidget *atmtTreeWidget; struct AtmtTreeBase treeBase;
  FPlainTextEdit *editDescription; FTextEdit *viewDescription;
  QSplitter *tapeSplitter, *treeViewSplitter, *descriptionSplitter;
  ButtonSidebar *buttonSidebar; ButtonDockWidget *buttonDock; QLabel *statusBarLabel;
  bool descriptionIsEdited;
private:
  QString curFile; bool isUntitled;
  enum { MaxRecentFiles = 5 };
  QAction *recentFileActions[MaxRecentFiles];
  QAction *newAction, *openAction, *saveAction, *saveAsAction, *importAction, *exportAction, *separatorAction ,*closeAction, *exitAllAction;
  QAction *printAtmtTreeAction, *quickHelpAction, *aboutAction, *aboutQtAction; //, *viewCFSLAction
  QAction *overviewModeAction, *editModeAction, *execModeAction;
  QAction *moveMachineUpAction, *moveMachineDownAction, *deleteMachineAction, *newMachineAction, *newDirectoryAction, *machineSettingsAction;
  QAction *execResetAction, *execSimulateAction, *execSingleStepAction, *execRunAction, *execRunThroughAction, *execSelectInputAction, *execOutcomeAction;
  ViewQuickHelp *viewQuickHelpDialog; SelectNewAtmt *selectNewAtmt; AtmtSettings *atmtSettings; //ViewCFSL *viewCFSLDialog; 
  void createActions();
  void createMenus();
  void enableExecMenu(bool enabled); void enableTreeViewMenu(bool enabled);
public:
  bool saveFile(QString filename); bool openFile(QString filename);
  void writeSettings(); void readSettings(); 
private:
  bool okToContinue(); void setCurrentFileName(QString fileName); QString strippedFileName(QString fullFileName);
  void updateRecentFileActions(); void updateAllRecentFileActions();
private slots:
  void closeEvent(QCloseEvent *event); void setModified(); void setModifiedIfEditingDescription(); void overviewMode(); void editMode(); void execMode();
  void openRecentFile(); void newFile(); bool open(); bool import(); bool SVGexport(); bool save(); bool saveAs(); 
  void printAtmtTree(); void quickHelp(); void about(); // void viewCFSL(); 
  void moveMachineUp(); void moveMachineDown(); void askDeleteMachine(); void newMachine(); void newDirectory(); void machineSettings();
public:
  void setAutomaton( Automaton *a );
  void changeStack( int stackpos );
  void keyPressEvent(QKeyEvent *event);
protected:
  void saveCurrentDescription( QTreeWidgetItem *previous );
protected slots:
  void buttonDockWidgetClicked();
  void focusChanged( QWidget *old, QWidget *now );
  void treeViewItemChanged( QTreeWidgetItem *current, QTreeWidgetItem *previous );
protected:
  QSize sizeHint() const;
};

#endif
