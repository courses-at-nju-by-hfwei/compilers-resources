#ifndef ATMT_CANVAS_H
#define ATMT_CANVAS_H

#include <QtWidgets/QWidget>
#include "automatdef.h"
#include "AtmtExec.h"

class QLineEdit;
class QMenu;

class AtmtCanvas : public AtmtWatch {
  Q_OBJECT
public:
  AtmtCanvas();
  bool keyPressed(QKeyEvent *event);
protected:
  void mouseMoveEvent(QMouseEvent *event);
  void mousePressEvent(QMouseEvent *event);
  void mouseReleaseEvent(QMouseEvent *event);
  void keyPressEvent(QKeyEvent *event);
  void mouseDoubleClickEvent(QMouseEvent *event);
  bool eventFilter(QObject *target,QEvent *event);
  void setupContextMenus();
  QMenu *nodeContextMenu, *edgeContextMenu; // int curButton; 
  QPointF rightClickPosition; bool didTrackBeforeClick;
  int edgeNodeTracked; 
  QAction *setStartNodeAction, *setFinalNodeAction;
  void prepareLineEdit( GraphElement *elm, QString editwhat );
protected slots:
  void lineEditFinished();
  void toggleStartNode(bool isStartNode); void toggleFinalNode(bool isFinalNode);
  void setLabelPosOneThird(); void setLabelPosOneHalf(); void setLabelPosTwoThirds();
  void editElement(); void deleteElement();
signals:
  void changed();
public slots:
  void unicodeLetterButtonClicked();
public:
  GraphElement* isThere( QPointF pos );
  void setActiveNode( Node *node );
  void setActiveEdge( Edge *edge );
  enum KindOfElm { nodes = 1, edges =2 }; 
  GraphElement* activateCurElm( QPointF pos, int kindOf = KindOfElm::nodes | KindOfElm::edges );
  void setAutomaton( Automaton *a ); bool escapeSlash, set_by_program;
  void finishEditing();
public:
  QLineEdit *lineEdit; GraphElement *editedElement = NULL;
  Node *movingNode; Edge *editedLabelEdge;
  Node *rubberLineStartNode; Edge *curCreatedEdge;
  Node *activeNode = NULL; Edge *activeEdge = NULL; GraphElement *activeElement = NULL;
};

#endif
