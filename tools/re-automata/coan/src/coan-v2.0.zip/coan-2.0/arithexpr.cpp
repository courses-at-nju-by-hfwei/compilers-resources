#include "arithexpr.h"

#define AE ArithmeticExpression 

#define isWhiteSpace(c) ( (c)==' ' || (c) == '\t' )

#define fetchRequiredNext(ErrFlag) { if( ++pos >= str.length ) { flags |= ErrFlag; position = pos; return new NumberConst( 0 ); } else c = str.chars[pos]; } 

AE::SubExpr* AE::NumberConst::parse( bool below_zero, estr_const str, int& position, int& flags ) {
  register int base = 10, c; bool hadbase = false, hadRangeErr = false;
  register unsigned char maxdigit, digitval;
  register int val = 0, nextval; 
  register int pos = position;
  c = str.chars[pos];
  if( c == '0' ) { base = 8; } 
  if( base == 8 && c=='x' )  { base = 16; fetchRequiredNext(MissingOperand); }
  do {
    maxdigit = '0' + base - 1; if( maxdigit > '9' ) maxdigit = '9';
    while( ( digitval = '0' <= c && c <= maxdigit ) || ( 'A' <= c && c <= 'A'+base-10 ) ) {
      if(digitval) digitval = c - '0'; else digitval = c - ('A'-10);
      nextval = val * base;
      if( nextval > val ) hadRangeErr = true;
      val = nextval - digitval;
      if( ++pos < str.length ) c = str.chars[pos]; else c = '\000';
    }
    if( c != '_' || hadbase || base != 10 ) break;
    base = val; val = 0; hadbase = true; fetchRequiredNext(RequiredDigit); position = pos;
  } while( base <= MAXBASE );
  if( base > MAXBASE ) flags |= InvalidBase;
  if( hadbase && position == pos ) flags |= RequiredDigit;
  if(!below_zero) { 
    if(unlikely( val == MinSigned(int) )) { hadRangeErr = true; val = MaxSigned(int); }
    else val = -val;   // space of allowed numbers has one more negativ number
  }
  position = pos;
  if(unlikely(hadRangeErr)) {
    flags |= RangeErr;
    return below_zero ? new NumberConst( MinSigned(int) ) : new NumberConst( MaxSigned(int) );
  }
  return new NumberConst( val );
}

#undef fetchRequiredNext

AE::SubExpr* AE::VariableExpr::parse( estr_const str, int& pos, int& flags ) {
  assert( pos < str.length && isLatinLetter( str.chars[pos] ) );
  SubExpr *result = new VariableExpr( str.chars + pos);
  pos += SymbolTable::varLength( str.chars + pos );
  if( pos > str.length ) flags |= VariableNameTransgressesLength;
  return result;
}

int AE::VariableExpr::eval( EvalParams &params ) {
  register long long result = SymbolTable::var_is_undefined; 
  if( params.localSymTab ) result = params.localSymTab->lookUp( varName );
  if( ( result & SymbolTable::var_is_undefined ) && params.globalSymTab ) result = params.globalSymTab->lookUp( varName );
  if( result & SymbolTable::var_is_undefined ) params.flags |= VariableNotFound;
  return (int)result;
}

inline bool doLookBeyondWhiteSpace( int lookAhead, estr_const str, int& pos ) { while( pos < str.length && isWhiteSpace(str.chars[pos]) ) pos++; return ( pos + lookAhead <= str.length ); } 
#define BeyondWhiteSpace(lookAhead) doLookBeyondWhiteSpace( lookAhead, str, pos )

AE::SubExpr* AE::BracketExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: (
  pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; return NULL; }    //  ¡¡ may return NULL only when at the end of the whole arithmentic expression !!
  SubExpr *bracketExpr = ChoiceExpr::parse( str, pos, flags );
  if( !BeyondWhiteSpace(1) ) flags |= MissingOrLateClosingBracket;  
  else if( str.chars[pos] == ':' ) { 
    flags |= MissingOrLateClosingBracket; 
    pos++; if(BeyondWhiteSpace(1)) delete ChoiceExpr::parse( str, pos, flags );
  } else if( str.chars[pos] != ')' ) flags |= MissingOrLateClosingBracket;   //  shall never be executed since ChoiceExpr::parse will only break on EOF, ':' and ')'.
  else ++pos;  // from now on we will simply assume that the closing bracket has already been read
  return bracketExpr;
}

bool hug = false;

AE::SubExpr* AE::FactorialExpr::parseWithHighPrecedence( bool negated, estr_const str, int& pos, int& flags ) {
  // lookAhead: 0..9, a..z, A..Z
  SubExpr *expr;
  if( isNumeral( str.chars[pos] ) ) expr = NumberConst::parse( negated, str, pos, flags );
  else { expr = VariableExpr::parse( str, pos, flags ); assert(!negated); }
  look_for_another_highPrecFactorialExpr:
    if( BeyondWhiteSpace(1) ) {
#ifndef __GNUC__
      echar c = str.chars[pos];
      if( ( 'a' <= c && c <= 'z' ) || ( 'A' <= c && c <= 'Z' ) ) {
	   expr = new FactorialExpr( Operator::Multiplication, expr, VariableExpr::parse( str, pos, flags ) ); 
	  goto look_for_another_highPrecFactorialExpr;
      } else if( '0' <= c && c <= '9' ) flags |= MissingOperator;
      else switch(c) {
#else
      switch(str.chars[pos]) {
	case 'a'...'z': case 'A'...'Z': 
	   expr = new FactorialExpr( Operator::Multiplication, expr, VariableExpr::parse( str, pos, flags ) ); 
	  goto look_for_another_highPrecFactorialExpr;
	case '0'...'9': flags |= MissingOperator; break;
#endif
	case ')': case '(': case '^': case '*': case '/': case '%': case '+': case '-': case '<': case '>': case '=': case '&': case '|': case '?': case ':': case '!': break;
	default: flags |= UnexpectedCharacter; break;
    }  }
  if(hug) cout << "hp-flags: " << flags << endl;
  return expr;
}

int AE::FactorialExpr::eval( EvalParams &params ) {
  register int leftVal = left->eval(params);
  register int rightVal = right->eval(params);
  if( operation == Operator::Multiplication ) {
    register long long result = leftVal * rightVal;
    if(likely( result == (int)result )) return (int)result;
    params.flags |= result < 0 ? Underflow : Overflow;
    return result < 0 ? MinSigned(int) : MaxSigned(int);
  } else {
    if(unlikely( !rightVal )) {
      params.flags |= DivisionByZero;
      if( operation == Operator::Division )
        return ( leftVal < 0 ) ? MinSigned(int) : MaxSigned(int);   // result like if there was a positive divisor (rightVal)
      params.flags |= NotAScalar;   // Modulo: no natural number with 0<=x && x<0 exists
      return 0;
    }
    if( operation == Operator::Division )
      return leftVal / rightVal;
    else
      return leftVal % rightVal;
  }
}

AE::SubExpr* AE::ExponentialExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: 0..9, a..z, A..Z, +, -, (
  SubExpr *subExpr, *expr = NULL; bool negated = false;
  had_another_neg_or_plus_operator:
#ifndef __GNUC__
    echar c = str.chars[pos];
    if( '0' <= c && c <= '9') { expr = FactorialExpr::parseWithHighPrecedence( negated, str, pos, flags ); negated = false; }
    else if( ( 'a' <= c && c <= 'z' ) || ( 'A' <= c && c <= 'Z' ) ) { expr = FactorialExpr::parseWithHighPrecedence( false, str, pos, flags ); }
    else switch(c) {
#else
    switch( str.chars[pos] ) {
      case '0'...'9': expr = FactorialExpr::parseWithHighPrecedence( negated, str, pos, flags ); negated = false; break;
      case 'a'...'z': case 'A'...'Z': expr = FactorialExpr::parseWithHighPrecedence( false, str, pos, flags ); break;
#endif
      case '-': negated = !negated; case '+': pos++; if( BeyondWhiteSpace(1) ) goto had_another_neg_or_plus_operator; else flags |= MissingOperand;
      case '(': expr = BracketExpr::parse( str, pos, flags ); break;
      case ')': case '^': case '*': case '/': case '%': case '!': case '<': case '>': case '=': case '&': case '|': case '?': case ':': 
	flags |= MissingOperand; break;
      default: flags |= UnexpectedCharacter; break;
    }
  if(!expr) return NULL;
  if( negated && expr ) expr = new NegateExpr(expr);
  if( BeyondWhiteSpace(1) )
    switch(str.chars[pos]) {
      case '^': if( pos+1 < str.length && str.chars[pos+1] == '^' ) break;
	 pos++; if( BeyondWhiteSpace(1) ) {
	   subExpr = ExponentialExpr::parse( str, pos, flags ); if(!subExpr) break;
	   expr = new ExponentialExpr( expr, subExpr ); 
	 } else flags |= MissingOperand; 
	break;
      case ')': case '(': case '*': case '/': case '%': case '+': case '-': case '<': case '>': case '=': case '&': case '|': case '?': case ':': case '!': break;
      default: flags |= UnexpectedCharacter; break;
    }
  if(hug) cout << "exp-flags: " << flags << endl;
  return expr;
}

int AE::ExponentialExpr::eval( EvalParams &params ) {
  register int base = basis->eval(params);
  register int exp = exponent->eval(params);
  if(unlikely( exp < 0 )) { params.flags |= ZeroedFraction; return 0; }
  register long long curBasePot = base, result = 1;
  while( exp ) {
    if( exp & 1 ) result *= curBasePot;
    curBasePot *= curBasePot;
    if(unlikely( result != (int)result || curBasePot != (int)curBasePot )) {
      params.flags |= Overflow;
      break;
    }
    exp >>= 1;
  }
  return (int) result;
}

AE::SubExpr* AE::FactorialExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: 0..9, a..z, A..Z, +, -, (
  SubExpr *expr = ExponentialExpr::parse( str, pos, flags ), *secondExpr;
  look_for_another_FactorialExpr:
    if( BeyondWhiteSpace(1) )
      switch(str.chars[pos]) {
	case '*': 
	   pos++; if( BeyondWhiteSpace(1) ) { 
	     secondExpr = ExponentialExpr::parse( str, pos, flags ); if( !secondExpr ) break;
	     expr = new FactorialExpr( Operator::Multiplication, expr, secondExpr ); 
	     goto look_for_another_FactorialExpr; 
	   } else flags |= MissingOperand; 
	  break;
	case '/': 
	   pos++; if( BeyondWhiteSpace(1) ) { 
	     secondExpr = ExponentialExpr::parse( str, pos, flags ); if( !secondExpr ) break;
	     expr = new FactorialExpr( Operator::Division, expr, secondExpr ); 
	     goto look_for_another_FactorialExpr; 
	   } else flags |= MissingOperand; 
	  break;
	case '%': 
	   pos++; if( BeyondWhiteSpace(1) ) { 
	     secondExpr = ExponentialExpr::parse( str, pos, flags ); if( !secondExpr ) break;
	     expr = new FactorialExpr( Operator::Modulo, expr, secondExpr ); 
	     goto look_for_another_FactorialExpr; 
	   } else flags |= MissingOperand; 
	  break;
	case '(': 
	   secondExpr = BracketExpr::parse( str, pos, flags ); if( !secondExpr ) break;
	   expr = new FactorialExpr( Operator::Multiplication, expr, secondExpr ); 
	  goto look_for_another_FactorialExpr;
	case ')': case '+': case '-': case '<': case '>': case '=': case '&': case '|': case '^': case '?': case ':': case '!': break;
	default: flags |= UnexpectedCharacter; break;
      }
  if(hug) cout << "fact-flags: " << flags << endl;
  return expr;
}

AE::SubExpr* AE::AdditionExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: 0..9, a..z, A..Z, +, -, (
  SubExpr *expr = FactorialExpr::parse( str, pos, flags ), *secondExpr;
  look_for_another_AdditionExpr:
    if( BeyondWhiteSpace(1) )
      switch(str.chars[pos]) {
	case '+': 
	   pos++; if( BeyondWhiteSpace(1) ) { 
	     secondExpr = FactorialExpr::parse( str, pos, flags ); if(!secondExpr) break;
	     expr = new AdditionExpr( Plus, expr, secondExpr ); 
	     goto look_for_another_AdditionExpr; 
	   } else flags |= MissingOperand; 
	  break; 
	case '-': 
	   pos++; if( BeyondWhiteSpace(1) ) { 
	     secondExpr = FactorialExpr::parse( str, pos, flags ); if(!secondExpr) break;
	     expr = new AdditionExpr( Minus, expr, secondExpr ); 
	     goto look_for_another_AdditionExpr; 
	   } else flags |= MissingOperand; 
	  break; 
	case ')': case '<': case '>': case '=': case '&': case '|': case '^': case '?': case ':': case '!': break;
	default: flags |= UnexpectedCharacter; break;
      }
  // if( flags & isBoolean ) { flags |= TypeMismatch; flags &= ~ isBoolean; };
  if(!expr) expr = new NumberConst(0);  // from now on continue to calaculate with zero or false if there was a missing operand / bracket expression
  if(hug) cout << "add-flags: " << flags << endl;
  return expr;
}

int AE::AdditionExpr::eval( EvalParams &params ) {
  register int leftVal = left->eval(params);
  register int rightVal = right->eval(params);
  register long long sum = ( operation == Plus ? leftVal + rightVal : leftVal - rightVal );
  if(unlikely( sum != (int)sum )) {
    if( sum < 0 ) { params.flags |= Underflow; return MinSigned(int); }
    params.flags |= Overflow;
    return MaxSigned(int);
  }
  return (int) sum;
}

const echar AE::CompareExpr::Operator2EChar[] = { '<', leq_char, '=', neq_char, geq_char, '>'  }; 

AE::SubExpr* AE::CompareExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: 0..9, a..z, A..Z, +, -, (
  SubExpr *finalExpr, *newExpr, *expr = AdditionExpr::parse( str, pos, flags );
  enum Operator op; finalExpr = expr; echar c;
  look_for_next_CompareExpr:
    if( BeyondWhiteSpace(1) )
      switch(( c = str.chars[pos] )) {
	case '<': case '>': case '=': case '!': case neq_char:
	   switch(c) {
	     case '<': op = Less; if( ++pos < str.length && str.chars[pos] == '=' ) { ++pos; op = LowerEq; }; break;
	     case '>': op = More; if( ++pos < str.length && str.chars[pos] == '=' ) { ++pos; op = GreaterEq; }; break;
	     case leq_char: op = LowerEq; ++pos; break;
	     case geq_char: op = GreaterEq; ++pos; break;
	     case '=': op = Equal; if( ++pos < str.length && str.chars[pos] == '=' ) ++pos; break;
	     case neq_char: op = NotEqual; ++pos; break;
	     case '!': if( ++pos < str.length && str.chars[pos] == '=' ) { op = NotEqual; ++pos; } else --pos; break;
	   }
	   if( str.chars[pos] == '!' ) { flags |= MissingOperand; break; }
	   if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 
	   if( finalExpr == expr ) finalExpr = new CompareExpr( op, finalExpr, ( expr = AdditionExpr::parse( str, pos, flags ) ) ); 
	   else { finalExpr = new LogicalExpr( LogicalExpr::And, finalExpr, new CompareExpr( op, expr, ( newExpr = AdditionExpr::parse( str, pos, flags ) ) ) ); expr = newExpr; } 
	  goto look_for_next_CompareExpr;
	case ')': case '&': case '|': case '^': case '?': case ':': break;
	default: flags |= UnexpectedCharacter; break;
      }
  if(hug) cout << "cmp-flags: " << flags << endl;
  return finalExpr;
}

AE::LogicalExpr::~LogicalExpr() {
  CompareExpr *rightCompare = dynamic_cast<CompareExpr*>(right);
  LogicalExpr *leftLogical = dynamic_cast<LogicalExpr*>(left);
  if( rightCompare ) {
    if( leftLogical ) {
      CompareExpr *leftRightCompare = static_cast<CompareExpr*>(leftLogical->right);
      if( leftRightCompare && leftRightCompare->right == rightCompare->left ) rightCompare->left = NULL; 
    } else {
      CompareExpr *leftCompare = dynamic_cast<CompareExpr*>(left);
      if( leftCompare && leftCompare->right == rightCompare->left ) rightCompare->left = NULL;
  } }
  delete left; delete right;
}

int AE::CompareExpr::eval( EvalParams &params ) {
  register int leftVal = left->eval(params);
  register int rightVal = right->eval(params);
  switch( operation ) {
    case Less: return leftVal < rightVal;
    case LowerEq: return leftVal <= rightVal;
    case Equal: return leftVal == rightVal;
    case NotEqual: return leftVal != rightVal;
    case GreaterEq: return leftVal >= rightVal;
    case More: return leftVal > rightVal;
    default: cerr << "unknown compare operation" << endl;
  }
  return 0;
}

int AE::NotExpr::eval( EvalParams &params ) {
  register int baseVal = base->eval(params);
  return !baseVal;
}

int AE::LogicalExpr::eval( EvalParams &params ) {
  register int leftVal = left->eval(params);
  register int rightVal = right->eval(params);
  switch( operation ) {
    case And: return leftVal && rightVal;
    case Or: return leftVal || rightVal;
    case Xor: return !leftVal ^ !rightVal;
    default: cerr << "unknown logical operation" << endl;
  }
  return 0;
}

AE::SubExpr* AE::NotExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: !, 0..9, a..z, A..Z, +, -, (, on error: any other character
  SubExpr *expr = NULL; bool appliedNot = false;
  look_for_another_NotOperator:
    if( BeyondWhiteSpace(1) ) {
#ifndef __GNUC__
      echar c = str.chars[pos];
      if( ( '0' <= c && c <= '9' ) || ( 'a' <= c && c <='z' ) || ( 'A' <= c && c <= 'Z' ) || c=='(' || c=='+' || c=='-' )
        expr = CompareExpr::parse( str, pos, flags );
      else switch(c) {
#else
      switch(( str.chars[pos] )) {
	case '0'...'9': case 'a'...'z': case 'A'...'Z': case '(': case '+': case '-':
           expr = CompareExpr::parse( str, pos, flags );
	  break;
#endif
	case '!': 
	   pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 
	   appliedNot = !appliedNot;
	  goto look_for_another_NotOperator;
	case ')': case '^': case '*': case '/': case '%': case '<': case '>': case '=': case '&': case '|': case '?': case ':': 
	  break;
	default: 
	   expr = new NumberConst(0); flags |= UnexpectedCharacter; 
	  break;
    } }
  if(!expr) { expr = new NumberConst(0); flags |= MissingOperand; }
  if( appliedNot ) expr = new NotExpr( expr ); 
  if(hug) cout << "not-flags: " << flags << endl;
  return expr;
}

AE::SubExpr* AE::LogicalExpr::parseXor( estr_const str, int& pos, int& flags ) {
  // lookAhead: !, 0..9, a..z, A..Z, +, -, (, on error: any other character
  SubExpr *expr = NotExpr::parse( str, pos, flags );
  look_for_another_XorExpr:
    if( BeyondWhiteSpace(2) )
      switch(( str.chars[pos] )) {
	case '^': 
	   if( str.chars[++pos] != '^' ) { flags |= UnknownOperator; break; }
	   pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 
	   expr = new LogicalExpr( Operator::Xor, expr, NotExpr::parse( str, pos, flags ) ); 
	  goto look_for_another_XorExpr;
	case ')': case '&': case '|': case '?': case ':': break;
	default: flags |= UnexpectedCharacter; break;
      }
  if(hug) cout << "xor-flags: " << flags << endl;
  return expr;
}

AE::SubExpr* AE::LogicalExpr::parseAnd( estr_const str, int& pos, int& flags ) {
  // lookAhead: !, 0..9, a..z, A..Z, +, -, (, on error: any other character
  SubExpr *expr = LogicalExpr::parseXor( str, pos, flags );
  look_for_another_AndExpr:
    if( BeyondWhiteSpace(2) )
      switch(( str.chars[pos] )) {
	case '&': 
	   if( str.chars[++pos] != '&' ) { flags |= UnknownOperator; break; }
	   pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 
	   expr = new LogicalExpr( Operator::And, expr, LogicalExpr::parseXor( str, pos, flags ) ); 
	  goto look_for_another_AndExpr;
	case ')': case '|': case '?': case ':': break;
	default: flags |= UnexpectedCharacter; break;
      }
  if(hug) cout << "and-flags: " << flags << endl;
  return expr;
}

AE::SubExpr* AE::LogicalExpr::parseOr( estr_const str, int& pos, int& flags ) {
  // lookAhead: !, 0..9, a..z, A..Z, +, -, (, on error: any other character
  SubExpr *expr = LogicalExpr::parseAnd( str, pos, flags );
  look_for_another_OrExpr:
    if( BeyondWhiteSpace(2) )
      switch(( str.chars[pos] )) {
	case '|': 
	   if( str.chars[++pos] != '|' ) { flags |= UnknownOperator; break; }
	   pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 
	   expr = new LogicalExpr( Operator::Or, expr, LogicalExpr::parseAnd( str, pos, flags ) ); 
	  goto look_for_another_OrExpr;
	case ')': case '?': case ':': break;
	default: flags |= UnexpectedCharacter; break;
      }
  if(hug) cout << "or-flags: " << flags << endl;
  return expr;
}

/*
  cout << "----- (" << endl;
  cout << "{" << str.sub(0,pos) << "|" << str.sub(pos) << "}" << endl;
  cout << ") ----- " << endl;
*/

AE::SubExpr* AE::ChoiceExpr::parse( estr_const str, int& pos, int& flags ) {
  // lookAhead: !, 0..9, a..z, A..Z, +, -, (, on error: any other character
  SubExpr *expr = LogicalExpr::parseOr( str, pos, flags );
  SubExpr *expr4True;
  if( BeyondWhiteSpace(1) )
    switch(( str.chars[pos] )) {
      case '?': 
	 pos++; if(!BeyondWhiteSpace(1)) { flags |= MissingOperand; break; } 

	 expr4True = ChoiceExpr::parse( str, pos, flags );

	 if( !BeyondWhiteSpace(1) || str.chars[pos] == ')' ) flags |= MissingOperand;
         else if( str.chars[pos] != ':' ) flags |= UnknownOperator; 
	 if( pos >= str.length || str.chars[pos] != ':' ) {
	   expr = new ChoiceExpr( expr, expr4True, new NumberConst( 0 ) ); 
	   break; 
	 }

	 expr = new ChoiceExpr( expr, expr4True, ChoiceExpr::parse( str, ++pos, flags ) ); 

	break;
      case ')': case ':': break;
      default: flags |= UnexpectedCharacter; break;
    }
  return expr;
}

int AE::ChoiceExpr::eval( EvalParams &params ) {
  register int condVal = condition->eval(params);
  if( condVal ) return whenTrue->eval(params);
  else return whenFalse->eval(params);
}

// ArithmeticExpression *nae = new arithmetic expression

void ArithmeticExpression::parse( estr_const inputString, int *position, int *errFlags ) {
  if( baseExpr ) delete baseExpr;
  int pos = 0, flags = 0; 
  if( position ) pos = *position;
  content = inputString; while( pos < inputString.length && isWhiteSpace(inputString.chars[pos]) ) pos++;
  if( pos >= inputString.length || inputString.isInvalid() ) {
    baseExpr = new NumberConst( 0 );
    flags = MissingOperand;
  } else if( inputString.chars[pos] == '(' ) {
    baseExpr = BracketExpr::parse( inputString, pos, flags );
  } else {
    baseExpr = ChoiceExpr::parse( inputString, pos, flags );
  }
  if( position ) *position = pos;
  if( errFlags ) *errFlags = flags;
}

ArithmeticExpression::ArithmeticExpression( estr_const inputString, int *position, int *errFlags ) {
  baseExpr = NULL;
  this->parse( inputString, position, errFlags );
}

const char* ArithmeticExpression::FlagBit2Text[] { "UnexpectedCharacter", "UnknownOperator", "MissingOperator", "MissingOperand", "MissingOrLateClosingBracket", "RequiredDigit", "RangeErr", "InvalidBase", 
	       "TypeMismatch", "VariableNameTransgressesLength", "isBoolean",
	       // evaluation Flags & ErrorFlags
               "VariableNotFound", "Underflow", "Overflow", "DivisionByZero", "NotAScalar", "ZeroedFraction"
	      };

const int ArithmeticExpression::FlagBit2TextMaxShift = sizeof(FlagBit2Text) / sizeof(const char*);

bool ArithmeticExpression::printFlags( IOStream &out, int flags ) {
  int i = 0; bool needsColon = false;
  while( flags && i < FlagBit2TextMaxShift ) {
    if( flags & 1 ) {
      if( needsColon ) out << ", ";
      out << FlagBit2Text[i];
      needsColon = true;
    }
    ((unsigned int&)flags) >>= 1; i++;
  }
  if( flags ) { 
    if( needsColon ) out << ", ";
    out << "unknown flags";
  }
  return out;
}

