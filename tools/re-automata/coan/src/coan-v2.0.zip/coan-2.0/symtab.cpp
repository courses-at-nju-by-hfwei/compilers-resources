#ifdef QT_CORE_LIB
 #include <QtCore/QRegExp>
#endif
#include <memory>
#include <assert.h>
#include "symtab.h"

using namespace aux;

const echar echars_epsilon[2] = { epsilon_letter, 0 }, echars_neq_char[2] = { neq_char, 0}, echars_eq_char[2] = { '=', 0 }, echars_empty_set_char[2] = { empty_set_char, 0 }; 
const estr_const estr_epsilon(echars_epsilon,1), estr_neq_char(echars_neq_char,1), estr_eq_char(echars_eq_char,1), estr_empty_set_char(echars_empty_set_char,1);

__pure_const inline bool input_char_allowed( wchar c ) { // setminus_4_editing_char is allowed but needs to be checked for separately, chars for and within subscripts may still return false (still almost anything is allowed within a subscript)!
  if( c <= 0xFF || ( c >= first_greek_letter && c <= last_greek_letter ) ) return true;
  switch(c) {
    case unicode_space: case range_char: case neq_char: case setminus_char: case concat_char: case SlashSeparator: return true;
    default: return false;
  }
}

void*(*alloc)(size_t) = malloc;
void(*dealloc)(void*,size_t) = aux::std_dealloc;

//
// SymbolTable implementation
//

#ifndef _MSC_VER
 SymbolTable::Entry one_empty_entry = { .index = NULL, .content = 0, .varlen = 0, .varbstb = 0, .first_index_char = 0 };
#else
 SymbolTable::Entry one_empty_entry = { NULL, 0, 0, 0, 0 };
#endif
SymbolTable emptySymbolTable( &one_empty_entry, 0, 1 );

#define EntrySize mem_align(sizeof(Entry),sizeof(void*))
#define SymbolTableSize mem_align(sizeof(SymbolTable),EntrySize)

SymbolTable* SymbolTable::allocate_new( int num_entries, int table_size ) {
  assert( num_entries <= table_size );
  char *table_mem = (char*)alloc( SymbolTableSize + EntrySize * table_size );
  return new((SymbolTable*)table_mem) SymbolTable( (Entry*)( table_mem + SymbolTableSize ), num_entries, table_size );
}

__warn_unused_result SymbolTable* SymbolTable::reserveEmpty( int prospective_entry_num ) {
  int table_size = prospective_entry_num * 2 + 1; if( table_size < 0 ) table_size = 1;  // get an odd number of entries
  char *table_mem = (char*)alloc( SymbolTableSize + EntrySize * table_size );
  SymbolTable *symtab = new((SymbolTable*)table_mem) SymbolTable( (Entry*)( table_mem + SymbolTableSize ), 0, table_size );
  for( register int i=0; i < table_size; i++ ) symtab->entry[i].varbstb = 0;
  return symtab;
}

SymbolTable* SymbolTable::copy() const {
  SymbolTable *new_table = (SymbolTable*)alloc( SymbolTableSize + EntrySize * table_size );
  memcpy( new_table, this, SymbolTableSize + EntrySize * table_size );
  return new_table;
}

inline int SymbolTable::hash( achar var_num, const echar *variable, int *var_len, int *jump_len ) const { 
  register u_iword hash = var_num << 1;
  if( *++variable != subscript_char ) { *var_len = *jump_len = 1; return (int)( hash % (unsigned int) table_size ); }
  register int len = 2; register echar c; int tmplen = 0;
  int subscript_nest = 0; register int buf_count = 9;  // 9 ~ 18bit belegt sobald hash += c; (eigentlich 1bit weniger) - die ersten beiden Zeichen
  if( isChar4VariableIndex(( c = *++variable )) || c == subscript_char ) {
    if( c == subscript_char ) subscript_nest++;
    else { len++; hash += c; }
    do {
      while( isChar4VariableIndex(( c = *++variable )) ) {
	hash *= 3; hash += c; len++; buf_count++;
	if( buf_count >= ( sizeof(u_iword) < 8 ? 16 :  32 ) ) {  // most variables are shorter than 8 chars so the division would only need to be performed once
	  hash %= (unsigned int) table_size; 
	  buf_count = 8;  
	}
      }
      if( c == ' ' && subscript_nest <= 0 ) { tmplen=1; break; }
      if( c != subscript_char && c != ' ' ) { if( c == close_subscripts_char ) tmplen=1; break; }
      if( c == subscript_char ) subscript_nest++; else { subscript_nest--;
	// recognize the same variable with nested subscritps in spite of excess spaces at the end (would basically not be necessary for normalized estrs)
	tmplen = 1; while( subscript_nest >= 0  && ( c = *++variable ) == ' ' ) { subscript_nest--; tmplen++; }
	if( subscript_nest < 0 || ( !isChar4VariableIndex(c) && c != subscript_char ) ) break; 
	len += tmplen; hash += tmplen;
      }
      hash = hash * 3 + c; len++; buf_count++;
    } while( true );
  } 
  if( len > 2 ) *var_len = len; else *var_len = 1;
  *jump_len = len + tmplen; // last terminating space shall be jumped over ( i.e. it is not interpreted as it merely serves to terminate 
  return (int)( hash % (unsigned int) table_size );   // *jump_len = len + 1: count subscript_char only for jump_len
}

int SymbolTable::varLength( const echar *variable, int *true_len ) {   // returns solely var_length but does not perform a lookup - compare with hash
  // assume that the first character has already been checked with 
  if( *++variable != subscript_char ) { if(true_len) *true_len = 1; return 1; }
  register int jump_len = 2; int subscript_nest = 0;
  register echar c; int trueLen = 1;
  do {
    if( isChar4VariableIndex(( c = *++variable )) ) {
      do { jump_len++; } while( isChar4VariableIndex(( c = *++variable )) );
      trueLen = jump_len;
    }
    if( c == ' ' && subscript_nest <= 0 ) break;
    if( c != subscript_char && c != ' ' ) break;
    if( c == subscript_char ) subscript_nest++; else subscript_nest--;
    jump_len++;
  } while( true );
  if(true_len) *true_len = trueLen;
  jump_len += ( c == ' ' || c == close_subscripts_char ); // last terminating space shall be jumped over ( i.e. it is not interpreted as it merely serves to terminate 
  return jump_len;
}

//
// that does not guarantee yet that variables are well-formed:
//   i.e. remove empty subscripts, remove ε from strbuf before it is finally used
//        unescape \... sequences
//        better readable: also collapse multiple spaces at the end of the variable into one close_subscript_char
//
// -> have a look at SmybolTable::normalize
//

#define index_offset 3
#define tailcmp(varlen,entry,index_str) ( varlen <= 2 || ( entry.first_index_char == index_str[-1] && ( varlen <= 3 || !memcmp( entry.index, index_str, (varlen-index_offset)*sizeof(echar) )  ) ) )

long long SymbolTable::lookUp( const echar *variable ) const {
  echar first_char = *variable; assert( usage_count > 0 );
  if(unlikely(!maySet(first_char))) return ( first_char <= 0xFF ? first_char : unknown_achar ) | ( (long long)3 << 32 );
  register achar var_num = varbstb2num( first_char );
  int var_len, skip_len; register int index = hash( var_num, variable, &var_len, &skip_len );
  register int primary_index = index;
  variable += index_offset; // if used from hereon only the subscript of the variable will be interesting
  if( this )
    do {
      if( entry[index].varbstb == var_num && entry[index].varlen == var_len && tailcmp(var_len,entry[index],variable) ) 
	return entry[index].content | ( (long long)skip_len << 33 );
      if( !entry[index].varbstb ) break;
      index++; if( index >= table_size ) index = 0;
    } while( index != primary_index );
  return initialValue(first_char) | ( (long long)skip_len << 33 ) | ( (long long)1 << 32 ); 
}

int SymbolTable::lookUpEntry( const echar *variable, int **content_ptr, int *true_len ) {
  echar first_char = *variable; assert( usage_count > 0 );
  if(!maySet(first_char)) { *content_ptr = NULL; if(true_len) *true_len=1; return 1; }
  register achar var_num = varbstb2num( first_char );
  int var_len, skip_len; register int index = hash( var_num, variable, &var_len, &skip_len );
  register int primary_index = index;
  if( true_len ) *true_len = var_len;
  variable += index_offset; // if used from hereon only the subscript of the variable will be interesting
  if( this )
    do {
      if( entry[index].varbstb == var_num && entry[index].varlen == var_len && tailcmp(var_len,entry[index],variable) ) {
	*content_ptr = (int*) &entry[index].content; return skip_len;
      }
      if( !entry[index].varbstb ) break;
      index++; if( index >= table_size ) index = 0;
    } while( index != primary_index );
  *content_ptr = NULL; 
  return skip_len;
}

#define an_entry one_empty_entry

void SymbolTable::removeEntry( int *content_ptr ) {
  Entry *this_entry = (Entry*)( (char*)content_ptr - ( (char*)&(an_entry.content) - (char*)&an_entry ) );
  assert( entry <= this_entry && this_entry <= entry + (table_size-1) );
  if( this_entry->varbstb != 0 ) {
    entry_num--;
    this_entry->varbstb = 0;
  }
}

void SymbolTable::forall( ReadVarProc proc, void *data ) {
  int symbols_found = 0;
  for( int j=0; j < table_size; j++ )
    if( entry[j].varbstb ) { 
      proc( this, estr_const( entry[j].index - index_offset, entry[j].varlen ), (int)entry[j].content, data );
      symbols_found++;
    }
  assert( symbols_found == entry_num );
}

void SymbolTable::forallEntry( ProcessVarProc proc, void *data ) {
  int symbols_found = 0;
  for( int j=0; j < table_size; j++ )
    if( entry[j].varbstb ) { 
      proc( this, estr_const( entry[j].index - index_offset, entry[j].varlen ), (int*)&(entry[j].content), data );
      if( entry[j].varbstb ) symbols_found++;   // entry could have been deleted in the meantime
    }
  assert( symbols_found == entry_num );
}

SymbolTable* SymbolTable::print( IOStreamRef out, const char *sep ) {
  int symbols_found = 0;
  if(!this) { out << "<(SymbolTable*)NULL>"; return this; }
  int seplen = strlen(sep);
  bool condensed = !seplen || sep[seplen-1] != ' '; 
  for( int j=0; j < table_size; j++ )
    if( entry[j].varbstb ) { 
      if( symbols_found ) out << sep;
      out << estr_const( entry[j].index - index_offset, entry[j].varlen ) << ( condensed ? "=" : " = " );
      if( entry[j].varbstb <= greek_letter_num ) out << "'" << EChar(entry[j].content) << "'"; else out << (int)entry[j].content;
      symbols_found++;
    }
  assert( symbols_found == entry_num );
  return this;
}

int SymbolTable::compare( SymbolTable* another ) const {
  if( this == another ) return 0; else if(!this) return -1; else if(!another) return +1;
  int delta = entry_num - another->entry_num;
  if( delta ) return delta < 0 ? -1 : +1;
  for( int j=0; j < table_size; j++ )
    if( entry[j].varbstb ) { 
      long long aol = another->lookUp( entry[j].index - index_offset );
      if( aol & var_is_undefined ) return +1;
      delta = entry[j].content - (int)aol;
      if( delta ) return delta < 0 ? -1 : +1;
    }
  return 0;
}

SymbolTable* SymbolTable::copy_acquireSymsFrom( const SymbolTable *overrideSyms ) {
  if( !overrideSyms || !overrideSyms->entry_num ) return this->anotherInstance();
  SymbolTable *newTab = this, *prevTab;
  for( int j=0; j < overrideSyms->table_size; j++ ) {
    struct Entry *cur = &(overrideSyms->entry[j]);
    if( cur->varbstb ) {
      prevTab = newTab;
      newTab = newTab->set_and_copy( cur->index - index_offset, cur->content );
      if( prevTab != this ) freeMem(prevTab);
  } }
  return newTab;
}


void SymbolTable::CopyToNewTable( SymbolTable *new_table, Entry new_entry ) const {
  int new_size = new_table->table_size;
  for( register int i=0; i < new_size; i++ ) new_table->entry[i].varbstb = 0; // memset( new_table->entry, 0, EntrySize * new_size );
  int var_len, skip_len, index;
  int upper_bound = table_size;
  for( index=0; index <= upper_bound; index++ ) {
    register achar vnum; register int idx, start_idx; const echar *varname;
    bool isTheNewEntry = !( index < table_size ); 
    if( index < table_size ) { 
      vnum = entry[index].varbstb; 
      varname = entry[index].index - index_offset;
      // isTheNewEntry = false;
    } else { 
      vnum = new_entry.varbstb;
      varname = new_entry.index - index_offset;
      // isTheNewEntry = true;
    }
    if(vnum) {
      start_idx = idx = new_table->hash( vnum, varname, &var_len, &skip_len );
      do {
	if( !new_table->entry[idx].varbstb ) break;
	idx++; if( idx >= new_size ) idx = 0;
	assert( idx != start_idx );
      } while( true );
      isTheNewEntry = isTheNewEntry || ( vnum == new_entry.varbstb && var_len == new_entry.varlen && tailcmp( new_entry.varlen, entry[index], new_entry.index ) ); 
      if( !isTheNewEntry ) {
        new_table->entry[idx] = entry[index];
      } else {
        new_table->entry[idx] = new_entry;
	upper_bound--;
      }
      new_table->entry_num++;
    }
  }
}

SymbolTable* SymbolTable::set( const echar *variable, int value, int *pos_inc, enum VarSetMode mode, int *true_len ) {
  assert(this); assert( entry_num >= 0 ); assert( table_size >= 0 ); assert(variable); /* if( entry_num > table_size ) cerr << entry_num << "##" << table_size << endl; */ assert( entry_num <= table_size );
  echar first_char = *variable; if(!maySet(first_char)) { if( pos_inc ) *pos_inc += 1; if(true_len) *true_len=1; return this; }
  register achar var_num = varbstb2num( first_char );
  int var_len, skip_len; register int index = hash( var_num, variable, &var_len, &skip_len );
  register int primary_index = index; int add_search_count = 0;
  if( pos_inc ) *pos_inc += skip_len;
  if( true_len ) *true_len = var_len;
  variable += index_offset; // if used from hereon only the subscript of the variable will be interesting
  do {
    if( entry[index].varbstb == var_num && entry[index].varlen == var_len && tailcmp(var_len,entry[index],variable) ) {
      if( mode != set_if_undefined ) entry[index].content = value; 
      return this;
    }
    if( !entry[index].varbstb ) break;
    index++; if( index >= table_size ) index = 0;
    add_search_count++;
  } while( index != primary_index );
  if( mode == set_if_defined ) return this;
  int min_size;  if( add_search_count > 2 ) min_size = entry_num * 2 - ( entry_num >> 1 ) + 1;   // not necessary here: adding additional entries for alignment, 
#ifndef _MSC_VER
  Entry new_entry { .index = variable, .content = (unsigned int)value, .varlen = (achar)var_len, .varbstb = var_num, .first_index_char = var_len > 2 ? variable[-1] : (echar)0 };
#else
  Entry new_entry { variable, (unsigned int)value, (achar)var_len, var_num, var_len > 2 ? variable[-1] : (echar)0 };
#endif
  if( ( add_search_count <= 2 || min_size <= table_size ) && index != primary_index ) {
    entry[index] = new_entry; entry_num++;
    return this;
  }
  register int new_size = entry_num * 2 + 1;   // get an odd number of entries,  entry_num * 2 + 3 == ( entry_num + 1 )*2 + 1
  SymbolTable *new_table = allocate_new( 0, new_size );
  CopyToNewTable( new_table, new_entry );
  if( --usage_count <= 0) dealloc( this, mem_align(sizeof(SymbolTable),sizeof(Entry)) + sizeof(Entry) * table_size );
  return new_table;
}

void SymbolTable::freeMem( SymbolTable *symtab ) {
  if(!symtab) return;
  symtab->usage_count--;
  if( symtab->usage_count > 0 ) return;
  if(unlikely( symtab == &emptySymbolTable )) { 
    cerr << "SymbolTable::freeMem: emptySymbolTable had a wrong usage count (never use &emptySymbolTable but always emptySymbolTable.anotherInstance())!" << endl; 
    return; 
  }
  dealloc( symtab, mem_align(sizeof(SymbolTable),sizeof(Entry)) + sizeof(Entry) * symtab->table_size );
}

void SymbolTable::free( SymbolTable **symtab ) {
  if(!*symtab) return;
  (*symtab)->usage_count--;
  //if( *symtab == &emptySymbolTable ) return;
  if( (*symtab)->usage_count <= 0 ) {
    if(unlikely( *symtab == &emptySymbolTable )) cerr << "SymbolTable::free: emptySymbolTable had a wrong usage count (never use &emptySymbolTable but always emptySymbolTable.anotherInstance())!" << endl;
    else dealloc( *symtab, mem_align(sizeof(SymbolTable),sizeof(Entry)) + sizeof(Entry) * (*symtab)->table_size );
  }
  (*symtab) = NULL;
}

SymbolTable* SymbolTable::set_and_copy_by_index( int index, int is_a_new_var, Entry new_e ) const {
  SymbolTable *new_table = allocate_new( entry_num + is_a_new_var, table_size );
  if( table_size > 1 ) memcpy( new_table->entry, entry, EntrySize * table_size );
  new_table->entry[index] = new_e;
  return new_table;
}

SymbolTable* SymbolTable::set_and_copy( const echar *variable, int value ) const {
  assert(this); assert( entry_num >= 0 ); assert( table_size >= 0 ); assert(variable); /* if( entry_num > table_size ) cerr << entry_num << "##" << table_size << endl; */ assert( entry_num <= table_size );
  echar first_char = *variable;
  if(!maySet(first_char)) { usage_count++; return const_cast<SymbolTable*>(this); }
  register achar var_num = varbstb2num( first_char );
  int var_len, skip_len; register int index = hash( var_num, variable, &var_len, &skip_len ); 
  register int next_index = index + 1 >= table_size ? 0 : index + 1; 
#ifndef _MSC_VER
  variable += index_offset; Entry new_entry { .index = variable, .content = (unsigned int)value, .varlen = (achar)var_len, .varbstb = var_num, .first_index_char = var_len > 2 ? variable[-1] : (echar)0 };
#else
  variable += index_offset; Entry new_entry { variable, (unsigned int)value, (achar)var_len, var_num, var_len > 2 ? variable[-1] : (echar)0 };
#endif

  if( entry[index].varbstb == var_num && entry[index].varlen == var_len && tailcmp( var_len, entry[index], variable ) ) 
    return set_and_copy_by_index( index, 0, new_entry );
  if( !entry[index].varbstb )
    return set_and_copy_by_index( index, +1, new_entry );
  if( entry[next_index].varbstb == var_num && entry[next_index].varlen == var_len && tailcmp( var_len, entry[next_index], variable ) )
    return set_and_copy_by_index( next_index, 0, new_entry );
  if( !entry[next_index].varbstb ) 
    return set_and_copy_by_index( next_index, +1, new_entry );
  int min_size = entry_num * 2 - ( entry_num >> 1 ) + 1;   // not necessary here: adding additional entries for alignment, 
  // ... - ( entry_num  >> 1 ): search for existing variable even if table_size is smaller than what is considered ideal ( entry_num * 2 ) 
  if( min_size <= table_size ) {
    register int is_a_new_var = 0;
    do {
      next_index++; if( next_index >= table_size ) next_index = 0;
      if( entry[next_index].varbstb == var_num && entry[next_index].varlen == var_len && tailcmp( var_len, entry[next_index], variable ) ) break;
      if(( is_a_new_var = !entry[next_index].varbstb )) break;
    } while( index != next_index ); assert( index != next_index );
    //putchar('.');
    return set_and_copy_by_index( next_index, is_a_new_var, new_entry );
  }
  register int new_size = entry_num * 2 + 1;   // get an odd number of entries,  entry_num * 2 + 3 == ( entry_num + 1 )*2 + 1
  SymbolTable *new_table = allocate_new( 0, new_size );

  //putchar(':');
  CopyToNewTable( new_table, new_entry );

  return new_table;
}

#undef tailcmp
#undef index_offset


#ifdef QT_CORE_LIB

QRegExp htmlEsc("(&[+-];|&[!<>]=;|&..;|&[a-z]*;)");

QString unescape_html( QString text ) {
  int pos = 0; QString escStr; bool matched; int len;
  while( ( pos = htmlEsc.indexIn(text,pos) ) != -1 ) {
    len = htmlEsc.matchedLength();  matched = true;
    escStr =  text.mid( pos+1, len - 2 );
    if( escStr == "+" ) text = text.mid(0,pos) + QChar(concat_char) + text.mid(pos+len);
    else if( escStr == "-" ) text = text.mid(0,pos) + QChar(setminus_char) + text.mid(pos+len);
    else if( escStr == "!=" ) text = text.mid(0,pos) + QChar(neq_char) + text.mid(pos+len);
    else if( escStr == "<=" ) text = text.mid(0,pos) + QChar(leq_char) + text.mid(pos+len);
    else if( escStr == ">=" ) text = text.mid(0,pos) + QChar(geq_char) + text.mid(pos+len);
    else if( escStr == ".." ) text = text.mid(0,pos) + QChar(range_char) + text.mid(pos+len);
    else {
      int symIdx = SymbolNameToIndex<echar>( (echar*)escStr.utf16(), escStr.length(), '\000', true );
      matched = symIdx >= 0;
      if(matched) text = text.mid(0,pos) + QChar( SymbolIndexToCharCode(symIdx) ) + text.mid(pos+len);
    }
    if(!matched) pos += len;
    else pos++;
  }
  return text;
}
#endif


#define isUcHexNum(c) ( ( c >= '0' && c <= '9' ) || ( c >= 'A' && c <= 'F' ) )
#define isHexNum(c) ( ( c >= '0' && c <= '9' ) || ( c >= 'A' && c <= 'F' ) || ( c >= 'a' && c <= 'f' ) )
#define isOctNum(c) ( c >='0' && c <= '7' )

template<class xchar> wchar DecodeBackSlash( register xchar **src_ptr, register int &len, int &run_ahead, int escape_L_and_R ) {
  #define src (*src_ptr)
  register echar dest_char; bool ob = false;
  //if( len == 1 ) { if( dest < buf->chars + buf->buflen - 1 ) { *dest++ = SymbolTable::unknown_echar; src++; }; len=0; break; }
  if(unlikely( len <= 1 )) return SymbolTable::unknown_echar;
  if( ( '0' <= src[1] && src[1] <= '9' ) || ( ob = ( src[1] == '{' || src[1] == charcode_start_char ) && len >= 3 && '0' <= src[2] && src[2] <= '9'  ) ) {
    register xchar *rsrc = src+ob;
    if( ob && len >= 4 && src[3] == 'x' && src[2] == '0' ) { src+=2; len-=2; run_ahead+=2; goto decode_hex_digits; }
    if(unlikely( len < 4+ob+ob || !isOctNum(rsrc[1]) || !isOctNum(rsrc[2]) || !isOctNum(rsrc[3]) || ( ob && rsrc[4] != '}' && rsrc[4] != charcode_end_char ) )) { 
      if( ob ) { src++; len--; run_ahead++; }  // not needed: && len >= 1+ob && isOctNum(rsrc[1]) - already checked at entrance
      if( len > (int)ob && ( isOctNum(rsrc[2]) || rsrc[2] == '}' || rsrc[2] == charcode_end_char ) ) { src++; len--; run_ahead++;     // ~ len >= 2+ob ohne len--;
        if( len > (int)ob && ( isOctNum(rsrc[3]) || ( ( rsrc[2] != '}' && rsrc[2] != charcode_end_char ) && ( rsrc[3] == '}' || rsrc[3] == charcode_end_char ) ) ) ) { src++; len--; run_ahead++;   // ~ len >= 3+ob ohne len--; len--;
      }}
      dest_char = SymbolTable::unknown_echar; 
    } else {
      dest_char = (rsrc[1]-'0') << 6 | (rsrc[2]-'0') << 3 | (rsrc[3]-'0'); 
      if(ob) { src+=4; len-=4; run_ahead += 4; }
      else { src+=2; len-=2; run_ahead += 2; }
    }
  } else switch(wchar(src[1])) {   // eliminate warning that charcode_start_char exceeds the range of an achar
    case 'x': { 
decode_hex_digits:
	if(unlikely( len < 4+ob || ( ob && src[4] != '}' && src[4] != charcode_end_char ) )) { 
	    if( len > 2 && ( isHexNum(src[2]) || src[2] == '}' || src[2] == charcode_end_char ) ) { src++; len--; run_ahead++;     // ~ len >= 2+ob ohne len--;
	      if( len > 2 && ( isHexNum(src[2]) || ( ( src[1] != '}' && src[1] != charcode_end_char ) && ( src[2] == '}' || src[2] == charcode_end_char ) ) ) ) { src++; len--; run_ahead++;   // ~ len >= 3+ob ohne len--; len--;
	    }}
	    dest_char = SymbolTable::unknown_echar; 
	  break; 
	}
	register echar c1 = src[2] >= 'a' ? src[2] - ('a'-'A') : src[2];
	register echar c2 = src[3] >= 'a' ? src[3] - ('a'-'A') : src[3];
	if( !isUcHexNum(c1) || !isUcHexNum(c2) ) { dest_char = SymbolTable::unknown_echar; break; }
	dest_char = ( c1 - ( c1 > '9' ? ('A'-10) : '0' ) ) << 4 | ( c2 - ( c2 > '9' ? ('A'-10) : '0' ) ); 
	src+=2+ob; len-=2+ob; run_ahead += 2+ob; }
      break;
    case 'n': dest_char = '\n'; break;
    case 'r': dest_char = '\r'; break;
    case 'a': dest_char = '\a'; break;
    case 't': dest_char = '\t'; break;
    case 'v': dest_char = '\v'; break;
    case 'b': dest_char = '\b'; break;
    case 'f': dest_char = '\f'; break;
    case ' ': dest_char = unicode_space; break;
    case '+': dest_char = concat_char; break;
    case '-': dest_char = setminus_char; break;
    case '!': if(likely( len >= 3 && src[2]=='=' )) { dest_char = neq_char; src++; len--; run_ahead++; } else dest_char = SymbolTable::unknown_echar; break;
    case '<': if(likely( len >= 3 && src[2]=='=' )) { dest_char = leq_char; src++; len--; run_ahead++; } else dest_char = SymbolTable::unknown_echar; break;
    case '>': if(likely( len >= 3 && src[2]=='=' )) { dest_char = geq_char; src++; len--; run_ahead++; } else dest_char = SymbolTable::unknown_echar; break;
    case '.': if(likely( len >= 3 && src[2]=='.' )) { dest_char = range_char; src++; len--; run_ahead++; } else dest_char = SymbolTable::unknown_echar; break;
    case ':': case '{': case charcode_start_char: {
       xchar closing_bracket = src[1]==':' ? (xchar)':' : src[1]=='{' ?  (xchar)'}' : (xchar)charcode_end_char;
       int tmplen, result = SymbolNameToIndex( src+2, len-2, closing_bracket );
       if(likely( result >= 0 )) {
	 register int symbol_length = symbol_name[result].length;
	 src += symbol_length; len -= symbol_length; run_ahead += symbol_length;
	 if( len > 0 ) { src++; len--; run_ahead++; }   // skip closing ':' if there is one rather than the end of the input
	 dest_char = SymbolIndexToCharCode( result );
       } else {
	 tmplen = max_symbol_len + 3; if( len-2 < tmplen ) tmplen = len - 2;
	 result = 0; while( result < tmplen && ( ( (src+2)[result] >= 'a' && (src+2)[result] <= 'z' ) || (src+2)[result] == '_' ) ) result++;
	 if( result < tmplen && (src+2)[result] == closing_bracket ) ++result; 
	 if( result <= tmplen ) { src += result; len -= result; run_ahead += result; }
	 dest_char = SymbolTable::unknown_echar;
      }}
      break;
    case 'L': case 'R': 
		if( escape_L_and_R ) {
		  bool had_closing_bracket = !( escape_L_and_R & 2 );   // there was an opening bracket -> had_closing_bracket = false; i.e. still scan for a closing bracket to come
		  for(int j=2; j<len; j++ )
		    if(!( src[j] == ' ' || ( !had_closing_bracket && ( had_closing_bracket = ( src[j] == ')' ) ) ) )) { escape_L_and_R = 0; break; }
		}
	        if( escape_L_and_R ) { return '\\'; }
		dest_char = src[1];
	      break;
    default: dest_char = src[1]; break;
  }
  src++; len--; run_ahead++;  // do not forward the last character of the backslash sequence
  return dest_char;  // return value of this function will from now on be used instead of *src
  #undef src
}

template wchar DecodeBackSlash( register achar **src_ptr, register int &len, int &run_ahead, int escape_L_and_R );
template wchar DecodeBackSlash( register echar **src_ptr, register int &len, int &run_ahead, int escape_L_and_R );

int unescape_chars( astrbuf *buf ) {
  register int len = buf->length; register achar *src = buf->chars; int run_ahead = 0; 
  register achar *dest; int invalid_escapes = 0;
  while( len > 0 && *src != '\\' )  { src++; len--; }
  dest = src; run_ahead = 0;
  while( len > 0 ) {
    wchar result = DecodeBackSlash( &src, len, run_ahead, 0 );
    if( result == SymbolTable::unknown_echar ) { invalid_escapes++; *dest++ = '?'; }
    else *dest++ = result;
    src++; len--;
    while( len > 0 && *src != '\\' )  { *dest++ = *src++; len--; }
  }
  buf->length -= run_ahead;
  assert( src - dest == run_ahead );
  return invalid_escapes;
} 

#define inVarListMode ( mode == mode_grVarList || mode == mode_latVarList )

int SymbolTable::normalize( estrbuf *buf, enum SymbolMode mode ) {
  register int len = buf->length; register echar *src = buf->chars; int run_ahead = 0; bool had_an_unclosed_variable = false;
  register echar *dest; bool buf_realloced = false; bool had_comma = false; int escape_L_and_R_mask;
  bool strip_spaces = ( mode != mode_MS && mode != mode_anySubscript );
  int errpos = -1; bool(*isGood)(echar); SymbolTable *dupVars = NULL; echar *varStart = NULL;
  estrbuf src_buf = *buf;  // ~src, if realloced then it will be auto-dealloced on procedure exit because it is a local variable

  if( inVarListMode ) {

    isGood = mode == mode_grVarList ? SymbolTable::isGreekVariable : isLatinLetter<echar>;

    register int estimatedVarNum = 0; register bool subscripted = false;
    for( int j=0; j<len; j++ ) { 
      if( src[j] == subscript_char ) subscripted = true; 
      else if( src[j] == close_subscripts_char || src[j] == ' ' ) subscripted = false; 
      else if( src[j] == '\\' && j+3 < len && ( src[j+1] == ':' || src[j+1] == '{' ) ) { int result = SymbolNameToIndex( src+2, len-2, src[j+1] == ':'  ? (echar)':' : (echar)'}' ); 
	if( result >=0 ) { echar dest_char = SymbolIndexToCharCode( result ); 
	                   if( dest_char == subscript_char ) subscripted =true; else if( dest_char == close_subscripts_char ) subscripted = false;  
			   else if( isGood(dest_char) && !subscripted ) estimatedVarNum++; 
			   j += symbol_name[result].length + 2; } 
      } else if( isGood(src[j]) && !subscripted ) estimatedVarNum++;
    }
    dupVars = reserveEmpty( estimatedVarNum );

    errpos = 0;    // used as varcount instead

  } else {

    if( mode == mode_TM ) {
      escape_L_and_R_mask = 1;
      int j=0; while( j < len && src[j] == ' ' ) j++;
      if( j < len && src[j] == '(' ) escape_L_and_R_mask |= 2;
      assert( strip_spaces );   // necessary so that had_comma is initialized correctly by the following loop (i.e. it is not reset to false wrongly if a space occurs)
    } else {
      escape_L_and_R_mask = 0;
    }

    while( len > 0 && input_char_allowed(*src) && *src != subscript_char && *src != '\\' && *src != epsilon_letter
		   && ( !strip_spaces || *src != ' ' )
		   && ( mode != mode_greekvars_convert_slash || *src != '/' ) ) { len--; src++; }
    had_comma = src-1 >= buf->chars && *(src-1) == ',' ;
    // if( *src == subscript_char && src > buf->chars ) { src--; len++; }  // go back one character so that the initial letter of the variable can be seen

    if( len <= 0 ) return errpos;

  }

  if( xstrbuf_bufLength(*buf) < buf->length ) {  // content of buf may not be changed up to and including its last character   
    register int j, add_length; register bool subscripted;
    add_length = 0; for( j=0, subscripted=false; j < len; j++ ) { 
      if( src[j] == subscript_char ) subscripted = true; 
      else if( src[j] == close_subscripts_char ) subscripted = false; 
      else if( subscripted && !isChar4VariableIndex(src[j]) ) { add_length++; subscripted = false; }
    }; add_length += subscripted;
    src_buf.moveFrom(buf); buf->realloc_for_len( len );
    //buflen = elm_align( len + 1 + add_length, sizeof(echar), estrbuf::min_alignment );
    //if(unlikely(buflen<0)) dest = NULL;
    //else dest = (echar*) estrbuf::alloc( sizeof(echar) * buflen ); 
    //if(unlikely(!dest)) { fprintf(stderr,(buflen<0?"xstr: buflen: overflow\n":"xstr: out of memory\n")); fflush(stderr); *buf = invalid_estr; return 0; }
    if( ! buf->chars ) return 0;
    dest = buf->chars;
    memcpy( dest, src_buf.chars, sizeof(echar) * ( src_buf.length - len ) );
    dest += src_buf.length - len;
    run_ahead = xstrbuf_bufLenHeap(*buf) - 1 - src_buf.length; 
    buf_realloced = true;
    //cout << "!! realloced const buf" << endl;
    //memcpy( dest, buf->chars, sizeof(echar) * ( buf->length - len ) );
    //buf->chars = dest; dest += buf->length - len;
    //xstrbuf_bufLenHeap(*buf) = buflen;
    //run_ahead = buflen - 1 - buf->length; 
    //buf_realloced = true;
  } else {
    dest = src; run_ahead = 0;
  }

  register echar new_char;

  if( inVarListMode && len > 0 ) {
    new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false );
    goto start_to_process_VarList;
  }

  while( len > 0 ) {

    new_char = *src;
    process_new_char:

    switch( new_char ) {

      case '\\':
	if( had_an_unclosed_variable ) { *dest++ = close_subscripts_char; run_ahead--; had_an_unclosed_variable = false; }
	// one backslash at the end: this is an error; copy the stale \\ only if there is space to do so (!had_an_unclosed_variable)
	new_char = DecodeBackSlash( &src, len, run_ahead, had_comma ? escape_L_and_R_mask : 0 );
	if( run_ahead >= 0 ) { if( new_char!='\\' && new_char!='/' ) goto process_new_char; else { *dest++ = new_char; src++; len--; had_comma = false; } } 
	else { run_ahead++; if( errpos < 0 ) errpos = dest - buf->chars; }
      break;

      case charcode_start_char:
	if( had_an_unclosed_variable ) { *dest++ = close_subscripts_char; run_ahead--; had_an_unclosed_variable = false; }
	// one backslash at the end: this is an error; copy the stale \\ only if there is space to do so (!had_an_unclosed_variable)
	if( len >= 2 ) {
	  src--; len++; run_ahead--; new_char = DecodeBackSlash( &src, len, run_ahead, had_comma ? escape_L_and_R_mask : 0 );
	} else new_char = unknown_echar;
	if( run_ahead >= 0 ) { if( new_char!='\\' && new_char!='/' ) goto process_new_char; else { *dest++ = new_char; src++; len--; had_comma = false; } } 
	else { run_ahead++; if( errpos < 0 ) errpos = dest - buf->chars; }
      break;

      case '/':
        *dest++ = ( mode == mode_greekvars_convert_slash ) ? SlashSeparator : '/';
	src++; len--; had_an_unclosed_variable = false; had_comma = false;
      break;
      
      case ' ':
        if( strip_spaces ) run_ahead++; else *dest++ = ' ';
	src++; len--; had_an_unclosed_variable = false;
      break;

      case ',':
	*dest++ = new_char; src++; len--;
	had_an_unclosed_variable = false; had_comma = true;
      break;

      case setminus_4_editing_char:
	*dest++ = setminus_char; src++; len--;
	had_an_unclosed_variable = false; had_comma = false;
      break;

      default:
        if(likely( input_char_allowed(new_char) )) *dest++ = new_char;
	else { *dest++ = unknown_echar; if( errpos < 0 ) errpos = dest - buf->chars - 1; }
	src++; len--; had_an_unclosed_variable = false; had_comma = false;
      break;

      case subscript_char: {

	if(unlikely( dest <= buf->chars /* || ( mode ==dest[-1] */  )) {   // should never get executed ?!
	    *dest++ = unknown_echar; src++; len--; 
	    if( errpos < 0 ) errpos = dest - buf->chars - 1;
	  break; 
	}

        had_subscript_char_in_VarList:

	int subscript_nest = 0; register int subscript_polarity = 0; 
	do {
	  had_an_unclosed_variable = false;  // assume that the variable index will still be closed ( or set it to true on break otherwise )

	  do {
	    if( new_char == subscript_char ) ++subscript_polarity; else --subscript_polarity;
	    src++; len--; run_ahead++;
	    if( !len ) break;
	    new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false );
	  } while( new_char == subscript_char || new_char == ' ' );

	  if( subscript_polarity > 0 ) {
	    if( subscript_nest == 0 && len == 0 ) break;  // there was no valid variable index at all
	    if( len == 0 ) { had_an_unclosed_variable=true; break; }
	    if( subscript_nest == 0 && new_char == close_subscripts_char ) { // there was no valid variable index at all
	      src++; len--; run_ahead++; 
	      new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false );
	      break; 
	    }
	    if( new_char == close_subscripts_char ) break;
	    else if( !isChar4VariableIndex(new_char) ) { had_an_unclosed_variable=(subscript_nest!=0); break; }
	    *dest++ = subscript_char; run_ahead--;   // at most one new subscript can be opened once
	    subscript_nest++;

	  } else if( subscript_polarity < 0 ) {    // however multiple subscripts can be closed at one time
	    if( subscript_nest == 0 ) {  // there was no valid variable index at all
	      if(!strip_spaces) while( subscript_polarity < 0 ) { *dest++ = ' '; subscript_polarity++; run_ahead--; }   // write out superfluous spaces that remain after all spaces used to close indices
	      break;
	    }
	    if( subscript_nest + subscript_polarity <= 0 ) {   // now all sub-indices got closed 
	      *dest++ = close_subscripts_char; run_ahead--;   // now close all indices by one termination character
	      if(!strip_spaces) while( subscript_polarity < -subscript_nest ) { *dest++ = ' '; subscript_polarity++; run_ahead--; }   // write out superfluous spaces that remain after all spaces used to close indices
	      break;
	    };
	    subscript_nest += subscript_polarity;
	    while( subscript_polarity < 0 ) { *dest++ = ' '; subscript_polarity++; run_ahead--; }    // close only the number of indices that need to be closed by a space
	  }
	  subscript_polarity = 0;

	  if( len > 0 ) {
	    while( isChar4VariableIndex(new_char) ) { 
	      *dest++ = new_char != unicode_space ? new_char : subscript_space; src++; len--; 
	      //if( new_char == 0x2E2E ) printf("::%i - %c - %i\n",len,*src,run_ahead);
	      if( !len ) break;
	      new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false );
	  }}

	  had_an_unclosed_variable = true;
	} while( len > 0 && ( new_char == subscript_char || new_char == ' ' ) );

	if( had_an_unclosed_variable ) {

	  if( len > 0 && new_char == close_subscripts_char ) {
	    *dest++ = new_char; src++; len--; 
	    if( len > 0 ) { new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false ); }
	    had_an_unclosed_variable = false;    // close_subscripts char will simply be copied in the next step

	  } else if( run_ahead > 0 ) {
	    *dest++ = close_subscripts_char; run_ahead--;
	    had_an_unclosed_variable = false;

	  } else { int j, add_length; register bool subscripted;
	    //  "\L" and "\R" do not get unescaped and stay literally the same; they must not be part of a variable index
	    //  reallocating and copying to a larger buffer can thereby become necessary if a variable index has not been closed
	    //  ... at least as long as the BackSlash becomes accepted by isChar4VariableIndex
	    //
	    // this here basically should not be necessary since user input as well as the text file format ought not to contain unescaped control characters
	    // if it contains unescaped control characters variable termination still works as control characters can terminate a subscript like the close_subscripts_char can
	    // the code below is just seen to improve user readability; it only applies for input considered bad
	    //
	    if( buf_realloced ) {  // always realloc sufficient space at the first time
	      fprintf(stderr, "internal error in SymbolTable::normalize: tried to reallocate the buffer several times.");
	      return dest - buf->chars;

	    } else {
	      add_length = 1; for( j=1, subscripted=false; j < len; j++ ) { 
		if( src[j] == subscript_char ) subscripted = true; 
		else if( src[j] == close_subscripts_char ) subscripted = false; 
		else if( subscripted && !isChar4VariableIndex(src[j]) ) { add_length++; subscripted = false; }
	      }; add_length += subscripted;
	      int used_length = buf->length - len;    // buf->length - len == dest - buf->chars only works on the first realloc
	      src_buf.moveFrom(buf); buf->realloc_for_len( used_length + len + add_length );
	      run_ahead = xstrbuf_bufLenHeap(*buf) - 1 - len - used_length;
	      dest = buf->chars; if(unlikely(!dest)) return 0;
	      memcpy( dest, src_buf.chars, sizeof(echar) * used_length );
	      buf_realloced = true;
	      dest += used_length; *dest++ = close_subscripts_char; run_ahead--;
	      had_an_unclosed_variable = false;

	  }}
        }}
	// had_comma is already false; since ",\:sub: is not allowed"; this is ok as "," is an allowed char for a variable index; it would never terminate the index scan

        if( len > 0 ) {

	  if( !inVarListMode )
	    goto process_new_char;

          start_to_process_VarList:

	  do {
	    if( isGood(new_char) ) { 
	      if( !varStart ) { varStart = dest; }
	      else if( dupVars->lookUp(varStart) & var_is_undefined ) { dupVars = dupVars->set(varStart,0); varStart = dest; }
              else { run_ahead += dest - varStart; dest = varStart; errpos--; }
              *dest++ = new_char; errpos++; 
	    } else run_ahead++;
	    src++; len--; 
	    if( !len ) break;
	    new_char = *src; if( new_char == '\\' ) new_char = DecodeBackSlash( &src, len, run_ahead, false );
	  } while( new_char != subscript_char || !varStart ); 

	  if( len > 0 )
	    goto had_subscript_char_in_VarList;

        }

      break;

      case epsilon_letter:
	src++; len--; run_ahead++;
	had_an_unclosed_variable = false; had_comma = false;
      break;

    }
  }

  if( varStart && !( dupVars->lookUp(varStart) & var_is_undefined ) ) { run_ahead += dest - varStart; dest = varStart; errpos--; }
  if( dupVars ) free(&dupVars); 

  if(!buf_realloced) {
    if( run_ahead != src - dest ) fprintf(stderr, "internal error in SymbolTable::normalize: wrong run_ahead( %i ~ %lli ), no realloc\n", run_ahead, (long long)( src - dest ) );
    //assert( run_ahead ==  src - dest );    // only valid if buf has not been reallocated initially
  } else {
    if( run_ahead != xstrbuf_bufLength(*buf) - ( dest - buf->chars ) - 1 ) fprintf(stderr, "internal error in SymbolTable::normalize: wrong run_ahead( %i ~ %i ), with realloc\n", run_ahead, xstrbuf_bufLength(*buf) - (int)( dest - buf->chars ) - 1 );
    //assert( run_ahead == buf->buflen - ( dest - buf->chars ) - 1 );
  }
  buf->length = len = dest - buf->chars;
  if( xstrbuf_bufLength(*buf) > len ) *dest = '\000';
  return errpos;
}

#undef isUcHexNum
#undef inVarListMode


int SymbolTable::countVariables( astrbuf *buf_for_translation, estr_const s ) {
  register int var_count = 0, target_length = s.length;
  for( register int i=0; i < s.length; i++ ) {
    register echar c = s.chars[i];
    if( c == epsilon_letter ) target_length--;
    else if( isGreekVariable(c) ) {
      register int vlen = varLength( s.chars + i );
      target_length = target_length - vlen + 1;   // variable always replaced by a single character
      var_count++; i += vlen - 1;
    }
  }
  if( xstrbuf_bufLength(*buf_for_translation) - 1 < target_length ) 
    buf_for_translation->realloc_for_len( target_length );
  return var_count;
}

// #define var_is_undefined ((long long)1<<32)

int SymbolTable::translate( astrbuf *dest, estr_const src, SymbolTable *local, SymbolTable *global ) {
  register int i, len; register achar *dest_char = dest->chars;
  int err = 0; int dest_buflen = xstrbuf_bufLength(*dest);
  i=0, len=0; 
  while( i < src.length && len < dest_buflen ) {
    register echar c = src.chars[i];
    if(!isGreekVariable(c)) {
      if(unlikely( c & ~0xFF )) { *dest_char = unknown_achar; if(!err) err = -1; }
      else *dest_char = c;
      i++; dest_char++; len++;
    } else if( c != epsilon_letter ) {
      //if( len >= dest_buflen ) break;
      register long long res = var_is_undefined; 
      if( local ) res = local->lookUp( src.chars + i );
      if( global && ( res & var_is_undefined ) ) res = global->lookUp( src.chars + i );
      *dest_char = res & 0xFF;
      res >>= 32; if(unlikely( res & 1 )) { *dest_char = unknown_achar; err = -2; }
      i += res >> 1;
      dest_char++; len++;
    } else {
      i++;
    }
  }
  if( len < dest_buflen ) {
    *dest_char = '\000';
    dest->length = len;
    return err;
  } else {
    cerr << "SymbolTable::translate: insufficiently allocated destination buffer. " << endl;
    // dest->length = len - 1; dest->chars[len-1] = '\000';
    return -3;
  }
}

