#include "FiniteAutomata.h"
#include "auxtypes.h"
#include "charset.h"

using namespace aux;

bool FA_print_cond_as_set = true; 

// ------------------  Finite Automata  ------------------  

int FAEdgeProxy::execLength() const { return ((FA_Edge*)main)->edge_proxy.size()+1; }
int FA_Edge::execLength() const { return edge_proxy.size()+1; }

inline estr_const FA_Edge::getCond( int pos, int *flags ) const {
  if( !pos ) { if(flags) *flags = baseFlags; return entryCondition; } 
  std::vector<FAEdgeProxy>::const_iterator pi = edge_proxy.begin() + ( pos - 1 );
  if(flags) *flags = pi->cond_flags; return estr_const( content.chars + pi->cond_start, pi->cond_len );
}

const echar echars_slash[2] = { '/', 0 }, echars_concat_char[2] = { concat_char, 0 }; 
const estr_const estr_slash = estr_const( echars_slash, 1 ), estr_concat_char( echars_concat_char, 1 );

void FA_Edge::printHead( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos, int varLength, bool escapeSlash ) const {
  if( debuglevel > 1 ) out << from->getContent() << "-";
  if( baseFlags & isEpsilonTransition ) {
    out << EChar(epsilon_letter);
  } else {
    bool print_as_set = ( baseFlags & hasASet ) && FA_print_cond_as_set;
    for( int i=0, num=conditionLength(); i < num; i++ ) {
      int cur_flags; estr_const this_cond = getCond( i, &cur_flags); bool isNegated = ( cur_flags & negatedCond ) != 0;
      if( varLength ) {  // also used for PDA-Edges which can have edge local variables
	out << content.sub(0,varLength) << ( isNegated ? EChar(neq_char) : EChar('=') );
	varLength = 0; isNegated = false;
      }
      if( relpos == i && !( baseFlags & zeroReadTransition ) ) out << ( isLookAhead ? AChar('(') : AChar('|') );
      if( !i && escapeSlash && !print_as_set ) cout << IOChangeVal( IOAttr::EscapeChars, estr_slash );    // Einstellung bleibt bestehen!
      if( baseFlags & zeroReadTransition ) out << EChar(epsilon_letter); 
      else if( this_cond.length == 1 && !isNegated ) out << EChar(this_cond.chars[0]);
      else ExtCharSet::print( out, this_cond, isNegated, print_as_set );
      if( relpos == i && isLookAhead && !( baseFlags & zeroReadTransition ) ) out << AChar(')');
      if( ( i+1 < num && ( baseFlags & hasASet ) ) || ( !FA_print_cond_as_set && num <= 1 && this_cond.length > 1 ) ) out << EChar(concat_char);
  } }
}

inline void FA_Edge::printTail( IOStreamRef out, int debuglevel ) const {
  estr_const to_label = to ? to->getContent() : estrbc(dangling_node_buf,"<dangling_node>"); 
  if( debuglevel > 1 ) out << "-" << to_label;
}

void FA_Edge::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  printHead( out, debuglevel, isLookAhead, relpos );
  printTail( out, debuglevel );
}

#ifdef QT_CORE_LIB

void FA_Edge::cbPrintCond( TextCallBack cb, int i, int num, bool alreadyNegated, bool print_as_set, void *data ) const {
  int cur_flags; estr_const this_cond = getCond( i, &cur_flags); bool isNegated = ( cur_flags & negatedCond ) != 0 && !alreadyNegated;
  if( baseFlags & zeroReadTransition ) cb( 0, 0, false, estr_epsilon, data );
  //else if( this_cond.length == 1 ) cb( 0, 0, isNegated, estr_const(this_cond.chars,1), data );
  else ExtCharSet::cbPrint( cb, this_cond, isNegated, print_as_set, data );
  if( ( i+1 < num && ( baseFlags & hasASet ) ) || ( !FA_print_cond_as_set && num <= 1 && this_cond.length > 1 ) ) cb( 0, 0, false, estr_concat_char, data );
}

void FA_Edge::callbackPrint( TextCallBack cb, void *data ) const {
  if( baseFlags & isEpsilonTransition ) { cb( 0, 0, false, estr_epsilon, data ); return; };
  bool print_as_set = ( baseFlags & hasASet ) && FA_print_cond_as_set;
  int i, num = execLength(), val; struct CursorCounter cc; InitCursorCounter(&cc);  // execLength is the same as conditionLength()
  for( i=0; i < num; i++) {
    if( num > 1 ) { val = nextCursor(&cc); if(val) cb( -3, val>1, false, empty_estr, data ); }
    cbPrintCond(cb,i,num,false,print_as_set,data);
  }

}

#endif

const echar FA_Edge::CharSetTermEChars[] = { concat_char, SlashSeparator, 0 }; 
const estr_const FA_Edge::CharSetTermChars( CharSetTermEChars, 2 );

int FA_Edge::scanForNeq( estr_const s, int pos ) {
  if( s.chars[pos] == neq_char ) return 1;
  else if( s.chars[pos] == '!' && s.length > 1 && s.chars[pos+1] == '=' ) return 2;
  else return 0;
}

#define skipTargetLetter(s,i) ( SymbolTable::isGreekVariable(s.chars[i]) ? SymbolTable::varLength(s.chars+i) : 1 )

int FA_Edge::scanCharSets( estr_const s, int initialPos, int initialFlags, int charsetCheckFlags, int *errpos ) {
  int startPos = initialPos, endPos = initialPos, i = 0, curFlags = initialFlags, setErr, setChkFlags; 
  std::vector<FAEdgeProxy> *proxy = &(edge_proxy); bool atLeastOneSet = false, onlySimpleCharPlaceholders = true;
  proxy->clear();
  while( startPos < s.length ) {
    endPos = s.find_first_of( CharSetTermChars, startPos );
    if( endPos == startPos && s.chars[endPos] != concat_char ) break;   // termination character: treat like !( starPos < s.length )
    setErr = ExtCharSet::first_error_position( s.sub(startPos,endPos-startPos), charsetCheckFlags, &setChkFlags );
    if( setErr >= 0 && ( *errpos < 0 || setErr < *errpos ) ) *errpos = setErr;
    if(!( setChkFlags & ExtCharSet::is_a_simple_range )) onlySimpleCharPlaceholders = false; 
    else if(!( setChkFlags & ExtCharSet::has_variables )) curFlags |= simpleCond; 
    if(!( setChkFlags & ExtCharSet::exactly_one_character )) atLeastOneSet = true;
    if( i == 0 ) { entryCondition = s.sub( startPos, endPos - startPos ); baseFlags = curFlags; }
    else proxy->push_back( FAEdgeProxy( this, (short)i, (short)curFlags, (short)startPos, (short)(endPos-startPos) ) );
    if( endPos >= s.length || s.chars[endPos] != concat_char ) break;   // end of string or termination char
    startPos = endPos + 1; onlySimpleCharPlaceholders = false;   // had at least a concat_char
    if( startPos < s.length ) startPos += scanForNeq( s, startPos ); if( startPos == endPos + 1 ) curFlags = 0; else curFlags = negatedCond; 
    i++;
  }
  if( endPos == initialPos ) { entryCondition = empty_estr; baseFlags = initialFlags | simpleCond; }
  else if( onlySimpleCharPlaceholders ) {  // no concat_char & nothing that would point to a set: interprete the whole as string rather than as set
    // i > 0: had a concat_char or more, s.length == 0: that would be an epsilon transition, find_first_of never transgresses s.length if it was invoked with a smaller value before
    assert( i == 0 ); assert( s.length > initialPos ); assert( endPos == s.length || s.chars[endPos] != concat_char ); assert( proxy->empty() );
    int curPos = initialPos; int curLen = skipTargetLetter( s, initialPos ); entryCondition = s.sub( initialPos, curLen ); 
    i = 0; curPos += curLen; baseFlags = initialFlags | ( s.chars[initialPos]<=0xFF ? simpleCond : 0 );
    while( curPos < endPos ) {
      curLen = skipTargetLetter( s, curPos ); curFlags = s.chars[curPos] <= 0xFF ? simpleCond : 0;
      proxy->push_back( FAEdgeProxy( this, (short)++i, (short)curFlags, (short)curPos, (short)curLen ) );
      curPos += curLen;
    }
    atLeastOneSet = false; 
  }
  if( i > 0 && endPos > MaxSigned(short) ) { fprintf(stderr,"error: label of FA multi-input-character-edge may not exceed %i characters.\n",MaxSigned(short)); fflush(stderr); abort(); }
  if(atLeastOneSet) baseFlags |= EdgeFlags::hasASet;
  return endPos;
}

int FA_Edge::setContent( Automaton *a, estrbuf *userstr ) { 
  int errpos = SymbolTable::normalize( userstr, SymbolMode::mode_greekvars );
  if( estr::isEmpty(userstr) || *userstr == estr_epsilon ) { 
    baseFlags = isEpsilonTransition; edge_proxy.clear();
    entryCondition = content = empty_estr; 
    userstr->buf_free(); 
    return errpos; 
  }
  content.moveFrom(userstr);
  int start = scanForNeq( content, 0 );
  scanCharSets( content, start, start ? negatedCond : 0, a->charsetCheckFlags, &errpos );
  return errpos; 
};

inline bool FA_Edge::evalCurCond( FA_Runtime *r, int pos, achar inpChar ) {
  int flags; estr_const cond = getCond( pos, &flags );
  bool neg = ( flags & negatedCond ) != 0;
  if( flags & simpleCond ) 
    return neg ^ ( cond.find_first_of(inpChar) < cond.length );
  bool result, undef_var = false;
  result = neg ^ ExtCharSet::elm_in( inpChar, cond, NULL, r->paramSymTab, &undef_var );
  if( undef_var ) { r->setCondition( Runtime::undefined_variable_during_lookahead ); r->addErrorWithElement(this); } 
  return result;
}

bool FA_Edge::evalEntryCond( FA_Runtime *r, achar firstInpChar ) {
  bool result = evalCurCond( r, 0, firstInpChar );
  if( !result || !r->deterministicAutomaton ) return result;
  int len = conditionLength();
  if( r->pos + len > r->tape.length ) return false;
  for( int j=1; j < len; j++ ) { 
    if(!evalCurCond( r, j, r->tape.chars[r->pos+j] )) return false;
  }
  return true;
}

void FA_Edge::lookAhead( Runtime *rg, Data *d, int relpos ) {    // also executed by PDA_Edge
  FA_Runtime *r = (FA_Runtime*)rg; assert( relpos >= 1 );
  if( r->pos < 0 || r->pos >= r->tape.length ) return;
  if( r->deterministicAutomaton ) {   // nothing to check: all condition characters have already been checked
    r->addLookAhead( IntermedState( &(edge_proxy[relpos-1]), d, NULL ) );
    return;
  }
  achar curInpChar = r->tape.chars[r->pos];
  if( evalCurCond( r, relpos, curInpChar ) )
    r->addLookAhead( IntermedState( &(edge_proxy[relpos-1]), d, NULL ) );
}

void FA_Edge::next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos ) {
  if( relpos + 1 >= conditionLength() ) 
    r->addState( State( to, NULL ) );
  else 
    r->addState( State( &(edge_proxy[relpos]), NULL ) );
}

FA_Runtime::FA_Runtime( FA *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos ) : Runtime(a,charParam,valParam,tracelen) {
  tape_alloc = input->duplicate(); tape = *tape_alloc;
  pos = position < 0 ? 0 : position;
  deterministicAutomaton = ( a->flags & Automaton::isDeterministic ) != 0;
  if(a->startNode) {
    addState( State( a->startNode, NULL ) ); 
    lookAhead( prepareStatePos );
  } else {
    cur->status = no_successor; cur->conditions |= at_lookAhead;
    setCondition( Condition::no_startNode ); 
  }
}

PDA_Runtime::PDA_Runtime( FA *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos ) : FA_Runtime(a,charParam,valParam,tracelen) {
  // copy and paste is necessary since addState and lookAhead will need to call the virtual PDA versions of the respective functions
  tape_alloc = input->duplicate(); tape = *tape_alloc;
  pos = position < 0 ? 0 : position;
  deterministicAutomaton = ( a->flags & Automaton::isDeterministic ) != 0;
  if(a->startNode) {
    addState( State( a->startNode, NULL ) ); 
    lookAhead( prepareStatePos );
  } else {
    cur->status = no_successor; cur->conditions |= at_lookAhead;
    setCondition( Condition::no_startNode ); 
  }
}

void FA_Runtime::freeMemSub( Automaton *atmt ) { 
  astr_shared::freeMem(tape_alloc); 
#ifdef QT_CORE_LIB
  for(std::list<Edge*>::const_iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ ) {
    if( (*ie)->execLength() >= CursorPack && (*ie)->cursorSet.ref ) { free((*ie)->cursorSet.ref); (*ie)->cursorSet.ref = NULL; } else (*ie)->cursorSet.val = 0;
  }
#endif
  Runtime::freeMemSub(atmt); 
}

void FA_Runtime::finalizeStep() {
  if( pos < tape.length ) pos++;
}

Status FA_Runtime::getResultStatus( Element *e, Data *d ) {
  if( pos < tape.length ) return Status::stepDone;
  if( e->isFinalNode() && !d ) return Status::accepted;  // mayAcccept(d) == !d
  else return Status::dismissed;
}

bool FA_Node::setFinalNode( bool is_final_acceptor ) {
  acceptorNode = is_final_acceptor;
  return true;
};

bool FA_Node::isFinalNode() const {
  return acceptorNode;
};

void FA_Node::lookAhead( Runtime *rg, Data *d, int relpos ) {
  FA_Runtime *r = (FA_Runtime*)rg;
  if( r->pos < 0 || r->pos >= r->tape.length ) return;
  achar curInpChar = r->tape.chars[r->pos];
  for(Edges::const_iterator ie = succ.begin() + epsilonSucc; ie != succ.end(); ie++ ) { 
    FA_Edge *edge = (FA_Edge*)*ie;
    if( edge->evalEntryCond( r, curInpChar ) )
      r->addLookAhead( IntermedState( edge, NULL, NULL ) );
  }
}

void FA_Node::next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos ) {
  cerr << "internal error: FA_Node::next was called; i.e. a node was in the lookahead set." << endl;
  abort();
}

int FA_Runtime::numTapes( ParentTapeIndex i ) { 
  return likely( i.isRootAnchor() ) ? ( 1 ) : 0; 
} 

int FA_Runtime::getTape( astr_const *content, int *position, SymbolTable **symTab, TapeIndex i ) {
  if(unlikely( i != TapeIndex(0) )) return nonExistantTape(content,position,symTab);
  if(content) *content = tape; if(position) *position = pos; if(symTab) *symTab = NULL; 
  return 0;
}

void FA_Runtime::getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i ) { 
  if(likely( i.subidx <= -1 && i.topidx <= 0 )) getAllStatesWithLookAhead( standlh ); 
  else getEmptyStatesAndLookAhead( standlh );
};

void FA_Runtime::getOutcome( int idx, astr_shared **tape, int *position, enum Status *status, int *step_num ) {
  if(tape) *tape = tape_alloc->duplicate();
  // if(position) *position = pos;
  if(position) *position = this->tape.length;
  if( idx < (int)finalStates.size() ) {
    FinalState *f = &finalStates[idx];
    if(status) *status = f->status;
    if(step_num) *step_num = f->step_num;
  } else {
    if(status) *status = Status::stepDone;
    if(step_num) *step_num = cur_step;
  }
}

// ------------------  Push Down Automata  ------------------  

bool PDA_Runtime::popOK( Data *base, astr_const toPop ) const {
  if(!base) return toPop.length == 0;
  const astr_const *stack = &( (PDA_Data*) base )->stack;
  return stack->sub( stack->length - toPop.length ) == toPop;
}

bool PDA_Data::print( IOStreamRef out ) {
  if(!this) cout << "(PDA_Data*)NULL";
  else cout << (u_iword)this << "_" << (int)usage_count << ":" << stack << "$"; 
  return out;
}

void PDA_Runtime::printData( IOStreamRef out, Data *d, bool shallPrintVars ) const { 
  if(d) {
    astr_const stack = ((PDA_Data*)d)->stack; 
    int i = 0, j; bool quoted = false, pending_quote = false;
    while( i < stack.length ) {
      j = i + 1; while( j < stack.length && stack.chars[i] == stack.chars[j] ) j++;
      if( j - i > 3 ) { // human-readable-repeated output
	if(pending_quote) out << AChar('\''); 
	if(i) out << EChar(concat_char); 
	out << j-i << "*'" << AChar(stack.chars[i]) << AChar('\''); 
	quoted = true; pending_quote = false;
      } else {  // otherwise
        while( j < stack.length && stack.chars[j] != stack.chars[j-1] ) j++;
	if( j > i + 1 ) j--;
	if( i == 0 ) {   // look for a stack content like "33x.."; if so quote it so that it can not be confused with the human-readable-repeated output
          int k; for( k=0; k < stack.length && isNumeral(k); k++ ); 
	  if( 0 < k && k < stack.length - 1 && stack.chars[k] == '*' ) quoted = true;
	}
        if( i && quoted && !pending_quote ) out << EChar(concat_char);
	if( quoted && !pending_quote ) out << AChar('\''); 
	out << stack.sub( i, j-i );
	pending_quote = quoted;
      }
      i = j;
    }
    if(pending_quote) out << AChar('\''); 
    int uc = ((PDA_Data*)d)->usage_count; uc = uc;
    assert( uc != 0 ); //assert( ( 0<uc && uc<12 ) || ( -12<uc && uc<0 ) );
  }
  out << "$"; 
};

void PDA_Runtime::pushPopStack_nomem() {
  fprintf(stderr,"PDA_Runtime::pushPopStack/evalEntryCond/execPushPop: out of memory\n"); fflush(stderr);
  setCondition(Runtime::out_of_memory);
}

Data* PDA_Runtime::pushPopStack( Data *base, astr_const toPush, int pop_len, bool isTemporary ) {
  if( !pop_len && !toPush.length ) return duplicateData(base);
  if( !base && !isTemporary ) {
    if( !toPush.length ) return NULL;
    PDA_Data *data_obj = (PDA_Data*) alloc(sizeof(PDA_Data)); if(!data_obj) { pushPopStack_nomem(); return NULL; }
    return new(data_obj) PDA_Data( toPush.chars, toPush.length, true );
  }
  if( !toPush.length && base && ((PDA_Data*)base)->usage_count < 0 ) {
    if( ((PDA_Data*)base)->stack.length <= pop_len ) return NULL;
    PDA_Data *data_obj = (PDA_Data*) alloc(sizeof(PDA_Data)); if(!data_obj) { pushPopStack_nomem(); return NULL; }
    return new(data_obj) PDA_Data( ((PDA_Data*)base)->stack.chars, ((PDA_Data*)base)->stack.length - pop_len , true );
  }
  const astr_const stack = base ? ( (PDA_Data*) base )->stack : empty_astr;
  int final_length = stack.length - pop_len + toPush.length;
  if( final_length <= 0 ) return NULL;
  achar* data = (achar*) alloc( sizeof(PDA_Data) + final_length ); if(!data) { pushPopStack_nomem(); return NULL; }
  achar* new_stack_start = data + sizeof(PDA_Data);
  PDA_Data *data_obj = new((PDA_Data*)data) PDA_Data( new_stack_start, final_length, false );
  memcpy( new_stack_start, stack.chars, stack.length - pop_len );
  memcpy( new_stack_start + stack.length - pop_len, toPush.chars, toPush.length );
  //cout << (u_iword)base << "_" << ( base ? (int)( (PDA_Data*) base )->usage_count : -99 ) << ":" << stack << "->" << (u_iword)data_obj << "_" << ( data_obj ? (int)( (PDA_Data*) data_obj )->usage_count : -99 ) << ":" << data_obj->stack << ":" << stack.length << "-" << pop_len << "+" << toPush.length << " = " << final_length << endl;
  return data_obj;
}

bool PDA_Edge::evalEntryCond( PDA_Runtime *r, achar firstChar, Data *data, SymbolTable **tmpTransitionSymbols ) {
  if( !( baseFlags & zeroReadTransition ) && !FA_Edge::evalEntryCond( r, firstChar ) ) {
    if(tmpTransitionSymbols) *tmpTransitionSymbols = NULL;
    return false;
  }
  SymbolTable *tmpSmbls = varLength && tmpTransitionSymbols ? emptySymbolTable.set_and_copy(content.chars,firstChar) : NULL;
  astrbuf actToPop; int res;
  if( toPopAsConst.chars ) actToPop = toPopAsConst.as_const();
  else {
    actToPop.setUserAllocedBuf( alloca( sizeof(achar) * ( toPopAsConst.length + 1 ) ), toPopAsConst.length + 1 );
    if(( res = SymbolTable::translate( &actToPop, toPop, tmpSmbls, r->paramSymTab )) < 0 ) {
      if( res == -3 ) r->setCondition(Runtime::out_of_memory);
      else { r->setCondition( Runtime::undefined_variable_during_lookahead ); r->addErrorWithElement(this); }
      return false;
  } }
  if(tmpTransitionSymbols) *tmpTransitionSymbols = tmpSmbls;
  //print(cout,2,false,0); cout << ": "; tmpSmbls->print(cout); cout << endl;
  return r->popOK( data, actToPop );
}

PDA_Data* PDA_Edge::execPushPop( PDA_Runtime *r, PDA_Data *d, SymbolTable *tmpTransitionSymbols ) const {
  astrbuf actToPush; bool isTemporary = true; int res; 
  if( toPushAsConst.chars ) { actToPush.referenceFrom(toPushAsConst); isTemporary = false; }
  else {
    actToPush.setUserAllocedBuf( alloca( sizeof(achar) * ( toPushAsConst.length + 1 ) ), toPushAsConst.length + 1 );
    if(( res = SymbolTable::translate( &actToPush, toPush, tmpTransitionSymbols, r->paramSymTab )) < 0 ) { 
      if( res == -3 ) { r->setCondition(Runtime::out_of_memory); return NULL; }
      else r->setCondition( Runtime::undefined_variable_during_next ); 
    }
  }
  //PDA_Data* nd = (PDA_Data*) r->pushPopStack( d, actToPush, toPopAsConst.length, isTemporary );
  //print(cout,2,false,0); cout << ": "; r->printData(cout,nd,true); cout << " - "; tmpTransitionSymbols->print(cout); cout << " ~ " << actToPush << endl;
  //return nd;
  return (PDA_Data*) r->pushPopStack( d, actToPush, toPopAsConst.length, isTemporary );
}

void PDA_Node::lookAhead( Runtime *rg, Data *dg, int relpos ) {
  PDA_Runtime *r = (PDA_Runtime*)rg; PDA_Data *d = (PDA_Data*)dg;
  if( r->pos < 0 || r->pos >= r->tape.length ) return;
  achar curInpChar = r->tape.chars[r->pos];
  for(Edges::const_iterator ie = succ.begin() + zeroReadSucc; ie != succ.end(); ie++ ) { 
    PDA_Edge *edge = (PDA_Edge*)*ie; SymbolTable *symtab;
    if( edge->evalEntryCond( r, curInpChar, d, &symtab ) ) {
      r->addLookAhead( IntermedState( edge, d, symtab ) );
  } }
}

void PDA_Edge::next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos ) {
  if( relpos == 0 ) d = execPushPop( (PDA_Runtime*) r, (PDA_Data*) d, tmpTransitionSymbols ); 
               else d = ((PDA_Runtime*)r)->duplicateData( d );
  if( relpos + 1 >= conditionLength() )
    r->addState( State( to, d ) );
  else r->addState( State( &(edge_proxy[relpos]), d ) );
}


//
//  Zero Read LookAhead Transitions
//

// void PDA_Node::zeroReadLookAhead( ImStateVector *l, PDA_Runtime *r, achar curChar, PDA_Data *d, struct LookAheadChain *parent_chain_node, bool firstCall4Cycle ) {

#define nn newest.node

void PDA_Node::prepareZeroReadTransitions( struct ZeroReadChain newest ) {
  struct ZeroReadChain *cur = &newest;
  do { cur = cur->prev; } while( cur && cur->node != newest.node );
  if( cur ) { // cur->node == newest.node
    if( !cur->prev ) newest.node->max_incoming_zeroReadCycles++; 
    return; 
  }
  for( Edges::const_iterator ie = nn->succ.begin() + nn->epsilonSucc; ie != nn->succ.begin() + nn->zeroReadSucc; ie++ ) { 
    PDA_Edge *edge = (PDA_Edge*)*ie; assert( edge->baseFlags & PDA_Edge::zeroReadTransition ); assert( edge->to );
#ifdef _MSC_VER
    prepareZeroReadTransitions( ZeroReadChain{ (PDA_Node*)edge->to, &newest } );
#else
    prepareZeroReadTransitions( ZeroReadChain{ .node = (PDA_Node*)edge->to, .prev = &newest } );
#endif
  }
}

#undef nn

bool PDA_Edge_isZeroReadTransition( Edge *e ) { return ( ((PDA_Edge*)e)->baseFlags & PDA_Edge::zeroReadTransition ) != 0; }

void PDA::prepareZeroReadTransitions() {
  for(std::list<Node*>::const_iterator in = allNodes.begin(); in != allNodes.end(); in++ ) {
    PDA_Node *n = (PDA_Node*)*in; assert( 0 <= n->epsilonSucc && n->epsilonSucc <= (int)n->succ.size() );
    n->zeroReadSucc = std::partition( n->succ.begin() + n->epsilonSucc, n->succ.end(), PDA_Edge_isZeroReadTransition ) - n->succ.begin();
    assert( n->epsilonSucc <= n->zeroReadSucc && n->zeroReadSucc <= (int)n->succ.size() );
  }
  for(std::list<Node*>::const_iterator in = allNodes.begin(); in != allNodes.end(); in++ ) {
    PDA_Node *n = (PDA_Node*)*in;  n->max_incoming_zeroReadCycles = 0; 
#ifdef _MSC_VER
    PDA_Node::prepareZeroReadTransitions( PDA_Node::ZeroReadChain{ n, NULL } );
#else
    PDA_Node::prepareZeroReadTransitions( PDA_Node::ZeroReadChain{ .node = n, .prev = NULL } );
#endif
  }
}


#define this_node this_chain_node.node
#define this_data this_chain_node.data
#define this_parent this_chain_node.previous

void PDA_Node::simpleComputeZeroReadLookAhead( Runtime *rg, struct SimpleLookAheadChain this_chain_node ) {
  PDA_Runtime *r = (PDA_Runtime*)rg;
  //cout << "simpleComputeZeroReadLookAhead: ";  if(this_parent) { this_parent->node->print(cout); cout << " -> "; }
  //  this_node->print(cout); cout << " / "; this_data->print(cout); r->printData(cout,this_data,false); cout << endl;

  for( struct SimpleLookAheadChain *cur = this_parent; cur; cur = cur->previous )
    if( cur->node == this_node )
      if( this_data && ( !cur->data || this_data->stack.length > cur->data->stack.length || ( this_data->stack.length == cur->data->stack.length && this_data->stack != cur->data->stack ) ) ) {
	// error: stack length stayed the same or has increased by cycle // other error: stack has stayed empty & cycle detected
	r->setCondition( Runtime::had_an_illegal_epsilon_loop );
	r->freeData( this_data );
	return;
      }

  if( this_parent && !r->addState( State( this_node, this_data ) ) )
    return;
  //putchar('&');

  for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
    for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
      PDA_Edge *edge = (PDA_Edge*)*ie;
      if( edge->evalEntryCond( r, '\000', this_data, NULL ) ) {
	r->addZeroReadEdge( edge );
	simpleComputeZeroReadLookAhead( r, SimpleLookAheadChain( (PDA_Node*)edge->to, edge->execPushPop( r, this_data, NULL ), &this_chain_node ) );
    } }

  //cout << "return" << endl;
}

#undef this_parent

#if ZERO_READ_MODE != ZRM_simple

#define this_parent ((LookAheadChain*)this_chain_node.previous)
#define cur_newDataCount this_chain_node.newDataCount 
#define cur_newData this_chain_node.newData

void PDA_Node::computeZeroReadLookAhead( Runtime *rg, struct LookAheadChain this_chain_node, bool firstCall4Cycle ) {
  PDA_Runtime *r = (PDA_Runtime*)rg;

  for( struct LookAheadChain *cur = this_parent; cur; cur = (LookAheadChain*)cur->previous ) {
    if( cur->node == this_node ) {
      if( this_data && ( !cur->data || this_data->stack.length > cur->data->stack.length || ( this_data->stack.length == cur->data->stack.length && this_data->stack != cur->data->stack ) ) ) {
	// error: stack length stayed the same or has increased by cycle // other error: stack has stayed empty & cycle detected
	r->setCondition( Runtime::had_an_illegal_epsilon_loop );
	r->freeData( this_data );
	return;
      } else if( ( !this_data && cur->data ) || ( this_data && this_data->stack.length < cur->data->stack.length ) ) {  
	// good: stack length has decreased
	if( cur->newDataCount >= cur->node->max_incoming_zeroReadCycles ) {   // we have a nested cycle
	  simpleComputeZeroReadLookAhead( r, SimpleLookAheadChain( this_node, this_data, this_chain_node.previous ) );
	  return;
	}
        if( r->addState( State( this_node, this_data ) ) )
	  cur->newData[cur->newDataCount++] = this_data;   // i.e. restart from the same node with the new stack content
	return;
    } }
  }

  if( this_parent && !r->addState( State( this_node, this_data ) ) )
    return;
  //putchar('%');

  int ndcLen = 0;   // maximum return data item count for the target of any zero read edge that will be visited
  for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
    for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
      int thisLen = ((PDA_Node*)(*ie)->to)->max_incoming_zeroReadCycles; 
      if( thisLen > ndcLen ) ndcLen = thisLen;
  }
  if( ndcLen > 0 ) ndcLen += 2;   // add space for previous and next pointers
  else ndcLen = 0;
  PDA_Data** newData4Child = (PDA_Data**)alloca( ndcLen * sizeof(PDA_Data*) ); 

  int n = this_node->max_incoming_zeroReadCycles;
  cur_newData[n] = NULL;      // would be the pointer to a previous newData array: as none exists this value shall stay NULL in the primary record here
  cur_newData[n+1] = NULL;    // will be used as a pointer to a consecutive newData array: used when there are multiple zeroRead loops

  for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
    for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
      PDA_Edge *edge = (PDA_Edge*)*ie;
      if( edge->evalEntryCond( r, '\000', this_data, NULL ) ) {

	if( firstCall4Cycle ) r->addZeroReadEdge( edge );

	PDA_Node* target_node = ((PDA_Node*)edge->to);
	//this_node->print(cout); cout << "->"; target_node->print(cout); cout << ": " << (u_iword)newData4Child << "/" << (u_iword)cur_newData << ":: "; 
	//this_data->print(cout); cout << ", edge:"; edge->print(cout);
	//cout << endl;

	computeZeroReadLookAhead( r, LookAheadChain( target_node, edge->execPushPop(r,this_data,NULL), &this_chain_node, 0, newData4Child ), firstCall4Cycle );
    } }

  //this_node->print(cout); cout << "/ " << (u_iword) cur_newData<< endl;

#if ZERO_READ_MODE == ZRM_goback_double_recursive
  processRemainingData4ZeroReadLookAhead( r, this_node, cur_newDataCount, cur_newData, &this_chain_node, newData4Child ); return;
#else

  while( cur_newDataCount > 0 ) {

    PDA_Data *curDataItem;
    // putchar('*');
    //  cout << (u_iword) cur_newData << "~" << cur_newDataCount << endl;

    while( cur_newDataCount > 1 ) {   // multiple values in current newData: we may need to allocate another instance of newData if needed

      curDataItem = cur_newData[cur_newDataCount-1];

      ((iword*) cur_newData )[n-1] = cur_newDataCount - 1;      // save decremented newDataCount: last node is already in curDataItem: it will be processed soon
      if( cur_newData[n+1] ) { 
       // cout << endl; this_node->print(cout); cout << "/re-push:: " << (u_iword) cur_newData;
	cur_newData = (PDA_Data**)cur_newData[n+1];  //  when a consecutive newData array does already exist then re-use it
       // cout <<  "->" << (u_iword) cur_newData << endl;
      } else {
	void *data = alloca( sizeof(PDA_Data*) * (n+2) );     //  allocate a consecutive newData array
	((void**) data )[n] = cur_newData;                   //  previous pointer of the newly allocated array
	((void**) data )[n+1] = NULL;                 //  next pointer of the newly allocated array is still empty
	((void**) cur_newData )[n+1] = data;                  //  install a next pointer in the current newData array
	//cout << endl; this_node->print(cout); cout << "/push:: " << (u_iword) cur_newData <<  "->" << (u_iword) data << endl;
	cur_newData = (PDA_Data**) data;                      //  now use the newly allocated array
      }

      cur_newDataCount = 0;    // we are now in a fresh and yet unused newData arrray

      //this_node->print(cout); cout << "-i>"; target_node->print(cout); cout << ": " << (u_iword)newData4Child << "/" << (u_iword)cur_newData << ":: "; 
      //this_data->print(cout); cout << ", edge:"; edge->print(cout);
      //cout << endl;

      for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
	for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
	  PDA_Edge *edge = (PDA_Edge*)*ie;
	  if( edge->evalEntryCond( r, '\000', curDataItem, NULL ) ) {
	    PDA_Node* target_node = ((PDA_Node*)edge->to);
	    computeZeroReadLookAhead( r, LookAheadChain( target_node, edge->execPushPop(r,curDataItem,NULL), &this_chain_node, 0, newData4Child ), false );
	} }

      //this_node->print(cout); cout << "/i " << (u_iword) cur_newData << endl;

    }  // end: while cur_newDataCount > 1 

    if( cur_newDataCount > 0 ) {

      curDataItem = cur_newData[0];
      // all cur_newData items except data item #i have already been processed; 
      cur_newDataCount = 0; // now empty this array so that the consecutive call to computeZeroReadLookAhead can re-use it

      for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
	for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
	  PDA_Edge *edge = (PDA_Edge*)*ie;
	  if( edge->evalEntryCond( r, '\000', curDataItem, NULL ) ) {
	    PDA_Node* target_node = ((PDA_Node*)edge->to);
	    computeZeroReadLookAhead( r, LookAheadChain( target_node, edge->execPushPop(r,curDataItem,NULL), &this_chain_node, 0, newData4Child ), false );
	} }

      //this_node->print(cout); cout << "/ii " << (u_iword) cur_newData << endl;

    };

    //this_node->print(cout); cout << "/0 " << (u_iword) cur_newData << endl;

    if( !cur_newDataCount && cur_newData[n] ) {  // last computeZeroReadLookAhead call has not produced any new data, look for a preceding call
      cur_newData = (PDA_Data**)cur_newData[n];     // go to old array
      //this_node->print(cout); cout << "/pop:: " << (u_iword) cur_newData << endl << endl;
      cur_newDataCount = (iword)cur_newData[n-1];    // restore old newDataCount value from there and decrement it
    }

  }  // end: while cur_newData
#endif

}

#undef this_node
#undef this_data
#undef newDataCount
#undef newData

#if ZERO_READ_MODE == ZRM_goback_double_recursive

void PDA_Node::processRemainingData4ZeroReadLookAhead( Runtime *rg, PDA_Node *this_node, int dataCount, PDA_Data **dataItem, struct LookAheadChain *this_chain_node, PDA_Data **childData ) {
  PDA_Runtime *r = (PDA_Runtime*)rg;
  while( dataCount > 0 ) {
    if( dataCount >= 2 ) {
      PDA_Data** freshThisNodeData = (PDA_Data**)alloca( this_node->max_incoming_zeroReadCycles * sizeof(PDA_Data*) );
      this_chain_node->newData = freshThisNodeData;
      do {
	dataCount--; this_chain_node->newDataCount = 0;
	for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
	  for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
	    PDA_Edge *edge = (PDA_Edge*)*ie;
	    if( edge->evalEntryCond( r, '\000', dataItem[dataCount], NULL ) ) {
	      PDA_Node* target_node = ((PDA_Node*)edge->to);
	      computeZeroReadLookAhead( r, LookAheadChain( target_node, edge->execPushPop(r,dataItem[dataCount],NULL), this_chain_node, 0, childData ), false );
	  } }
	processRemainingData4ZeroReadLookAhead( r, this_node, this_chain_node->newDataCount, freshThisNodeData, this_chain_node, childData );
      } while( dataCount >= 2 );
    }
    if( dataCount == 1 ) {
      PDA_Data *curDataItem = dataItem[0];   // prepare to re-use the dataItem array by copying its only still meaningful value out
      this_chain_node->newDataCount = 0; this_chain_node->newData = dataItem;
      for( Nodes::const_iterator in = this_node->epsilonClosure.begin(); in != this_node->epsilonClosure.end(); in++ )
	for( Edges::const_iterator ie = (*in)->succ.begin() + (*in)->epsilonSucc ; ie != (*in)->succ.begin() + ((PDA_Node*)*in)->zeroReadSucc; ie++ ) { 
	  PDA_Edge *edge = (PDA_Edge*)*ie;
	  if( edge->evalEntryCond( r, '\000', curDataItem, NULL ) ) {
	    PDA_Node* target_node = ((PDA_Node*)edge->to);
            computeZeroReadLookAhead( r, LookAheadChain( target_node, edge->execPushPop(r,curDataItem,NULL), this_chain_node, 0, childData ), false );
	  } }
      dataCount = this_chain_node->newDataCount;   // redundant: dataItem = this_chain_node->newData;
    }
  }
  // assert( this_chain_node->newData == dataItem );
}

#undef this_parent

#endif
#endif

void PDA_Node::zeroReadLookAhead( Runtime *r, Data *data ) {
#if ZERO_READ_MODE != ZRM_simple
  PDA_Data** newData = (PDA_Data**)alloca( ( max_incoming_zeroReadCycles + 2 ) * sizeof(PDA_Data*) );
#endif
  if(unlikely( r->cur->conditions & Runtime::adding_zeroreads )) { cerr << "error: PDA_Node::zeroReadLookAhead called recursively from callback of runtime object (addState, addZeroReadEdge, etc.)." << endl; abort(); } 
  r->cur->conditions |= Runtime::adding_zeroreads;
#if ZERO_READ_MODE == ZRM_simple
  simpleComputeZeroReadLookAhead( r, SimpleLookAheadChain( this, (PDA_Data*)data, NULL ) ) ;
#else
  computeZeroReadLookAhead( r, LookAheadChain( this, (PDA_Data*)data, NULL, 0, newData ), true );
#endif
  r->cur->conditions &= ~Runtime::adding_zeroreads;
}


int PDA_Edge::setContent( Automaton *a, estrbuf *userstr ) { 
  int errpos = SymbolTable::normalize( userstr, SymbolMode::mode_greekvars_convert_slash );
  if( *userstr == estr_epsilon ) { userstr->buf_free(); }
  content.moveFrom(userstr);

  if( content.length ) {
    int pos, endpos; bool negated = false;

    if( SymbolTable::isGreekVariable( content.chars[0] ) ) {
      pos = varLength = SymbolTable::varLength( content.chars );  // greater than zero: at least one character
      if( pos >= content.length ) { pos = 0; varLength = 0; }  // no assignment for variable found, only this produces pos > varLength
      else {
	if( content.chars[pos] == '=' ) pos++;
	else {
          pos += scanForNeq( content, pos );
	  if( pos == varLength ) { pos = 0; varLength = 0; }  // no assignment for variable found
	  else negated = true;
      } }
    } else {
      pos = varLength = 0;
      pos += scanForNeq( content, pos );
      negated = ( pos != varLength );
    }

    assert( varLength <= pos );
    pos = scanCharSets( content, pos, negated ? EdgeFlags::negatedCond : 0, a->charsetCheckFlags, &errpos );
    //else { entryCondition = content; baseFlags = simpleCond; /* condition ~ singleton variable value */ edge_proxy.clear(); assert(!negated); }

    if( ++pos < content.length ) {
      int varCount = 0, charCount = 0; for( endpos = pos; endpos < content.length && content.chars[endpos] != SlashSeparator; endpos++ )
 	 if(!SymbolTable::isGreekVariable(content.chars[endpos])) charCount++; else { varCount++; endpos+=SymbolTable::varLength(content.chars+endpos); }
      toPop = content.sub( pos, endpos - pos ); 
      if( !varCount ) astrbuf_from_xstr( &toPopAsConst, toPop, SymbolTable::unknown_achar | aux::convert_special_space );
       else { toPopAsConst.buf_free(); toPopAsConst.chars = NULL; toPopAsConst.length = charCount + varCount; }   // charCount + varCount + 1 is always a valid integer as pos > 0 and thus endpos - pos < MaxValue - 1
      pos = endpos;
    } else {
      toPop = empty_estr; toPopAsConst = empty_astr;
    }

    if( ++pos < content.length ) {
      int varCount = 0, charCount = 0; for( endpos = pos; endpos < content.length && content.chars[endpos] != SlashSeparator; endpos++ )
	 if(!SymbolTable::isGreekVariable(content.chars[endpos])) charCount++; else { varCount++; endpos+=SymbolTable::varLength(content.chars+endpos); }
      toPush = content.sub( pos, endpos - pos ); 
      if( !varCount ) astrbuf_from_xstr( &toPushAsConst, toPush, SymbolTable::unknown_achar | aux::convert_special_space );
      else { toPushAsConst.buf_free(); toPushAsConst.chars = NULL; toPushAsConst.length = charCount + varCount; }   // charCount + varCount + 1 is always a valid integer as pos > 0 and thus endpos - pos < MaxValue - 1
    } else {
      toPush = empty_estr; toPushAsConst = empty_astr;
    }

    if( entryCondition.isEmpty() && !negated && edge_proxy.empty() ) {   // needs special implementation: transitions that do not read an input character
      baseFlags |= zeroReadTransition;
      if( varLength ) { varLength = 0; errpos = 0; }   // no variable may be assigned if no characters are read
    }

  } else {
    toPop = toPush = empty_estr; toPopAsConst = toPushAsConst = empty_astr; edge_proxy.clear(); baseFlags = 0; 
  }

  if( content.isEmpty() || ( ( baseFlags & zeroReadTransition ) && toPop.isEmpty() && toPush.isEmpty() ) ) { 
    baseFlags = isEpsilonTransition;
    entryCondition = content = empty_estr; varLength = 0;
    //userstr->buf_free(); 
  }

  return errpos; 
}

void PDA_Edge::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  printHead( out, debuglevel, isLookAhead, relpos, varLength, true );
  out << IOChangeVal( IOAttr::EscapeChars, estr_slash ); 
  if(!( baseFlags & isEpsilonTransition )) {
    if( toPop.length || toPush.length ) out << "/" << toPop;
    if( toPush.length ) out << "/" << toPush;
  }
  out << IOChangeVal( IOAttr::EscapeChars, empty_estr );   // previously set by printHead if last 
  printTail( out, debuglevel );
}

#ifdef QT_CORE_LIB

void PDA_Edge::cbPrintStackOp( TextCallBack cb, estr_const stackstr, void *data ) const {
  cb( 0, 0, false, estr_slash, data );
  int i = 0, j = stackstr.find_first_of('/');
  while( i < stackstr.length ) {
    if( i < j ) cb( 0, 0, false, stackstr.sub(i,j-i), data );
    if( j >= stackstr.length ) break;
    cb( 0, 0, false, estr_backslash, data );
    i = j; j = stackstr.find_first_of('/',i+1);
  }
}

void PDA_Edge::callbackPrint( TextCallBack cb, void *data ) const {
  if( baseFlags & isEpsilonTransition ) { cb( 0, 0, false, estr_epsilon, data ); return; };
  bool print_as_set = ( baseFlags & hasASet ) && FA_print_cond_as_set;
  int i, num = execLength(), val; struct CursorCounter cc; InitCursorCounter(&cc);   // execLength is the same as conditionLength()
  bool alreadyNegated = false;
  if(num>1) { val = nextCursor(&cc); if(val) cb( -3, val>1, false, empty_estr, data ); }
  if( varLength ) {  // also used for PDA-Edges which can have edge local variables
    bool isNegated = ( baseFlags & negatedCond ) != 0;
    cbPrintSubscripted( cb, 0, false, content.sub(0,varLength), data ); 
    cb( 0, 0, false, isNegated ? estr_neq_char : estr_eq_char , data );
    alreadyNegated = true;
  }
  for( i=0; i < num; i++) { 
    if(i) { val = nextCursor(&cc); if(val) cb( -3, val>1, false, empty_estr, data ); }
    cbPrintCond(cb,i,num,alreadyNegated,print_as_set,data); alreadyNegated = false; 
  }
  if( toPop.length || toPush.length ) cbPrintStackOp( cb, toPop , data );
  if( toPush.length ) cbPrintStackOp( cb, toPush , data );
}

#endif

int PDA_Runtime::numTapes( ParentTapeIndex i ) { 
  if( i.isRootAnchor() ) return 1;
  if(unlikely( i.topidx != 0 )) return 0;
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  return (int)cur->new_data_pos.size() - 1; 
};

int PDA_Runtime::getTape( astr_const *content, int *position, SymbolTable **symTab, TapeIndex i ) {
  if(unlikely( i.topidx != 0 )) return nonExistantTape(content,position,symTab);
  if( i.subidx <= -1 ) {
    if(content) *content = tape; if(position) *position = pos; if(symTab) *symTab = NULL; 
    return 0;
  }
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  if(unlikely( i.subidx >= (int)cur->new_data_pos.size() - 1 )) return nonExistantTape(content,position,symTab);
  PDA_Data *data = (PDA_Data*) cur->new_data_pos[i.subidx].state_pos->data;
  //if(unlikely( !data )) return nonExistantTape(content,position,symTab);
  if(content) *content = data ? data->stack : empty_astr; if(position) *position = -2; 
  if(symTab) *symTab = NULL; 
  return 0;
};

void PDA_Runtime::getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i ) { 
  if( i.subidx <= -1 && i.topidx <= 0 ) { getAllStatesWithLookAhead( standlh ); return; }
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  if(unlikely( i.topidx != 0 || i.subidx >= (int)cur->new_data_pos.size() - 1 )) { getEmptyStatesAndLookAhead( standlh ); return; }
  TraceStep::StatePosVec::const_iterator spos = cur->new_data_pos.begin() + i.subidx;
  standlh->first_state = spos->state_pos;
  standlh->first_lookahead = spos->lhd_pos;
  spos++;
  standlh->last_state = spos->state_pos;
  standlh->last_lookahead = spos->lhd_pos;
};


