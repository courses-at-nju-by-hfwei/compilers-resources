//#include <QtWidgets/QApplication>
#include <QtCore/QTextStream>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtGui/QPainter>
#include <stdio.h>
#include "auxtypes.h"
//#include "automatdef.h"
//#include "FiniteAutomata.h"
//#include "TuringMachine.h"
//#include "LoadSaveAtmt.h"

using namespace aux;

int main( int argc, char *argv[] ) {
  //QApplication app(argc,argv);
  QTextStream qcerr(stderr);
  QString myqstr;
  IOStream(&myqstr) << "world αβγ";
  IOStream myqstr_out(&myqstr); myqstr_out << "world αβγ";
  qcerr << QString("hello %1!").arg(myqstr) << ::endl;

  myqstr = "";
  estrbuf hug2("abcdefg αβγδ xᴗ11❫ hijklämönüo\001\002ÜÄÖüäöß");
  myqstr_out << IOChangeFlags( IOFlag::OverlineNextXStr ) << hug2 << ", " << -123 << IOChangeVal(IOAttr::NumberBaseNextOne,16) << ", hex-value: " << 0xFF << aux::endl;
  myqstr_out << IOChangeVal(IOAttr::NumberBaseNextOne,7) << 8  << ", " << IOChangeVal(IOAttr::NumberBaseNextOne,8) << -9;
  myqstr_out << ", 127 = " << IOChangeFlags( IOFlag::ShowPositiveSign ) << 127 << aux::endl;
  qcerr << myqstr;

  QString qinput = "αβγabc"; myqstr = "";
  IOStream(&qinput) >> &hug2;
  myqstr_out << hug2;
  qcerr << myqstr << ::endl;

  //qcerr << sizeof(QPainter) << ::endl;

  //return app.exec();
}
