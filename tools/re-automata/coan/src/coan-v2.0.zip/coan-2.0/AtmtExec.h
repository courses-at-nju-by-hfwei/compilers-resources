#ifndef ATMT_EXEC_H
#define ATMT_EXEC_H

#include <QtWidgets/QWidget>
#include <QtWidgets/QDialog>
#include "auxtypes.h"
#include "LoadSaveAtmt.h"

class Automaton; class Runtime;
class AtmtWatch; class TapeWatch; class InputSelector; class ExecEnv; class MainWindow;
 class QCheckBox;


class AtmtWatch : public QWidget {
public:
  AtmtWatch( MainWindow *mainWin = NULL );
  int xvirtual, yvirtual; 
  const int pad_xvirtual = 160, pad_yvirtual = 160;
protected:
  void paintEvent(QPaintEvent *event);
  void setMaxCoords( QPointF pos );
  //void resizeEvent(QResizeEvent *event);
  bool event(QEvent *event);
public:
  QSize sizeHint() const { return QSize(xvirtual,yvirtual); }
  //QSize minimumSizeHint() const { return QSize(xvirtual,yvirtual); }
  bool rubberLine; QPointF rubberLineStart, rubberLineEnd;
  Automaton *atmt; MainWindow *mainWindow;
  void setAutomaton( Automaton *a );
};



class OutcomeView : public QWidget {
public:
  OutcomeView( int pointsize = 10 );
  enum ViewWhat { ViewAccepted = 1, ViewHalted = 2, ViewDismissed = 4, ViewErroneous = 8 }; int viewWhat;
  QSize calcExtent();
protected:
  int tapeExtent( int ypos, astr_const tape, int *maxx );
  int drawTape( QPainter *painter, int xpos, int ypos, aux::astr_const tape, int cursor, int *maxx );
  void paintEvent(QPaintEvent *event);
public:
  QSize sizeHint() const { return QSize(xvirtual,yvirtual); }
  Runtime *rt; int xvirtual, yvirtual; int pointsize;
  QFont tapeLetterFont, paramsFont;
};


class OutcomeDialog : public QDialog {
  Q_OBJECT
public:
  OutcomeDialog();
  void adjustSize();
  OutcomeView *view;
  QCheckBox *checkAccepted, *checkHalted, *checkDismissed, *checkErroneous; 
protected slots:
  void cbToggled(bool isChecked);
};


class TapeWatch : public OutcomeView {
public:
  TapeWatch( bool limitedSidebarView = false );
protected:
  QString getValParam( int i, bool addcolon ); QString getCharParam( int i, bool addcolon );
  int drawParams( QPainter *painter, int xpos, int ypos, aux::estr_const formalParams, QString(TapeWatch::*getParam)(int,bool), int *maxheight );
  void paintEvent(QPaintEvent *event);
  bool limitedSidebarView;
  void mouseDoubleClickEvent(QMouseEvent *event);
  void mousePressEvent(QMouseEvent *event);
public:
  enum TapeClickFlags { ChangeOnly = 1, ViewOnly =2, ShowMessageBox = 4 };
  void tape_click( int flags = 0 );
  void setInputList( std::vector<RuntimeParams> *params );
  //QSize minimumSizeHint() const { if(!limitedSidebarView) return QSize(xvirtual,yvirtual); else return QSize(100,yvirtual); }
  //QSize sizeHint() const { if(!limitedSidebarView) return QSize(xvirtual,yvirtual); else return QSize(100,yvirtual); }
  InputSelector *inputSelector; OutcomeDialog *outcomeDialog;
  Automaton *atmt; ExecEnv *execEnv;
  aux::astrbuf tape, charparams; aux::intabuf valparams;
};

#endif
