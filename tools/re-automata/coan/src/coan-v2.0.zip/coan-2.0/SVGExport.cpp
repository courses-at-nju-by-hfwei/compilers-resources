#include "SVGExport.h"
#include <QtGui/QPainter>
#include <QtSvg/QSvgGenerator>

#include "automatdef.h"
#include "AtmtExec.h"

bool createSVG( Automaton *atmt, QString title, QString filename, AtmtWatch *atmtWatch ) {
  if(!atmt) return false;  assert( atmtWatch->atmt == atmt );
  int xvirtual = atmtWatch->xvirtual, yvirtual = atmtWatch->yvirtual;
  QSvgGenerator generator;
  generator.setSize(QSize(xvirtual,yvirtual));
  generator.setViewBox(QRect(0,0,xvirtual,yvirtual));
  generator.setTitle(title);
  generator.setFileName(filename);
  atmt->updateGeometry(&generator);
  QPainter painter;
  painter.begin(&generator);
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) (*in)->draw(&painter,atmt);
  for(std::list<Edge*>::const_iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ ) (*ie)->draw(&painter,atmt);
  painter.end();
  atmt->updateGeometry(atmtWatch);
  return true;
}

