//
//  application written by Elmar Stellnberger 2017, 2018, estellnb@elstel.org, © copyright by E.S.
//
//  This program may be used under the terms of GPLv3; see: https://www.gnu.org/licenses/gpl-3.0.en.html
//  If you apply changes please sign our contributor license agreement at https://www.elstel.org/license/CLA-elstel.pdf
//  so that your changes can be included into the main trunk at https://www.elstel.org/coan/
//

#include <QtWidgets/QApplication>
#include <QtCore/QTextStream>
//#include <QtGui/QPainter>
//#include <QtCore/QString>
#include <stdio.h>
//#include "auxtypes.h"
#include "AtmtCanvas.h"
#include "MainWindow.h"
#include "TuringMachine.h"
#include "FiniteAutomata.h"
#include "TreeWidget.h"
//#include "automatdef.h"
//#include "LoadSaveAtmt.h"

using namespace aux;

#pragma warning(disable:4189)   // do not complain eN: initialized but not referenced

Edge *e2;

Automaton* MS_GraphTest() {
  Automaton *m = new MS();
  Node *a = m->createNode()->assignContent(m,"L:# R^kᴗ12❫-gᴗstartᴗ1❫+1_lᴗ13333❫+mᴗ31❫ R"); a->setCoords(QPointF(200,300)); m->startNode = a;
  Node *b = m->createNode()->assignContent(m,"R σ "); b->setCoords(QPointF(600,300));
  Node *c = m->createNode()->assignContent(m,"R^4 L^4 L^2:#"); c->setCoords(QPointF(1000,300));
  Edge *e1 = m->createEdge(a,b)->assignContent(m,"σ!=#");
  e2 = m->createEdge(b,c)->assignContent(m,"");
  return m;
}

Automaton* MS_Test() {
  Automaton *m = new MS();
  Node *a = m->createNode()->assignContent(m,"L^k:#"); a->setCoords(QPointF(200,300)); m->startNode = a;
  Node *b = m->createNode()->assignContent(m,"R"); b->setCoords(QPointF(400,300));
  Node *c = m->createNode()->assignContent(m,"# R^k+1:# σ L^k+1:# σ"); c->setCoords(QPointF(700,300));
  Node *d = m->createNode()->assignContent(m,"R^k:#"); d->setCoords(QPointF(400,500));
  Edge *e1 = m->createEdge(a,b)->assignContent(m,"");
  Edge *e2 = m->createEdge(b,c)->assignContent(m,"σ!=#");
  Edge *e3 = m->createEdge(c,b)->assignContent(m,"");
  std::vector<int> track; 
  track.push_back(700); track.push_back(300);
  track.push_back(1100); track.push_back(300);
  track.push_back(1100); track.push_back(150);
  track.push_back(400); track.push_back(150);
  track.push_back(400); track.push_back(300);
  e3->setLinearTrack(&track);
  Edge *e4 = m->createEdge(b,d)->assignContent(m,"#");
  m->setFormalCharParams("αᴗ11❫βγ"); m->setFormalValParams("klᴗ12❫m");

  //Runtime *r = m->createRuntime("#abc#"); 
  //r->exec_traced(cout,true,2);   // stopOnResult, debuglevel, max_steps
  //m->freeRuntime(r); cout << aux::endl; 

  return m;
}

Automaton* FA_Test() {
  Automaton *m = new PDA();
  Node *a = m->createNode()->assignContent(m,"nᴗ1❫"); a->setCoords(QPointF(200,300)); m->startNode = a;
  Node *b = m->createNode()->assignContent(m,"nᴗ2❫"); b->setCoords(QPointF(600,300));
  Node *c = m->createNode()->assignContent(m,"nᴗ3❫"); c->setCoords(QPointF(1000,300));
  Node *d = m->createNode()->assignContent(m,"nᴗ4❫"); d->setCoords(QPointF(1000,500));
  Node *e = m->createNode()->assignContent(m,"nᴗ5❫"); e->setCoords(QPointF(600,500));
  Node *f = m->createNode()->assignContent(m,"nᴗ6❫"); f->setCoords(QPointF(200,500)); f->setFinalNode(true);
  Edge *e1 = m->createEdge(a,b)->assignContent(m,"a//xxx");
  e2 = m->createEdge(b,c)->assignContent(m,"b/x/");
  m->createEdge(c,d)->assignContent(m,"c/xx/");
  m->createEdge(c,e)->assignContent(m,"c/x/");
  m->createEdge(d,e)->assignContent(m,"ε");
  m->createEdge(e,f)->assignContent(m,"ε");
  e2 = m->createEdge(a,f); 
  e2->assignContent(m,"abc");

  //Runtime *r = m->createRuntime("abc"); r->exec_traced(aux::cout); m->freeRuntime(r);
  //m->setFormalCharParams("αᴗ11❫βγ"); m->setFormalValParams("klᴗ12❫m");
  //Runtime *r = m->createRuntime("#abc#"); 
  //r->exec_traced(cout,true,2);   // stopOnResult, debuglevel, max_steps
  //m->freeRuntime(r); cout << aux::endl; 

  return m;
}

AtmtTreeNode* InsertExampleAutomaton( struct AtmtTreeBase *base, Automaton *atmt, const char *atmtName ) {
  estrbuf name = atmtName; AtmtTreeNode *node;
  node = new AtmtTreeNode(); node->atmt = atmt;
  setAtmtIndexName( base, node, name ); insertAtmtTreeNode( base, NULL, NULL, node, true );  // base, parent, previous, node, insertAsFirstOne
  return node;
}

void InsertExampleAutomata( struct AtmtTreeBase *base ) {
  AtmtTreeNode *node; astrbuf input_tape; struct RuntimeParams *params;
  node = InsertExampleAutomaton( base, MS_GraphTest(), "MachineSchema_IndexPrintTest" );
  node = InsertExampleAutomaton( base, MS_Test(), "MS_k_Copy_Machine" );
   node->default_inputs.push_back( RuntimeParams{} ); params = &node->default_inputs.back(); int valparams[3] = {2,12,13};
   params->tape = "#Höhle#Axolottl"; params->charparams = "abc"; params->valparams =  inta_const(valparams,3);
  node = InsertExampleAutomaton( base, FA_Test(), "FA_Test" );
   node->default_inputs.push_back( RuntimeParams{} ); params = &node->default_inputs.back(); params->tape = "abc"; params->charparams = "";params->valparams =  inta_const(NULL,0);
   node->default_inputs.push_back( RuntimeParams{} ); params = &node->default_inputs.back(); params->tape = "abcd"; params->charparams = "";params->valparams =  inta_const(NULL,0);
}

int main( int argc, char *argv[] ) {
  QTextStream qcerr(stderr);
  //qcerr << sizeof(QPainter) << ::endl;
  QApplication app(argc,argv);
  //app.setStyle("Plastique");
  app.setStyleSheet("QSplitter::handle { background-color: darkgray; border-style: outset; border-width: 2px; border-color: gray; }");
  elmLabelFont.setPointSize(12); elmLabelFont.setFamily("Helvetica");

  //AtmtCanvas canvas;
  //canvas.setAutomaton( MS_Test() ); canvas.atmt->updateGeometry(&canvas);
  //canvas.setAutomaton( FA_Test() ); canvas.atmt->updateGeometry(&canvas);
  //canvas.show();

  //MainWindow mainWindow; int valparams[3] = {11,12,13}; astrbuf input_tape = "abc", input_charparams = "xyz"; 
  //mainWindow.execEnv->setAutomaton( FA_Test() ); 
  MainWindow *mainWindow = new MainWindow(); 
  mainWindow->readSettings(); 
  //mainWindow->openFile("Test2.atm");
  ////InsertExampleAutomata( &mainWindow->treeBase );
  ////if( !LoadAllAtmts( &mainWindow->treeBase, "../Test.atm" ) ) LoadAllAtmts( &mainWindow->treeBase,"Test.atm");
  ////updateAllAutomataGeometry( mainWindow->treeBase.atmtTree, mainWindow->viewAtmt );
  //estrbuf kopiere_label = "Kopiere"; AtmtIndex::iterator ref = atmtIndex.find(kopiere_label); if( ref != atmtIndex.end() ) ref->second->atmt->updateGeometry(mainWindow->viewAtmt); 
  ////mainWindow->atmtTreeWidget->setModel( &mainWindow->treeBase );
  //QTreeWidgetItem *current = mainWindow->atmtTreeWidget->currentItem(); mainWindow->atmtTreeWidget->setCurrentItem(mainWindow->atmtTreeWidget->topLevelItem(0)); mainWindow->atmtTreeWidget->setCurrentItem(current);
  
  /*
  int valparams[3] = {2,12,13}; astrbuf input_tape = "#abc#def#", input_charparams = "xyz"; 
  mainWindow->setAutomaton( MS_Test() ); 
  mainWindow->viewAtmt->atmt->updateGeometry(mainWindow->viewAtmt);
  mainWindow->viewTape->tape = input_tape; mainWindow->viewTape->charparams = input_charparams; mainWindow->viewTape->valparams = inta_const(valparams,3);
  std::vector<RuntimeParams> predef_params;
  predef_params.push_back( RuntimeParams{} ); predef_params.back().tape = "#abcd#efgh#ijkl#"; predef_params.back().charparams = "xyz"; predef_params.back().valparams =  inta_const(valparams,3);
  predef_params.push_back( RuntimeParams{} ); predef_params.back().tape = "abcd"; predef_params.back().charparams = "xyz"; predef_params.back().valparams =  inta_const(valparams,3);
  predef_params.push_back( RuntimeParams{} ); predef_params.back().tape = "mnop"; predef_params.back().charparams = "qrx"; predef_params.back().valparams =  inta_const(valparams,3);
  mainWindow->viewTape->setInputList( &predef_params );
  mainWindow->viewTape->inputSelector->pickLast();*/
  mainWindow->show();

  return app.exec();
}
