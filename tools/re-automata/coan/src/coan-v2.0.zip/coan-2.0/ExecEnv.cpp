#include "AtmtExec.h"

#include <QtCore/QTimer>
#include <QtGui/QKeyEvent>
#include <QtWidgets/QLabel>
#include <QtWidgets/QStatusBar>
#include "automatdef.h"
#include "AtmtExec.h"
#include "ExecEnv.h"

using namespace aux;


ExecEnv::ExecEnv( AtmtWatch *atmtWatch, TapeWatch *tapeWatch, TapeWatch *addTapeWatch, QStatusBar *appStatusBar, QLabel *atmtStatus ) : viewAtmt(atmtWatch), viewTape(tapeWatch), addTapeView(addTapeWatch), statusBar(appStatusBar), statusBarLabel(atmtStatus) { 
  tapeWatch->execEnv = this; if(addTapeWatch) addTapeWatch->execEnv = this; tracelen = 2; atmt = NULL; rt = NULL;
  simulateTimer = new QTimer(atmtWatch);
  connect(simulateTimer,SIGNAL(timeout()),this,SLOT(simulation_step()));
}

void ExecEnv::setAutomaton( Automaton *atmt ) { 
  reset(); this->atmt = atmt; viewAtmt->setAutomaton(atmt); viewTape->atmt = atmt; addTapeView->atmt = atmt;
}

void ExecEnv::start_exec() { if(rt) return;
  rt = atmt->createRuntime( viewTape->tape, -1, viewTape->charparams, viewTape->valparams, tracelen, true );
  viewTape->rt = rt; addTapeView->rt = rt;
}

//    States::const_iterator first_state, last_state;
//    ImStateVector::const_iterator first_lookahead, last_lookahead;

void ExecEnv::unmark() { 
  //cout << "unmark " << IOFlush();
  struct Runtime::StatesAndLookAhead active; rt->getAllStatesWithLookAhead( &active );
  for( States::const_iterator state = active.first_state; state != active.last_state; state++ ) {
    GraphElement *ge = gelm(state->elm); ge->setNormalModus(); ge->resetCursor(); 
  }
  for( ImStateVector::const_iterator lookahead = active.first_lookahead; lookahead != active.last_lookahead; lookahead++) { 
    GraphElement *ge = gelm(lookahead->elm); ge->setNormalModus();
    // cout << lookahead->elm->getContent() << lookahead->elm->modus << ", " << IOFlush(); 
  }
  struct Runtime::ViewOnlyElementRange voera;
  rt->getZeroReadEdges(&voera); for( ViewOnlyElements::iterator vi = voera.begin; vi != voera.end; vi++) gelm(*vi)->setNormalModus();
  rt->getActiveErrorElements(&voera); for( ViewOnlyElements::iterator vi = voera.begin; vi != voera.end; vi++) gelm(*vi)->setNormalModus();
  viewAtmt->update();
}

void ExecEnv::mark() { 
  //cout << "mark " << IOFlush();
  struct Runtime::StatesAndLookAhead active; rt->getAllStatesWithLookAhead( &active );
  for( States::const_iterator state = active.first_state; state != active.last_state; state++ ) {
    GraphElement *ge = gelm(state->elm); ge->modus = Modus::inexec; ge->setCursor(state->elm->relpos(),1); // cout << state->elm->getContent(); }
  }
  for( ImStateVector::const_iterator lookahead = active.first_lookahead; lookahead != active.last_lookahead; lookahead++) { 
    GraphElement *ge = gelm(lookahead->elm); ge->modus = Modus::inexec;
    //cout << (u_iword)lookahead->elm << lookahead->elm->getContent() << lookahead->elm->modus << ", " << IOFlush(); 
  }
  struct Runtime::ViewOnlyElementRange voera;
  rt->getZeroReadEdges(&voera); for( ViewOnlyElements::iterator vi = voera.begin; vi != voera.end; vi++) gelm(*vi)->modus = Modus::inexec;
  rt->getActiveErrorElements(&voera); for( ViewOnlyElements::iterator vi = voera.begin; vi != voera.end; vi++) gelm(*vi)->modus = Modus::inexec_erroneous;
  viewAtmt->update();
}

void ExecEnv::reset() { 
  if(!atmt) return; simulateTimer->stop(); 
  if(rt) { unmark(); atmt->freeRuntime(rt); }; 
   rt = NULL; viewTape->rt = NULL; addTapeView->rt = NULL; 
   statusBarLabel->setText(""); viewTape->update(); addTapeView->update(); 
}

void ExecEnv::updateStatusBar() {
  if(!rt) { statusBarLabel->setText(""); return; }
  QString statusBarText = tr(Status2Chars[rt->getStatus()]); 
  IOStream stream(&statusBarText);
  int cur_errors = rt->getErrorConditionsFromLastStep();
  int accrued_errors = rt->getErrorConditions() & ~cur_errors;
  if(cur_errors) { statusBarText.append(tr(", errors: ")); rt->printConditions( stream, cur_errors ); }   // not translation aware, yet
  if(accrued_errors) { statusBarText.append(tr(", errors from before: ")); rt->printConditions( stream, accrued_errors ); }
  statusBarLabel->setText(statusBarText);
}

void ExecEnv::step_forward() { 
  if(!rt) { start_exec(); mark(); statusBarLabel->setText(tr("initialized")); } 
  else { unmark(); rt->nextStep(); mark(); updateStatusBar(); }; 
  viewTape->update(); addTapeView->update(); 
}

void ExecEnv::run( bool stopOnResult )  { 
  simulateTimer->stop(); if(!rt) start_exec(); 
  if(rt) { 
    unmark();
    bool quitted_before = !rt->exec(stopOnResult,100000);
    updateStatusBar(); if(quitted_before) statusBar->showMessage("quitted after 100.000 steps.",2000); 
    mark(); viewTape->update(); addTapeView->update(); 
  } 
}
void ExecEnv::run_through()  { run(false); }
void ExecEnv::run_till_result() { run(true); }

void ExecEnv::startstop_simulation() { if(!simulateTimer->isActive()) simulateTimer->start(500); else simulateTimer->stop(); }  // half a second
void ExecEnv::simulation_step() { step_forward(); updateStatusBar(); if( rt && rt->getStatus() > Status::stepDone ) simulateTimer->stop(); } 

void ExecEnv::leave() { reset(); }

void ExecEnv::step_backward() { 
}

void ExecEnv::change_tape() { viewTape->tape_click( TapeWatch::ChangeOnly | TapeWatch::ShowMessageBox ); }
void ExecEnv::view_outcome() { viewTape->tape_click( TapeWatch::ViewOnly | TapeWatch::ShowMessageBox ); }

bool ExecEnv::keyPressed(QKeyEvent *event) { 
  //cout << "keypress" << IOFlush();
  switch(event->key()) {
    case Qt::Key_F5: reset(); break;
    case Qt::Key_F6: startstop_simulation(); break;
    case Qt::Key_F7: step_backward(); break;
    case Qt::Key_F8: step_forward(); break;
    case Qt::Key_F9: run( !( event->modifiers() & ( Qt::ControlModifier | Qt::ShiftModifier | Qt::AltModifier ) ) ); break;
    default: return false;
  }
  return true;
}

