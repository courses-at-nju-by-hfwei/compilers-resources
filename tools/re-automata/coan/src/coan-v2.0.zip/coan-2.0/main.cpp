#include "auxtypes.h"
#include "charset.h"
#include "automatdef.h"
#include "FiniteAutomata.h"
#include "TuringMachine.h"
#include "LoadSaveAtmt.h"
//#include <iostream>
//#include <map>
#include "errno.h"

using namespace aux;

void simpleFA() {
  cout << "****** simpleFA ******" << endl;
  Automaton  *a = new FA(); Edge *e;
  Node *s0 = a->createNode()->assignContent(a,"s0");
  Node *s0e = a->createNode()->assignContent(a,"s0ε");
  Node *s1 = a->createNode()->assignContent(a,"s1");
  Node *s2 = a->createNode()->assignContent(a,"s2");
  Node *s3 = a->createNode()->assignContent(a,"s3");
  Node *s4 = a->createNode()->assignContent(a,"s4");
  Node *s4e = a->createNode()->assignContent(a,"s4ε");
  Node *s4ee = a->createNode()->assignContent(a,"s4εε");
  e = a->createEdge(s0e,s1)->assignContent(a,"a");
  e = a->createEdge(s0e,s2)->assignContent(a,"a");
  e = a->createEdge(s1,s3)->assignContent(a,"b");
  e = a->createEdge(s2,s3)->assignContent(a,"c");
  //e = a->createEdge(s3,s4)->assignContent(estrb("c"));
  e = a->createEdge(s0e,s4)->assignContent(a,"abc");
  e = a->createEdge(s0,s0e)->assignContent(a,estrb(estr_epsilon));
  e = a->createEdge(s4,s4e)->assignContent(a,estrb(empty_estr));
  e = a->createEdge(s4e,s4ee)->assignContent(a,estrb(estr_epsilon));
  s4ee->setFinalNode(true); e = e;
  a->startNode = s0;
  //a->refreshEpsilonClosure();
  //cout << "epsl[s4] = " << s4->epsilonClosure.size() << endl;
  Runtime *r = a->createRuntime("abc"); r->exec_traced(cout,0);
  Runtime *r2 = a->createRuntime("xxx"); r2->exec_traced(cout);
  Runtime *r3 = a->createRuntime("axx"); r3->exec_traced(cout);
  Runtime *r4 = a->createRuntime("ab"); r4->exec_traced(cout);
  a->freeRuntime(r); a->freeRuntime(r2); a->freeRuntime(r3); a->freeRuntime(r4); delete a;
}

void simplePDA() {
  cout << "****** simplePDA ******" << endl;
  Automaton  *a = new PDA(); Edge *e;
  Node *s0 = a->createNode()->assignContent(a,"s0");
  Node *s1 = a->createNode()->assignContent(a,"s1");
  Node *s2 = a->createNode()->assignContent(a,"s2");
  Node *s3 = a->createNode()->assignContent(a,"s3");
  Node *s4 = a->createNode()->assignContent(a,"s4");
  Node *s4e = a->createNode()->assignContent(a,"s4ε");
  e = a->createEdge(s0,s1)->assignContent(a,"a/ε/x");
  e = a->createEdge(s0,s2)->assignContent(a,"a//yy");
  e = a->createEdge(s1,s3)->assignContent(a,"b/x");
  e = a->createEdge(s2,s3)->assignContent(a,"c/y/ε");
  //e = a->createEdge(s3,s4)->assignContent(estrb("c"));
  e = a->createEdge(s0,s4)->assignContent(a,"ab//ba");
  e = a->createEdge(s0,s4)->assignContent(a,"ab//ba");
  e = a->createEdge(s0,s4)->assignContent(a,"ab//qa");
  e = a->createEdge(s4,s4e)->assignContent(a,"ε/ε/ε");
  PDA_Edge *pe = (PDA_Edge*) e;
  cout << pe->entryCondition << "<" << pe->toPop << "," << pe->toPush << ">" << endl;
  s3->setFinalNode(true);
  s4e->setFinalNode(true);
  a->startNode = s0;
  //a->refreshEpsilonClosure();
  //cout << "epsl[s4] = " << s4->epsilonClosure.size() << endl;
  Runtime *r = a->createRuntime("ab")->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void simpleTM() {
  cout << "****** simpleTM ******" << endl;
  Automaton *a = new TM(); Edge *e;
  Node *s0 = a->createNode()->assignContent(a,"s0");
  Node *s1 = a->createNode()->assignContent(a,"s1");
  Node *s2 = a->createNode()->assignContent(a,"s2");
  Node *q1 = a->createNode()->assignContent(a,"q1");
  Node *q2 = a->createNode()->assignContent(a,"q2");
  Node *p1 = a->createNode()->assignContent(a,"p1");
  Node *p2 = a->createNode()->assignContent(a,"p2");
  Node *p3 = a->createNode()->assignContent(a,"p3");
  Node *p4 = a->createNode()->assignContent(a,"p3");
  Node *h = a->createNode()->assignContent(a,"h");
  Node *right = a->createNode()->assignContent(a,"right");
  e = a->createEdge(s0,s1)->assignContent(a,"(#,L)");
  TM_Edge *te = (TM_Edge*) e;
  cout << "TM_Edge('#/L') " << te->condition << "<" << AChar(te->write_char) << "," << te->move_position << ">" << endl;
  e = a->createEdge(s1,s1)->assignContent(a,"(b,#)");
  e = a->createEdge(s1,s2)->assignContent(a,"(#,L)");
  e = a->createEdge(s2,s2)->assignContent(a,"(a,Y)");
  e = a->createEdge(s2,h)->assignContent(a,"Y,R");
  e = a->createEdge(s0,q1)->assignContent(a,"#,L");
  e = a->createEdge(q1,q1)->assignContent(a,"ab,#");
  e = a->createEdge(q1,q2)->assignContent(a,"#,L");
  e = a->createEdge(q2,q2)->assignContent(a,"ab,N");
  e = a->createEdge(q2,h)->assignContent(a,"N,R");
  e = a->createEdge(s0,p1)->assignContent(a,"#,L");
  e = a->createEdge(p1,p1)->assignContent(a,"b,#");
  e = a->createEdge(p1,p2)->assignContent(a,"#,L");
  e = a->createEdge(p2,p3)->assignContent(a,"a,L");
  e = a->createEdge(p3,p3)->assignContent(a,"#,R");
  e = a->createEdge(p3,p4)->assignContent(a,"a,N");
  e = a->createEdge(p4,h)->assignContent(a,"N,R");
  e = a->createEdge(s0,right)->assignContent(a,"(#,R)");
  a->startNode = s0;
  Runtime *r;
/* cout << "pos:2 " << ( r = a->createRuntime(astrc("#ab#######"),2) )->getTapeContent(0); cout  << ":" << r->getTapePos(0) << " = 2" << endl;
  cout << "pos:3 " << ( r = a->createRuntime(astrc("#ab#######"),3) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << ( r = a->createRuntime(astrc("#ab#######")) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << ( r = a->createRuntime(astrc("#ab")) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << "pos:4 " << ( r = a->createRuntime(astrc("#ab#"),4) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << "pos:8 " << ( r = a->createRuntime(astrc("#ab#"),8) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << "pos:8 " << ( r = a->createRuntime(astrc("#ab"),8) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 3" << endl;
  cout << ( r = a->createRuntime(astrc("")) )->getTapeContent(0); cout << ":" << r->getTapePos(0) << " = 0" << endl; */
  r = a->createRuntime("#abc"); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc#"); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc#####"); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc",3); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc#####",2); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc",4); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc#",4); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc##",4); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  r = a->createRuntime("#abc",8); r->printData( cout, r->cur->states.begin()->data, false ); a->freeRuntime(r); cout << endl;
  //delete a; return;
  r = a->createRuntime("#ab#")->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void SpecialTest() {
  cout << "****** SpecialTest ******" << endl;
  Automaton  *a = new PDA(); Edge *e;
  // there was an error that an ε-edge was marked multiple times when it was reachable from non-adjacent states
  // in bool Runtime::addState( State next ):
  // bool epsilonNotHereYet = !lookForSameElement( insertPos.first, node ) && needed2AddEpsilonEdgesOf( node );
  // if(epsilonNotHereYet) addEpsilonEdgesOf( node );
  // this automaton tests the case that lookForSameElement( insertPos.first, node ) is false but needed2AddEpsilonEdgesOf( node ) also yields false the second time (Edge(s,na) a//xxx) 
  //   so that epsilonNotHereYet becomes false and adding a-ε-f for the second time is avoided
  Node *s = a->createNode()->assignContent(a,"s");
  Node *na = a->createNode()->assignContent(a,"a");
  Node *nb = a->createNode()->assignContent(a,"b");
  Node *f = a->createNode()->assignContent(a,"f");
  e = a->createEdge(s,na)->assignContent(a,"a//x");
  e = a->createEdge(s,nb)->assignContent(a,"a//xx");
  e = a->createEdge(s,na)->assignContent(a,"a//xxx");
  e = a->createEdge(na,f)->assignContent(a,"ε"); e = e;
  a->startNode = s; f->setFinalNode(true); 
  Runtime *r = a->createRuntime("a"); r->exec_traced(cout);
  a->freeRuntime(r); delete a;
  a = new FA();
  s = a->createNode()->assignContent(a,"s");
  f = a->createNode()->assignContent(a,"f");
  e = a->createEdge(s,f)->assignContent(a,"!=a\\+!=b\\+!=c");   // there was an error printng negated one character conditions
  e = a->createEdge(s,f)->assignContent(a,"αβγ");   // there was an error printng negated one character conditions
  a->startNode = s; f->setFinalNode(true); 
  cout << a->setFormalCharParams("αβγ") << " of 3 variable parameters defined sucessfully." << endl;    // both functions will return the number of accepted params
  r = a->createRuntime("bcd",0,"bcd"); r->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void PalindromPDA() {
  cout << "****** PalindromPDA ******" << endl;
  Automaton  *a = new PDA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  a->startNode = s; f->setFinalNode(true);
  a->createEdge(s,s)->assignContent(a,"α!=//α");
  a->createEdge(s,f)->assignContent(a,"ε");
  a->createEdge(s,f)->assignContent(a,"!=")->print(cout,2,false); cout << endl;
  a->createEdge(f,f)->assignContent(a,"α!=/α");
  Runtime *r1 = a->createRuntime("abcddcba");
  r1->exec_traced(cout);
  Runtime *r2 = a->createRuntime("abcdcba");
  r2->exec_traced(cout);
  a->freeRuntime(r1); a->freeRuntime(r2); delete a;
}

void GEQ_PDA() {
  cout << "****** GEQ_PDA ******" << endl;
  Automaton  *a = new PDA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  a->startNode = s; f->setFinalNode(true);
  a->createEdge(s,s)->assignContent(a,"a//x");
  a->createEdge(s,f)->assignContent(a,"b/x");
  a->createEdge(f,f)->assignContent(a,"b/x");
  a->createEdge(f,f)->assignContent(a,"ε/x");
  Runtime *r1 = a->createRuntime("aaabbb");	    // error - this is not an illegal epsilon-loop!!!
  r1->exec_traced(cout);
  Runtime *r2 = a->createRuntime("aab");
  r2->exec_traced(cout);
  a->freeRuntime(r1); a->freeRuntime(r2); delete a;
}

void ZeroReadLoop( bool loopOfLoops ) {
  cout << "****** ZeroReadLoop(loopOfLoops=" << ( loopOfLoops ? "true" : "false" ) << ") ******" << endl;
  Automaton  *a = new PDA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  Node *m = a->createNode()->assignContent(a,"m");
  a->startNode = s; f->setFinalNode(true);
  a->createEdge(s,s)->assignContent(a,"a//x");
  a->createEdge(s,f)->assignContent(a,"z");
  a->createEdge(f,m)->assignContent(a,"ε//x");	      // +1
  a->createEdge(m,f)->assignContent(a,"ε/xx");	      // -2 ~ -1
  a->createEdge(m,f)->assignContent(a,"ε/xxxx");        // -4 ~ -3
  a->createEdge(m,f)->assignContent(a,"ε/xxxxxxxxxx");    // -10 ~ -9
  if( loopOfLoops ) a->createEdge(m,m)->assignContent(a,"ε/x");
  Runtime *r = a->createRuntime("aaaaaaaaaaaaaaz");   // 14xa 
  r->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void ZeroReadLoops() {
  cout << "****** ZeroReadLoops ******" << endl;
  Automaton  *a = new PDA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  Node *m = a->createNode()->assignContent(a,"m");
  a->startNode = s; f->setFinalNode(true);
  a->createEdge(s,s)->assignContent(a,"a//x");
  a->createEdge(s,f)->assignContent(a,"z");
  a->createEdge(f,f)->assignContent(a,"ε/xx");    // - 2
  //a->createEdge(f,f)->assignContent(a,"ε/xxx");    // - 3
  a->createEdge(f,m)->assignContent(a,"ε//x");
  a->createEdge(m,f)->assignContent(a,"ε/xxxx");  // - 3
  Runtime *r = a->createRuntime("aaaaaz");  // + 5
  r->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void MultiCharSetEdgeFA() {
  cout << "****** MultiCharSetEdgeFA ******" << endl;
  Automaton  *a = new FA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  a->createEdge(s,f)->assignContent(a,"p\\+g\\+q");
  //a->createEdge(s,f)->assignContent(a,"pgq");  // same result as with \\+
  a->createEdge(s,f)->assignContent(a,"p12\\+");
  a->createEdge(s,f)->assignContent(a,"p\\+e\\..g\\+q");
  a->createEdge(s,f)->assignContent(a,"αβ\\:sub:11 γ\\+ABC\\+a\\..c\\-β\\:sub:11")->print(cout); cout << endl;
  a->startNode = s; f->setFinalNode(true);
  cout << a->setFormalCharParams("αβ\\:sub:11 γ") << " of 3 variable parameters defined sucessfully." << endl;    // both functions will return the number of accepted params
  Runtime *r0 = a->createRuntime("pfq",0,"xxx")->exec_traced(cout);
  Runtime *r1a = a->createRuntime("aBc",0,"abc");
  r1a->paramSymTab->print(cout); cout << endl; r1a->exec_traced(cout);
  Runtime *r1b = a->createRuntime("bBc",0,"abc"); r1b->exec_traced(cout);
  Runtime *r1c = a->createRuntime("cBc",0,"abc"); r1c->exec_traced(cout);
  Runtime *r2 = a->createRuntime("aBb",0,"abc"); r2->exec_traced(cout);
  Runtime *r3 = a->createRuntime("aBb",0,"a");
  r3->paramSymTab->print(cout); cout << endl; 
  r3->exec_traced(cout); r3->setIgnoreErrorMask(-1); r3->exec_traced(cout); 
  a->freeRuntime(r0); a->freeRuntime(r1a); a->freeRuntime(r1b); a->freeRuntime(r1c); a->freeRuntime(r2); a->freeRuntime(r3); delete a;
  a = new FA(); a->charsetCheckFlags = ExtCharSet::allow_var_ranges;
  s = a->createNode()->assignContent(a,"s");
  a->createEdge(s,s)->assignContent(a,"α\\..β");
  a->startNode = s; s->setFinalNode(true);
  cout << a->setFormalCharParams("αβ") << " of 2 variable parameters defined sucessfully (α…β = a…d)." << endl;    // both functions will return the number of accepted params
  Runtime *r = a->createRuntime("abcd",0,"ad")->exec_traced(cout);
  a->freeRuntime(r); delete a;
}

void testCreateRemove() {
  cout << "****** testCreateRemove ******" << endl;
  cout << "Automaton::removeElement(..) - test" << endl;
  Automaton  *a = new PDA();
  Node *s = a->createNode()->assignContent(a,"s");
  Node *f = a->createNode()->assignContent(a,"f");
  assert( a->removeElement( a->createEdge(s,f)->assignContent(a,"edge1") ) );
  Edge *e2 = a->createEdge(s,f)->assignContent(a,"edge2"); e2 = e2;
  Edge *e3 = a->createEdge(s,f)->assignContent(a,"edge3"); e3 = e3;
  assert( a->removeElement( &s ) );
  assert( a->removeElement( &f ) );
  // assert( a->removeElement( &e2 ) ); // already destroyed
  s = a->createNode()->assignContent(a,"s");
  f = a->createNode()->assignContent(a,"f");
  a->createEdge(s,f)->assignContent(a,"edge1");
  e2 = a->createEdge(f,f)->assignContent(a,"edge2");
  e3 = a->createEdge(s,f)->assignContent(a,"edge3");
  a->typedRemoveElement( s, &a->allNodes );
  cout << a->removeDanglingEdges() << " dangling edges removed." << endl; 
  assert( a->elementIsPartOf( e2 ) );
  assert( !a->elementIsPartOf( e3 ) );
  delete a;
  cout << "test passed ok." << endl;
}

void TuringMachineTest() {
  cout << "****** TuringMachineTest ******" << endl;
  Automaton *t = new TM();
  Node *a = t->createNode()->assignContent(t,"a"); t->startNode = a;
  Node *b = t->createNode()->assignContent(t,"b");
  Node *c = t->createNode()->assignContent(t,"c");
  Node *h = t->createNode()->assignContent(t,"h");
  t->createEdge(a,b)->assignContent(t,"(σᴗ12 =#,L)");
  t->createEdge(b,b)->assignContent(t,"(σᴗ12 !=#,#)");
  t->createEdge(b,c)->assignContent(t,"(#,L)");
  t->createEdge(c,c)->assignContent(t,"(!=σᴗ12 ,σᴗ12 )");  // mehrbuchstabiger VariablenName geschrieben!!
  t->createEdge(c,h)->assignContent(t,"(σᴗ12 ,R)");  // mehrbuchstabiger VariablenName geschrieben!!
  Runtime *r = t->createRuntime("#abc#")->exec_traced(cout); 
  t->freeRuntime(r); delete t; 
}

void TM_ContinueErrTest() {
  cout << "****** TM_ContinueErrTest ******" << endl;
  Automaton *t = new TM();
  Node *a = t->createNode()->assignContent(t,"a"); t->startNode = a;
  Node *b = t->createNode()->assignContent(t,"b");
  Node *c = t->createNode()->assignContent(t,"c");
  Node *d = t->createNode()->assignContent(t,"d");
  Node *e = t->createNode()->assignContent(t,"e");
  Node *h = t->createNode()->assignContent(t,"h");
  t->createEdge(a,b)->assignContent(t,"(#,L)");
  t->createEdge(b,b)->assignContent(t,"(σᴗ12 !=#,#)");
  t->createEdge(b,c)->assignContent(t,"(#,L)");
  t->createEdge(c,d)->assignContent(t,"(!=,σᴗ12 )");
  t->createEdge(d,e)->assignContent(t,"(!=,R)");
  t->createEdge(e,h)->assignContent(t,"(σᴗ12 ,σᴗ12 )");
  t->createEdge(e,h)->assignContent(t,"(α!=,α)");

  t->freeRuntime( t->createRuntime("#abc#")->exec_traced(cout) ); cout << endl; 

  Runtime *r = t->createRuntime("#ab##",4); 
  while( r->mightContinue() ) r->exec_traced(cout); 
  t->freeRuntime(r); cout << endl; 

  r = t->createRuntime("#ab##",4)->setIgnoreErrorMask(-1)->exec_traced(cout); 
  t->freeRuntime(r); cout << endl; 

  delete t;

}

struct AtmtTreeBase treeBase;

void LoadSaveTest() {
  Automaton *chkkl,*endlatmt,*copy,*dblkl,*simpleMS; estrbuf chkkl_label = "ChkKl", endlatmt_label = "EndlicherAutomat", copy_label = "Kopiere", dblkl_label = "DblKl", simpleMS_label = "SimpleMS";
  AtmtIndex::iterator ref;
  if( !LoadAllAtmts( &treeBase, "../Test2.atm" ) ) LoadAllAtmts( &treeBase, "Test2.atm" );
  PrintAtmtTree( &treeBase );

  ref = treeBase.atmtIndex.find( endlatmt_label );
  if( ref != treeBase.atmtIndex.end() ) {
    endlatmt = ref->second->atmt;
    Runtime *r = endlatmt->createRuntime("aa");
    r->exec_traced(cout);
    endlatmt->freeRuntime(r);
  }

  chkkl = NULL; chkkl = chkkl;
  ref = treeBase.atmtIndex.find(chkkl_label);
  if( ref != treeBase.atmtIndex.end() ) {
    chkkl = ref->second->atmt; // if(!dynamic_cast<TM*>(chkkl)) { cerr << "not a turing machine." << endl; return; }
    //Runtime *r = chkkl->createRuntime("{{}}{}");
    Runtime *r = chkkl->createRuntime("#{{}}{}");
    r->exec_traced(cout);
    chkkl->freeRuntime(r);
  } else cerr << "automaton " << chkkl_label << " not found." << endl; 

  copy = NULL; copy = copy;
  ref = treeBase.atmtIndex.find(copy_label);
  if( ref != treeBase.atmtIndex.end() ) {
    copy = ref->second->atmt;
    copy->startNode->print(cout,2,0,0); cout << endl; // debuglevel, isLookAhead, relpos
    Runtime *r = copy->createRuntime("#abcdef");
    r->exec_traced(cout);
    copy->freeRuntime(r);
  } else cerr << "automaton " << copy_label << " not found." << endl; 
  dblkl = NULL; dblkl = dblkl;
  ref = treeBase.atmtIndex.find(dblkl_label);
  if( ref != treeBase.atmtIndex.end() ) {
    dblkl = ref->second->atmt;
    //Runtime *r = dblkl->createRuntime("#{{}}{}#{}{}#");
    Runtime *r = dblkl->createRuntime("#{{}}{}");
    r->exec_traced(cout);
    dblkl->freeRuntime(r);
  } else cerr << "automaton " << dblkl_label << " not found." << endl; 

  simpleMS = NULL; simpleMS = simpleMS;
  ref = treeBase.atmtIndex.find(simpleMS_label);
  if( ref != treeBase.atmtIndex.end() ) {
    dblkl = ref->second->atmt;
    Runtime *r = dblkl->createRuntime("#{{}}{}");
    r->exec_traced(cout);
    dblkl->freeRuntime(r);
  } else cerr << "automaton " << simpleMS_label << " not found." << endl; 
}

void MS_Test() {
  cout << "****** MS_Test ******" << endl;
  Automaton *m = new MS();
  Node *a = m->createNode()->assignContent(m,"L:# R R"); m->startNode = a;
  Node *b = m->createNode()->assignContent(m,"R^3:# σ ");
  Node *c = m->createNode()->assignContent(m,"R^4 L^4 L^2:#");
  Edge *e1 = m->createEdge(a,b)->assignContent(m,"σ!=#");
  Edge *e2 = m->createEdge(b,c)->assignContent(m,"");
  // m->createEdge(b,a)->assignContent(m,"σ!=#");

  a->print(cout,2,0,0); cout << endl; // debuglevel, isLookAhead, relpos
  e1->print(cout,2,0,0); cout << endl;
  e2->print(cout,2,0,0); cout << endl;
  b->print(cout,2,0,0); cout << endl;

  Runtime *r = m->createRuntime("#abc#"); 
  r->exec_traced(cout,true,2);   // stopOnResult, debuglevel, max_steps
  m->freeRuntime(r); cout << endl; 

  delete m;
}

int main( int argc, char *argv[] ) {
  //echar *readstring; 
  //long long hug;
  cout << IOChangeFlags( IOFlag::ImmediateFlush ); 
  cout << "Console Automaton Simulator" << endl;
  //cout << sizeof( std::map<long,achar> );
  cout << "len('abwzäöüαβγÜZ') = " << utf8len("abwzäöüαβγÜZ") << endl;
  cout << "len('世界 你好') = " << utf8len("世界 你好") << endl;
  //if( ~( stin >> &readstring  ) ) stin.perror("error reading string");
  //cout << estrlen(readstring) << ": " << readstring << endl;
  // if( ~( stin >> &hug  ) ) stin.perror("error reading integer");
  // cout << hug << endl;
  //cout << sizeof(echar) << endl;

  //simpleFA(); cout << "-------------------------------------" << endl;
  //return 0;

 simplePDA(); cout << "-------------------------------------" << endl;
 // SpecialTest();  cout << "-------------------------------------" << endl;
//PalindromPDA(); cout << "-------------------------------------" << endl;
 // GEQ_PDA(); cout << "-------------------------------------" << endl;
 //ZeroReadLoop(false); cout << "-------------------------------------" << endl;
 // ZeroReadLoop(true); cout << "-------------------------------------" << endl;
  //ZeroReadLoops(); cout << "-------------------------------------" << endl;
  // MultiCharSetEdgeFA(); cout << "-------------------------------------" << endl;
  // testCreateRemove();
  //simpleTM(); cout << "-------------------------------------" << endl;
  //TuringMachineTest(); cout << "-------------------------------------" << endl;
  //TM_ContinueErrTest();
  //MS_Test();
  
  //LoadSaveTest();

  cout.flush();
  //delete readstring;
  return 0;
}
