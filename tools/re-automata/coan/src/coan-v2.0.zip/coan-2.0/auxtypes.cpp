#include <stdarg.h>
#include <vector>
#include <time.h>
#ifdef UCONTEXT_SUPPORT
  #include <signal.h>
  #include <ucontext.h>
#endif
#ifdef QT_CORE_LIB
  #include <QtCore/QTextCodec>
#endif
#include "auxtypes.h"

#if defined UNLOCKED_STDIO || defined _GNU_SOURCE
// faster standard-IO by avoidance of double locking
  #define fgetc fgetc_unlocked
  #define fgets fgets_unlocked
  #define fread fread_unlocked
  #define fputc fputc_unlocked
  #define fputs fputs_unlocked
  #define fwrite fwrite_unlocked
  #define fflush fflush_unlocked
  #define feof feof_unlocked
  #define ferror ferror_unlocked
  #define fileno fileno_unlocked
  #define clearerr clearerr_unlocked
#define UNLOCKED_STDIO true
#endif

namespace aux {

small_int errnum = 0;    // sth. like errno for aux to indicate global error conditions
small_int verbose_errnum_mask = -1;

void aux_set_err_flag( small_int new_errnum ) {
  small_int prn_err = new_errnum & verbose_errnum_mask;
  if( prn_err ) {
    if( prn_err & EAUX_NOMEM ) aux_error("error: out of memory ( aux::errnum |= EAUX_NOMEM ).");
    if( prn_err & EAUX_BUF_LEN_USER_INVALID ) aux_error("error: bufsize overflow or negative length at xstr_mutable<xchar> - constructor or at xstrbuf<xchar>::setUserAllocedBuf ( aux::errnum |= EAUX_BUF_LEN_USER_INVALID ).");
    if( prn_err & EAUX_BUF_LEN_HEAP_INVALID ) aux_error("error: bufsize overflow or negative length with xstrbuf<xchar> auto-allocation ( aux::errnum |= EAUX_BUF_LEN_HEAP_INVALID .)");
    if( prn_err & EAUX_SHARED_STR_SIZE_INVALID ) aux_error("error at aux::xstr_shared<xchar> allocation: overflow or negative length ( aux::errnum |= EAUX_SHARED_STR_SIZE_INVALID ).");
    if( prn_err & EAUX_DECODE_ERROR ) aux_error("error(s) at decoding utf8 string into xchar target ( aux::errnum |= EAUX_DECODE_ERROR ).");
  };
  abort();
  errnum |= new_errnum;
}

// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

const char *symbol_to_ascii[symbol_name_num] = { "{sub}", "{endsub}", "{alpha}", "{beta}", "{gamma}", "{delta}", "{epsilon}", "{zeta}", "{eta}", "{theta}", "{iota}", "{kappa}", "{lambda}", "{my}", "{ny}", "{xi}", "{omikron}", "{pi}", "{rho}", "{final_sigma}", "{sigma}", "{tau}", "{ypsilon}", "{phi}", "{chi}", "{psi}", "{omega}", "{dialytik_iota}" };
utf8str_const symbol_name[symbol_name_num];
const echar symbol_code[additional_symbol_name_num] = { subscript_char, close_subscripts_char };
//const idx_diff symbol_name_num = sizeof(symbol_name) / sizeof(const char*);
//const idx_diff additional_symbol_name_num = sizeof(symbol_code) / sizeof(echar);
//const idx_diff greek_letter_num  = symbol_name_num - additional_symbol_name_num;
//const echar first_greek_letter = 0x3B1, last_greek_letter = first_greek_letter + greek_letter_num - 1;

class IOStream cout(stdout);
class IOStream cerr(stderr,&cout,true);
class IOStream cin(stdin,&cerr,true);
class IOStreamRef clog( cerr.base, cerr.attr );
//class IOStreamRef cinvalid( (aux::IOStream_Base_Rec*)0xEEEE, (aux::IOStream_Attr_Rec*)0xEEFF );
//class IOStreamRef cinvalid2( (aux::IOStream_Base_Rec*)cerr.base, (aux::IOStream_Attr_Rec*)0xEEFF );
class IOStreamGroup cgstd( &cin, &cerr, &cout, NULL ); // &cinvalid, NULL ); // 0xFFFFffffFFFFffff );

struct TerminalType terminal_type;
EndL endl;
SkipAnySep skip_sep;
SkipSpace skip_space;

#define symbol_hash_size ( symbol_name_num * 2 + 1 )
struct SymbolHashEntry { idx_diff symbol_index; idx_diff next_entry;  } symbol_entry[symbol_hash_size];

strsize max_symbol_len = 20;
#define hash_symbol_lookahead 2
#define hash_symbol(s) ( ((s)[0]+(s)[1]*3) % symbol_hash_size )

void BuildSymbolHashTable() {
  idx_diff i, hash;
  aux_assert( symbol_hash_size >= symbol_name_num );
  max_symbol_len = 0;
  for( i=0; i < symbol_hash_size; i++ ) { symbol_entry[i].symbol_index = -1;  symbol_entry[i].next_entry = -1; }
  for( i=0; i < symbol_name_num; i++ ) {
    hash = hash_symbol( symbol_to_ascii[i] + 1 );
    symbol_name[i].chars = symbol_to_ascii[i] + 1; 
    symbol_name[i].length = strlen( symbol_to_ascii[i] + 1 ) - 1; 
    if( max_symbol_len < symbol_name[i].length ) max_symbol_len = symbol_name[i].length;
    if( symbol_entry[hash].symbol_index < 0 ) symbol_entry[hash].symbol_index = i;
    else {
      idx_diff last = hash; while( symbol_entry[last].next_entry >= 0 ) { last = symbol_entry[last].next_entry; /* putchar('.'); */ }
      idx_diff free = last; while( symbol_entry[free].symbol_index >= 0 ) { free++; if( free >= symbol_hash_size ) free = 0; }
      symbol_entry[free].symbol_index = i; symbol_entry[last].next_entry = free;
      // printf("<%s>",symbol_name[i]);
  }}
}

template<class xchar> __pure idx_diff SymbolNameToIndex( const xchar *name, strsize max_name_len, xchar term_char, small_bool check_4_term_char ) {
  idx_diff tridx, idx = hash_symbol( name );
  strsize j; small_bool compares_ok; const char *cmp_name;
  do {
    tridx = symbol_entry[idx].symbol_index; if( tridx < 0 ) break;
    cmp_name = symbol_name[tridx].chars;
    compares_ok = max_name_len >= symbol_name[tridx].length;
    if( compares_ok ) {
      for( j=0; j < symbol_name[tridx].length; j++ ) if( (xchar)cmp_name[j] != name[j] ) { compares_ok = false; break; }
      if( compares_ok && max_name_len > symbol_name[tridx].length && ( !check_4_term_char || name[symbol_name[tridx].length] != term_char ) ) compares_ok = false;
    }
    if( compares_ok ) break;
    idx = symbol_entry[idx].next_entry;
  } while( idx >= 0 );
  if( idx < 0 || tridx < 0 ) return -1;
  return tridx;
}

template __pure idx_diff SymbolNameToIndex( const achar *name, strsize max_name_len, achar term_char, small_bool check_4_term_char );
template __pure idx_diff SymbolNameToIndex( const echar *name, strsize max_name_len, echar term_char, small_bool check_4_term_char );
template __pure idx_diff SymbolNameToIndex( const wchar *name, strsize max_name_len, wchar term_char, small_bool check_4_term_char );

void InitTerminalType() {
  const char *start, *end; char buf[12]; register strsize i, len;
  const char *locale; bool is_utf8 = false; //, is_euro, is_latin15, is_cp1252;
  locale = getenv("LANG");
  if(!locale||!*locale) {
    if(!getenv("COMSPEC")) {
      terminal_type.charset = utf8;
      terminal_type.initialized = true;
    } else {
      terminal_type.charset = latin1;
      terminal_type.initialized = true;
    }
    return; // emtpy string: keep default settings
  }
  end = locale + strcspn(locale,".:@, ");
  while( *end ) {
    start = end + 1;
    if(!*start) break;
    end = start + ( len = strcspn(start,".:@, ") );
    if(len>12) len=12; for(i=0;i<len;i++) { buf[i] = start[i] + ( ( 'A' <= start[i] && start[i] <= 'Z' ) ? ('a'-'A') : 0 ); }
    if( len==5 && !memcmp(buf,"utf-8",len) ) is_utf8 = true; // else
    //if( len==4 && !memcmp(buf,"euro",len) ) is_euro = true; else
    //if( len==11 && !memcmp(buf,"iso-8859-15",len) ) lis_atin15 = true; else
    //if( len==6 && !memcmp(buf,"cp1252",len) ) is_cp1252 = true;
  }
  if(is_utf8) terminal_type.charset = utf8;
  else terminal_type.charset = latin1;
  //fprintf(stderr,"utf8-terminal: %i\n",is_utf8);
  //terminal_type.charset = latin1;
}

void InitIOSValidityChecking();

#ifdef QT_CORE_LIB
  QTextCodec *utf8Codec;
#endif

void Initialize() {
  if( terminal_type.initialized && symbol_name[0].chars ) return;
#ifdef QT_CORE_LIB
  utf8Codec = QTextCodec::codecForName("UTF-8");
#endif
  BuildSymbolHashTable();
  InitTerminalType();
  InitIOSValidityChecking();
  terminal_type.initialized = true;
  //for(idx_diff i=0; i<symbol_name_num; i++) fprintf( stdout, "%i: %s/%i\n", i, symbol_name[i].chars, symbol_name[i].length );
}

//
// XStrTraits: empty & invalid strings
//

struct XStrTraits<achar> AStrTraits;
struct XStrTraits<echar> EStrTraits;
struct XStrTraits<wchar> WStrTraits;

struct XStrTraits<int> IntATraits;
struct XStrTraits<unsigned int> UIntATraits;

template<class xchar>
  const xchar& XStrTraits<xchar>::zero_char = (xchar&)zero_wchar;

template<class xchar>
  const xchar* const XStrTraits<xchar>::empty_xchars = &XStrTraits<xchar>::zero_char;

template<class xchar>
  const xstr_mutable<xchar> XStrTraits<xchar>::empty_xstr(const_cast<xchar*>(empty_xchars),0);   // basically that would have to be xstr_const; however it shall also be assignable to pure/mutable xstr-s

template<class xchar>
  const xstr_mutable<xchar> XStrTraits<xchar>::invalid_xstr(NULL,0);   // basically that would have to be xstr_const; however it shall also be assignable to pure/mutable xstr-s


//
// xstr: estr & astr implementation
//

// template<class xchar> typename xstr_mutable<xchar>::str_const xstr_mutable<xchar>::as_const() const { return str_const(xstr::chars,xstr::length); }   // valid as long as estrbuf is not changed

template<class xchar,class xchar_mutable> __pure bool xstr_abstract<xchar,xchar_mutable>::identical ( str_const s ) const { 
  return ( chars == s.chars ) && ( length == s.length ); 
}

template<class xchar,class xchar_mutable> __pure small_int xstr_abstract<xchar,xchar_mutable>::binary_compare ( str_const s ) const { 
  strsize i; strsize commlen = length; if( s.length < commlen ) commlen = s.length;
  for( i=0; i < commlen; i++ )
    if( chars[i] != s.chars[i] ) break;
  if( i < commlen ) return chars[i] < s.chars[i] ? -1 : +1;
  if( length == s.length ) return 0; 
  return length < s.length ? -1 : +1;
}

template<class xchar,class xchar_mutable> __pure small_int xstr_abstract<xchar,xchar_mutable>::binary_compare ( const achar *s ) const { 
  strsize i; 
  for( i=0; i < length; i++ )
    if( chars[i] != s[i] || !s[i] ) break;
  if( i < length && !s[i] ) return +1;
  if( i >= length ) return s[i] ? -1 : 0;
  return chars[i] < s[i] ? -1 : +1;
}

template<class xchar,class xchar_mutable> xstr_abstract<xchar,xchar_mutable> xstr_abstract<xchar,xchar_mutable>::sub_abstract( register strsize pos, register strsize len ) const {
  if( pos > length ) pos = length; else if( pos < 0 ) { len += pos; pos = 0; }
  if( len < 0 ) len = 0; 
  else if( length - pos < len ) { len = length - pos; }
  return xstr_abstract( chars+pos, len );
}

//
// xstr: string search
//

#define wordsize ((int)sizeof(word)*8)

template<class xchar,class xchar_mutable> template<class ychar> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_compound( xstr_abstract<const ychar,ychar> needle, strsize start ) const {
//template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find( str_const needle, strsize start ) const {
  register u_word needlehash, curhash; register u_word mask; register small_int shift; strsize searchstart, i, j;
  if( needle.length <= 0 ) return start; if( start < 0 ) start = 0;
  if( needle.length <= wordsize/2 ) { 
    shift = wordsize / needle.length; 
    mask = ( (u_word)1 << (shift*needle.length) ) - 1;
  } else {
    shift = 1; 
    if( needle.length < wordsize ) mask = ( (u_word)1 << needle.length ) - 1;
    else mask = ~(u_word)0;
  }
  //cout << shift << "," << mask << endl;
  searchstart = start + needle.length - 1; if( searchstart >= length ) return length;
  for( needlehash = 0, i = 0; i < needle.length; i++ ) { needlehash <<= shift; needlehash ^= needle.chars[i]; }; needlehash &= mask;
  for( curhash = 0, i = start; i < searchstart; i++ ) { curhash <<= shift; curhash ^= chars[i]; };
  while( i < length ) {
    curhash <<= shift; curhash ^= chars[i]; curhash &= mask;
    if( curhash == needlehash ) {
      i -= needle.length-1;
      for( j = 0; j < needle.length; j++ ) if( chars[i+j] != (xchar)needle.chars[j] ) break;
      if( j == needle.length ) return i;
      i += needle.length-1;
    }
    i++;
  }
  return i;
}

template<class xchar,class xchar_mutable> template<class ychar> __pure strsize xstr_abstract<xchar,xchar_mutable>::rfind_compound( xstr_abstract<const ychar,ychar> needle, strsize start ) const {
//template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find( str_const needle, strsize start ) const {
  register word needlehash, curhash; register word mask; register small_int shift; strsize searchstart, i, j;
  if( needle.length <= 0 ) return start; if( start >= length ) start = length-1; 
  if( needle.length <= wordsize/2 ) { 
    shift = wordsize / needle.length; 
    mask = ( (u_word)1 << (shift*needle.length) ) - 1;
  } else {
    shift = 1; 
    if( needle.length < wordsize ) mask = ( (u_word)1 << needle.length ) - 1;
    else mask = ~(u_word)0;
  }
  searchstart = start - needle.length + 1; if( searchstart < 0 ) return -1;
  for( needlehash = 0, i = needle.length-1; i >= 0; i-- ) { needlehash <<= shift; needlehash ^= needle.chars[i]; }; needlehash &= mask;
  for( curhash = 0, i = start; i > searchstart; i-- ) { curhash <<= shift; curhash ^= chars[i]; };
  while( i >= 0 ) {
    curhash <<= shift; curhash ^= chars[i]; curhash &= mask;
    if( curhash == needlehash ) {
      for( j = 0; j < needle.length; j++ ) if( chars[i+j] != (xchar)needle.chars[j] ) break;
      if( j == needle.length ) return i;
    }
    i--;
  }
  return i;
}

#undef wordsize

//template<class xchar,class xchar_mutable> template<typename achar> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_x( xstr_abstract<const achar,achar> needle, strsize start ) const;

//
// xstr: character based searches
//

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_of( wchar cc, strsize start ) const {
  register strsize i = start; if(i<0) i=0; register xchar c = cc; if((wchar)c!=cc) return length;
  for(; i < length; i++ ) if( chars[i] == c ) break; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_of( str_const setstr, strsize start ) const {
  register strsize i = start, j; if(i<0) i=0; 
  for(; i < length; i++ ) for( j=0; j < setstr.length; j++ ) if( chars[i] == setstr.chars[j] ) return i; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_of( const achar *setstr, strsize start ) const {
  register strsize i = start; register const achar *p;  if(i<0) i=0; 
  for(; i < length; i++ ) for( p=setstr; *p; p++ ) if( chars[i] == (xchar)*p ) return i; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_not_of( register wchar cc, strsize start ) const {
  register strsize i = start;  if(i<0) i=0; register xchar c = cc; if((wchar)c!=cc) return 0; 
  for(; i < length; i++ ) if( chars[i] != c ) break; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_not_of( str_const setstr, strsize start ) const {
  register strsize i = start, j;  if(i<0) i=0; 
  for(; i < length; i++ ) { register bool notfound = true; for( j=0; j < setstr.length; j++ ) if(chars[i]==setstr.chars[j]) { notfound=false; break; }; if(notfound) break; }; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_first_not_of( const achar *setstr, strsize start ) const {
  register strsize i = start; register const achar *p;  if(i<0) i=0; 
  for(; i < length; i++ ) { register bool notfound = true; for( p=setstr; *p; p++ ) if( chars[i] == (xchar)*p ) { notfound=false; break; }; if(notfound) break; }; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_of( register wchar cc, strsize start ) const {
  register strsize i = start; if( i >= length ) i = length - 1; register xchar c = cc; if((wchar)c!=cc) return -1;
  for(; i>=0; i-- ) if( chars[i] == c ) break; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_of( str_const setstr, strsize start ) const {
  register strsize i = start, j; if( i >= length ) i = length - 1;
  for(; i>=0; i-- ) for( j=0; j < setstr.length; j++ ) if( chars[i] == setstr.chars[j] ) return i; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_of( const achar *setstr, strsize start ) const {
  register strsize i = start; register const achar *p; if( i >= length ) i = length - 1;
  for(; i>=0; i-- ) for( p=setstr; *p; p++ ) if( chars[i] == (xchar)*p ) return i; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_not_of( register wchar cc, strsize start ) const {
  register strsize i = start; if( i >= length ) i = length - 1; register xchar c = cc; if((wchar)c!=cc) return i;
  for(; i>=0; i-- ) if( chars[i] != c ) break; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_not_of( str_const setstr, strsize start ) const {
  register strsize i = start, j; if( i >= length ) i = length - 1;
  for(; i>=0; i-- ) { register bool notfound = true; for( j=0; j < setstr.length; j++ ) if(chars[i]==setstr.chars[j]) { notfound=false; break; }; if(notfound) break; }; return i;
}

template<class xchar,class xchar_mutable> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_last_not_of( const achar *setstr, strsize start ) const {
  register strsize i = start; register const achar *p; if( i >= length ) i = length - 1;
  for(; i>=0; i-- ) { register bool notfound = true; for( p=setstr; *p; p++ ) if( chars[i] == (xchar)*p ) { notfound=false; break; }; if(notfound) break; }; return i;
}



//
// std. memory allocation routines for xstr_mutable, xstr_shared, xstrbuf 
//

void*(*const std_alloc)( size_t sz ) = malloc;
void std_dealloc( void* ptr, __unused size_t sz ) { free(ptr); }
void* std_realloc( void* ptr, __unused size_t oldsz, size_t newsz ) { return realloc(ptr,newsz); };

template<class xchar> void*(*xstr_mutable<xchar>::alloc)(size_t) = malloc;
template<class xchar> void(*xstr_mutable<xchar>::dealloc)(void*,size_t) = std_dealloc;
template<class xchar> void*(*xstrbuf<xchar>::realloc)(void*,size_t,size_t) = std_realloc;


//
//  xstrbuf - memory allocation
//

template<class xchar> small_int xstrbuf<xchar>::alloc_factor = 0x080;  // allocate_for_len allocates at least for ( ( required_size * alloc_factor ) >> 8 + alloc_addspace ) characters
template<class xchar> small_int xstrbuf<xchar>::alloc_addspace = 8;     // if allocate_for_len realizes that more space is needed allocate for an additional of alloc_addspace characters; 

template<class xchar> small_int xstrbuf<xchar>::setAllocFactor( small_int new_alloc_factor, small_int new_alloc_addspace ) { 
  register small_int result = 0;
  if(unlikely( new_alloc_factor < 0 )) { new_alloc_factor = 0; result = 1; } if(unlikely( new_alloc_addspace < 0 )) { new_alloc_addspace = 0; result = 1; }
  if(unlikely( new_alloc_factor > 0x800 )) { new_alloc_factor = 0x800; result |= 2; }   // max. 8x
  if(unlikely( new_alloc_addspace > 0x8000 )) { new_alloc_addspace = 0x8000; result |= 4; }  // max. + 32.000 characters
  alloc_factor = new_alloc_factor; alloc_addspace = new_alloc_addspace;
  return -result;
}

#define bufIsHeapAlloced ( (strsize)xstrbuf::bufParams >= 0 )     // same as !( bufParams & bufUserAllocatedBit )
#define bufIsUserAlloced ( (strsize)xstrbuf::bufParams < 0 )     // same as !!( bufParams & bufUserAllocatedBit )
#define bufLenHeap xstrbuf::bufParams			  // whenever the bufUserAllocatedBit is not set then bufParams directly contains the bufLength (the highest bit has to be zero)
#define bufUserAllocatedBit xstrbuf_bufUserAllocatedBit 
#define bufLenMask xstrbuf_bufLenMask
#define bufLength (strsize)( xstrbuf::bufParams & bufLenMask )

#define SMALL_size_t ( sizeof(size_t) < sizeof(dbl_unsigned_strsize) )
//#define ssize_t_MAX_as_unsigned  (((size_t)-1)>>1)

template<class xchar> inline void xstrbuf<xchar>::realloc_uninitialized( strsize new_length_4str ) {
  // reallocates always unconditionally, no matter how much space there was reserved before
  // always check for chars != NULL afterwards: memory allocation or overflow errors possible; if so xstrbuf_constBuf
  if(bufIsHeapAlloced) { base_str::dealloc( base_str::chars, sizeof(xchar)*(size_t)bufLenHeap ); } 
  dbl_unsigned_strsize target_length = elm_align( (dbl_unsigned_strsize)new_length_4str + 1, sizeof(xchar), xstrbuf::min_alignment );
  bufLenHeap = target_length; target_length *= sizeof(xchar);
  if(unlikely( ( SMALL_size_t && target_length > (size_t)target_length ) || bufIsUserAlloced )) { bufLenHeap = 0; base_str::chars = NULL; return; }  // overflow; please set EAUX_BUF_LEN_HEAP_INVALID
  base_str::chars = (xchar*) base_str::alloc( target_length );   // caller must reset bufLenHeap & set EAUX_NOMEM if chars should turn out to be NULL 
}

template<class xchar> inline void xstrbuf<xchar>::realloc_for_len( strsize new_length_4str ) {
  realloc_uninitialized( new_length_4str );
  if(unlikely( !base_str::chars )) { 
    aux_set_err_flag( bufLenHeap ? EAUX_NOMEM : EAUX_BUF_LEN_HEAP_INVALID ); 
    base_str::length = 0; bufParams = xstrbuf_constBuf; //*this = XStrTraits<xchar>::invalid_xstr;
  }
}

template<class xchar> void xstrbuf<xchar>::allocate_for_len( strsize min_length_4str, strsize base_length_4str ) { 
  if( bufLength - 1 >= min_length_4str ) return;
  strsize suggested_length_4str = base_length_4str + ( ( ( base_length_4str + 1 ) * alloc_factor ) >> 8 ) + alloc_addspace;
  realloc_uninitialized( suggested_length_4str < min_length_4str ? min_length_4str : suggested_length_4str ); 
  if(unlikely( !base_str::chars )) {
    if( suggested_length_4str > min_length_4str ) { 
      realloc_uninitialized( min_length_4str ); 
      if(base_str::chars) return;
    }
    aux_set_err_flag( bufLenHeap ? EAUX_NOMEM : EAUX_BUF_LEN_HEAP_INVALID ); 
    base_str::length = 0; bufParams = xstrbuf_constBuf;  //*this = XStrTraits<xchar>::invalid_xstr;
    return;
  }
}

template<class xchar> void xstrbuf<xchar>::free_additional_space() {      // uses realloc or does nothing if realloc == NULL 
  if( bufIsUserAlloced || !xstrbuf::realloc ) return;
  register unsigned_strsize reduced_length = elm_align( (dbl_unsigned_strsize)base_str::length + 1, sizeof(xchar), xstrbuf::min_alignment );
  // do not check for overflows as ::length is expected to be valid under current conditions
  if( reduced_length >= bufLenHeap ) return;   // allocation already is of minimal length (with or without space for a terminating '\000'-char)
  register size_t reduced_size = (size_t)reduced_length * sizeof(xchar);
  register xchar* newmem = (xchar*) xstrbuf::realloc( base_str::chars, sizeof(xchar)*(size_t)bufLenHeap, reduced_size );
  if( newmem ) {
    bufLenHeap = reduced_length;
    base_str::chars = newmem;
  }
}

template<class xchar> void xstrbuf<xchar>::reserve( register strsize min_length_4str ) {  // reallocates the buffer like allocate_for_len but preserving its content
  register strsize cur_length = bufLength, new_length; register dbl_unsigned_strsize new_size;
  if( cur_length - 1 >= min_length_4str ) return;
  new_length = elm_align( (dbl_unsigned_strsize)min_length_4str + 1, sizeof(xchar), xstrbuf::min_alignment );
  if(unlikely( new_length < 0 )) { 
    new_length = (unsigned_strsize)-1 >> 1;
    register strsize algn_len = xstrbuf::min_alignment / sizeof(xchar);
    if(algn_len) new_length = new_length / algn_len * algn_len;
  }
  new_size = (dbl_unsigned_strsize) new_length * sizeof(xchar);
  if(unlikely( SMALL_size_t && (size_t)new_size < new_size )) {  // sizeof(size_t) == sizeof(unsigned_strsize) 
    new_size = sizeof(xchar)==1 ? (unsigned_strsize)-1 >> 1 : (size_t)-1; 
    new_size = ( new_size & ( xstrbuf::min_alignment - 1 ) ) / sizeof(xchar) * sizeof(xchar);
    new_length = new_size / sizeof(xchar); 
  } 
  if( !bufIsUserAlloced && xstrbuf::realloc ) {
    register xchar* newmem = (xchar*) xstrbuf::realloc( base_str::chars, sizeof(xchar)*(size_t)cur_length, new_size );
    if( newmem ) {
      bufLenHeap = new_length;
      base_str::chars = newmem;
    }
    return;
  }
  register xchar *new_chars = (xchar*)base_str::alloc( new_size ); 
  if(unlikely( !new_chars )) return;
  memcpy( new_chars, base_str::chars, (size_t)base_str::length * sizeof(xchar) );
  new_chars[base_str::length] = '\000';
  if( bufIsHeapAlloced ) { base_str::dealloc( base_str::chars, sizeof(xchar)*(size_t)cur_length ); } 
  bufLenHeap = new_length;
  base_str::chars = new_chars;
  return;
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::copyFrom ( base_str_const other, strsize prealloc_4strlen ) {
  if( other.length == 0 ) {
    base_str::chars = other.chars ? XStrTraits<xchar>::empty_xstr.chars : NULL;
    base_str::length = 0; bufParams = xstrbuf_constBuf;
    return *this;
  }
  if( bufLength - 1 < other.length ) {
    if( prealloc_4strlen < 0 ) prealloc_4strlen = other.length + ( ( (other.length+1) * alloc_factor ) >> 8 ) + alloc_addspace;
    else if( prealloc_4strlen < other.length ) prealloc_4strlen = other.length;
    realloc_uninitialized( prealloc_4strlen );
  }
  if(unlikely( !base_str::chars )) { 
    if( prealloc_4strlen > other.length ) {  // retry with smaller length
      realloc_uninitialized( other.length ); 
      if(base_str::chars) goto good_alloc2copy;
    };
    aux_set_err_flag( bufLenHeap ? EAUX_NOMEM : EAUX_BUF_LEN_HEAP_INVALID ); 
    base_str::length = 0; bufParams = xstrbuf_constBuf;
    return *this;
  }
good_alloc2copy:
  memcpy( base_str::chars, other.chars, (size_t)other.length * sizeof(xchar) );
  base_str::chars[other.length] = '\000';
  base_str::length = other.length;
  return *this;
}

#define unknown_achar ((achar)unknown_achar_with_flags)
#define shall_convert_special_space ( unknown_achar_with_flags & AStrBufCnvFlags::convert_special_space )

template<class xchar> strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<xchar> src, small_int unknown_achar_with_flags ) {
  register strsize i; register achar *tr; strsize res = -1;
  if( src.length == 0 ) {
    dest->chars = src.chars ? empty_astr.chars : NULL;
    dest->length = 0; dest->bufParams = xstrbuf_constBuf;
    return res;
  }
  if( xstrbuf_bufLength(*dest) < src.length + 1 ) {
    dest->realloc_for_len( src.length );
    if(unlikely( !dest->chars )) return -1;
  } else aux_assert(dest->chars);
  tr = dest->chars; i = 0;
  if(shall_convert_special_space) 
    for( ; i < src.length; i++ ) { register xchar c = src.chars[i]; if( c == unicode_space ) c = ' '; if(likely(!( c & ~0xFF ))) tr[i] = c; else { tr[i] = unknown_achar; if(res==-1) res = i; } }
  else for( ; i < src.length; i++ ) { register xchar c = src.chars[i]; if(likely(!( c & ~0xFF ))) tr[i] = c; else { tr[i] = unknown_achar; if(res==-1) res = i; } }
  tr[i] = '\000';
  dest->length = i;
  return res;
}

#undef unknown_achar
#undef shall_convert_special_space

template<echar> strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<echar> src, small_int unknown_achar_with_flags );
template<wchar> strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<wchar> src, small_int unknown_achar_with_flags );

strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<echar> src, small_int unknown_achar_with_flags ) { return astrbuf_from_xstr<echar>(dest,src,unknown_achar_with_flags ); }
strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<wchar> src, small_int unknown_achar_with_flags ) { return astrbuf_from_xstr<wchar>(dest,src,unknown_achar_with_flags ); }


template<class xchar> void xstrbuf<xchar>::buf_free() { 
  if(bufIsHeapAlloced) { base_str::dealloc(base_str::chars,sizeof(char_type)*(size_t)bufLenHeap); base_str::chars = NULL; base_str::length = 0; bufParams = xstrbuf_constBuf; } 
}

template<class xchar> inline void xstrbuf<xchar>::buf_freeMem() { 
  if(bufIsHeapAlloced) base_str::dealloc(base_str::chars,sizeof(char_type)*(size_t)bufLenHeap); 
}

template<class xchar> xstrbuf<xchar>::~xstrbuf() { buf_freeMem(); };


template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::setUserAllocedBuf( void *memory, strsize newBufLen ) {  
  buf_freeMem(); base_str::chars = (xchar*)memory; base_str::length = 0; if(unlikely(newBufLen<0)) { aux_set_err_flag( EAUX_BUF_LEN_USER_INVALID ); *this = XStrTraits<xchar>::invalid_xstr; } 
  bufParams =  newBufLen | xstrbuf_bufUserAllocatedBit; return *this; 
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::referenceFrom( base_str_const s ) { 
  buf_freeMem(); base_str::chars = const_cast<char_type*>(s.chars); base_str::length = s.length; 
  bufParams = xstrbuf_constBuf; return *this; 
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::sharedRefFrom( xstrbuf *other ) { 
  buf_freeMem(); base_str::chars = other->chars; base_str::length = other->length; 
  bufParams = other->bufParams | bufUserAllocatedBit; return *this; 
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::shareMoveFrom( xstrbuf *other ) { 
  buf_freeMem(); base_str::chars = other->chars; base_str::length = other->length; bufParams = other->bufParams; 
  other->bufParams |= bufUserAllocatedBit; 
  return *this; 
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::moveFrom( xstrbuf *other ) { 
  buf_freeMem(); base_str::chars = other->chars; base_str::length = other->length; 
  bufParams = other->bufParams; other->bufParams = xstrbuf_constBuf; 
  return *this; 
}


//
//  xstr_shared - memory allocation
//

template<class xchar> __malloced xstr_shared<xchar>* xstr_shared<xchar>::allocate_for_len( strsize len ) {
  register dbl_unsigned_strsize objsz = xstr_shared_HdrSize + ( (dbl_unsigned_strsize)len + 1 ) * sizeof(xchar); 
  if(unlikely( objsz <= 0 || ( SMALL_size_t && (size_t)objsz < objsz ) )) { aux_set_err_flag( EAUX_SHARED_STR_SIZE_INVALID ); return NULL; }
  char *new_shared_str = (char*)base_str::alloc( objsz );
  if(unlikely( !new_shared_str )) { aux_set_err_flag( EAUX_NOMEM ); return NULL; }
  return new((xstr_shared*)new_shared_str) xstr_shared( (xchar*)( new_shared_str + xstr_shared_HdrSize ), len );
}

template<class xchar> void xstr_shared<xchar>::buf_free() { 
  clog << "error: buf_free called for xstr_shared; use xstr_shared::free[Mem] instead to free the whole object." << endl*2 << IOFlush(); 
#ifdef DEBUG_IO
  abort(); 
#endif
};

template<class xchar> xstr_shared<xchar>::~xstr_shared() { 
  clog << "error: tried to auto-deallocate xstr_shared object; use xstr_shared::free[Mem] instead." << endl*2 << IOFlush(); 
#ifdef DEBUG_IO
  abort(); 
#endif
};


template<class xchar> xstr_shared<xchar>* xstr_shared<xchar>::dup_replace_char( strsize pos, xchar write_char ) {
  if( pos < 0 ) { usage_count++; return this; }
  strsize dup_len = xstr::length; if( pos >= dup_len ) dup_len = pos + 1;
  xstr_shared *dup = allocate_for_len( dup_len );
  if(likely(dup)) {
    memcpy( dup->chars, xstr::chars, xstr::length * sizeof(xchar) );
    dup->chars[pos] = write_char;
    dup->chars[dup_len] = (xchar)'\000';
  }
  return dup;
}

template<class xchar> __malloced xstr_shared<xchar>* xstr_shared<xchar>::copyFrom( xstr_const<xchar> base ) {
  xstr_shared *copy = allocate_for_len( base.length );
  if(likely(copy)) {
    memcpy( copy->chars, base.chars, base.length * sizeof(xchar) );
    copy->chars[base.length] = (xchar)'\000';
  }
  return copy;
}


// strsize getrunlength(char leadchar, unsigned char *leadmask) { unsigned char mask=0x80; // leadchar=11[1*]0xx, FE & FF not allowed in unicode
// small_int i=0; leadchar<<=1; while(leadchar&0x80) { leadchar<<=1; mask>>=1; i++; }; *leadmask=i>5?0:mask-1; return i>5?0:i; }

__pure strsize utf8len( register const char *buf, register strsize blen ) {
  register strsize ulen = 0; register char c; register small_int i;
  while( blen > 0 ) { c = *buf;
    if(!( c & 0x80 )); else			 // 0b0xxx -> single byte character: do nothing here
    if( ( c & 0xC0 ) == 0x80 ) return -1; else { // 0b10xxx -> not allowed here
       i=1; while( c & 0x20 ) { c<<=1; i++; }    // 0b11... - leading code word signals the number of 0x10xxx code chars that follow
       if( i>5 || i>blen ) return -1;            // i>5: currently only 3-byte codes defined; still we allow longer codes up to 32bit (5*6+2);
       blen -= i; while(i--) { if( ( *++buf & 0xC0 ) != 0x80 ) return -1; }  // !=0x80: incorrect number of following 0x10xxx code chars 
    }
    buf++; ulen++; blen--;
  }
  return ulen;
}

strsize utf8len( register const char *buf, strsize *byte_length ) {
  register strsize ulen = 0, blen = 0; register char c; register small_int i;
  while((c=*buf)) {
    if(!( c & 0x80 )); else				          // 0b0xxx -> single byte character: do nothing here
    if( ( c & 0xC0 ) == 0x80 ) { ulen=-1; blen+=strlen(buf); break; } else {    // 0b10xxx -> not allowed here
       i=1; while( c & 0x20 ) { c<<=1; i++; }              // 0b11... - leading code word signals the number of 0x10xxx code chars that follow
       if(i>5) { ulen=-1; blen+=strlen(buf); break; }  // currently only 3-byte codes defined; still we allow longer codes;
       while(i) { if( ( *++buf & 0xC0 ) != 0x80 ) break; ++blen; --i; }
       if(i) { ulen=-1; blen += 1 + strlen(buf); break; }   // incorrect number of following 0x10xxx code chars 
    }
    buf++; ulen++; blen++;
  }
  if(byte_length) *byte_length = blen;
  return ulen;
}

template<class xchar> strsize utf8decode( register xchar *targetbuf, strsize tglen, register const char *srcbuf, strsize srclen, const char **srcpos, const xchar unknown_xchar, strsize *invalidchars ) {
  register char c, leadc; register small_int i, wchar; strsize wrlen = 0; register unsigned char mask;
  if(invalidchars) (*invalidchars) = 0;
  while( tglen > 0 && srclen > 0 ) {
    c = *srcbuf;
    if(!( c & 0x80 )) {             // 0b0xxx -> single byte character: do nothing here
      *targetbuf = c; srcbuf++; srclen--;
    } else
    if( ( c & 0xC0 ) == 0x80 ) break;  // 0b10xxx -> not allowed here
    else { // 0b11...
      i=1; mask=0x40; leadc=c; while( leadc & 0x20 ) { leadc<<=1; mask>>=1; i++; }; mask--;    // leading code word signals the number of 0x10xxx code chars that follow
      if(i>5||i>srclen-1) break;  // currently only 3-byte codes defined; still we allow longer codes;
      wchar = c & mask; ++srcbuf; --srclen;
      while(i) { c=*srcbuf; if( ( c & 0xC0 ) != 0x80 ) break; wchar = wchar<<6 | ( c & 0x3F ); srcbuf++; srclen--; i--; }
      if(i) { break; }   // incorrect number of following 0x10xxx code chars 
      if(!( wchar & ~MaxUnsigned(xchar) )) *targetbuf = wchar;
      else { *targetbuf = unknown_xchar; if(invalidchars) (*invalidchars)++; }
    }
    targetbuf++; wrlen++; tglen--;
  }
  if(srcpos) *srcpos = srcbuf;
  return wrlen;
}

template strsize utf8decode( register echar *targetbuf, strsize tglen, register const char *srcbuf, strsize srclen, const char **srcpos, const echar unknown_xchar, strsize *invalidchars );
template strsize utf8decode( register wchar *targetbuf, strsize tglen, register const char *srcbuf, strsize srclen, const char **srcpos, const wchar unknown_xchar, strsize *invalidchars );


std::vector<void*> estra_stack;

void begin_scope() { estra_stack.push_back(NULL); }
void end_scope() { void *p; while((p=estra_stack.back())) { free(p); estra_stack.pop_back(); }; estra_stack.pop_back(); }

template<class xchar> xstr_mutable<xchar>::xstr_mutable( strsize blen, const char *s, void*(*allocate)(size_t) ) {
  strsize res; strsize buflen, invalidchars; bool push_back = false;
  if( blen >= 0 ) xstr::length = utf8len(s,blen); else xstr::length = utf8len(s,&blen); 
  if(!allocate) { allocate = alloc; push_back = true; }
  buflen = xstr::length+1;
  if(unlikely( buflen<=0 || ( SMALL_size_t && sizeof(xchar) * (dbl_unsigned_strsize)buflen > sizeof(xchar) * (size_t)buflen ) )) { 
    xstr::chars = NULL; aux_set_err_flag( EAUX_BUF_LEN_USER_INVALID ); 
  } else { 
    xstr::chars = (xchar*)allocate(sizeof(xchar)*(size_t)buflen);
    if(unlikely(!xstr::chars)) aux_set_err_flag( EAUX_NOMEM ); 
  }
  res = utf8decode( xstr::chars, buflen-1, s, blen, NULL, (xchar)'?', &invalidchars ); xstr::chars[res] = '\000';
  if( res != xstr::length || invalidchars > 0 ) aux_set_err_flag( EAUX_DECODE_ERROR );
  if(push_back) estra_stack.push_back(xstr::chars);
}
#define utf8_len base_str::length

template<class xchar> void xstrbuf<xchar>::assignByLength ( strsize blen, const char *s ) {
  strsize res, invalidchars; register strsize bufLen = bufLength;
  if( bufLen - 1 < base_str::length ) {
    realloc_for_len( base_str::length );
    if(unlikely( !base_str::chars )) { base_str::length=0; return; }
    bufLen = bufLenHeap;
  } 
  res = utf8decode( base_str::chars, bufLen-1, s, blen, NULL, (xchar)'?', &invalidchars ); base_str::chars[res] = '\000';
  if( res != base_str::length || invalidchars > 0 ) aux_set_err_flag( EAUX_DECODE_ERROR );
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::operator = ( const char *s ) { 
  strsize blen; base_str::length = utf8len( s, &blen ); 
  assignByLength( blen, s );   // side effect input; base_str::length
  return *this; 
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::operator = ( utf8str_const s ) { 
  base_str::length = utf8len( s.chars, s.length ); 
  assignByLength( s.length, s.chars );   // side effect input; base_str::length 
  return *this; 
}

template<class xchar> inline xstrbuf<xchar>::xstrbuf( const char *s ) : base_str() { 
  strsize blen; base_str::length = utf8len( s, &blen ); bufParams = xstrbuf_constBuf; // base_str::chars = NULL;
  assignByLength( blen, s );   // side effect input; base_str::length
}; 

template<class xchar> inline xstrbuf<xchar>::xstrbuf( utf8str_const s ) : base_str() { 
  base_str::length = utf8len( s.chars, s.length ); bufParams = xstrbuf_constBuf;  // base_str::chars = NULL;
  assignByLength( s.length, s.chars );   // side effect input; base_str::length
};

#ifdef QT_CORE_LIB

template<class xchar> int xstrbuf<xchar>::assignQStringByLength ( QString s ) {
  register strsize i, invalidchars = 0;
  if( bufLength - 1 < base_str::length ) {
    realloc_for_len( base_str::length );
    if(unlikely( !base_str::chars )) { base_str::length=0; return -1; }
  } 
  for( i = 0; i < base_str::length; i++ ) { 
    register ushort c = s[i].unicode();
    if( sizeof(xchar)<sizeof(ushort) && xchar(c) != c ) { base_str::chars[i] = '?'; invalidchars++; continue;  } 
    base_str::chars[i] = xchar(c);
  }
  base_str::chars[i] = '\000';
  return invalidchars;
}

int fromQString( QString from, astrbuf *buf ) {
  buf->length = from.length();
  int invalidchars = buf->assignQStringByLength( from );
  return invalidchars;
}

template<class xchar> inline xstrbuf<xchar>& xstrbuf<xchar>::operator = ( QString s ) { 
  base_str::length = s.length(); 
  int invalidchars = assignQStringByLength( s );   // side effect input; base_str::length 
  if( invalidchars > 0 ) aux_set_err_flag( EAUX_DECODE_ERROR );
  return *this; 
}

template<class xchar> inline xstrbuf<xchar>::xstrbuf( QString s ) : base_str() { 
  base_str::length = s.length(); bufParams = xstrbuf_constBuf;  // base_str::chars = NULL;
  int invalidchars = assignQStringByLength( s );   // side effect input; base_str::length
  if( invalidchars > 0 ) aux_set_err_flag( EAUX_DECODE_ERROR );
};
#endif

template<class xchar> inline void xstrbuf<xchar>::prepare_replace( strsize pos, strsize count, strsize ulen ) {
  strsize final_length, prevsz; xchar *prevmem = NULL;
  final_length = base_str::length + ulen - count;
  if( pos == base_str::length ) {
    if( bufLength - 1 < final_length ) { 
      strsize suggested_length_4str = final_length + ( ( ( final_length + 1 ) * alloc_factor ) >> 8 ) + alloc_addspace;
      reserve( suggested_length_4str );
      if( bufLength - 1 < final_length ) { 
	reserve( final_length );
	if( bufLength - 1 < final_length ) { 
	  aux_set_err_flag( EAUX_NOMEM );
	  buf_free(); return;  // no append can be performed due to a lack of memory
    } } }
  } else {
    if( bufLength - 1 < final_length ) {
      prevmem = base_str::chars; prevsz = bufParams; base_str::chars = NULL; bufParams = xstrbuf_constBuf;
      allocate_for_len( final_length, final_length );
      if(!base_str::chars) return;  // no append can be performed due to a lack of memory
      memcpy( base_str::chars, prevmem, sizeof(xchar) * (size_t)pos );
      memcpy( base_str::chars + pos + ulen, prevmem + pos + count, sizeof(xchar) * (size_t)( base_str::length - pos - count ) ); 
      if(  !( prevsz & xstrbuf_bufUserAllocatedBit ) ) base_str::dealloc( prevmem, sizeof(xchar)*(size_t)prevsz ); 
    } else memmove( base_str::chars + pos + ulen, base_str::chars + pos + count, sizeof(xchar) * ( base_str::length - pos - count ) ); 
  }
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::replace( strsize pos, strsize count, base_str_const s ) {
  if( pos < 0 ) pos = 0; else if( pos > base_str::length ) pos = base_str::length;
  if( pos + count > base_str::length ) count = base_str::length - pos;
  prepare_replace( pos, count, s.length );
  memcpy( base_str::chars + pos, s.chars, sizeof(xchar) * (size_t) s.length ); base_str::chars[ base_str::length + s.length - count ] = '\000';
  base_str::length += s.length - count;
  return *this;
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::do_replace( strsize pos, strsize count, const char *s, strsize ulen, strsize blen ) {
  strsize res, invalidchars;
  if( pos < 0 ) pos = 0; else if( pos > base_str::length ) pos = base_str::length;
  if( pos + count > base_str::length ) count = base_str::length - pos;
  prepare_replace( pos, count, ulen ); if(!base_str::chars) return *this;
  res = utf8decode( base_str::chars + pos, bufLength - pos - 1, s, blen, NULL, (xchar)'?', &invalidchars ); base_str::chars[base_str::length+res-count] = '\000';
  if( res != ulen || invalidchars > 0 ) aux_set_err_flag( EAUX_DECODE_ERROR );
  base_str::length += res - count;
  return *this;
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::append( const char *s ) {
  strsize blen, ulen = utf8len( s, &blen ); 
  return do_replace(base_str::length,0,s,ulen,blen);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::append( utf8str_const s ) {
  strsize ulen = utf8len( s.chars, s.length );
  return do_replace(base_str::length,0,s.chars,ulen,s.length);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::insert( strsize pos, const char *s ) {
  strsize blen, ulen = utf8len( s, &blen ); 
  return do_replace(pos,0,s,ulen,blen);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::insert( strsize pos, utf8str_const s ) {
  strsize ulen = utf8len( s.chars, s.length );
  return do_replace(pos,0,s.chars,ulen,s.length);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::replace( strsize pos, strsize count, const char *s ) {
  strsize blen, ulen = utf8len( s, &blen ); 
  return do_replace(pos,count,s,ulen,blen);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::replace( strsize pos, strsize count, utf8str_const s ) {
  strsize ulen = utf8len( s.chars, s.length );
  return do_replace(pos,count,s.chars,ulen,s.length);
}

template<class xchar> xstrbuf<xchar>& xstrbuf<xchar>::remove( strsize pos, strsize count ) {
  if( pos < 0 ) pos = 0; else if( pos > base_str::length ) return *this;
  if( pos + count > base_str::length ) count = base_str::length - pos;
  memmove( base_str::chars + pos, base_str::chars + pos + count, sizeof(xchar)*(size_t)(base_str::length - pos - count) );
  base_str::chars[ base_str::length - count ] = '\000';
  base_str::length -= count;
  return *this;
}

//
// instantiate all required template classes
//

// matrix-template instantiation seems not to be available on current C++ compilers:
//template<class xchar,class xchar_mutable> template<achar> __pure strsize xstr_abstract<xchar,xchar_mutable>::find_x( xstr_abstract<const achar,achar> needle, strsize start ) const;


template class xstr_abstract<achar,achar>;
template class xstr_abstract<echar,echar>;
template class xstr_abstract<wchar,wchar>;

template __pure strsize xstr_abstract<achar,achar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<achar,achar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<achar,achar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template __pure strsize xstr_abstract<echar,echar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<echar,echar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<echar,echar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template __pure strsize xstr_abstract<wchar,wchar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<wchar,wchar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<wchar,wchar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;

template class xstr_abstract<const achar,achar>;
template class xstr_abstract<const echar,echar>;
template class xstr_abstract<const wchar,wchar>;

template __pure strsize xstr_abstract<const achar,achar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const achar,achar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const achar,achar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const echar,echar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const echar,echar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const echar,echar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const wchar,wchar>::find_compound( xstr_abstract<const achar,achar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const wchar,wchar>::find_compound( xstr_abstract<const echar,echar> needle, strsize start ) const;
template __pure strsize xstr_abstract<const wchar,wchar>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;

template class xstr_const<achar>;
template class xstr_const<echar>;
template class xstr_const<wchar>;
template class xstr_const<char>;
template class xstr_mutable<achar>;
template class xstr_mutable<echar>;
template class xstr_mutable<wchar>;
template class xstr_shared<achar>;
template class xstr_shared<echar>;
template class xstr_shared<wchar>;
template class xstrbuf<achar>;
template class xstrbuf<echar>;
template class xstrbuf<wchar>;
template class XStrTraits<achar>;
template class XStrTraits<echar>;
template class XStrTraits<wchar>;
#if CHARTYPE == IS_unsigned 
template class xstr_abstract<unsigned int,unsigned int>;
template class xstr_abstract<const unsigned int,unsigned int>;
//template __pure strsize xstr_abstract<unsigned int,unsigned int>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
//template __pure strsize xstr_abstract<const unsigned int,unsigned int>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template class xstr_const<unsigned int>;
template class xstr_mutable<unsigned int>;
template class xstr_shared<unsigned int>;
template class xstrbuf<unsigned int>;
template class XStrTraits<unsigned int>;
#else
template class xstr_abstract<int,int>;
template class xstr_abstract<const int,int>;
//template __pure strsize xstr_abstract<int,int>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
//template __pure strsize xstr_abstract<const int,int>::find_compound( xstr_abstract<const wchar,wchar> needle, strsize start ) const;
template class xstr_const<int>;
template class xstr_mutable<int>;
template class xstr_shared<int>;
template class xstrbuf<int>;
template class XStrTraits<int>;
#endif

/*
#if CHARTYPE == IS_unsigned 
  // unsigned char* -> signed achar, echar, wchar
  template class xstr_abstract<unsigned int,unsigned int>;
  template class xstr_abstract<const unsigned int,unsigned int>;
  template class xstr_const<unsigned int>;
  template class xstr_mutable<unsigned int>;
  template class xstr_shared<unsigned int>;
  template class xstrbuf<unsigned int>;
  template class XStrTraits<unsigned int>;
#else
  // signed char* -> unsigned achar, echar, wchar
  template class xstr_abstract<int,int>;
  template class xstr_abstract<const int,int>;
  template class xstr_const<int>;
  template class xstr_mutable<int>;
  template class xstr_shared<int>;
  template class xstrbuf<int>;
  template class XStrTraits<int>;
#endif
*/

//
// some functions for zero terminated echar* and achar*
//

template<class xchar> __pure strsize xstrlen( register const xchar *buf ) {
  register strsize len = 0; while(*buf++) len++;
  return len;
}

template<class xchar> __malloced xchar* xstrdup( const xchar *s, strsize *length ) {
  register strsize len = xstrlen(s);
  register xchar *dup = (xchar*) malloc(sizeof(xchar)*(len+1));
  if(length) *length = len;
  if(!dup) return NULL;
  memcpy( dup, s, sizeof(xchar)*(len+1) );
  return dup;
}

template<class xchar> __malloced xchar* xmemdup( const xchar *s, strsize len ) {
  register xchar *dup = (xchar*) malloc(sizeof(xchar)*(len+1));
  if(!dup) return NULL;
  memcpy( dup, s, sizeof(xchar)*(len+1) );
  return dup;
}

template __pure strsize xstrlen( register const achar *buf );
template __pure strsize xstrlen( register const echar *buf );
template __pure strsize xstrlen( register const wchar *buf );
template __malloced achar* xstrdup( const achar *s, strsize *length );
template __malloced echar* xstrdup( const echar *s, strsize *length );
template __malloced wchar* xstrdup( const wchar *s, strsize *length );
template __malloced achar* xmemdup( const achar *s, strsize len );
template __malloced echar* xmemdup( const echar *s, strsize len );
template __malloced wchar* xmemdup( const wchar *s, strsize len );

//
// IOStreams: auxiliary classes
//

RepeatWrapper_4_utf8str_const operator * ( utf8str_const str, strsize times ) { return RepeatWrapper_4_utf8str_const(str,times); }
/* nothing to instantiate: no hidden methods; all methods declared in the interface
template<class xchar> RepeatWrapper_4_XChar<xchar> operator * ( XChar<xchar> c, strsize times ) { return RepeatWrapper_4_XChar<xchar>(c,times); }
template<class xchar> RepeatWrapper_4_xstr_const<xchar> operator * ( xstr_const<xchar> str, strsize times ) { return RepeatWrapper_4_xstr_const<xchar>(str,times); }

template class RepeatWrapper_4_XChar<achar>;
template class RepeatWrapper_4_XChar<echar>;
template class RepeatWrapper_4_XChar<wchar>;
template RepeatWrapper_4_XChar<achar> operator * ( XChar<achar> c, strsize times );
template RepeatWrapper_4_XChar<echar> operator * ( XChar<echar> c, strsize times );
template RepeatWrapper_4_XChar<wchar> operator * ( XChar<wchar> c, strsize times );
template class RepeatWrapper_4_xstr_const<achar>;
template class RepeatWrapper_4_xstr_const<echar>;
template class RepeatWrapper_4_xstr_const<wchar>;
template RepeatWrapper_4_xstr_const<achar> operator * ( xstr_const<achar> str, strsize times );
template RepeatWrapper_4_xstr_const<echar> operator * ( xstr_const<echar> str, strsize times );
template RepeatWrapper_4_xstr_const<wchar> operator * ( xstr_const<wchar> str, strsize times );
*/

IOChangeFlags_AttrChanger::IOChangeFlags_AttrChanger( IOFlagDblMask mkTrue, register IOFlagInt setFalse, register IOFlagInt invert ) {
  register IOFlagInt trueMask = IOFlag_getMask(mkTrue), setTrue = IOFlag_getVal(mkTrue);
  if( setTrue & setFalse ) { setTrue |= IOStreamRef::AttrFlags::undef_attr; clog << "IOChangeFlags: tried to set and unset the same or an overlapping attribute by the same time." << endl; }
  setTrue &= ~setFalse;   // in case of doubt: unset (error message has already been printed)
  setFalse |= trueMask & ~setTrue;     // if some flag is set to true other flags with continguity may automatically become reset (to false) at the same time 
  // f.i.: setting IOFlag::OverlineNextXStr will only cause the next xstr to become overlined, no matter how the setting for the following xstr-s was before.
  register IOFlagInt shall_reset = setTrue & invert; if(shall_reset) { setTrue &= ~shall_reset; setFalse |= shall_reset; invert &= ~shall_reset; }
  register IOFlagInt shall_set = setFalse & invert; if(shall_set) { setTrue |= shall_set; setFalse &= ~shall_set; invert &= ~shall_set; }
  set_if1 = setTrue | invert; unset_if0 = ~( setFalse | invert ); 
}

IOStreamRef IOStreamRef::operator<< ( IOChangeFlags_AttrChanger flagChanger ) {
  register IOFlagInt invert = flagChanger.set_if1 & ~flagChanger.unset_if0;
  //clog << attr->flags << "," << ( flagChanger.set_if1 & ~invert ) << "," << ~( flagChanger.unset_if0 | invert ) << "," << invert << endl;
  attr->flags = ( ( attr->flags | ( flagChanger.set_if1 & ~invert ) ) & ( flagChanger.unset_if0 | invert ) ) ^ invert;
  //clog << attr->flags << endl;
  if(unlikely( flagChanger.set_if1 & IOStreamRef::AttrFlags::undef_attr )) setUsrError( EIO_NOTIMPL_OR_PROGRERR );
  return *this;
}

IOStreamRef IOStreamRef::operator<< ( IOChangeIntegerValue_AttrChanger chg ) {
  switch(chg.attr) {
    case IOAttr::NumberBase: attr->prev_number_base = chg.value;
    case IOAttr::NumberBaseNextOne: attr->number_base = chg.value; break;
    case IOAttr::NumberBaseAfterTheNextOne: attr->prev_number_base = chg.value; break;
    case IOAttr::UnknownXChar: attr->unknown_wchar = chg.value; attr->unknown_echar = chg.value; attr->unknown_achar = chg.value; break;
    case IOAttr::UnknownWChar: attr->unknown_wchar = chg.value; break;
    case IOAttr::UnknownEChar: attr->unknown_echar = chg.value; break;
    case IOAttr::UnknownAChar: attr->unknown_achar = chg.value; break;
    default: setUsrError( EIO_NOTIMPL_OR_PROGRERR ); break;
  }
  return *this;
}

IOStreamRef IOStreamRef::operator<< ( IOChangeAStrValue_AttrChanger chg ) {
  switch(chg.attr) {
    case IOAttr::InputTermChars: attr->term_chars = chg.value; break;
    default: setUsrError( EIO_NOTIMPL_OR_PROGRERR ); break;
  }
  return *this;
}

IOStreamRef IOStreamRef::operator<< ( IOChangeEStrValue_AttrChanger chg ) {
  switch(chg.attr) {
    case IOAttr::EscapeChars: attr->xstr_escapeChars = chg.value; break;
    default: setUsrError( EIO_NOTIMPL_OR_PROGRERR ); break;
  }
  return *this;
}


//
//  IOStreamRef: some elementary functions needed by IOStreamGroup
//

inline bool IOStreamRef::isValidNoCatch() const {
  return this && base && attr && base->uyType && base->uyType <= IOStream_Base_Rec::MaxVal4UnderlyingType && attr->identification_code == IOStream_Attr_Rec::IDENTIFICATION_CODE;
}

#ifndef UCONTEXT_SUPPORT

bool IOStreamRef::isValid() const { return isValidNoCatch(); }
bool IOStreamRef::isValidRegionCheck() const { return isValidNoCatch(); }
void InitIOSValidityChecking() {};
void IOStreamRef::startValidityChecking() {};
void IOStreamRef::endValidityChecking() {};

#else

typedef void(*sigaction_handler)(int,siginfo_t*,void*);
void SIGAddrErr_Handle4_IOStreamValidityCheck( int signo, siginfo_t *siginf, struct ucontext *uctx );

struct {
#ifndef SINGLE_IO_THREAD
  pthread_mutex_t globalMutex = PTHREAD_MUTEX_INITIALIZER;
#endif
  struct sigaction catch_segv_bus_sighandler;
  struct sigaction prev_sigsegv_handler;
  struct sigaction prev_sigbus_handler;
  bool ret_from_context, context_is_valid;
  struct ucontext ret_context;
  const void *streamref, *stream_baserec, *stream_attrrec;
} iosValidityChecking;

#define iosVC iosValidityChecking 

void InitIOSValidityChecking() {
  iosVC.catch_segv_bus_sighandler.sa_sigaction = (sigaction_handler)SIGAddrErr_Handle4_IOStreamValidityCheck;
  sigemptyset( &iosVC.catch_segv_bus_sighandler.sa_mask );
  iosVC.catch_segv_bus_sighandler.sa_flags = SA_SIGINFO;
}

__noinline void SIGAddrErr_Handle4_IOStreamValidityCheck( int signo, siginfo_t *siginf, struct ucontext *uctx ) {
  void *offend_addr = siginf->si_addr;
  //aux_sysmsg("SEGV");

  // !! sometimes offend_addr is NULL though the dereferenced pointer was very high like 0xEEEEffffFFFFffff !!
  if( offend_addr && ( offend_addr == iosVC.streamref || offend_addr == iosVC.stream_baserec || offend_addr == iosVC.stream_attrrec ) ) {
    // ss_sp is the base address of the stack according to the docs (and not the stack pointer) - currently filled with zero!
    if( uctx->uc_stack.ss_sp == iosVC.ret_context.uc_stack.ss_sp || ( uctx->uc_link && uctx->uc_link->uc_stack.ss_sp == iosVC.ret_context.uc_stack.ss_sp ) ) {
      iosVC.ret_from_context = true;
      if( iosVC.context_is_valid ) setcontext( &iosVC.ret_context );
  } }

  // if not caused by isValid call the previously installed signal handlers
  void (*sig_handler)(int);
  void (*sig_sigaction)(int,siginfo_t*,void*);
  int sig_flags;

  if( signo == SIGSEGV ) {
    sig_handler = iosVC.prev_sigsegv_handler.sa_handler;
    sig_sigaction = iosVC.prev_sigsegv_handler.sa_sigaction; 
    sig_flags = iosVC.prev_sigsegv_handler.sa_flags; 
  } else if( signo == SIGBUS ) {
    sig_handler = iosVC.prev_sigbus_handler.sa_handler;
    sig_sigaction = iosVC.prev_sigbus_handler.sa_sigaction; 
    sig_flags = iosVC.prev_sigbus_handler.sa_flags; 
  } else {
    aux_error("SIGAddrErr_Handle4_IOStreamValidityCheck called with wrong signal number "); aux_sysmsg_int(signo); aux_sysmsg(".\n");
    abort();
  }
  if( sig_flags & SA_SIGINFO ) {
    if((void*)sig_sigaction != (void*)SIG_IGN && (void*)sig_sigaction != (void*)SIG_DFL ) {
      sig_sigaction(signo,siginf,uctx);
      return;
  }} else {
    if(sig_handler != SIG_IGN && sig_handler != SIG_DFL ) {
      sig_handler(signo);
      return;
  }}

  aux_sysmsg("memory access error ("); aux_sysmsg(sys_siglist[signo]); aux_sysmsg(")\n");
  aux_sysmsg("this ss_sp: "); aux_sysmsg_adr(uctx->uc_stack.ss_sp); aux_sysmsg("\n");
  aux_sysmsg("this stack size: "); aux_sysmsg_adr(uctx->uc_stack.ss_size); aux_sysmsg("\n");
  if(uctx->uc_link) {
    aux_sysmsg("this ss_sp one level upwards via uc_link: "); aux_sysmsg_adr(uctx->uc_link->uc_stack.ss_sp); aux_sysmsg("\n");
  }
  aux_sysmsg("caller ss_sp: "); aux_sysmsg_adr(iosVC.ret_context.uc_stack.ss_sp); aux_sysmsg("\n");
  aux_sysmsg("address streamref: "); aux_sysmsg_adr(iosVC.streamref); aux_sysmsg("\n");
  aux_sysmsg("address baserec: "); aux_sysmsg_adr(iosVC.stream_baserec); aux_sysmsg("\n");
  aux_sysmsg("address attrec: "); aux_sysmsg_adr(iosVC.stream_attrrec); aux_sysmsg("\n");
  aux_sysmsg("context_is_valid: "); aux_sysmsg_int(iosVC.context_is_valid); aux_sysmsg("\n");
  aux_sysmsg("address: "); aux_sysmsg_adr(offend_addr); aux_sysmsg("\n");
  abort();
}

void IOStreamRef::startValidityChecking() {
#ifndef SINGLE_IO_THREAD
  pthread_mutex_lock( &iosVC.globalMutex );
#endif
  iosVC.streamref = NULL; iosVC.stream_baserec = NULL; iosVC.stream_attrrec = NULL;
  iosVC.context_is_valid = false;
  sigaction( SIGSEGV, &iosVC.catch_segv_bus_sighandler, &iosVC.prev_sigsegv_handler );
  sigaction( SIGBUS, &iosVC.catch_segv_bus_sighandler, &iosVC.prev_sigbus_handler );
}

void IOStreamRef::endValidityChecking() {
  sigaction( SIGSEGV, &iosVC.prev_sigsegv_handler, NULL );
  sigaction( SIGBUS, &iosVC.prev_sigbus_handler, NULL );
#ifndef SINGLE_IO_THREAD
  pthread_mutex_unlock( &iosVC.globalMutex );
#endif
}

bool IOStreamRef::isValidRegionCheck() const {
  bool is_valid = true; int getctx_err;
  iosVC.ret_from_context = false;

  getctx_err = getcontext( &iosVC.ret_context ); iosVC.context_is_valid = !getctx_err;
  iosVC.streamref = this;  
  if( iosVC.ret_from_context || !( this && base && attr )) { is_valid = false; goto isValid_endCritSection; }

  getctx_err = getcontext( &iosVC.ret_context ); iosVC.context_is_valid = !getctx_err;
  iosVC.stream_baserec = &base->uyType; iosVC.stream_attrrec = &attr->identification_code;
  is_valid = !iosVC.ret_from_context && base->uyType && base->uyType <= IOStream_Base_Rec::MaxVal4UnderlyingType && attr->identification_code == IOStream_Attr_Rec::IDENTIFICATION_CODE;

isValid_endCritSection:
  iosVC.context_is_valid = false;
  return is_valid;
}

bool IOStreamRef::isValid() const {
  startValidityChecking(); 
  bool is_valid =  isValidRegionCheck();
  endValidityChecking();
  return is_valid;
}

#undef iosVC
#endif

void IOStreamRef::flush() const { 
  if(base->flush_before) base->flush_before->flush(); 
  if( base->uyType == TypeOfUnderlying::file ) fflush(base->uy.fstream); 
}

//
// IOStreamGroup
//

/*
class IOStreamGroup { 
public:
  struct Compound { IOStreamRef *ref[3]; struct RefGroup *next; } primaryCompound;
  const small_int refs_per_compound = sizeof(primaryCompound.ref)/sizeof(IOStreamRef*); 
*/

IOStreamGroup::IOStreamGroup( IOStreamRef *first, ... ) {
  va_list aglis; small_int refIdx; struct Compound *curCmpd, *lastCmpd; IOStreamRef *thisIOStream;
  primaryCompound.ref[0] = first; refIdx = 0; curCmpd = &primaryCompound;
  if(first) {
    va_start(aglis,first);
    thisIOStream = va_arg(aglis,IOStreamRef*);
    IOStreamRef::startValidityChecking();
    while(thisIOStream) {
      if(unlikely( !thisIOStream->isValidRegionCheck() )) {
	clog << "IOStreamGroup: illegal IOStreamRef argument trying to create IOStreamGroup from argument list; pls. assert the argument list to be terminated by NULL!!!" << endl;
	break;
      }
      //clog << "added IOStream #"<< refIdx << ": " << (u_iword)thisIOStream << endl;
      if( ++refIdx >= refs_per_compound ) {
        lastCmpd = curCmpd; curCmpd = new Compound();
	refIdx = 0; lastCmpd->next = curCmpd;
      }
      curCmpd->ref[refIdx] = thisIOStream;
      thisIOStream = va_arg(aglis,IOStreamRef*);
    }
    IOStreamRef::endValidityChecking();
    va_end(aglis);
  }
  while( ++refIdx < refs_per_compound ) curCmpd->ref[refIdx] = NULL;
  curCmpd->next = NULL;
  //clog << "~~~~~~~~~" << endl;
}

status_int IOStreamGroup::addIOStreamRef() {        // 0 ~ added, 1 ~ was already present before, -1 ~ error (malloc)
  return -1;
}

status_int IOStreamGroup::removeIOStreamRef() {     // 0 ~ removed, 1 ~ not found
  return -1;
}

IOStreamGroup& IOStreamGroup::operator<< ( IOChangeFlags_AttrChanger flagChanger ) {
  struct Compound *curCmpd = &primaryCompound; small_int refIdx = 0; register IOStreamRef *thisIOStream;
  while(( thisIOStream = curCmpd->ref[refIdx] )) {
    *thisIOStream << flagChanger;
    ++refIdx; if( refIdx >= refs_per_compound ) { curCmpd = curCmpd->next; if(!curCmpd) break; refIdx = 0; }
  }
  return *this;
}

void IOStreamGroup::immediateFlush( register bool state ) {
  struct Compound *curCmpd = &primaryCompound; small_int refIdx = 0; register IOStreamRef *thisIOStream;
  while(( thisIOStream = curCmpd->ref[refIdx] )) {
    if(state) thisIOStream->attr->flags |= IOStreamRef::AttrFlags::immediate_flush;
         else thisIOStream->attr->flags &= ~ IOStreamRef::AttrFlags::immediate_flush;
    ++refIdx; if( refIdx >= refs_per_compound ) { curCmpd = curCmpd->next; if(!curCmpd) break; refIdx = 0; }
  }
}

void IOStreamGroup::flushAll() {
  struct Compound *curCmpd = &primaryCompound; small_int refIdx = 0; register IOStreamRef *thisIOStream;
  while(( thisIOStream = curCmpd->ref[refIdx] )) {
    thisIOStream->flush();
    ++refIdx; if( refIdx >= refs_per_compound ) { curCmpd = curCmpd->next; if(!curCmpd) break; refIdx = 0; }
  }
}

IOStreamGroup::~IOStreamGroup() {
  struct Compound *curCmpd, *nextCmpd;
  curCmpd = primaryCompound.next;
  if( curCmpd ) {
    while(( nextCmpd = curCmpd->next )) {
      free(curCmpd); curCmpd = nextCmpd;
    }
    free(curCmpd);
  }
};


//
// IOStream[Ref]: implementation
//

IOStream::IOStream( FILE *stdio_stream, IOStreamRef *flushBefore, bool flushImmediate ) { 
  Initialize();   // asssert to initialize global data structures of auxtypes (needed by IOStream);
  base = &baseRec; attr = &attrRec;

  baseRec.flush_before = NULL;
  baseRec.uy.fstream = stdio_stream; baseRec.uyType = TypeOfUnderlying::file;
  baseRec.lineno = 0; baseRec.col = 0; baseRec.tokNum = 0; 
  baseRec.errcode = 0;
  baseRec.last_was_a_control_character = true; 
  baseRec.linebuflen=1024; 
#ifndef SINGLE_IO_THREAD
  baseRec.mutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
#endif
  setCharset( terminal_type.charset ); 

  attrRec.term_chars = astr_const((achar*)"\n",1); //astr_const((achar*)"\n\000",2);
  attrRec.xstr_escapeChars = empty_estr;
  attrRec.number_base = 10; attrRec.prev_number_base = 10; 
  attrRec.lang = 0;                        // no automatic translation
  attrRec.flags = ( flushImmediate ? AttrFlags::immediate_flush : 0 );
  attrRec.unknown_echar = 0x2E2E; attrRec.unknown_achar = '?';   // 0x2E2E ... reversed question mark
  attrRec.identification_code = IOStream_Attr_Rec::IDENTIFICATION_CODE;

  setFlushBefore(flushBefore); 
}


bool IOStreamRef::open( const char* filename, small_int mode ) {
  const char *modestr;
  switch(mode) {
    case OpenMode::in: modestr = "r"; break;
    case OpenMode::in|OpenMode::out: case OpenMode::out: modestr = "r+"; break;
    case OpenMode::in|OpenMode::out|OpenMode::trunc: case OpenMode::in|OpenMode::trunc: modestr = "w+"; break;
    case OpenMode::out|OpenMode::trunc: modestr = "w"; break;
    case OpenMode::out|OpenMode::app: modestr = "a"; break;
    case OpenMode::in|OpenMode::out|OpenMode::app: modestr = "a+"; break;
    default: setUsrError(EIO_INVAL); return false;
  }
  base->uy.fstream = fopen( filename, modestr );
  return base->uy.fstream != NULL;
}

bool IOStreamRef::close() {
  fclose( base->uy.fstream );  
  base->uy.fstream = NULL;
  return !bad();
}

status_int IOStreamRef::setFlushBefore( IOStreamRef *flushBefore ) {
  base->flush_before = flushBefore;
  while( flushBefore ) { flushBefore = flushBefore->base->flush_before; if( flushBefore == base->flush_before ) break; };
  if(flushBefore) { base->flush_before = NULL; return -1; }
  return 0;
}

status_int IOStreamRef::setTermChars( astr_const termchars ) {
  if(termchars.isEmpty()) { setUsrError(EIO_INVAL); return -1; }
  for(register strsize i = 0; i < termchars.length; i++)
    if( termchars.chars[i] & 0x80 ) { setUsrError(EIO_INVAL); return -1; }
  attr->term_chars = termchars;
  return 0;
}

IOStream::~IOStream() {
  if(!isValid()) {
    aux_error("error: tried to destruct an invalid IOStream: double free?\n");
    return;
  }
#ifndef SINGLE_IO_THREAD
  int ret;
  if(( ret = pthread_mutex_destroy(&base->mutex) )) { 
    small_int i = 0; struct timespec ts = { .tv_sec = 0, .tv_nsec = 500000 };
    aux_error( ret == EBUSY ? "error: IOStream still in use while its destructor was called.\n" : "error: destructor ~IOStream: invalid mutex.\n" );
    while( ret == EBUSY && ++i < 1000 ) { nanosleep(&ts,NULL); ret = pthread_mutex_destroy(&base->mutex); }  // more portable than pthread_yield(); // select(0,NULL,NULL,NULL,&tv); 
    if(ret) return;
    if(!isValidNoCatch()) aux_error("error: tried to destruct an invalid IOStream: double free?\n");
  }
#endif
  base->uyType = 0;
  attr->identification_code = (achar)~IOStream_Attr_Rec::IDENTIFICATION_CODE;
}


const char* const IO_ERRMSG = "I/O error (from the underlying stdio library)";
const char* const EOF_ERRMSG = "end of file reached";
const char* const FAIL_ERRMSG = "other separator token was expected";
const char* const SPURIOUS_ERRMSG = "spurious input at end of line";

const char* ios_base::usrerror( small_int error_number ) {
  switch(error_number) {
    case 0: return "Success";
    case EIO_NOMEM: return "out of memory";
    case EIO_DECODE: return "error decoding unicode character";
    case EIO_CHARRANGE: return "character code out of range";
    case EIO_VALRANGE: return "read: integer value out of range";
    case EIO_INVAL: return "wrong value for member variable";
    case EIO_NOTIMPL_OR_PROGRERR: return "not implemented or programming error";
    case EIO_FMT: return "format error at read or write";
    case ios_base::badbit: return IO_ERRMSG;
    case ios_base::eofbit: return EOF_ERRMSG;
    case ios_base::failbit: return FAIL_ERRMSG;
    case ios_base::spuriousbit: return SPURIOUS_ERRMSG;
    default: return "unknown error";
  }; 
}

const char* IOStreamRef::strerror() { 
  static char strerror_buf[256];
  const char *result = strerror_buf;
  int errcode = base->errcode; int errcount = !!( errcode & ios_base::badbit) + !!( errcode & ios_base::eofbit ) + !!( errcode & ios_base::failbit ) + !!( errcode & ios_base::spuriousbit ) + !!(errcode & ios_base::usrerrbit );
  if( errcount > 1 ) { int i = 0, l;
    if( errcode & ios_base::badbit ) { l = strlen(IO_ERRMSG); memcpy(strerror_buf,IO_ERRMSG,l); }
    if( errcode & ios_base::eofbit ) { l = strlen(EOF_ERRMSG); if(i) { memcpy(strerror_buf+i,", ",2); i+=2; } memcpy(strerror_buf+i,EOF_ERRMSG,l); i += l; }
    if( errcode & ios_base::failbit ) { l = strlen(FAIL_ERRMSG); if(i) { memcpy(strerror_buf+i,", ",2); i+=2; } memcpy(strerror_buf+i,FAIL_ERRMSG,l); i += l; }
    if( errcode & ios_base::spuriousbit ) { l = strlen(SPURIOUS_ERRMSG); if(i) { memcpy(strerror_buf+i,", ",2); i+=2; } memcpy(strerror_buf+i,SPURIOUS_ERRMSG,l); i += l; }
    if( errcode & ios_base::usrerrbit ) { const char *errmsg = usrerror( errcode & ios_base::usrerr_mask ); l = strlen(errmsg);
					  if(i) { memcpy(strerror_buf+i,", ",2); i+=2; } memcpy(strerror_buf+i,errmsg,l); i += l; }
    strerror_buf[i] = '\000';
  } else result = usrerror( errcode );
  if( base->uyType == TypeOfUnderlying::file ) clearerr(base->uy.fstream);
  base->errcode &= ~ios_base::eofbit;
  return result;
}

const char* IOStreamRef::str_usrerror() { 
   const char *result = usrerror( base->errcode & ios_base::usrerr_mask );
   base->errcode &= ~ios_base::usrerr_mask;
   return result;
}

IOStreamRef IOStreamRef::operator << ( PIfErr errObj ) {
  if( !errObj.baseStream.base->errcode && !( errObj.bitfield & PIfErr::onSuccess ) ) return *this;
  *this << errObj.message;
  if( errObj.message.length ) *this << ": ";
  if( errObj.bitfield & PIfErr::praefix ) *this << "aux::IOStream - ";
  *this << errObj.baseStream.strerror() << AChar('.') << endl * ( errObj.bitfield & PIfErr::nl3 ) << IOFlush(); 
  return *this;
}

void IOStreamRef::perror(const char *errmsg) { register unsigned int ures; register int res; bool haderr = false;
  if( errmsg ) { 
    res = fputs( errmsg, stderr ); if(unlikely( res == EOF )) haderr = true;
    res = fputs( ": ", stderr ); if(unlikely( res == EOF )) haderr = true;
  };
  utf8str_const nl = EndL::toText(attr->flags);
  res = fputs( strerror(), stderr ); if(unlikely( res == EOF )) haderr = true;
  ures = fwrite( nl.chars, 1, nl.length, stderr ); if(unlikely( ures != (unsigned int)nl.length )) haderr = true;
  if(unlikely( haderr )) cerr.base->errcode |=  ios_base::badbit; 
  cerr.base->last_was_a_control_character = true;  // had an endl/nl
  cerr.flush();
}

void IOStreamRef::perror(utf8str_const errmsg) { register unsigned int ures; register int res; bool haderr = false;
  if( errmsg.isValid() ) { 
    ures = fwrite( errmsg.chars, 1, errmsg.length, stderr ); if(unlikely( ures != (unsigned int)errmsg.length )) haderr = true;
    res = fputs(": ",stderr); if(unlikely( res == EOF )) haderr = true;
  };
  utf8str_const nl = EndL::toText(attr->flags);
  res = fputs( strerror(), stderr ); if(unlikely( res == EOF )) haderr = true;
  ures = fwrite( nl.chars, 1, nl.length, stderr ); if(unlikely( ures != (unsigned int)nl.length )) haderr = true;
  if(unlikely( haderr )) cerr.base->errcode |= ios_base::badbit; 
  cerr.base->last_was_a_control_character = true;  // had an endl/nl
  cerr.flush();
};



/*#define ungetc2(c,fstream) { if( c != EOF ) ungetc(c,fstream); }
inline small_int IOStreamRef::readTermCharTrailer( small_int c, FILE *fstream ) {
  if( c == '\r' ) { c = fgetc(fstream); if( c != '\n' && c != '\000' ) { ungetc2(c,fstream); return '\r'; } }  // not implemented yet: !! handle \r\n\000 !!
  if( c == '\n' ) { c = fgetc(fstream); if( c != '\000' ) { ungetc2(c,fstream); return '\n'; } }
  return c;
}
#undef ungetc2*/

inline __pure bool IOStreamRef::isTermChar( small_int chr ) const { return attr->term_chars.find_first_of(chr) < attr->term_chars.length; }

#define CheckEOF(fstream) if( c == EOF ) { base->errcode |= feof(fstream) ? ios_base::eofbit : ios_base::badbit; return *this; }

IOStreamRef IOStreamRef::operator >> ( __unused EndL endl ) {
  FILE *fstream = base->uy.fstream; int c = fgetc(fstream); int col = base->col;
  base->errcode &= ~spuriousbit;
  while( c == ' ' || c == '\t' ) { c = fgetc(fstream); col++; }
  if( c == '\r' && !( attr->flags & AttrFlags::no_read_combined_newline ) ) { c = fgetc(fstream); col++; }
  if( c != EOF && c != '\n' ) {
    base->errcode |= spuriousbit; // cerr << "spurious char: '" << AChar(c) << "'" << endl;
    do { c = fgetc(fstream); col++; } while ( c != EOF && c != '\n' );
  }
  base->col = col;
  CheckEOF(fstream);
  base->lineno++; base->col=0;
  //if( c == '\r' ) c = fgetc(fstream);
  //if( c != '\n' && c != EOF ) ungetc(c,fstream);
  ////if( c == '\n' ) c = fgetc(fstream);
  ////if( c != '\000' && c != EOF ) ungetc(c,fstream);
  return *this;
}

IOStreamRef IOStreamRef::operator >> ( SkipSpace skipper ) {
  FILE *fstream = base->uy.fstream; int c = fgetc(fstream); int col = base->col; base->errcode &= ~ios_base::failbit;
  if( skipper.term_chars.length == 0 ) { if( c != ' ' ) base->errcode |= ios_base::failbit; } else {
    while( c == ' ' ) { c = fgetc(fstream); col++; }
    if( skipper.term_chars.find_first_of(c) >= skipper.term_chars.length ) { base->errcode |= ios_base::failbit; base->col = col; CheckEOF(fstream); ungetc(c,fstream); return *this; } 
    else { c = fgetc(fstream); col++; }
  }
  while( c == ' ' ) { c = fgetc(fstream); col++; }
  if( c != EOF ) ungetc(c,fstream); else base->errcode |=  ios_base::eofbit;
  base->col = col;
  return *this;
}

IOStreamRef IOStreamRef::operator >> ( SkipSep skipper ) {
  FILE *fstream = base->uy.fstream; int c = fgetc(fstream); base->errcode &= ~ios_base::failbit;
  if( skipper.term_chars.find_first_of(c) >= skipper.term_chars.length ) { base->errcode |= ios_base::failbit; CheckEOF(fstream); ungetc(c,fstream); }
  else base->col++;
  return *this;
}

IOStreamRef IOStreamRef::operator >> ( SkipAnySep skipper ) {
  FILE *fstream = base->uy.fstream; int c = fgetc(fstream); base->errcode &= ~ios_base::failbit;
  if( c == '\n' || attr->term_chars.find_first_of(c) >= attr->term_chars.length ) { base->errcode |= ios_base::failbit; CheckEOF(fstream); ungetc(c,fstream); } 
  else base->col++;
  return *this;
}

#undef CheckEOF

inline void IOStreamRef::UnReadTermCharHeader( small_int c, char *linebuf, int &blen ) { 
  // blen++;    	// c has not yet been added to linebuf
  if(!blen) return; blen++; bool no_dec_yet = true;
  if( c == EOF || c == '\000' ) { blen--; if(!blen) return; c = linebuf[blen-1]; no_dec_yet = false; }
  if( c == '\n' ) { blen--; if(!blen) return; c = linebuf[blen-1]; no_dec_yet = false; }
  if( c == '\r' ) { blen--; if(!blen) return; no_dec_yet = false; }
  blen -= no_dec_yet;
}

template<class xchar> inline IOStreamRef IOStreamRef::read_xstrbuf_prepare ( xstrbuf<xchar> *string, strsize &ulen, char *linebuf, strsize &blen, bool utf8decode ) {
  register strsize linebuflen = base->linebuflen; register int c; register FILE *fstream = base->uy.fstream;
  if( attr->flags & AttrFlags::immediate_flush ) flush();  // make output appear that will tell the user what string to enter
  if( base->errcode & ios_base::failbit ) return *this;
  if( !base->col ) base->tokNum = 0;
  while( blen < linebuflen && ( ( c = fgetc(fstream) ) != EOF ) && !isTermChar(c) ) linebuf[blen++] = c;
  if( c != EOF && blen < linebuflen ) ungetc(c,fstream);
  if(!( attr->flags & AttrFlags::no_read_combined_newline )) {
    //c = readTermCharTrailer(c,fstream);
    UnReadTermCharHeader( c, linebuf, blen );
  }
  base->col += blen;
  if( !blen ) { 
    *string = XStrTraits<xchar>::empty_xstr;
    if( c == EOF ) { 
      base->errcode |= feof(fstream) ? ios_base::eofbit : ios_base::badbit;
    }
  } else {
    if(utf8decode) ulen = utf8len( linebuf, blen ); else ulen = blen;
    if( (strsize)xstrbuf_bufLength(*string) - 1 < ulen ) {  
      string->realloc_for_len( ulen );
    }
    base->tokNum++;
  }
  return *this;
}

#define attr_unknown_xchar (xchar)( sizeof(xchar)==4 ? attr->unknown_wchar : sizeof(xchar)==2 ? attr->unknown_echar : attr->unknown_achar )

template<class xchar> IOStreamRef IOStreamRef::read_xstrbuf_from_utf8 ( xstrbuf<xchar> *string ) {
  char *linebuf = (char*)alloca(base->linebuflen); register strsize blen = 0;
  strsize ulen, res, invalidchars;
  read_xstrbuf_prepare( string, ulen, linebuf, blen, true );
  if( string->chars && blen ) {
    res = utf8decode( string->chars, ulen, (char*)linebuf, blen, NULL, attr_unknown_xchar, &invalidchars ); string->chars[res] = '\000';
    if( res != ulen ) setUsrError( EIO_DECODE );
    else if( invalidchars > 0 ) setUsrError( EIO_CHARRANGE );
    string->length = res;
  }
  return *this;
}

template IOStreamRef IOStreamRef::read_xstrbuf_from_utf8 ( xstrbuf<achar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_utf8 ( xstrbuf<echar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_utf8 ( xstrbuf<wchar> *string );

template<class xchar> IOStreamRef IOStreamRef::read_xstrbuf_from_latin1 ( xstrbuf<xchar> *string ) {
  char *linebuf = (char*)alloca(base->linebuflen); register strsize blen = 0;
  read_xstrbuf_prepare( string, blen, linebuf, blen, false );
  if( string->chars && blen ) {
    if(sizeof(xchar)==1) memcpy( string->chars, linebuf, blen );
    else for( int i = 0; i < blen; i++ ) string->chars[i] = linebuf[i];
    string->chars[blen] = '\000';
    string->length = blen;
  }
  return *this;
}

template IOStreamRef IOStreamRef::read_xstrbuf_from_latin1 ( xstrbuf<achar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_latin1 ( xstrbuf<echar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_latin1 ( xstrbuf<wchar> *string );

#ifdef _MSC_VER    // because of if((xchar)neq_char==neq_char) ... 
  #pragma warning (disable: 4305)    // shortening from int to aux::achar 
  #pragma warning (disable: 4309)    // shortening of a constant value (xchar)neq_char
#endif

template<class xchar> IOStreamRef IOStreamRef::read_xstrbuf_from_asciiext ( xstrbuf<xchar> *string ) {
  char *linebuf = (char*)alloca(base->linebuflen); register strsize blen = 0;
  read_xstrbuf_prepare( string, blen, linebuf, blen, false );
  if( string->chars && blen ) {
    for( int i = 0; i < blen; i++ ) {
      if( 0xE1 <= (unsigned char)linebuf[i] && (unsigned char)linebuf[i] <= 0xFA ) {
	if( sizeof(xchar) == 1 ) string->chars[i] = attr->unknown_achar;
	else if( (unsigned char)linebuf[i] == 0xE5 ) string->chars[i] = (xchar)epsilon_letter;  
	else {
	 xchar letter = (xchar)(unsigned char)linebuf[i] + ( first_greek_letter - 0xE1 );
	 if( letter >= epsilon_letter ) letter++;
	 if( letter >= omikron_letter ) letter++;
	 string->chars[i] = letter;
	 aux_assert( letter >= first_greek_letter && letter <= last_greek_letter );
      } }
      //else if( 0x80 < (unsigned char)linebuf[i] ) cout << linebuf << "<<" << IOChangeVal(IOAttr::NumberBaseNextOne,16) << (unsigned char) linebuf[i] << ">>" << endl;
      else if( (unsigned char)linebuf[i] == 0xB9 ) { if((xchar)neq_char==neq_char) string->chars[i] = neq_char; else string->chars[i] = attr->unknown_achar; }
      else string->chars[i] = linebuf[i];
    }
    string->chars[blen] = '\000';
    string->length = blen;
  }
  return *this;
}

#ifdef _MSC_VER
  #pragma warning (default: 4305)    
  #pragma warning (default: 4309)    
#endif


template IOStreamRef IOStreamRef::read_xstrbuf_from_asciiext ( xstrbuf<achar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_asciiext ( xstrbuf<echar> *string );
template IOStreamRef IOStreamRef::read_xstrbuf_from_asciiext ( xstrbuf<wchar> *string );


IOStreamRef IOStreamRef::write_utf8str_as_undef ( utf8str_const string ) { 
  clog << "IOStreamRef::write_utf8str - output by the currently selected target character code not implemented." << endl;
  setUsrError( EIO_NOTIMPL_OR_PROGRERR );
  return *this;
}

IOStreamRef IOStreamRef::write_astr_as_undef ( astr_const string ) { 
  clog << "IOStreamRef::write_astr - output by the currently selected target character code not implemented." << endl;
  setUsrError( EIO_NOTIMPL_OR_PROGRERR );
  return *this;
}

IOStreamRef IOStreamRef::write_estr_as_undef ( estr_const string ) { 
  clog << "IOStreamRef::write_estr - output by the currently selected target character code not implemented." << endl;
  setUsrError( EIO_NOTIMPL_OR_PROGRERR );
  return *this;
}

#ifdef _MSC_VER
  #pragma warning (disable: 4146)	// minus operator assigned to unsigned type - does not check for IsSigned(xint)
#endif

template<class xint> IOStreamRef IOStreamRef::write_xint ( xint value ) {
  char buf[20]; small_int c; uidx pos=20; int res; register small_int number_base = attr->number_base;
  int uyType = base->uyType;
  if( value > 0 && attr->flags & AttrFlags::show_positive_sign )
      switch(uyType) { 
	case IOStream_Base_Rec::file: fputc('+',base->uy.fstream); break; 
#ifdef QT_CORE_LIB
        case IOStream_Base_Rec::qstring: base->uy.qstr->append(QChar('+')); break; 
#endif
      }
  if(IsSigned(xint)) {
    if(value<0) { 
      switch(uyType) { 
	case IOStream_Base_Rec::file: fputc('-',base->uy.fstream); break; 
#ifdef QT_CORE_LIB
        case IOStream_Base_Rec::qstring: base->uy.qstr->append(QChar('-')); break; 
#endif
      }
    } else value=-value;  // space of allowed numbers has one more negativ number
  }
  if( !( attr->flags &  AttrFlags::no_number_base_override ) )
    switch(number_base) {
      case 8:
	switch(uyType) { 
	  case IOStream_Base_Rec::file: fputc('0',base->uy.fstream); break; 
#ifdef QT_CORE_LIB
	  case IOStream_Base_Rec::qstring: base->uy.qstr->append(QChar('0')); break; 
#endif
	}; break;
      case 16:
	switch(uyType) { 
	  case IOStream_Base_Rec::file: fputs("0x",base->uy.fstream); break; 
#ifdef QT_CORE_LIB
	  case IOStream_Base_Rec::qstring: base->uy.qstr->append(QChar('0')); base->uy.qstr->append(QChar('x')); break; 
#endif
	}; break;
      case 10: break;
      default: if( number_base > MAXBASE ) { number_base = 10; setUsrError(EIO_INVAL); break; }
	       switch(uyType) { 
		 case IOStream_Base_Rec::file: fprintf(base->uy.fstream,"%i_",number_base); break;
#ifdef QT_CORE_LIB
		 case IOStream_Base_Rec::qstring: base->uy.qstr->append(QString::number(number_base)); base->uy.qstr->append(QChar('_')); break; 
#endif
	      }; break;
    }
  register small_int hexDigitOffs;
  if( !( attr->flags &  AttrFlags::lower_case_hex ) ) hexDigitOffs = 'A' - '9' - 1; 
					         else hexDigitOffs = 'a' - '9' - 1; 
  do { 
    if(IsSigned(xint)) c = (small_int)'0' - value % number_base;
                  else c = (small_int)'0' + value % number_base;
    if( c > '9' ) c += hexDigitOffs;
    buf[--pos] = (char)c; 
    value /= number_base;
  } while(value);
  switch(uyType) { 
    case IOStream_Base_Rec::file: 
	do { res = fwrite(buf+pos,1,20-pos,base->uy.fstream); pos += res; } while( res > 0 );
	if( pos != 20 ) base->errcode |= ios_base::badbit;
	if( attr->flags & AttrFlags::immediate_flush ) flush();
      break; 
#ifdef QT_CORE_LIB
    case IOStream_Base_Rec::qstring: 
        base->uy.qstr->append( utf8Codec->toUnicode( buf+pos, 20-pos ) );
      break; 
#endif
  }
  attr->number_base = attr->prev_number_base;
  base->last_was_a_control_character = false;
  return *this;
}


template IOStreamRef IOStreamRef::write_xint ( max_int value );
template IOStreamRef IOStreamRef::write_xint ( max_uint value );

#define errchk if(c==EOF) { base->errcode |= feof(fstream) ? ios_base::eofbit : ios_base::badbit; base->errcode |= ios_base::failbit; *value = 0; base->col = col; return *this; }
#define usrerrchk(adderr) if(c==EOF) { base->errcode |= feof(fstream) ? ios_base::eofbit : ios_base::badbit; base->errcode |= ios_base::failbit; \
	  			       if( base->errcode & ios_base::eofbit ) setUsrError(adderr); \
                                       *value = 0; base->col = col; return *this; }
#define errchk_RET_ZERO_ON_EOF if(c==EOF) { base->errcode |= feof(fstream) ? ios_base::eofbit : ios_base::badbit; *value = 0; base->col = col; return *this; }
#define errchk_UNGETC_RET_ZERO(prevchar) if(c==EOF) { if(ferror(fstream)) base->errcode |= ios_base::badbit; ungetc(prevchar,fstream); col--; *value = 0; base->col = col; return *this; }

template<class xint> IOStreamRef IOStreamRef::read_xint ( xint *value ) {
  // num_base must be no more than 16 (Hex still allowed) iff sizeof(xint) = 8 also for numeric reasons, num_base > 16 not implemented any way.
  register xint val = 0, nextval = 0, max_min_val; register small_int num_base = attr->number_base, c; bool below_zero = false; 
  register small_int maxdigit, digitval; bool hadBase = false, hadRangeErr = false, hadDigit = false;
  bool allowBaseOverride = !( attr->flags &  AttrFlags::no_number_base_override );
  register FILE *fstream = base->uy.fstream; int col = base->col;
  if( base->errcode & ios_base::failbit ) { *value = 0; return *this; }
  if( !col ) base->tokNum = 0;
  if( attr->flags & AttrFlags::immediate_flush ) flush();  // make output appear that will tell the user what string to enter
  c = fgetc(fstream); col++; errchk;
  if( c != '-' && c != '+' && ( c < '0' || '9' < c ) ) { 
    *value = 0; if(!isTermChar(c)&&c!='\r'&&c!=EOF) setUsrError(EIO_FMT); else base->errcode|=failbit; if(c!=EOF) ungetc(c,fstream); return *this; } 
  base->tokNum++;
  if( c == '-' ) { below_zero = true; } 
  if( c == '-' || c == '+' ) { c=fgetc(fstream); col++; usrerrchk(EIO_FMT); } 
  if( allowBaseOverride ) {
    if( c == '0' ) { num_base = 8; hadDigit = true; hadBase = true; c=fgetc(fstream); col++; errchk_RET_ZERO_ON_EOF; } 
    if( num_base == 8 && ( c=='x' || c=='b' ) )  { num_base = c=='x' ? 16 : 2; hadDigit = false; hadBase = true; small_int d = c; c = fgetc(fstream); col++; errchk_UNGETC_RET_ZERO(d); }
  }
  do {
    if(IsSigned(xint)) max_min_val = MinSigned(xint) / num_base;
                  else max_min_val = MaxUnsigned(xint) / num_base;
    maxdigit = '0' + num_base - 1; if( maxdigit > '9' ) maxdigit = '9';
    if( c >= 'a' ) c -= 'a' - 'A';
    while( ( digitval = '0' <= c && c <= maxdigit ) || ( 'A' <= c && c <= 'A'-10+num_base ) ) {
      if(digitval) digitval = c - '0'; else digitval = c - ('A'-10); hadDigit = true;
      if(IsSigned(xint)) {  // signed xint-type: all intermediate values below or eq. zero
        if(unlikely( val < max_min_val )) hadRangeErr = true;
      } else { // unsigned xint-type
        if(unlikely( val > max_min_val )) hadRangeErr = true;
      }
      nextval = val * num_base;
      if(IsSigned(xint)) { 
	// signed xint-type: first create a value below zero and then invert it for positive number inputs - one value more available below zero in the value range of xint
	val = nextval - digitval;  
      } else {
	//printf("%li\n",(iword)val);
       	val = nextval + digitval;
      }
      c = fgetc(fstream); col++; if( c >= 'a' && c != EOF ) c -= 'a' - 'A';
    }
    if(IsSigned(xint)) {  // signed xint-type: all intermediate values below or eq. zero
      if(unlikely( val > nextval )) hadRangeErr = true;
    } else { // unsigned xint-type
      if(unlikely( val < nextval )) hadRangeErr = true;
    }
    if( c != '_' || hadBase || !allowBaseOverride ) break;
    if( IsSigned(xint) ) val = -val;
    if(unlikely( val < 0 || val > MAXBASE )) { setUsrError(EIO_FMT); break; }
    else num_base = val; 
    val = 0; nextval = 0; hadBase = true; c = fgetc(fstream); col++; hadDigit = false;
  } while( true );
  if( c != EOF ) { ungetc(c,fstream); col--; }
  if( IsSigned(xint) ) {  // signed xint-type
    if( ! below_zero ) {
      if(unlikely( val == MinSigned(xint) )) hadRangeErr = true;
      else val = -val;   // space of allowed numbers has one more negativ number
    }
  } else {   // unsigned xint-type
    if(unlikely( below_zero )) hadRangeErr = true; 
  }
  if(unlikely(hadRangeErr)) {
    setUsrError( EIO_VALRANGE ); 
    if( IsSigned(xint) ) val = below_zero ? MinSigned(xint) : MaxSigned(xint);
                    else val = below_zero ? 0 : MaxUnsigned(xint);     // unsigned type: saturate values below zero to zero
  } else if(unlikely(!hadDigit)) {
    setUsrError( EIO_FMT );
  }
  *value = val;
  attr->number_base = attr->prev_number_base;
  base->col = col;
  return *this;
}

#undef errchk
#undef errchk_RET_ZERO_ON_EOF
#undef errchk_UNGETC_RET_ZERO

#ifdef _MSC_VER
  #pragma warning (default: 4146)    
#endif


template IOStreamRef IOStreamRef::read_xint ( max_int *value );
template IOStreamRef IOStreamRef::read_xint ( max_uint *value );
#ifdef HAVE_INT64      // max_int == int64 => also instantiate int32 
template IOStreamRef IOStreamRef::read_xint ( int32 *value );
template IOStreamRef IOStreamRef::read_xint ( uint32 *value );
#endif
template IOStreamRef IOStreamRef::read_xint ( int16 *value );
template IOStreamRef IOStreamRef::read_xint ( uint16 *value );


inline small_int HexDigit( register small_int val ) {
  val += '0'; if( val > '9' ) val += ('A'-'9'-1);
  return val;
};

IOStreamRef IOStreamRef::write_utf8str_as_utf8 ( utf8str_const string ) { 
  if( string.length > 0 ) {
    register unsigned int res, i = 0;
    do { res = fwrite( string.chars+i, 1, string.length-i, base->uy.fstream ); i += res; } while( res > 0 );
    if(unlikely( i != (unsigned int)string.length )) base->errcode |=  ios_base::badbit;
    base->last_was_a_control_character = isControlChar( string.chars[string.length-1] );
    if( attr->flags & AttrFlags::immediate_flush ) flush();
  }
  return *this;
}

#define fputs_(str,out) res = fputs(str,out);  if(unlikely( res == EOF )) break;
#define fputc_(c,out) res = fputc(c,out);  if(unlikely( res == EOF )) break;

IOStreamRef IOStreamRef::write_astr_as_utf8 ( astr_const string ) { 
  register strsize len = string.length; register const achar *chars = string.chars; register int res = 0;
  register FILE *fstream = base->uy.fstream; register bool overline_this_xstr = attr->flags & AttrFlags::overline_next_xstr ? true : false;
  register bool unchanged_space = !( attr->flags & AttrFlags::xstr_special_space );
  if( overline_this_xstr && len && base->last_was_a_control_character ) { res = fputs( thin_space_utf8, fstream ); }
  if( len ) base->last_was_a_control_character = false;
  if(likely( res != EOF ))
    while( len ) {
      register unsigned char c = (unsigned char)*chars;
      if( overline_this_xstr ) { fputs_( not_in_range_pred_overlay_utf8, fstream ); }
      else {
	register strsize relpos = 0; register unsigned char cc = c;
	while( !( cc & 0x80 ) && ( cc > ' ' || ( c==' ' && unchanged_space ) ) ) { relpos++; if( relpos >= len ) break; cc = chars[relpos]; }
	if( relpos > 1 ) { 
	  if(unlikely( fwrite( chars, 1, relpos, fstream ) != (unsigned_strsize) relpos )) { res = EOF; break; }
	  chars += relpos; len -= relpos; if( len <= 0 ) break;
	  c = cc;
	};
      }
      if( !( c & 0x80 ) || c==0xFF ) {
	if( ( c > ' ' && c!=0xFF ) || ( c==' ' && unchanged_space ) ) { fputc_( c, fstream ); }
	else if( c==' ' ) { fputs_( unicode_space_utf8, fstream ); }
	else if( !overline_this_xstr ) {  // control character, not overlined
	  fputs_( charcode_start_utf8 "0x", fstream ); 
	  fputc_( HexDigit(c>>4), fstream ); fputc_( HexDigit(c&0xF), fstream ); 
	  fputs_( charcode_end_utf8, fstream );
	} else {  // control character, overlined
	  fputs_( charcode_start_utf8 not_in_range_pred_overlay_utf8 "0" not_in_range_pred_overlay_utf8 "x" not_in_range_pred_overlay_utf8, fstream );
	  fputc_( HexDigit(c>>4), fstream ); fputs_( not_in_range_pred_overlay_utf8, fstream ); fputc_( HexDigit(c&0xF), fstream ); fputs_( not_in_range_pred_overlay_utf8, fstream );  
	  fputs_( charcode_end_utf8, fstream );
	}
      } else { fputc_( 0xC0 | c>>6, fstream ); fputc_( 0x80 | ( c & 0x3F ), fstream ); } 
      chars++; len--;
    }
  if(unlikely( res == EOF )) base->errcode |=  ios_base::badbit; 
  if( attr->flags & AttrFlags::overline_xstr ) attr->flags |= AttrFlags::overline_next_xstr;        // effect like : "overline_next_xstr" = "overline_xstr";
                                      else attr->flags &= ~AttrFlags::overline_next_xstr;
  if( attr->flags & AttrFlags::immediate_flush ) flush();
  return *this;
}

#define needsOverlayPred(c) ( (c) < first_greek_letter || (c) > last_greek_letter )

IOStreamRef IOStreamRef::write_estr_as_utf8 ( estr_const string ) { 
  register strsize len = string.length; register const echar *chars = string.chars; bool last_needed_overlay_pred = true; register int res = 0;
  register FILE *fstream = base->uy.fstream; estr_const xstr_escapeChars = attr->xstr_escapeChars; register bool overline_this_xstr = attr->flags & AttrFlags::overline_next_xstr ? true : false;
  if( overline_this_xstr && len && base->last_was_a_control_character ) { res = fputs( thin_space_utf8, fstream); }
  if( len ) base->last_was_a_control_character = false;
  if(likely( res != EOF ))
    while( len ) {
      register echar c = *chars++; len--;
      if( xstr_escapeChars.length && xstr_escapeChars.find_first_of(c) < xstr_escapeChars.length ) {
	if( overline_this_xstr ) { fputs_( last_needed_overlay_pred ? not_in_range_pred_overlay_utf8 : not_in_range_overlay_utf8, fstream ); last_needed_overlay_pred = true; }
	fputc_( '\\', fstream);
      }
      if( overline_this_xstr ) {
	fputs_( needsOverlayPred(c) && last_needed_overlay_pred ? not_in_range_pred_overlay_utf8 : not_in_range_overlay_utf8, fstream );
	last_needed_overlay_pred = needsOverlayPred(c);
      }
      if( !( c & 0xFF80 ) || c==0xFF || c==SlashSeparator ) {
	if( ' ' <= c && c < 0xFF ) { fputc_( c, fstream ); }
	else if( c==SlashSeparator ) { 
	  //fputs_( !overline_this_xstr ? "{/}" : "{" not_in_range_pred_overlay_utf8 "/" not_in_range_pred_overlay_utf8 "}", fstream ); last_needed_overlay_pred = true; 
	  fputc_( '/', fstream);
	} else if( !overline_this_xstr ) {  // control character, not overlined
	  fputs_( charcode_start_utf8 "0x", fstream ); 
	  fputc_( HexDigit(c>>4), fstream ); fputc_( HexDigit(c&0xF), fstream ); 
	  fputs_( charcode_end_utf8, fstream );
	} else {  // control character, overlined
	  fputs_( charcode_start_utf8 not_in_range_pred_overlay_utf8 "0" not_in_range_pred_overlay_utf8 "x" not_in_range_pred_overlay_utf8, fstream );
	  fputc_( HexDigit(c>>4), fstream ); fputs_( not_in_range_pred_overlay_utf8, fstream ); fputc_( HexDigit(c&0xF), fstream ); fputs_( not_in_range_pred_overlay_utf8, fstream );  
	  fputs_( charcode_end_utf8, fstream ); last_needed_overlay_pred = true; 
	}
      } else if(!( c & 0xF800 )) { 
	fputc_( 0xC0 | c>>6, fstream ); fputc_( 0x80 | ( c & 0x3F ), fstream ); 
      } else { 
	fputc_( 0xE0 | c>>12 , fstream ); fputc_( 0x80 | ( c>>6 & 0x3F ), fstream ); fputc_( 0x80 | ( c & 0x3F ), fstream );  
      }
    }
  if(unlikely( res == EOF )) base->errcode |=  ios_base::badbit; 
  if( attr->flags & AttrFlags::overline_xstr ) attr->flags |= AttrFlags::overline_next_xstr;        // effect like : "overline_next_xstr" = "overline_xstr";
                                      else attr->flags &= ~AttrFlags::overline_next_xstr;
  if( attr->flags & AttrFlags::immediate_flush ) flush();
  return *this;
}

#undef fputs_
#undef fputc_

__pure_const const char* letter2asciiEscape( wchar letter ) {
  if ( letter >= first_greek_letter && letter <=  last_greek_letter ) return greek_letter_to_ascii[ letter - first_greek_letter ];
  switch( letter ) {
    case subscript_char: return "{sub}";
    case close_subscripts_char: return "{endsub}";
    case subscript_space: return " ";
    case unicode_space: return "{ }";
    case range_char: return "{..}";
    case neq_char: return "{!=}";
    case leq_char: return "{<=}";
    case geq_char: return "{>=}";
    case '<': return "{<}";
    case '>': return "{>}";
    case setminus_char: return "{\\}";
    case setminus_4_editing_char: return "{-}";
    case empty_set_char: return "{}";
    case concat_char: return "{+}";
    case SlashSeparator: return "{/}";
    case thin_space: return "";
    case '\n': return "{\\n}";
    case '\a': return "{\\a}";
    case '\t': return "{\\t}";
    case '\v': return "{\\v}";
    case '\b': return "{\\b}";
    case '\f': return "{\\f}";
    case '{': return "<{>";
    case '}': return "<}>";
    default: break;
  }
  return NULL;
}

__pure_const const char* controlchar2asciiEscape( vchar letter ) {
  switch( letter ) {
    case '\n': return "{\\n}";
    case '\a': return "{\\a}";
    case '\t': return "{\\t}";
    case '\v': return "{\\v}";
    case '\b': return "{\\b}";
    case '\f': return "{\\f}";
    default: return NULL;
} }

__pure_const const char* controlchar2asciiSimpleEscape( vchar letter ) {
  switch( letter ) {
    case '\n': return "\\{n}";
    case '\a': return "\\{a}";
    case '\t': return "\\{t}";
    case '\v': return "\\{v}";
    case '\b': return "\\{b}";
    case '\f': return "\\{f}";
    default: return NULL;
} }

__pure_const const char* ascii2asciiEscape( vchar letter ) {
  switch( letter ) {
    case '<': return "{<}";
    case '>': return "{>}";
    case '{': return "<{>";
    case '}': return "<}>";
    default: return NULL;
} }

__pure_const const char* unicode2asciiEscape( vchar letter ) {
  switch( letter ) {
    case subscript_char: return "{sub}";
    case close_subscripts_char: return "{endsub}";
    case subscript_space: return " ";
    case unicode_space: return "{ }";
    case range_char: return "{..}";
    case neq_char: return "{!=}";
    case leq_char: return "{<=}";
    case geq_char: return "{>=}";
    case setminus_char: return "{\\}";
    case setminus_4_editing_char: return "{-}";
    case empty_set_char: return "{}";
    case concat_char: return "{+}";
    case SlashSeparator: return "{/}";
    case thin_space: return "";
    default: break;
  }
  if ( letter >= first_greek_letter && letter <= last_greek_letter ) return greek_letter_to_ascii[ letter - first_greek_letter ];
  return NULL;
}

#define fputs_(str,out) res = fputs(str,out);  if(unlikely( res == EOF )) { base->errcode |=  ios_base::badbit; break; }
#define fputc_(c,out) res = fputc(c,out);  if(unlikely( res == EOF )) { base->errcode |= ios_base::badbit; break; }

const char *chars_4_unknown_latin1 = "{?}";
//
// write_utf8str_as_latin1 is not meant to output non-latin1-utf-only characters (it currently prints symbolic representations of some of such characters though errcode will still be set in such a case)
//  -> print such characters as estr_const if really needed or use terminal_type.charset to print an equivalent latin1 representation instead
//
IOStreamRef IOStreamRef::write_utf8str_as_latin1 ( utf8str_const string ) { 
  register small_int c, leadc; register wchar xchar; strsize i, pos = 0, start_pos; register unsigned char mask; 
  const char *symbolName; register int res;
  register FILE *fstream = base->uy.fstream;
  if( string.length <= 0 ) return *this;
  do {
    start_pos = pos;
    while( !( string.chars[pos] & 0x80 ) ) { pos++; if( pos >= string.length ) break; }
    if( start_pos < pos ) { 
      register unsigned_strsize length = pos - start_pos;
      if(unlikely( fwrite( string.chars + start_pos, 1, length, fstream ) != length )) { base->errcode =  ios_base::badbit; break; }
      if( pos >= string.length ) { xchar = string.chars[string.length-1]; break; }
    };
    c = string.chars[pos++];
    if(unlikely( ( c & 0xC0 ) == 0x80 )) {    //  0x10xxx only allowed as part of multibyte char;
      res = fputs( chars_4_unknown_latin1, fstream ); xchar = 0; setUsrError(EIO_DECODE); 
      if(unlikely( res == EOF )) break;  // any kind of write error
      while( pos < string.length && ( string.chars[pos] & 0xC0 ) == 0x80 ) pos++;
    } else {   // c = 0x11...
      if(unlikely( pos >= string.length )) { setUsrError(EIO_DECODE); fputs( chars_4_unknown_latin1, fstream ); break; }
      i=1; mask=0x40; leadc=c; if(unlikely( leadc & 0x20 )) { do { leadc<<=1; mask>>=1; i++; } while( leadc & 0x20 ); }; mask--;    // leading code word signals the number of 0x10xxx code chars that follow
      if(likely( i >= 1 && i <= 5 && pos + i <= string.length  )) {
        xchar = c & mask; c = string.chars[pos++];
	while( ( c & 0xC0 ) == 0x80 ) { xchar = xchar<<6 | ( c & 0x3F ); i--; if(likely(!i)) break; c = string.chars[pos++]; }
        if(likely( !i )) {
          if(likely(!( xchar & ~0xFF ))) { fputc_( xchar, fstream ); }
          else {
	    setUsrError(EIO_CHARRANGE); 
	    if(( symbolName = unicode2asciiEscape(xchar) )) { fputs_( symbolName, fstream ); }
	    else { fputs_("{0x",fstream); fputc_(HexDigit(xchar>>12),fstream); fputc_(HexDigit(xchar>>8&0xF),fstream); 
	                                fputc_(HexDigit(xchar>>4&0xF),fstream); fputc_(HexDigit(xchar&0xF),fstream); fputc_('}',fstream); } 
	  }
	} else {
	  setUsrError(EIO_DECODE);
          fputs_( chars_4_unknown_latin1, fstream );
	  pos--;
      } }
    }
  } while( pos < string.length );
  base->last_was_a_control_character = isControlChar( xchar );  // only ascii characters can be control characters
  return *this;
}

#undef fputs_
#undef fputc_

#define DeclareVars4fputErrorHandling register int res; bool hadErr
#define DeclareVars4ErrorHandling register unsigned int ures; DeclareVars4fputErrorHandling
#define fputs_(str,out) res = fputs(str,out);  if(unlikely( res == EOF )) hadErr = true;
#define fputc_(c,out) res = fputc(c,out);  if(unlikely( res == EOF )) hadErr = true;
#define fwrite_utf8(str,out) ures = fwrite(str.chars,1,str.length,out); if(unlikely( ures != (unsigned int)str.length )) hadErr = true;
#define FinalizeErrorHandling if(unlikely( hadErr )) base->errcode |= ios_base::badbit; 

IOStreamRef IOStreamRef::write_astr_as_latin1 ( astr_const string ) { 
  register strsize len = string.length; register const achar *chars = string.chars; 
  register small_int c; const char *symbolName; DeclareVars4fputErrorHandling; 
  register FILE *fstream = base->uy.fstream; estr_const xstr_escapeChars = attr->xstr_escapeChars;
  if( len ) { 
    register bool overline_this_xstr = attr->flags & AttrFlags::overline_next_xstr ? true : false;
    if( overline_this_xstr ) fputs_("\\!(",fstream);
    while( len ) {
      c = *chars++; len--;
      if( c < ' ' || c == 0xFF ) {
	if(( symbolName = controlchar2asciiSimpleEscape(c) )) { fputs_(symbolName,fstream); continue; };
	fputs_("\\{0x",fstream); fputc_(HexDigit(c>>4),fstream); fputc_(HexDigit(c&0xF),fstream); fputc_('}',fstream);
      } else { 
	if( ( c == '\\' ) || ( xstr_escapeChars.length && xstr_escapeChars.find_first_of(c) < xstr_escapeChars.length ) )
	  fputc_( '\\', fstream ); 
	fputc_( c, fstream ); 
    } }
    if( overline_this_xstr ) fputs_(")\\!",fstream); 
    FinalizeErrorHandling;
    base->last_was_a_control_character = false;
  }
  if( attr->flags & AttrFlags::overline_xstr ) attr->flags |= AttrFlags::overline_next_xstr;        // effect like : "overline_next_xstr" = "overline_xstr";
                                      else attr->flags &= ~AttrFlags::overline_next_xstr;
  return *this;
}

IOStreamRef IOStreamRef::write_estr_as_latin1 ( estr_const string ) { 
  register strsize len = string.length; register const echar *chars = string.chars; small_int subscript_nest; bool toEscape;
  register small_int c; const char *symbolName; utf8str_const letterName; DeclareVars4ErrorHandling; register bool isAVariableWithIndex;
  register FILE *fstream = base->uy.fstream; estr_const xstr_escapeChars = attr->xstr_escapeChars;
  if( len ) { 
    bool overline_this_xstr = attr->flags & AttrFlags::overline_next_xstr ? true : false;
    if( overline_this_xstr ) fputs_("<!(",fstream);
    while( len ) {
      c = *chars++; len--;
      if( c < ' ' || c == 0xFF ) {
	if(( symbolName = controlchar2asciiEscape(c) )) { fputs_(symbolName,fstream); continue; };
	fputs_("{0x",fstream); fputc_(HexDigit(c>>4),fstream); fputc_(HexDigit(c&0xF),fstream); fputc_('}',fstream);
	continue;
      } else if( c < 0xFF ) { 
	if(( symbolName = ascii2asciiEscape(c) )) { fputs_(symbolName,fstream); continue; };
	isAVariableWithIndex = isLatinLetter(c) && len && *chars == subscript_char;   // "αᴗ11 ..." ~ α[11], output as {alpha:11} ( ᴗ ... bottom half )
	if(!isAVariableWithIndex) {
	  toEscape =  xstr_escapeChars.length && xstr_escapeChars.find_first_of(c) < xstr_escapeChars.length; 
	  if(toEscape) fputc_( '{', fstream ); 
	} else fputc_( '<', fstream );
	fputc_( c, fstream ); 
	if(!isAVariableWithIndex) {
	  if(toEscape) fputc_( '}', fstream ); 
	  continue;
	}
      } else if( c >= first_greek_letter && c <=  last_greek_letter ) { 
	fputc_('<',fstream); letterName = greek_letter[ c - first_greek_letter ]; 
	fwrite_utf8( letterName, fstream );
	isAVariableWithIndex = len && *chars == subscript_char;   // "αᴗ11 ..." ~ α[11], output as {alpha:11} ( ᴗ ... bottom half )
      } else { 
	if(( symbolName = unicode2asciiEscape(c) )) { fputs_(symbolName,fstream); continue; };
	fputs_("{0x",fstream); 
	fputc_(HexDigit(c>>12),fstream); fputc_(HexDigit(c>>8&0xF),fstream); 
	fputc_(HexDigit(c>>4&0xF),fstream); fputc_(HexDigit(c&0xF),fstream); 
	fputc_('}',fstream);
	continue;
      }
      if( isAVariableWithIndex ) {
	fputc_(':',fstream); chars++; len--; subscript_nest = 0;
	while( len ) { 
	  c = *chars++; len--; 
	  if ( isChar4VariableIndex(c) ) {
	    if(( symbolName = letter2asciiEscape(c) )) { fputs_(symbolName,fstream); continue; };
	    if(likely( c < 0xFF )) { fputc_(c,fstream); } else { fputs_("{another_unicode_letter}",fstream); }
	  } else if( c == subscript_char ) { fputc_('<',fstream); subscript_nest++; }
	  else if( c == ' ' && subscript_nest > 0 ) { fputc_('>',fstream); subscript_nest--; }
	  else {
	    if( c != ' ' && c != close_subscripts_char ) { chars--; len++; }
	    break; 
	} };
	if( subscript_nest > 0 && c != close_subscripts_char ) fputs_("{!missing_endsub!}",fstream);
	while( subscript_nest > 0 ) { fputc_('>',fstream); subscript_nest--; }
      }
      fputc_('>',fstream);
    }
    if( overline_this_xstr ) fputs_(")>",fstream); 
    FinalizeErrorHandling;
    base->last_was_a_control_character = false;
  }
  if( attr->flags & AttrFlags::overline_xstr ) attr->flags |= AttrFlags::overline_next_xstr;        // effect like : "overline_next_xstr" = "overline_xstr";
                                      else attr->flags &= ~AttrFlags::overline_next_xstr;
  return *this;
}

#undef DeclareVars4ErrorHandling
#undef fputs_
#undef fputc_
#undef fwrite_utf8
#undef FinalizeErrorHandling 


#ifdef QT_CORE_LIB

IOStream::IOStream( QString *qstr ) {
  Initialize();   // asssert to initialize global data structures of auxtypes (needed by IOStream);
  base = &baseRec; attr = &attrRec;

  baseRec.flush_before = NULL;
  baseRec.uy.qstr = qstr; baseRec.uyType = TypeOfUnderlying::qstring;
  baseRec.lineno = 0; baseRec.col = 0; baseRec.tokNum = 0; 
  baseRec.errcode = 0;
  baseRec.last_was_a_control_character = true; 
  baseRec.linebuflen=1024; 
#ifndef SINGLE_IO_THREAD
  baseRec.mutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
#endif
  setCharset( Charset::QString_utf16 ); 

  attrRec.term_chars = astr_const((achar*)"\n",1); //astr_const((achar*)"\n\000",2);
  attrRec.xstr_escapeChars = empty_estr;
  attrRec.number_base = 10; attrRec.prev_number_base = 10; 
  attrRec.lang = 0;                        // no automatic translation
  attrRec.flags = 0;
  attrRec.unknown_echar = 0x2E2E; attrRec.unknown_achar = '?';   // 0x2E2E ... reversed question mark
  attrRec.identification_code = IOStream_Attr_Rec::IDENTIFICATION_CODE;
}

IOStreamRef IOStreamRef::write_utf8str_as_QString( utf8str_const string ) {
  base->uy.qstr->append( utf8Codec->toUnicode( (const char*)string.chars, string.length ) );
  base->last_was_a_control_character = isControlChar( string.chars[string.length-1] );
  return *this;
}

QChar QChars_SlashSeparator[] = { QChar('{'), QChar('/'), QChar(')') };
QChar QChars_SlashSeparator_overlined[] = { QChar('{'), QChar(overlay_pred), QChar(not_in_range_overlay), QChar('/'), QChar(overlay_pred), QChar(not_in_range_overlay), QChar('}') };
QChar QChars_overlined_charcode[] = { QChar(charcode_start_char), QChar(overlay_pred), QChar(not_in_range_overlay), QChar('0'), QChar(overlay_pred), QChar(not_in_range_overlay), QChar('x'), QChar(overlay_pred), QChar(not_in_range_overlay) };

template<class xchar> IOStreamRef IOStreamRef::write_xstr_as_QString( xstr_const<xchar> string ) {
  register strsize len = string.length; register const xchar *chars = string.chars; bool last_needed_overlay_pred = true;
  register QString *qstr = base->uy.qstr; estr_const xstr_escapeChars = attr->xstr_escapeChars; register bool overline_this_xstr = attr->flags & AttrFlags::overline_next_xstr ? true : false;
  if( overline_this_xstr ) qstr->reserve( qstr->length() + 3*len + 1 ); else qstr->reserve( qstr->length() + len );
  if( overline_this_xstr && len && base->last_was_a_control_character ) { qstr->append(QChar(thin_space)); }
  if( len ) base->last_was_a_control_character = false;
  while( len ) {
    register xchar c = *chars++; len--;
    if( xstr_escapeChars.length && xstr_escapeChars.find_first_of(c) < xstr_escapeChars.length ) {
      if( overline_this_xstr ) { if(last_needed_overlay_pred) qstr->append(QChar(overlay_pred)); qstr->append(QChar(not_in_range_overlay)); last_needed_overlay_pred = true; }
      qstr->append(QChar('\\'));
    }
    if( overline_this_xstr ) {
      if( needsOverlayPred(c) && last_needed_overlay_pred ) qstr->append(QChar(overlay_pred)); qstr->append(QChar(not_in_range_overlay));
      last_needed_overlay_pred = needsOverlayPred(c);
    }
    if( c < ' ' || c==0xFF ) {
      if(!overline_this_xstr) {
        qstr->append(QChar(charcode_start_char));
        qstr->append(QChar('0')); qstr->append(QChar('x'));
        qstr->append(QChar(HexDigit(c>>4)));
	qstr->append(QChar(HexDigit(c&0xF)));
        qstr->append(QChar(charcode_end_char));
      } else {
        qstr->append( QChars_overlined_charcode, sizeof(QChars_overlined_charcode)/sizeof(QChar) );
        qstr->append(QChar(HexDigit(c>>4))); qstr->append(QChar(overlay_pred)); qstr->append(QChar(not_in_range_overlay));
	qstr->append(QChar(HexDigit(c&0xF))); qstr->append(QChar(overlay_pred)); qstr->append(QChar(not_in_range_overlay));
        qstr->append(QChar(charcode_end_char)); last_needed_overlay_pred = true;
      };
    } else if ( c==SlashSeparator ) {
      if(!overline_this_xstr) qstr->append( QChars_SlashSeparator, sizeof(QChars_SlashSeparator)/sizeof(QChar) );
      else { qstr->append( QChars_SlashSeparator_overlined, sizeof(QChars_SlashSeparator_overlined)/sizeof(QChar) ); last_needed_overlay_pred = true; }
    } else {
      qstr->append(QChar(c));
    } 
  }
  if( attr->flags & AttrFlags::overline_xstr ) attr->flags |= AttrFlags::overline_next_xstr;        // effect like : "overline_next_xstr" = "overline_xstr";
                                      else attr->flags &= ~AttrFlags::overline_next_xstr;
  return *this;
}

QString toQString( estr_const from, bool escapeSlash ) {
  QString qstr, intermed; strsize i, j; qstr = ""; qstr.reserve(from.length); i=0;
  while( i < from.length ) {
    j=i; while( j < from.length && from.chars[j] >= ' ' && from.chars[j] != SlashSeparator && ( !escapeSlash || from.chars[j]!='/' ) ) j++;
    if(!i) { qstr.setUtf16( (const ushort*)from.chars, j ); }
    else { intermed.setUtf16((const ushort*)from.chars + i, j - i ); qstr.append(intermed); }
    if( j >= from.length ) break;
    switch(from.chars[j]) {
      case SlashSeparator: qstr.append("/"); break;
      case '/': qstr.append("\\/"); break;
      default: qstr.append(QChar(charcode_start_char)); qstr.append("0x");
               qstr.append(QChar(HexDigit(from.chars[j]>>4)));
               qstr.append(QChar(HexDigit(from.chars[j]&0xF)));
               qstr.append(QChar(charcode_end_char));
	     break;
    }
    i = j + 1;
  } 
  return qstr;
}

QString toQString( astr_const from ) {
  QString qstr, intermed; strsize i, j; qstr = ""; qstr.reserve(from.length); i=0;
  while( i < from.length ) {
    j=i; while( j < from.length && from.chars[j] >= ' ' ) j++;
    if(!i) { qstr = QString::fromLatin1( (const char*)from.chars, j ); }
    else { intermed = QString::fromLatin1((const char*)from.chars + i, j - i ); qstr.append(intermed); }
    if( j >= from.length ) break;
    qstr.append(QChar(charcode_start_char)); qstr.append("0x");
    qstr.append(QChar(HexDigit(from.chars[j]>>4)));
    qstr.append(QChar(HexDigit(from.chars[j]&0xF)));
    qstr.append(QChar(charcode_end_char));
    i = j + 1;
  } 
  return qstr;
}

template<class xchar> IOStreamRef IOStreamRef::read_xstrbuf_from_QString ( xstrbuf<xchar> *string ) {
  register strsize i; register xchar *tr; QString src = *base->uy.qstr;
  if( xstrbuf_bufLength(*string) - 1 < src.length() ) {
    string->realloc_for_len( src.length() );
    if(unlikely( !string->chars )) return *this;
  }
  tr = string->chars; i = 0;
  for( i = 0; i < src.length(); i++ ) { register ushort qc = src[i].unicode(); register xchar c = qc; if( c == qc ) tr[i] = c; else tr[i] = attr->unknown_achar; }
  tr[i] = '\000';
  string->length = i;
  return *this;
}


#endif


//
// binary time constants to query with hindsight whether the given CPP macros had been set before at compile time
//
#ifdef UNLOCKED_STDIO
  const bool COMPILED_with_UNLOCKED_STDIO = true;
#else
  const bool COMPILED_with_UNLOCKED_STDIO = false;
#endif
#ifdef DEBUG_IO
  const bool COMPILED_with_DEBUG_IO = true;
#else
  const bool COMPILED_with_DEBUG_IO = false;
#endif
#ifdef SINGLE_IO_THREAD
  const bool COMPILED_with_SINGLE_IO_THREAD = true;
#else
  const bool COMPILED_with_SINGLE_IO_THREAD = false;
#endif
#ifdef NO_DEFAULT_IO_LOCK
  const bool COMPILED_with_NO_DEFAULT_IO_LOCK = true;
#else
  const bool COMPILED_with_NO_DEFAULT_IO_LOCK = false;
#endif
#ifdef UCONTEXT_SUPPORT
  const bool COMPILED_with_UCONTEXT_SUPPORT = true;
#else
  const bool COMPILED_with_UCONTEXT_SUPPORT = false;
#endif

}  // end of aux:: - namespace

status_int print_aux_config( aux::IOStreamRef out ) {
  aux::echar im_blank_echars[2] = { ' ', 0 }; aux::estr_const im_blank(im_blank_echars,1), im_sep = aux::empty_estr;
  if(aux::COMPILED_with_UNLOCKED_STDIO) { out << "-DUNLOCKED_STDIO"; im_sep = im_blank; }
  if(aux::COMPILED_with_DEBUG_IO) { out << im_sep << "-DDEBUG_IO"; im_sep = im_blank; }
  if(aux::COMPILED_with_SINGLE_IO_THREAD) { out << im_sep << "-DSINGLE_IO_THREAD"; im_sep = im_blank; }
  if(aux::COMPILED_with_NO_DEFAULT_IO_LOCK) { out << im_sep << "-DNO_DEFAULT_IO_LOCK"; im_sep = im_blank; }
  if(aux::COMPILED_with_UCONTEXT_SUPPORT) { out << im_sep << "-DUCONTEXT_SUPPORT"; im_sep = im_blank; }
  //if() { out << im_sep << ; im_sep = im_blank; }
  return out.base->errcode != 0;
}


#if defined UNLOCKED_STDIO || defined _GNU_SOURCE
  #undef fgetc
  #undef fgets
  #undef fread
  #undef fputc
  #undef fputs
  #undef fwrite
  #undef fflush
  #undef feof
  #undef ferror
  #undef fileno
  #undef clearerr
#endif



