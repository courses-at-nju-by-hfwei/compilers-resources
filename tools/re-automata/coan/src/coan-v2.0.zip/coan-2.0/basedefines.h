#ifndef BASE_DEFINES_H
#define BASE_DEFINES_H

//
//  C/C++ - language extensions
//   currently making use of language extensions by gcc and g++ 
//

#ifdef _MSC_VER	    // Microsoft Visual Studio
  #pragma warning (disable: 4099)	// integer overflow
  #pragma warning (disable: 4307)	// overflow of an integer constant
  #pragma warning (disable: 4100)	// unreferenced formal parameter
#endif

#if __GNUC__ >= 3
  #define HAS_WARN	  // use the #warning directive instead of #pragma message ( "..." );
  #define __warn_unused_result   __attribute__ ((warn_unused_result))
  #define __align(x)   __attribute__ ((aligned (x)))
  #define __align_max  __attribute__ ((aligned))
  #undef likely
   #define likely(x)    __builtin_expect (!!(x),1)
  #undef unlikely
   #define unlikely(x)  __builtin_expect (!!(x),0)
  #define __unused __attribute__ ((unused))     // do not warn about parameters that remain unused in deed 
  #define __pure __attribute__ ((pure))         // all access is read-only and calling it many times with the same parameter will always yield the same result
  #define __pure_const __attribute__ ((const))  // pure function with no pointer parameters and no access to global variables
  #define __malloced __attribute__ ((malloc))   // returned pointer is freshly malloced and will never alias existing memory
  #undef offsetof
   #define offsetof(type,member) __builtin_offsetof(type,member)    // faster but otherwise available via <stddef.h>; use: offsetof( struct mystrtType, mystr_member )
  #undef __noinline
   #define __noinline __attribute__ ((noinline))
  #define __noreturn  __attribute__ ((noreturn))	// function does not return due to an endless loop
  #undef __used
   #define __used  __attribute__ ((used)		        // mark function as used even if it appears not to referenced by any code so that it is still compiled
  #define exec_return_address(level) __builtin_return_address(level)   // only a level of zero will be portable across different machine architectures; use with noinline
  #define do_inline __attribute__ ((always_inline))

#else
  #define __warn_unused_result
  #define __align(x)
  #define __align_max
  #define likely(x)    (x)
  #define unlikely(x)  (x)
  #define __unused
  #define __pure
  #define __pure_const
  #define __malloced
  #ifndef __noinline
    #define __noinline
  #endif
  #define __noreturn
  #ifndef __used
    #define __used
  #endif
  #define do_inline inline

#endif

// Open WATCOM: disable the following warning messages: 13 - unreachable code,  367, 368 - if statement is always true/false
//  f.i. if( sizeof(xint) > 2 ) 
#if defined __WATCOMC__ || defined __WATCOM_CPLUSPLUS__
  #pragma disable_message( 13, 367, 368 );
#endif

//
//  defines for maximum and minimum values of certain types
//  macros for memory alignment
//

#define IsSigned(type) ( (type)-1 < 0 )
#define HighestSignedValueBit(type) (type)((type)1<<(sizeof(type)*8-2))
#define HighestBit(type) (type)((type)1<<(sizeof(type)*8-1))

#define MaxSigned(type) (type)(HighestBit(type)-1)	  // faster: (unsigned type)-1 >> 1
#define MinSigned(type) (HighestBit(type))
#define MaxUnsigned(type) ((type)-1)
#define MinUnsigned(type) ((type)0)

// same defnitions without overflow
//#define MaxSigned2(type) (HighestSignedValueBit(type)-1+HighestSignedValueBit(type))
//#define MinSigned2(type) (-HighestSignedValueBit(type)-HighestSignedValueBit(type))
//#define MaxUnsigned2(type) (HighestBit(type)-1+HighestBit(type))

//#define align(struct_size,alignment) ( ((struct_size)-1)/(alignment)*(alignment) + (alignment) )
#define mem_align(struct_size,alignment) ( ( ((struct_size)-1) & ~(alignment-1) ) + (alignment) )
//#define elm_align(element_num,element_size,alignment) ( ( ((element_num)*(element_size)-1)/(alignment)*(alignment) - 1 + (alignment) ) / (element_size) + 1 )
#define elm_align(element_num,element_size,alignment) ( ( ( ((element_num)*(element_size)-1) & ~(alignment-1) ) - 1 + (alignment) ) / (element_size) + 1 )


//
//  determine machine architecture
//   defines the following cpp-variables: 
//
//     MACHINE: M_amd64, M_x86, M_arm (ARM_VERSION: 7, 8, ..., undef; ARM_THUMB_MODE: 1 / undef ), (X86_VERSION: 3,4,5,6,undef ~ i386, i486, i586, i686) 
//     WORDSIZE: 64, 32, ( 16 - may erroneously be assumed as 32 )
//     BYTEORDER: BO_little_endian, BO_big_endian
//     OSTYPE: ( OS_unix, OS_pp ) | ( OS_linux, OS_BSD, OS_macos, OS_windows, OS_os2, OS_dos, 0  ) | ( OS_OpenBSD, 0 )    // f.i.: ( OS_win | OS_os2 ) - both use '\\' as path seperator
//     CHARTYPE: IS_signed, IS_unsigned
//

// never rely on any actual numeric value; always use the symbolic constants
#define M_x86 0x10020      // arch to be determined together with WORDSIZE: i386/amd64
#define M_arm 0x10030       // arch is arm or arm64: though MACHINE == M_ARM always

#define BO_little_endian 0x20000
#define BO_big_endian 0x20001

// reference to used macros largely provided by https://sourceforge.net/p/predef/wiki/Architectures
#if ! defined MACHINE || ! defined WORDSIZE
  #if ! defined MACHINE && ! defined WORDSIZE
    #if defined __x86_64__ || defined _M_X64
      #define MACHINE M_x86
      #define WORDSIZE 64
      #define BYTEORDER BO_little_endian 
    #elif defined _M_I86
      // known to work with the OpenWatcom and Digital Mars compilers //#define MACHINE _M_I86
      #define MACHINE M_x86
      #define WORDSIZE 16
      #define BYTEORDER BO_little_endian 
    #elif defined __i386__ || defined _M_IX86 || defined __i386 || defined _X86_ || defined __THW_INTEL__ || defined __I86__ || defined __INTEL__ || defined __386
      #define MACHINE M_x86
      #ifndef WORDSIZE
        // could be wordsize 16 or 32 - no cpp-variable would tell us! - i.e. always pass -m16 -DWORDSIZE=16
        #define WORDSIZE 32
      #endif
      #define BYTEORDER BO_little_endian 
    #endif
    #if defined __SW_0        // OpenWatcom can still compile for the 8086
      #define X86_VERSION 0
    #elif defined __SW_1
      #define X86_VERSION 1   // 80186 = i186, ...
    #elif defined __SW_2
      #define X86_VERSION 2
    #elif defined __i386__ || defined __SW_3   // gcc can compile back to the i386
      #define X86_VERSION 3
    #elif defined __i486__ || defined __SW_4
      #define X86_VERSION 4
    #elif defined __i586__ || defined __SW_5
      #define X86_VERSION 5
    #elif defined __i686__ || defined __SW_6
      #define X86_VERSION 6
    #elif defined _M_IX86
      #define X86_VERSION _M_IX86
    #elif defined __I86__
      #define X86_VERSION __I86__
    #endif
  #endif  
  #ifdef __aarch64__
    #define MACHINE M_arm 
    #define WORDSIZE 64
  #elif !defined MACHINE && ( defined __arm__ || defined __thumb__ || defined _M_ARM || defined _M_ARMT || defined __TARGET_ARCH_ARM || defined __TARGET_ARCH_THUMB || defined _ARM || defined __arm )
    #define MACHINE M_arm 
    #define WORDSIZE 32
    #if defined __thumb__ || defined _M_ARMT
      #define ARM_THUMB_MODE 1
    #endif
    #if defined __ARM_ARCH
      #define ARM_VERSION __ARM_ARCH
    #elif defined _M_ARM
      #define ARM_VERSION _M_ARM
    #elif defined __TARGET_ARCH_ARM
      #define ARM_VERSION __TARGET_ARCH_ARM
    #elif defined __TARGET_ARCH_THUMB
      #define ARM_VERSION __TARGET_ARCH_THUMB
      #define ARM_THUMB_MODE 1
    #endif
  #endif
  #if !( defined MACHINE )
    #ifdef HAS_WARN
      #warning "undefined machine type (use -DMACHINE=M_x86/M_arm ... 32/64bit is considered a matter of the arch; same machine ident)"
    #else
      #pragma message ( "undefined machine type (use -DMACHINE=M_x86/M_arm ... 32/64bit is considered a matter of the arch; same machine ident)" );
    #endif
  #endif
  #ifndef WORDSIZE
    #ifdef __SIZEOF_POINTER__
      #ifdef HAS_WARN
        #warning "assessing wordsize by sizeof(void*) - you may need to use -DWORDSIZE=64/32/16 at least if target arch != target machine."
      #else
        #pragma message ( "assessing wordsize by sizeof(void*) - you may need to use -DWORDSIZE=64/32/16 at least if target arch != target machine." );
      #endif
      #define WORDSIZE ((__SIZEOF_POINTER__)*8)
    #else
      #ifdef HAS_WARN
        #warning "unknown wordsize - please use -DWORDSIZE=64/32/16 !!!"
      #else
        #pragma message ( "unknown wordsize - please use -DWORDSIZE=64/32/16 !!!" );
      #endif
    #endif
  #endif
#endif



#ifndef BYTEORDER
  // ARM machines can have little as well as big endian
  #if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    #define BYTEORDER BO_little_endian
  #elif __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    #define BYTEORDER BO_big_endian
  #else 
    #ifdef HAS_WARN
      #warning "undefined Byte order (use -DBYTEORDER=BO_little/big_endian)."
    #else
      #pragma message ( "undefined Byte order (use -DBYTEORDER=BO_little/big_endian)." );
    #endif
  #endif
#endif

#define IS_signed 1
#define IS_unsigned 0

#ifdef __CHAR_UNSIGNED__
  #define CHARTYPE IS_unsigned
#elif defined __CHAR_SIGNED__
  #define CHARTYPE IS_signed
#else
  #include <limits.h>
  #if defined CHAR_MAX && CHAR_MAX == 255
    #define CHARTYPE IS_unsigned
  #elif defined CHAR_MAX && CHAR_MAX == 127
    #define CHARTYPE IS_signed
  #elif !defined NO_WARN_CHAR_SIGNEDNESS
    #ifdef HAS_WARN
      #warning "could not determine signedness of the char type (use -DCHARYPTE=IS_signed/IS_unsigned)"
    #else
      #pragma message ( "could not determine signedness of the char type (use -DCHARYPTE=IS_signed/IS_unsigned)" );
    #endif
  #endif
#endif

// operating system type; posix emulation on top of a winsys: ( OS_pp | OS_unix | ... )
#define OS_unix 0x61000 
#define OS_pp 0x62000       // mostly proprietary OS-es all using the '\\' as path separator
// operating system
#define OS_linux 0x60100
#define OS_BSD 0x60200
#define OS_OpenBSD 0x60010
#define OS_macos 0x60300
#define OS_windows 0x60400
#define OS_dos 0x60500
#define OS_os2 0x60600

#if ! defined OSTYPE
  #if defined __linux__ || defined __gnu_linux__
    #define OSTYPE ( OS_unix | OS_linux )
  #elif defined _WIN32 || defined _WIN64 || defined __WINDOWS__ || defined _WINDOWS
    #if ! defined __unix__ && ! defined __UNIX__
      #define OSTYPE ( OS_pp | OS_windows )
    #else
      #define OSTYPE ( OS_pp | OS_unix | OS_windows )
    #endif
  #elif defined __OpenBSD__
    #define OSTYPE ( IS_unix | OS_BSD | OS_OpenBSD )
  #elif defined __APPLE__
    #define OSTYPE ( IS_unix | OS_macos )
  #elif defined __OS2__
    #define OSTYPE ( IS_pp | OS_os2 )
  #elif defined __unix__ || defined __UNIX__
    #define OSTYPE ( OS_unix )
  #elif defined _DOS || defined __DOS__
    #define OSTYPE ( OS_pp | OS_dos )
  #endif
  #if !defined OSTYPE
    #ifdef HAS_WARN
      #warning "unknown operating system or unknown operating system type (f.i. use -DOSTYPE='(OS_unix|OS_linux)')"
    #else
      #pragma messsage ( "unknown operating system or unknown operating system type (f.i. use -DOSTYPE='(OS_unix|OS_linux)')" );
    #endif
  #endif
#endif


// type (word): 16/32/64bit depending on the standard word size of the »machine« (as far as allowed/usable in the current architecture)
//   usually has the same size as a pointer (or with segmented addressation as a near pointer / offset in 8086-mode);
//   exception: word is 32bit though all addresses are 16bit; can already use full i386 registers (with $66-praefix) though addresses (like ss:sp) still take 16bit ( machine != architecture )
//   rationale: use this for maximum speed with a size as high as possible to leverage this speed
//              could be used as efficient **》 building block of integer calculations with arbitrary size 《**
//
// type (int/iint): 16/32bit depending on the machine ("wordint"): size = min( sizeof(int), sizeof(word) )
//   i.e. usually 32bit (and 16bit on 16bit architectures), like word but has a maximum size of 32bit
//   rationale: ***》 the default choice 《***: use this for maximum speed and memory efficiency
//              on 64bit systems enlarging the size of all 32bit-int-s to 64bit would double the memory needs (would be a clear drawback for an 8GB system running on x86_64);
//
// type (adr): unsigned 16/32/64bit numeral depending on the standard word/address size of the »architecture«
//   rationale: shall be used for ***》 address calculations 《***; note: for 16bit-8086,i286 segmented addressation the segment part of the address needs to be handled independently
// type (adr_diff): signed 16/32/64bit numeral depending on the standard word/address size of the »architecture« 
// type (idx_diff), (uidx): signed/unsigned 16/32bit numeral for addressing ***》 array indices 《***, almost an int and like int bounded to a maximum of 32bit 
//                         except with $66-praefix for 32bit data calculations in 8086 mode where it would default to 16bit (then: idx_diff != int)
// type (dbl_adr_diff): signed 32/64/128bit numeral for address calculation that can always store the result of subtracting two addresses without an overflow
//                     note: on 64bit machines there is no language support for 128bit integers: here just defines NEED_128_DBLADRDIFF; may be implemented as C++ object with operators
// type (small_int, small_uint):  currently the same as idx_diff and idx but meant for data calculations rather than array indexing or addressing
//                                may default to sth. smaller than int iff that speeds up the calculation; at least 16bit (if it were predefined by the compiler it may even vary between 32 and 16bit for intermediate results)
// type (max_int, max_uint): integers of maximum size as natively supported by the given machines general purpose registers (if defined HAVE_INT64 => 64bit; otherwise: 32bit)
//
// signed types: word, int, dbl_int, max_int, small_int, adr_diff, dbl_adr_diff, idx_diff, dbl_idx_diff, int8, int16, int32, int64 (ifdef HAVE_INT64)
// unsigned types: u_word, uint, dbl_uint, max_uint, small_uint, adr, uidx, dbl_uidx, uint8, uint16, uint32, uint64 (ifdef HAVE_INT64) 
//
//  not about HAVE_INT64: value iff natively supported: (+1), types.h may redefine this to have a value of (+2)
//

#if defined __CHAR_BIT__ && __CHAR_BIT__ != 8
  #error "char type is required to have 8bits / 1Byte."
#endif
typedef signed char int8;
typedef unsigned char uint8;

#if defined __SIZEOF_SHORT__ && __SIZEOF_SHORT__ != 2
  #error "sizeof(short) would be expected to be 2Bytes long on any 16/32/64 bit system."
#endif 
typedef signed short int16;
typedef unsigned short uint16;

#if ! defined __SIZEOF_INT__ && defined __INTSIZE
  // OpenWatcom uses __INTSIZE while gcc uses __SIZEOF_INT__
  #define __SIZEOF_INT__ __INTSIZE
#endif
#if ! defined __SIZEOF_POINTER__ && defined WORDSIZE
  // WORDSIZE is in deed the architecture deducted __SIZEOF_POINTER__; it shall always fit if known (this branch is a.o. executed by OpenWatcom)
  #define __SIZEOF_POINTER__ WORDSIZE
#endif

//
// todo: make this code safe to the -mx32 option
//
//#pragma message ( WORDSIZE );

#if WORDSIZE == 16
  // 16bit: word <- int  (int is 2Byte in 8086/i286 mode, though 4Byte would be possible: addresses are 16bit but 32bit registers available with the i386)
  typedef signed int word;
  typedef unsigned int u_word;

  // preferrably take int over short as known 16bit C++ compilers ( WatCom, Digital Mars ) have a sizeof(int) = 2
  #if __SIZEOF_INT__ == 4
   typedef signed short adr_diff;     // .data32, .addr16 (exceptional but sizeof(short) is guaranteed; see: $66-datasize-override-praefix for x86 systems)
   typedef unsigned short adr;
  #else
   typedef signed int adr_diff;       // .data16, .addr16
   typedef unsigned int adr;
  #endif
  typedef adr_diff idx_diff;
  typedef adr uidx;

  #if defined __SIZEOF_LONG__ && __SIZEOF_LONG__ != 4
   #error "16bit compilation target is expected to have a 4Byte long type (as in 32bit mode)."
  #endif
  typedef signed long int32;
  typedef unsigned long uint32;
  typedef signed long dbl_adr_diff;
  typedef signed long dbl_idx_diff;
  typedef unsigned long dbl_uidx;

  #if __SIZEOF_INT__ == 4 && __SIZEOF_LONG_LONG__ == 8
   typedef signed long long dbl_int;        // may be available with $66-datasize-override-praefix even in 8086 mode (i.e. target arch != machine)
   typedef unsigned long long dbl_uint;
  #else
   typedef signed long dbl_int;
   typedef unsigned long dbl_uint;
  #endif

  #if defined __SIZEOF_LONG_LONG__ && __SIZEOF_LONG_LONG__ != 8
    #error "sizeof(long long) would be expected to be 8Bytes/64bit even with a 16bit addressation (as in 32/64bit mode)."
  #endif

  #if defined  __SIZEOF_LONG_LONG__ || defined __WATCOMC__ || defined __WATCOM_CPLUSPLUS__
   #define HAVE_INT64 1
   typedef signed long long int64;
   typedef unsigned long long uint64;
   typedef signed long long max_int;
   typedef unsigned long long max_uint;
  #else
   typedef signed long max_int;
   typedef unsigned long max_uint;
  #endif

#elif WORDSIZE >= 32

  typedef signed long word;       // true for 32 and 64bit systems
  typedef unsigned long u_word;

  #if !defined __SIZEOF_INT__ || __SIZEOF_INT__ == 4
    typedef signed int int32;       // this is now always 32 bits
    typedef unsigned int uint32;
  #else
    // exceptional case: .data16 but .addr32
    #if __SIZEOF_LONG__ != 4
      #error "sizeof(long) is required to be 4Byte/32Bit iff sizeof(int) != 4Byte; f.i. possible with sizeof(int) is just 2Byte (.data16 .addr32)."
    #elif __SIZEOF_INT__ != 2
      #error "sizeof(int) is neither 4Byte nor 2Byte: error - no 4Byte datatype appears to be defined."
    #endif
    typedef signed long int32;       // this is now always 32 bits
    typedef unsigned long uint32;
  #endif

  #if __SIZEOF_POINTER__ < __SIZEOF_LONG__     // this would be the case if we could use 64bit registers while still using 32bit addresses
    #ifdef HAS_WARN
      #warning "using a default data width of 64bit while still addressing with 32bit."
    #else
      #pragma message ( "using a default data width of 64bit while still addressing with 32bit." );
    #endif
    typedef signed int adr_diff;
    typedef unsigned int adr;
    typedef signed long long dbl_adr_diff;   // shall be 64bit; see below.
  #else  // the usual case: compilation target architecture (adressing mode) = compilation target machine (instruction set, registers)
    #if defined __SIZEOF_POINTER__ && defined __SIZEOF_LONG__ && __SIZEOF_POINTER__ !=  __SIZEOF_LONG__
      #error "32/64 bit system: type association error while data-word-size != pointer-size."
      // supported: .data32, .addr32:: void*32, int32, long32, longlong64
      //            .data64, .addr64:: void*64, int32, long64, longlong64
      //            .data64, .addr32:: void*32, int32, long64, longlong64 (not dealt with in here; see for the branch above)
      //            .data16, .addr32:: void*32, int16, long32, longlong64
    #endif
    typedef signed long adr_diff;
    typedef unsigned long adr;
    #if __SIZEOF_LONG__ == 8
      #define NEED_128_DBLADRDIFF 1
    #else
      typedef signed long long dbl_adr_diff;
    #endif
  #endif

  typedef signed int idx_diff;    // is an adr_diff bounded by 32bit
  typedef unsigned int uidx;

  #if defined __SIZEOF_LONG_LONG__ && __SIZEOF_LONG_LONG__ != 8
    #error "sizeof(long long) would be expected to be 8Bytes/64bit on 32/64 bit systems."
  #endif
  #define HAVE_INT64 1
  typedef signed long long int64;
  typedef unsigned long long uint64;

  #if !defined __SIZEOF_INT__ || __SIZEOF_INT__ == 4
    typedef signed long long dbl_int;        // use 64bit as int is 32bit
    typedef unsigned long long dbl_uint;

    typedef signed long long dbl_idx_diff;
    typedef unsigned long long dbl_uidx;

  #else
    typedef signed long dbl_int;        // .data16, .addr32:: use 32bit as int has just 16bit (asserted before)
    typedef unsigned long dbl_uint;

    typedef signed long dbl_idx_diff;
    typedef unsigned long dbl_uidx;

  #endif

  typedef signed long long max_int;
  typedef unsigned long long max_uint;

#else
  #error "currently there are only data and address word sizes with a power of two supported; nonetheless you shall be free to extend the current code of basedefines.h to support some historic word sizes like 24; the author will be looking forward to know ... "

#endif

#if WORDSIZE == 64 
  typedef int64 iword;
  typedef uint64 u_iword;
#elif WORDSIZE == 32
  typedef int32 iword;
  typedef uint32 u_iword;
#elif WORDSIZE == 16
  typedef int16 iword;
  typedef uint16 u_iword;
#endif 

typedef unsigned int uint;   // here because of our naming convention and also for convenience
typedef idx_diff small_int;
typedef uidx small_uint;

typedef small_int small_bool;


#ifndef __cplusplus
  typedef small_int bool;
  #define true 1
  #define false 0
#endif

#ifdef DEF_IINT
 // is here just for hysteric reasons:
 //   f.i. iff a compiler defined int by default as unsigned (almost all software the author knows relies on a singed int)
 //   i.e. we do not know a single architecture where int would neither be 32bit nor 16bit
 typedef signed int iint;
 typedef unsigned int uiint;
 typedef dbl_int dbl_iint;
 typedef dbl_uint dbl_uiint;
#endif

#endif
