#include "TreeWidget.h"
#include <QtGui/QKeyEvent>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMessageBox>


AtmtTreeWidget::AtmtTreeWidget( struct AtmtTreeBase *treeBase ) : base(treeBase) {
  setColumnCount(1); setHeaderLabels( QStringList() << tr("automaton/index name") );
  lineEdit = new QLineEdit(this); edited_item = NULL; lineEdit->hide();
  lineEdit->installEventFilter(this);
  //this->installEventFilter(this);
  connect( lineEdit, SIGNAL(returnPressed()), this, SLOT(treeViewItemEdited()) );
}


void AtmtTreeWidget::insertTreeNodes( QTreeWidgetItem *parent, struct AtmtTreeNode *node ) {
  struct AtmtTreeNode *firstnode = node;  if(!node) return; QString str;
  do {
    QTreeWidgetItem *curitem = new QTreeWidgetItem(parent);
    curitem->setText(0,str=toQString(node->ident));
    curitem->setData(0,Qt::UserRole,QVariant::fromValue(node));
    //curitem->setFlags(Qt::ItemIsEditable);
    if( node->child ) insertTreeNodes( curitem, node->child );
    expandItem(curitem);
    //if( str == "Kopiere" ) setCurrentItem(curitem);
    node = node->next;
  } while( node != firstnode );
}


void AtmtTreeWidget::deleteShadowTree( QTreeWidgetItem *parent ) {
  for( int i = 0; i < parent->childCount(); i++ )
    deleteShadowTree( parent->child(i) );
  while( parent->childCount() > 0 ) delete parent->child(parent->childCount()-1);
}


struct AtmtTreeItemAndNode AtmtTreeWidget::createDirectory( QString dirName, QTreeWidgetItem *parentItem, bool *didExist ) {
  QTreeWidgetItem *curitem; struct AtmtTreeNode *curnode = NULL; estrbuf dirNameStr = dirName; struct AtmtTreeNode *parent; 
  if( parentItem && parentItem != invisibleRootItem() ) parent = qvariant_cast<struct AtmtTreeNode*>(parentItem->data(0,Qt::UserRole)); 
                                                 else { parentItem = invisibleRootItem(); parent = NULL; }
  do {
    std::pair<AtmtIndex::iterator,AtmtIndex::iterator> range = base->atmtIndex.equal_range(dirNameStr);
    for( AtmtIndex::iterator ii = range.first; ii != range.second; ii++ )
      if( ii->second->parent == parent && !ii->second->atmt ) curnode = ii->second; 
    if( curnode ) break;
    if( range.first == range.second ) break;
    echar Ichar = 'I'; dirNameStr.append(estr_const(&Ichar,1)); dirName += 'I';
  } while(true);
  if(!curnode) {
    curnode = new AtmtTreeNode(); curnode->atmt = NULL;
    insertAtmtTreeNode( base, parent, NULL, curnode, false );  // false ~ insert as last node of parent
    setAtmtIndexName( base, curnode, dirNameStr );
    curitem = new QTreeWidgetItem(parentItem);
    curitem->setText(0,dirName);
    curitem->setData(0,Qt::UserRole,QVariant::fromValue(curnode));
    if(didExist) *didExist = false;
  } else { int i;
    if( parent == NULL ) {
      for( i = topLevelItemCount()-1; i >= 0; i-- ) {
        curitem = topLevelItem(i); if( qvariant_cast<struct AtmtTreeNode*>(curitem->data(0,Qt::UserRole)) == curnode ) break;
      }; assert( i >= 0 );
    } else {
      for( i = parentItem->childCount()-1; i >= 0; i-- ) {
        curitem = parentItem->child(i); if( qvariant_cast<struct AtmtTreeNode*>(curitem->data(0,Qt::UserRole)) == curnode ) break;
      }; assert( i >= 0 );
    }
    if(didExist) *didExist = true;
  } 
  //PrintAtmtTree(base);
#ifdef _MSC_VER
  return AtmtTreeItemAndNode { curitem, curnode };
#else
  return AtmtTreeItemAndNode { .item = curitem, .node = curnode };
#endif
}


void AtmtTreeWidget::setModel( struct AtmtTreeBase *base ) {
  clear(); this->base = base; insertTreeNodes( invisibleRootItem(), base->atmtTree );
}


bool AtmtTreeWidget::deleteCurrentMachine( bool ask, QWidget *parent ) {
  QTreeWidgetItem *current = currentItem(); if(!current) return false;
  struct AtmtTreeNode *node = qvariant_cast<struct AtmtTreeNode*>(current->data(0,Qt::UserRole));
  if( node->child != NULL ) {
    QMessageBox::critical( parent, tr("Error Deleting Node"), tr("This node is a directory and can not be deleted unless all of its children have been deleted."), QMessageBox::Ok ); 
    return false;
  }
  if( ask && node->atmt ) if( QMessageBox::warning( parent, tr("Delete Automaton"), tr("Are you sure that you want to delete the current automaton?"), 
	QMessageBox::Yes | QMessageBox::Cancel )  != QMessageBox::Yes ) return false;
  deleteAtmtTreeNode(base,node); delete current;
  return true;
}


QTreeWidgetItem* AtmtTreeWidget::insertAtCurrent( struct AtmtTreeBase *base, struct AtmtTreeNode *node, bool isDirectory ) {  // atmt shall be set in node, ident is assigned "NewAutomaton"
  QTreeWidgetItem *current_item = currentItem(); struct AtmtTreeNode *current_node; QString ident;
  if(current_item) current_node = qvariant_cast<struct AtmtTreeNode*>(current_item->data(0,Qt::UserRole)); else current_node = NULL;
  struct AtmtTreeNode *parent = NULL, *previous = NULL; QTreeWidgetItem *wdg_parent = NULL, *wdg_previous = NULL;
  if( current_node && !current_node->atmt ) { parent = current_node; wdg_parent = current_item; }
  else { previous = current_node; wdg_previous = current_item; }
  estrbuf new_ident_buf; if(isDirectory) new_ident_buf = "NewDirectory"; else new_ident_buf = "NewMachine";
  echar c='I'; while( base->atmtIndex.find(new_ident_buf) != base->atmtIndex.end() ) new_ident_buf.append(estr(&c,1));  // if(node->atmt) ... also make predef directory name unique as it could be in the same directory
  setAtmtIndexName( base, node, new_ident_buf ); ident = toQString(new_ident_buf);
  //node->ident = base->atmtIndex.insert(std::make_pair(new_ident_buf,node))->first; ident = toQString(new_ident_buf);  // adjust to add III at the end to avoid duplicates
  QTreeWidgetItem *new_item;
  if(previous) { if(wdg_previous->parent()) new_item = new QTreeWidgetItem( wdg_previous->parent(), wdg_previous ); else { new_item = new QTreeWidgetItem(); insertTopLevelItem(indexOfTopLevelItem(wdg_previous)+1,new_item); }; }
  else if(parent) { new_item = new QTreeWidgetItem(); wdg_parent->insertChild(0,new_item); }
  else new_item = new QTreeWidgetItem(this);
  new_item->setText(0,ident);
  new_item->setData(0,Qt::UserRole,QVariant::fromValue(node));
  //new_item->setFlags(Qt::ItemIsEditable);
  insertAtmtTreeNode( base, parent, previous, node ); node->child = NULL;
  //PrintAtmtTree(base);
  setCurrentItem(new_item);
  prepareLineEdit(new_item);
  return new_item;
}


void AtmtTreeWidget::moveCurrentUp() {
  QTreeWidgetItem *item = currentItem(); if(!item) return;
  QTreeWidgetItem *parent = item->parent();
  int index; if(parent) index = parent->indexOfChild(item); else index = indexOfTopLevelItem(item);
  if( index <= 0 && !parent ) return;
  if(parent) parent->removeChild(item); else takeTopLevelItem(index);
  if( index <= 0 ) { 
    QTreeWidgetItem *grandparent = parent->parent(); if(grandparent) index = grandparent->indexOfChild(parent); else index = indexOfTopLevelItem(parent); parent = grandparent;
  } else {
    index--; QTreeWidgetItem *prev_item; if(parent) prev_item = parent->child(index); else prev_item = topLevelItem(index);
    if( prev_item && qvariant_cast<struct AtmtTreeNode*>(prev_item->data(0,Qt::UserRole))->atmt == NULL && ( prev_item->isExpanded() || !prev_item->childCount() ) ) { 
      parent = prev_item; index = prev_item->childCount(); }
  }
  if(parent) parent->insertChild(index,item); else insertTopLevelItem(index,item);
  setCurrentItem(item);
  struct AtmtTreeNode *node = qvariant_cast<struct AtmtTreeNode*>(item->data(0,Qt::UserRole));
  struct AtmtTreeNode *parent_node; if(parent) parent_node = qvariant_cast<struct AtmtTreeNode*>(parent->data(0,Qt::UserRole)); else parent_node = NULL;
  QTreeWidgetItem *prev_item = NULL; if( index > 0 ) { if(parent) prev_item = parent->child(index-1); else prev_item = topLevelItem(index-1); }
  struct AtmtTreeNode *prev_node = NULL;  if(prev_item) prev_node = qvariant_cast<struct AtmtTreeNode*>(prev_item->data(0,Qt::UserRole));
  unlinkAtmtTreeNode( base, node ); if(prev_node) parent_node = NULL;
  insertAtmtTreeNode( base, parent_node, prev_node, node );
  //PrintAtmtTree(base);
}


void AtmtTreeWidget::moveCurrentDown() {
  QTreeWidgetItem *item = currentItem(); if(!item) return;
  QTreeWidgetItem *parent = item->parent();
  int index; if(parent) index = parent->indexOfChild(item); else index = indexOfTopLevelItem(item);
  int count; if(parent) count = parent->childCount(); else count = topLevelItemCount();
  if( index+1 >= count && !parent ) return;
  if(parent) parent->removeChild(item); else takeTopLevelItem(index);
  if( index+1 >= count ) { 
    QTreeWidgetItem *grandparent = parent->parent(); if(grandparent) index = grandparent->indexOfChild(parent)+1; else index = indexOfTopLevelItem(parent)+1; parent = grandparent;
  } else {
    QTreeWidgetItem *new_item; if(parent) new_item = parent->child(index); else new_item = topLevelItem(index);
    if( new_item && qvariant_cast<struct AtmtTreeNode*>(new_item->data(0,Qt::UserRole))->atmt == NULL && ( new_item->isExpanded() || !new_item->childCount() ) ) { 
      parent = new_item; index = 0; }
    else index++;
  }
  if(parent) parent->insertChild(index,item); else insertTopLevelItem(index,item);
  setCurrentItem(item);
  struct AtmtTreeNode *node = qvariant_cast<struct AtmtTreeNode*>(item->data(0,Qt::UserRole));
  struct AtmtTreeNode *parent_node; if(parent) parent_node = qvariant_cast<struct AtmtTreeNode*>(parent->data(0,Qt::UserRole)); else parent_node = NULL;
  QTreeWidgetItem *prev_item = NULL; if( index > 0 ) { if(parent) prev_item = parent->child(index-1); else prev_item = topLevelItem(index-1); }
  struct AtmtTreeNode *prev_node = NULL;  if(prev_item) prev_node = qvariant_cast<struct AtmtTreeNode*>(prev_item->data(0,Qt::UserRole));
  unlinkAtmtTreeNode( base, node ); if(prev_node) parent_node = NULL;
  insertAtmtTreeNode( base, parent_node, prev_node, node );
  //PrintAtmtTree(base);
}


void AtmtTreeWidget::prepareLineEdit( QTreeWidgetItem *item ) {
  if(!item) return; lineEdit->setText(item->text(0)); edited_item = item;
  QRect itemRect = visualItemRect(item); //QPoint pos = mapTo(itemRect.topLeft());
  //itemRect.moveTop( itemRect.top() + visualItemRect(headerItem()).height() );
  itemRect.moveTop( itemRect.top() + itemRect.height() );
  lineEdit->move( itemRect.x(), itemRect.y() ); 
  int width = qMax( itemRect.width(), lineEdit->fontMetrics().width(item->text(0)) + lineEdit->fontMetrics().averageCharWidth()*8 );
  width = qMin( width, this->width() - lineEdit->pos().x() );
  lineEdit->setFixedWidth(width);
  lineEdit->show(); lineEdit->setFocus(Qt::MouseFocusReason); lineEdit->selectAll();
}


bool AtmtTreeWidget::eventFilter(QObject *target,QEvent *event) {
  if( event->type() == QEvent::KeyPress ) {
    QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
    if( target == lineEdit && keyEvent->key() == Qt::Key_Escape) {
      edited_item = NULL; lineEdit->hide(); setFocus(Qt::FocusReason::TabFocusReason);
      return true;
  } }
  return QTreeWidget::eventFilter(target,event);
}


void AtmtTreeWidget::treeViewItemEdited() {
  lineEdit->hide(); if(!edited_item) return; estrbuf new_ident_buf = lineEdit->text();
  struct AtmtTreeNode *node = qvariant_cast<struct AtmtTreeNode*>(edited_item->data(0,Qt::UserRole)); if(!node) return; 
  bool renamed = new_ident_buf != node->ident, othername = false, isPredef; AtmtIndex::iterator found;
  echar c='I'; if( renamed ) while( ( isPredef = isPredefinedIdentifier(new_ident_buf) ) || ( found = base->atmtIndex.find(new_ident_buf) ) != base->atmtIndex.end() ) { 
    if( !node->atmt && !found->second->atmt && !isPredef ) {  // directory with same name is allowed as long as it is in another directory
      if( node->parent != found->second->parent ) break;
    }
    new_ident_buf.append(estr(&c,1)); othername = true; 
  }
  if(renamed) {
    edited_item->setText(0, toQString(new_ident_buf) );
    unlinkIndexEntry( base, node );
    setAtmtIndexName( base, node, new_ident_buf );
  }
  if(othername) {
    if(node->atmt) QMessageBox::warning( this, tr("set name for automaton"), tr("Automaton has been renamed to %1 since an automaton or directory with name %2 does already exist.").arg(edited_item->text(0)).arg(lineEdit->text()) );
    else QMessageBox::warning( this, tr("set name for directory"), tr("Directory has been renamed to %1 since an automaton with name %2 does already exist (or a directory at the same level with the same name).").arg(edited_item->text(0)).arg(lineEdit->text()) );
  }
  //PrintAtmtTree(base); 
  edited_item = NULL; setFocus(Qt::FocusReason::TabFocusReason);
}


bool AtmtTreeWidget::keyPressed(QKeyEvent *event) {
  //cerr << "kk:"<< IOChangeVal(IOAttr::NumberBaseNextOne,16) << event->key() << "," << IOChangeVal(IOAttr::NumberBaseNextOne,16) << Qt::Key_Delete << aux::endl;
  QTreeWidgetItem *item;
  switch(event->key()) {
    case Qt::Key_Return:  case Qt::Key_Enter:
        if( event->modifiers() & Qt::AltModifier ) { prepareLineEdit(currentItem()); break; }
      return false;
    case Qt::Key_Up:
        if( event->modifiers() &  Qt::AltModifier ) { moveCurrentUp(); break; }
        item = currentItem(); if (!item) break;
        item = itemAbove(item); if(item) setCurrentItem(item);
      break;
    case Qt::Key_Down:
        if( event->modifiers() &  Qt::AltModifier ) { moveCurrentDown(); break; }
        item = currentItem(); if (!item) break;
        item = itemBelow(item); if(item) setCurrentItem(item);
      break;
    case Qt::Key_Space:
        item = currentItem(); if (!item) break;
       	if(item->isExpanded()) collapseItem(item); else expandItem(item);
      break;
    case Qt::Key_Delete: 
        deleteCurrentMachine( !(event->modifiers() &  Qt::ShiftModifier), this ); 
      break;
    default: return false;
  }
  return true;
}


void AtmtTreeWidget::keyPressEvent(QKeyEvent *event) {
  if(!keyPressed(event)) QTreeWidget::keyPressEvent(event);
}


void AtmtTreeWidget::mousePressEvent(QMouseEvent *event) {
  if( event->modifiers() & Qt::AltModifier ) { prepareLineEdit(itemAt(event->pos())); }
  else {
    if( edited_item ) treeViewItemEdited();
    QTreeWidget::mousePressEvent(event);
} }


