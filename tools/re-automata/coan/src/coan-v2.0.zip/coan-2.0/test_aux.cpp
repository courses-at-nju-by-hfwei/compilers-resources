//#include <iostream>
#include <errno.h>
#include "auxtypes.h"

using namespace aux;

void SimpleOutput() {
  cout << "*** SimpleOutput ***" << endl;
  cout << "ÄÖÜäöüß" << endl;

  echar test_str[] = { overlay_pred, not_in_range_overlay, first_greek_letter, not_in_range_overlay, first_greek_letter+1, not_in_range_overlay, 'b', overlay_pred, not_in_range_overlay, unicode_space, overlay_pred, not_in_range_overlay, 'A', overlay_pred, not_in_range_overlay, 'a', '.', 0 };
  //echar test_str[] = { not_in_range_overlay, first_greek_letter, not_in_range_overlay, first_greek_letter+1, not_in_range_overlay, 'b', overlay_pred, not_in_range_overlay, unicode_space, overlay_pred, not_in_range_overlay, 'A', overlay_pred, not_in_range_overlay, 'a', '.', 0 };
  echar test_str2[] = { thin_space, overlay_pred, not_in_range_overlay, 'b', overlay_pred, not_in_range_overlay, 'A', overlay_pred, not_in_range_overlay, 'a', '.', 0 };
  echar test_str3[] = { thin_space, overlay_pred, not_in_range_overlay, 'b', overlay_pred, not_in_range_overlay, close_subscripts_char, overlay_pred, not_in_range_overlay, 'a', '.', 0 };
  cout << "!=" << estr( test_str, sizeof(test_str)/sizeof(echar)-1 ) << endl;
  cout << estr( test_str2, sizeof(test_str2)/sizeof(echar)-1 ) << endl;
  cout << estr( test_str3, sizeof(test_str3)/sizeof(echar)-1 ) << endl;
  const char *test = "teststring-auto-overlining";
  cout << IOChangeFlags( IOFlag::OverlineNextXStr ) << astr_const((const achar*)test,strlen(test)) << endl;
  cout << IOChangeFlags( IOFlag::OverlineNextXStr ) << estr("αbc+kᴗfirst❫∘αᴗmid❫") << endl;
  cout << endl;

  cout.flush();
}

const char* bool2str[2] = { "bad", "good" };
const char* in_or_not[2] = { "not in", "in" };

void prn_find_result( const char *msg, estr_const haystack, astr_const needle, int pos ) {
  cout << msg; 
  if( 0 <= pos && pos < haystack.length ) cout << haystack.sub(0,pos) << "((" << needle << "))" << haystack.sub(pos+needle.length) << endl;
  else cout << "needle not found" << endl;
}

void string_find_test() {
  estrbuf haystack("there is a large haystack in which we wanna find the first needle or even another needle wherever that should be necessary.");
  astrbuf needle("needle"), needle12("first needle"), needle79("a large haystack in which we wanna find the first needle or even another needle"); 
  astrbuf needle33("the first needle or even another "), needleNotFound("hjkhjk");
  strsize pos;
  pos = needle.find(needle); if( pos < needle.length ) cout << "find:: needle is self-contained." << endl;
  pos = needle.find(needle); if( pos < needle.length ) cout << "rfind:: needle is self-contained." << endl;
  pos = haystack.find(needle); prn_find_result( "forward search6:: ", haystack, needle, pos );
  pos = haystack.rfind(needle); prn_find_result( "backward search6:: ", haystack, needle, pos );
  pos = haystack.find(needle12); prn_find_result( "forward search12:: ", haystack, needle12, pos );
  pos = haystack.rfind(needle12); prn_find_result( "backward search12:: ", haystack, needle12, pos );
  pos = haystack.find(needle33); prn_find_result( "forward search33:: ", haystack, needle33, pos );
  pos = haystack.rfind(needle33); prn_find_result( "backward search33:: ", haystack, needle33, pos );
  pos = haystack.find(needle79); prn_find_result( "forward search79:: ", haystack, needle79, pos );
  pos = haystack.rfind(needle79); prn_find_result( "backward search79:: ", haystack, needle79, pos );
  pos = haystack.find(needleNotFound); prn_find_result( "forward search (find nothing):: ", haystack, needleNotFound, pos );
  pos = haystack.rfind(needleNotFound); prn_find_result( "backward search (find nothing):: ", haystack, needleNotFound, pos );
  cout << endl;
}

void overline_test() {
  astrbuf hug("abcdefg hijklämönüo\001\002ÜÄÖüäöß");
  cout << hug << endl;
  cout << IOChangeFlags( IOFlag::OverlineNextXStr ) << hug << endl;
  
  estrbuf hug2("abcdefg αβγδ xᴗ11❫ hijklämönüo\001\002ÜÄÖüäöß");
  cout << hug2 << endl;
  cout << IOChangeFlags( IOFlag::OverlineNextXStr ) << hug2 << endl;

  echar special_chars[] = { 'a', subscript_space, unicode_space, range_char, neq_char, leq_char, geq_char, setminus_char, setminus_4_editing_char, empty_set_char, concat_char, 0 };
  cout << estr( special_chars, sizeof(special_chars)/sizeof(echar)-1 ) << endl;
  cout << IOChangeFlags( IOFlag::OverlineNextXStr ) << estr( special_chars, sizeof(special_chars)/sizeof(echar)-1 ) << endl;
}

void numberbase_test() {
  cout << IOChangeVal(IOAttr::NumberBaseNextOne,16) << "hex-value: " << 0xFF << endl << "decimal-value: " << 0xFF << endl;
}

void alloc_test() {
  estrbuf hug("abcαβγ"); estrbuf has = hug; 
  cout << IOChangeVal(IOAttr::NumberBase,16) << hug.bufParams << "/" << (u_iword)hug.chars << " - " << has.bufParams << "/" << (u_iword)has.chars << endl; 
  has = hug;
  cout << IOChangeVal(IOAttr::NumberBase,16) << hug.bufParams << "/" << (u_iword)hug.chars << " - " << has.bufParams << "/" << (u_iword)has.chars << endl; 
  estrbuf hug2(hug);
  cout << IOChangeVal(IOAttr::NumberBase,16) << hug.bufParams << "/" << (u_iword)hug.chars << " - " << hug2.bufParams << "/" << (u_iword)hug2.chars << endl; 
  hug2 = hug;
  cout << IOChangeVal(IOAttr::NumberBase,16) << hug.bufParams << "/" << (u_iword)hug.chars << " - " << hug2.bufParams << "/" << (u_iword)hug2.chars << endl; 
  cout << IOChangeVal(IOAttr::NumberBase,10); 
}

void numIO_test() {
  /*cout << -36 << endl;
  cout << +36 << endl;
  cout << MaxSigned(int64) << endl;
  cout << MaxUnsigned(int64) << endl;
  cout << UInt( 36 ) << endl;
  cout << UInt( MaxUnsigned(int64) ) << endl;
  cout << UInt( -1 ) << endl;
  cout << "int16 input test (first signed, then unsigned)" << endl;  cout << PIfErr(cin,", ");*/
  int16 hug; cin >> &hug >> endl; cout << hug << PIfErr(cin,", uint16") << endl;
  int hugInt; cin >> &hugInt >> endl; cout << hugInt << PIfErr(cin,", int") << endl;
  //uint16 uhug; cin >> &uhug; cout << uhug << PIfErr(cin,", uint16") << endl;
}

void readline_test() {
  estrbuf buf; cout << "utf8-estr line input: "; cin >> &buf >> endl; cout << "'" << buf << "'" << endl;
  cin.setCharset( Charset::latin1 );
  astrbuf asciibuf; cout << "latin1-astr line input: "; cin >> &asciibuf >> endl; cout << "'" << asciibuf << "'" << endl;
  cin.setCharset( Charset::utf8 );
}

void append_test() {
  estrbuf hug("abc");
  cout << xstrbuf_bufLength(hug) << ",";
  //hug.insert(2,"defghijklmnop");
  hug.append("defghijklmnop");
  cout << xstrbuf_bufLength(hug) << ",";
  hug.replace(3,2,"qrstuvwxyz0123456789-.");
  cout << xstrbuf_bufLength(hug) << ",";
  cout << hug << endl;
  hug.remove(3,20);
  cout << hug << endl;
  estrbuf hase("-hoppel-");
  hug.replace(3,2,hase);
  cout << hug << endl;
}

int main( int argc, char *argv[] ) {

  //cgstd << IOChangeFlags( XStrSpecialSpace | XStrVisibleControlChars );
  cout << "compiled with: "; print_aux_config(cout); cout << endl;
  cout << "charset (0-latin1,1-asciiext,2-utf8):" << terminal_type.charset << endl;
  //aux_assert( 2 == 7 + 3 ); 

  cout.attr->flags |= IOStream::AttrFlags::immediate_flush;
  cout << "AUX Test" << endl;
  cout << "overlined: " << IOChangeFlags( IOFlag::OverlineNextXStr | IOFlag::XStrSpecialSpace ) << astr_const((const achar*)"abcde",5) << astr_const((const achar*)" = 12.",6) << endl * 2;
  //string_find_test();
  SimpleOutput();
  overline_test();
  numberbase_test();
  alloc_test();
  //numIO_test();
  //readline_test();
  append_test();

  //stout << IOChangeFlags( IOFlag::OverlineXStr ) << IOChangeFlags( 0, 0, IOFlag::OverlineNextXStr ); cout.attr->flags = IOStream::Flags::immediate_flush;
  //stout << AChar('=') * 20 << endl;
  //stout << IOChangeFlags( IOFlag::OverlineNextXStr ) << IOChangeFlags( 0, IOFlag::OverlineAfterNextXStr, 0 ); cout.attr->flags = IOStream::Flags::immediate_flush;
  //stout << AChar('-') * 20 << endl;
  //stout << IOChangeFlags( IOFlag::OverlineNextXStr, IOFlag::OverlineAfterNextXStr, 0 ); cout.attr->flags = IOStream::Flags::immediate_flush;
  //cout << endl * 2;
  cout.flush();
  return 0;
}
