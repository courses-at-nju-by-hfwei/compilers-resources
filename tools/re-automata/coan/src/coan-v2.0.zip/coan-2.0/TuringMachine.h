#ifndef TURING_MACHINE_H
#define TURING_MACHINE_H

#include "charset.h"
#include "arithexpr.h"
#include "automatdef.h"
#include "LoadSaveAtmt.h"
#ifdef QT_CORE_LIB
  #include "GraphicalNode.h"
#else
  #define EllipticalNode Node
  #define RectangularNode Node
#endif


// ------------------  Turing Machines  ------------------  

class TM_Data : public Data {
public:
  SymbolTable *localSymTab; astr_shared *tape; int pos;
public:
  TM_Data( const TM_Data *previous, achar write_char, int move_pos, SymbolTable *newSymTab ) {
    if( move_pos ) {
      pos = previous->pos + move_pos;
      if( pos < previous->tape->length ) {
	if( previous->pos == previous->tape->length - 1 && previous->tape->chars[previous->pos] == '#' && move_pos == -1 ) 
	  tape = previous->tape->dup_sub(0,pos+1);   // end of tape: moved to the left
	else
          tape = previous->tape->duplicate();        // inner move
      } else {
        tape = previous->tape->dup_replace_char(pos,'#');    // end of tape: moved to the right
      }
    } else {
      pos = previous->pos;
      tape = previous->tape->dup_replace_char(pos,write_char);
    };
    localSymTab = newSymTab;
  };
  TM_Data( const TM_Data *other, SymbolTable *newSyms ) {
    pos = other->pos;
    tape = other->tape->duplicate();
    localSymTab = other->localSymTab->copy_acquireSymsFrom( newSyms );
  };
  TM_Data( const TM_Data *other ) {
    pos = other->pos;
    tape = other->tape->duplicate();
    localSymTab = other->localSymTab->anotherInstance();
  };
  TM_Data( astr_const init_tape, int initial_pos, SymbolTable *newSyms = NULL ) {
    pos = initial_pos; int target_len =  pos < init_tape.length ? init_tape.length : pos + 1;
    tape = astr_shared::allocate_for_len( target_len );
    memcpy( tape->chars, init_tape.chars, init_tape.length );
    memset( tape->chars + init_tape.length, '#', target_len - init_tape.length );
    tape->chars[target_len] = '\000';
    if(!newSyms) localSymTab = emptySymbolTable.anotherInstance();
    else localSymTab = newSyms;
  };
  TM_Data( astr_shared *init_tape, int initial_pos, SymbolTable *newSyms ) {
    pos = initial_pos;
    if( pos < init_tape->length ) {
      tape = init_tape->duplicate();
    } else {
      int target_len = pos + 1;
      tape = astr_shared::allocate_for_len( target_len );
      memcpy( tape->chars, init_tape->chars, init_tape->length );
      memset( tape->chars + init_tape->length, '#', target_len - init_tape->length );
      tape->chars[target_len] = '\000';
    }
    if(!newSyms) localSymTab = emptySymbolTable.anotherInstance();
    else localSymTab = newSyms;
  }
  inline static void freeMem( TM_Data *d ) { if(!d) return; SymbolTable::freeMem(d->localSymTab); astr_shared::freeMem(d->tape); dealloc( d, sizeof(TM_Data) );}
};


class TM_Runtime;

void TM_MS_Node_do_lookAhead( TM_Runtime *r, TM_Data *d, int relpos );

class TM_Node : public EllipticalNode {
protected:
  estrbuf label;
  virtual int setContent( Automaton *a, estrbuf *newlabel ) { label.moveFrom(newlabel); *newlabel = invalid_estr; return -1; };
public:
  TM_Node() : EllipticalNode() { label = empty_estr; }
  virtual estr_const getContent() const { return label; };
#ifdef QT_CORE_LIB
  virtual void callbackPrint( TextCallBack cb, void *data ) const { cbPrintSubscripted( cb, 0, false, label, data ); }
#endif
  virtual bool isFinalNode() const { return label.length > 0 && label.chars[0] == 'h' && ( label.length == 1 || label.chars[1] == subscript_char ); };
  virtual bool setFinalNode( bool shouldHalt ) { return isFinalNode() == shouldHalt; }
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
  friend class TM_Runtime;
};

class MS_Edge : public Edge {
public:
  MS_Edge( Node *a, Node *b ) : Edge(a,b) { condition = content = estr_epsilon; variable = invalid_estr; flags = EdgeFlags::isEmptyTransition; };
  estrbuf content;
  enum EdgeFlags { isEmptyTransition = 1, negatedCond = 2, simpleCond = 4, needsPreviousVar = 8 };
  estr_const variable, condition; int flags;
protected:
  virtual int setContent( Automaton *a, estrbuf *acceptation );
  void printHead( IOStreamRef out, int debuglevel ) const;
  void printTail( IOStreamRef out, int debuglevel ) const;
  bool check4Epsilon( estrbuf *label );
  void scan4VariableAndCondition( int startPos, int onePastEnd, int *trueVarLen, int *errpos );
public:
  virtual estr_const getContent() const { return content; };
  virtual void print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const;
#ifdef QT_CORE_LIB
  virtual void callbackPrint( TextCallBack cb, void *data ) const;
#endif
  bool evalConditionAndAssignment( Runtime *r, TM_Data *d, achar curChar, SymbolTable **tmpTransitionSymbols );
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
};

class TM_Edge : public MS_Edge {
public:
  TM_Edge( Node *a, Node *b ) : MS_Edge(a,b) { write_variable = NULL; write_char = '#'; move_position = 0; };
  echar write_char; short int move_position;
  echar *write_variable;
protected:
  virtual int setContent( Automaton *a, estrbuf *acceptation );
public:
  virtual void print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const;
#ifdef QT_CORE_LIB
  virtual void callbackPrint( TextCallBack cb, void *data ) const;
#endif
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
};

class TM;

class TM_Runtime : public Runtime {
protected:
  TM_Runtime( Automaton *a, astr_const charParam, inta_const valParam, int tracelen ) : Runtime(a,charParam,valParam,tracelen) { };
  TM_Data* createInitialData( astr_shared *input, int position );
  virtual Status getResultStatus( Element *e, Data *d );
public:
  TM_Runtime( TM *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos );
  static void*(*alloc)(size_t);		// defaults to malloc
  static void(*dealloc)(void*,size_t);   // defaults to demalloc = free
  TM_Data* dataChangeTape( Data *d , echar write_char, int move_pos, SymbolTable *newSyms ) const { return new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( (TM_Data*)d, write_char, move_pos, newSyms ); }
  TM_Data* dataAcquireSymTab( Data *d , SymbolTable *newSyms ) const { return new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( (TM_Data*)d, newSyms ); }
  virtual Data* duplicateData( Data *d ) const { return new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( (TM_Data*)d ); }
  virtual void freeData( Data *data ) const { TM_Data::freeMem( (TM_Data*)data ); /* not-to-do: d->~TM_Data();*/  }
  virtual void printData( IOStreamRef out, Data *data, bool shallPrintVars ) const;
  virtual int compareData( Data *a0, Data *b0 ) const;
  virtual SymbolTable* getDataSymTab( Data *data ) const { if(!data) return NULL; return ((TM_Data*)data)->localSymTab; }
public:
  virtual int numTapes( ParentTapeIndex i = ParentTapeIndex() );
  virtual int getTape( astr_const *content, int *pos, SymbolTable **symTab, TapeIndex idx = TapeIndex() );
  virtual void getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i = TapeIndex() );
  virtual void getOutcome( int idx, astr_shared **tape, int *pos, enum Status *status, int *step_num );
};

class TM : public Automaton {
public:

  TM() : Automaton() {};

  virtual const char* typeStr() { return "TM"; }
  virtual bool posTapeCursorAtBegin() { return false; }

  Node* createNode() {
    TM_Node *n = new TM_Node();
    allNodes.push_back(n);
    return n;
  }

  Edge* createEdge( Node *a, Node *b ) {
    TM_Edge *n = new TM_Edge( a, b );
    allEdges.push_back(n);
    return n;
  }

  Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) { 
    //refreshEpsilonClosure();  // TMs do not use to have epsilon closures; however a reflexive closure was formerly necessary for addState
    return new TM_Runtime(this,input,pos,charParam,valParam,tracelen,prepareStatePos); 
  }

};

extern const echar echars_one[2]; // = { '1', 0 };
extern const estr_const estr_one; // ( echars_one, 1 );

class MS;

#define MAX_NUM_PARAM 3
#define MAX_CHAR_PARAM 6

class MSNodeProxy : public ElementProxy {
public:
  short int start, len, action;
  int int_param_count, char_param_count;
  Automaton *atmt;
  ArithmeticExpression potency, int_param[MAX_NUM_PARAM];
  estr_const char_param[MAX_CHAR_PARAM];
public:
  MSNodeProxy( Element *e, short runtime_pos) : ElementProxy(e,runtime_pos), int_param_count(0), char_param_count(0), atmt(NULL), potency(estr_one) {};
  //MSNodeProxy( Element *e, short runtime_pos, short int start, short int len ) : ElementProxy(e,runtime_pos), start(start), len(len), int_param_count(0), char_param_count(0), atmt(NULL), potency(estr_one) {};
  virtual int execLength() const;
};

class MS_Node : public RectangularNode {
protected:
  estrbuf cmdd;
  std::vector<MSNodeProxy> command;
  virtual int execLength() const;
  virtual int setContent( Automaton *a, estrbuf *newAcceptation );
public:
  MS_Node() : RectangularNode() { cmdd = empty_estr; }
  virtual estr_const getContent() const { return cmdd; };
  void printCmd( IOStreamRef out, int i ) const;
  virtual void print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const;
#ifdef QT_CORE_LIB
  void cbPrintCmd( TextCallBack cb, int i, void *data ) const;
  virtual void callbackPrint( TextCallBack cb, void *data ) const;
#endif
  virtual bool isFinalNode() const { return succ.empty(); };
  virtual bool setFinalNode( bool shouldHalt ) { return isFinalNode() == shouldHalt; }
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
  void clear_commands();
  virtual ~MS_Node() { clear_commands(); }
  friend class MS;
  friend class MS_Runtime;
  friend MSNodeProxy;
};

class MS_Runtime : public TM_Runtime {
public:
  MS_Runtime( TM *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos );
  virtual Status status_4_no_successor( const State *state );
protected:
  virtual Status getResultStatus( Element *e, Data *d );
  virtual void freeMemSub( Automaton *a );
};


class MS : public TM {
public:

  MS() : TM() { atmtIndex = NULL; };

  virtual const char* typeStr() { return "MS"; }

  AtmtIndex *atmtIndex;
  enum Action { Print, Left, Right, SearchLeft, SearchRight, Exec };
  bool backpatchAtmtRefs(bool refreshAll);  // returns true on backpatching completed well

  Node* createNode() {
    MS_Node *n = new MS_Node();
    allNodes.push_back(n);
    return n;
  }

  Edge* createEdge( Node *a, Node *b ) {
    MS_Edge *n = new MS_Edge( a, b );
    allEdges.push_back(n);
    return n;
  }

  Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) { 
    // refreshEpsilonClosure();  // MSs do not use to have epsilon closures; however a reflexive closure was foremerly necessary for addState
    backpatchAtmtRefs(false);
    return new MS_Runtime(this,input,pos,charParam,valParam,tracelen,prepareStatePos); 
  }

};


#endif
