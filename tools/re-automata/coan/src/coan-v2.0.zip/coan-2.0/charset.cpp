#include "charset.h"
#include "assert.h"

// shorthand procedure to handle the unicode_space

__pure_const inline echar prepare_echar(register echar c) { return c!=unicode_space ? c : ' '; };  // leaves all unconverted xchars the same

//
// Character Set with Variables: base operations, static implementation
//

int ExtCharSet::first_error_position( estr_const set, int flags, int *outFlags ) {
  register int j; int errpos = -1; register bool isSimple = true; int numCharsEqOne = 0;
  if(!( flags & allow_var_ranges )) {
    register bool had_a_special_char = true;
    for( j=0; j < set.length; numCharsEqOne++, j++ ) {
      if( prepare_echar(set.chars[j]) <= 0xFF ) { 
	if( !( flags & allow_dot_dot ) && set.chars[j] == '.' && j>0 && set.chars[j-1] == '.' ) { errpos = (j); break; }
	had_a_special_char = false; continue; 
      };
      if( set.chars[j] == range_char && !had_a_special_char && j+1 < set.length && prepare_echar(set.chars[j+1]) <= 0xFF ) { isSimple = false; 
	if( !( flags & allow_empty_ranges ) && prepare_echar(set.chars[j-1]) > prepare_echar(set.chars[j+1]) ) { errpos = (j); break; }
	j++; numCharsEqOne++; continue; 
      }
      had_a_special_char = true;
      if( set.chars[j] == setminus_char && j>0 && j<set.length-1 ) { isSimple = false; continue; }
      if( !SymbolTable::isGreekVariable(set.chars[j]) ) { errpos = (j); isSimple = false; break; }
      if( j+1 < set.length && set.chars[j+1] == subscript_char ) j += SymbolTable::varLength( set.chars + j ) - 1;  // relies on zero-Termination
      flags |= has_variables;
    }
  } else {
    register echar c; bool hadVar = false;
    for( j=0; j < set.length; numCharsEqOne++, j++ ) {
      c = prepare_echar( set.chars[j] );
      if( c <= 0xFF ) {
	if( !( flags & allow_dot_dot ) && c == '.' && j>0 && set.chars[j-1] == '.' ) { errpos = (j); break; }
	hadVar = false; continue;
      };
      if( c == setminus_char && j>0 && j < set.length-1 ) { isSimple = false; continue; }
      if( c == range_char && j>0 && j+1 < set.length && set.chars[j+1] != setminus_char && set.chars[j-1] != setminus_char ) { isSimple = false; 
	if( !( flags & allow_empty_ranges ) && !hadVar ) {
	  echar start_char = prepare_echar(set.chars[j-1]); echar end_char = prepare_echar(set.chars[j+1]);
	  if(  start_char <= 0xFF && end_char <= 0xFF && start_char > end_char ) { errpos = (j); break; }
	}
	continue;
      }
      if( !SymbolTable::isGreekVariable(c) ) { errpos = (j); isSimple = false; break; }
      if( j+1 < set.length && set.chars[j+1] == subscript_char ) j += SymbolTable::varLength( set.chars + j ) - 1;  // relies on zero-Termination
      flags |= has_variables;
      hadVar = true;
    }
  }
  while( j < set.length && ( isSimple || !( flags & has_variables ) || numCharsEqOne <= 1 ) ) {
    if( SymbolTable::isGreekVariable(set.chars[j]) ) { 
      flags |= has_variables; 
      j += SymbolTable::varLength( set.chars + j ); 
      numCharsEqOne++; 
    } else {
      isSimple = isSimple && prepare_echar(set.chars[j]) <= 0xFF; 
      j++; numCharsEqOne++; 
    }
  }
  if(isSimple) flags |= is_a_simple_range;
  if(numCharsEqOne==1) flags |= exactly_one_character;
  if(outFlags) *outFlags = flags;
  return errpos;
}

inline void ExtCharSet::do_lookUp( int &j, echar &c, estr_const &set, SymbolTable *local, SymbolTable *global, bool *undefined_variable ) {
  long long res; bool found; // assert( c == set.chars[j] );
  if( local || global ) {
    res = 3; found = false;
    if( local ) { 
      res = local->lookUp( set.chars + j );
      c = (achar)res; res >>= 32; found = !( res & 1 );
    }
    if( global && !found ) {
      res = global->lookUp( set.chars + j );
      c = (achar)res; res >>= 32; found = !( res & 1 );
    }
    j += ( res >> 1 ) - 1;
    if( !found ) { c = SymbolTable::unknown_echar; if( undefined_variable != NULL ) *undefined_variable = true; }
  } else {
    j += SymbolTable::varLength( set.chars + j ) - 1;
  }
}

bool ExtCharSet::elm_in( achar elm, estr_const set, SymbolTable *local, SymbolTable *global, bool *undefined_variable ) {
  register echar c, d; bool isset = false; bool positive = true;

  register int j=0;

  elm_isset_check:

    for(; j < set.length; j++ ) {
      c = prepare_echar( set.chars[j] );
      if( c == setminus_char && positive ) break;
      if( SymbolTable::isGreekVariable(c) ) do_lookUp( j, c, set, local, global, undefined_variable );
      if( j+2 < set.length && set.chars[j+1] == range_char ) {
	j += 2; d = prepare_echar( set.chars[j] );
	if( SymbolTable::isGreekVariable(d) ) do_lookUp( j, d, set, local, global, undefined_variable );
	if( c <= elm && elm <= d && d <= 0xFF ) { isset = positive; break; }
	continue;
      }
      if( c == elm ) { isset = positive; break; }
    }

    if( positive ) { 
      if( !isset ) return false;
      positive = false; while( j < set.length && set.chars[j] != setminus_char ) j++;
      j++; goto elm_isset_check;
    }

  return isset;
}

const echar echars_ChangeSubscript[] = { subscript_char, ' ', close_subscripts_char };
const estr_const estr_ChangeSubscript( echars_ChangeSubscript, sizeof(echars_ChangeSubscript)/sizeof(echar) );

void cbPrintSubscripted( TextCallBack cb, int baseline, bool overlined, estr_const text, void *data ) {
  int i, j; int subscript_count = 0, subscript_nest = 0;
  i=0; while( i < text.length ) {
    j = text.find_first_of( subscript_char, i ); 
    cb( baseline, subscript_count, overlined, text.sub(i,j-i), data );
    if( j+1 >= text.length ) break;
    if( baseline ) subscript_count++; else baseline++;
    subscript_nest = 1;
    i = j+1; while( 0 < subscript_nest && i < text.length ) {
      j = text.find_first_of( estr_ChangeSubscript, i ); 
      cb( baseline, subscript_count, overlined, text.sub(i,j-i), data );
      i = j + 1;
      if( i >= text.length ) break;
      switch( text.chars[j] ) {
	case subscript_char: subscript_count++; subscript_nest++; break;
	case ' ': subscript_count--; subscript_nest--; break;
	case close_subscripts_char:  // subscript_count may be one smaller if baseline zero
	    //if( subscript_nest > subscript_count ) baseline = 0;
	    subscript_count -= subscript_nest; subscript_nest = 0; 
	  break;
      }
    }
    if( subscript_count < 0 ) { baseline = 0; subscript_count = 0; }
  }
}


const echar echars_setminus_embedded[] = { '}', setminus_char, '{', 0 }; 
const estr_const estr_setminus_embedded(echars_setminus_embedded,sizeof(echars_setminus_embedded)/sizeof(echar)-1);

bool ExtCharSet::print( IOStreamRef out, estr_const set, bool negated, bool print_as_set ) {
  IOFlagInt prev_io_flags = out.getIOAttrFlags();
  //out.overline_xstr = out.overline_next_xstr = negated;
  out << IOChangeFlags( 0, IOFlag::OverlineXStr, negated ? IOFlag::OverlineXStr : 0 );
  if( set.length == 0 ) {
    out << EChar( empty_set_char );
  } else if( !print_as_set ) {
    out << set;
  } else {
    bool had_set_minus = false; 
    out << AChar('{');
    for(int j=0; j < set.length; j++ ) {
      if( set.chars[j] == setminus_char ) {  if(!had_set_minus) { had_set_minus = true; out << estr_setminus_embedded; continue; } else goto continue_print; }
      else if( SymbolTable::isGreekVariable(set.chars[j]) ) { int varLen = SymbolTable::varLength( set.chars + j ); out << set.sub(j,varLen); j += varLen - 1;  }
      else if( set.chars[j] == ',' || set.chars[j] == '}' || set.chars[j] == '{' ) out << EChar('\'') << EChar(set.chars[j]) << EChar('\'') ;
      else out << EChar(set.chars[j]);
    continue_print:
      if( j+1 < set.length && set.chars[j+1] != setminus_char && set.chars[j+1] != range_char && set.chars[j] != range_char ) 
	out << AChar(',');
    }
    out << AChar('}');
  };
  out.restoreIOAttrFlags(prev_io_flags);
  return out;
}

const echar echars_backslash[2] = { '\\', 0 }, echars_quote[2] = { '\'', 0 }, echars_comma[2] = { ',', 0 }, echars_open_curly_bracket[2] = { '{', 0 }, echars_close_curly_bracket[2] = { '}', 0 };
const estr_const estr_backslash( echars_backslash, 1 ), estr_quote( echars_quote, 1 ), estr_comma( echars_comma, 1), estr_open_curly_bracket(echars_open_curly_bracket,1), estr_close_curly_bracket(echars_close_curly_bracket,1); 

void ExtCharSet::cbPrint( TextCallBack cb, estr_const set, bool negated, bool print_as_set, void *data ) {
  if( set.length == 0 ) { cb( 0, 0, negated, estr_empty_set_char, data ); return; }
  else if(!print_as_set) { cb( 0, 0, negated, set, data ); return; }
  bool had_set_minus = false; 
  cb( 0, 0, negated, estr_open_curly_bracket, data ); 
  for(int j=0; j < set.length; j++ ) {
    if( set.chars[j] == setminus_char ) {  if(!had_set_minus) { had_set_minus = true; cb( 0, 0, negated, estr_setminus_embedded, data ); continue; } else goto continue_print; }
    else if( SymbolTable::isGreekVariable(set.chars[j]) ) { 
      int varLen = SymbolTable::varLength( set.chars + j );
      cbPrintSubscripted( cb, 0, negated, estr_const(set.chars+j,varLen), data );
      j += varLen - 1;  
    }
    else if( set.chars[j] == ',' || set.chars[j] == '}' || set.chars[j] == '{' ) { 
      cb( 0, 0, negated, estr_quote, data ); 
      cb( 0, 0, negated, estr_const(set.chars+j,1), data ); 
      cb( 0, 0, negated, estr_quote, data ); 
    } else cb( 0, 0, negated, estr_const(set.chars+j,1), data ); 
  continue_print:
    if( j+1 < set.length && set.chars[j+1] != setminus_char && set.chars[j+1] != range_char && set.chars[j] != range_char ) 
      cb( 0, 0, negated, estr_comma, data ); 
  }
  cb( 0, 0, negated, estr_close_curly_bracket, data ); 
}

//
// Character Set with Variables: set operations, static implementation
//

void ExtCharSet::collectSymbolsAndVars( register estr_const set, bool set_is_complemented, int *round_value,
                                        StaticCharSet *positive_set, StaticCharSet *used_set, SymbolTable **collect_variables, int *collect_flags ) {

  StaticCharSet cur_set[2]; memset( cur_set, 0 , sizeof(cur_set) );
  int flags, round, prev_round; int *value, pos_inc, last_pos_inc, true_len, last_true_len;
  bool keep_deduct = collect_flags && ( *collect_flags & keep_all_and_only_deduction_vars );
  bool process_open_ranges = collect_flags && ( *collect_flags & manifest_open_ranges_as_char_values );
  SymbolTable *vars = NULL; if( collect_variables ) { 
    vars = *collect_variables; if(!vars) vars = SymbolTable::reserveEmpty(1); 
    prev_round = *round_value; if( prev_round <= 0 ) prev_round = 2; else prev_round &= ~1;  // prev_round shall be any valid round value before the current one
    round = prev_round + 2; if( round <= 0 ) round = 2;                                      // current round value
  }
  if( collect_flags ) flags = *collect_flags; else flags = 0;
  register echar c, prev_c = SlashSeparator; bool hadARange = false; register int j=0;
  bool positive = !set_is_complemented;   // true ~ current placeholders can appear in the input set, false ~ used otherwise ( f.i. in deduction set or a set that has been complemented )
  set_is_complemented = !positive;    // assert this to be zero or one
  //
  // loop: set == "A\B": always starts reading with A and then comes to B
  // normal operation: result = A ⋂ ¬B ::  A is read into cur_set[true], B is then read into cur_set[false]
  // set is complemented: result = ¬A ⋃ B ::  A is read into cur_set[false], B is then read into cur_set[true]
  //

  collect_the_right_set:

    for(; j < set.length; j++ ) {
      c = prepare_echar( set.chars[j] );
      if( c == setminus_char && positive != set_is_complemented ) break;
      if( c ==  range_char ) { hadARange = true; continue; }
      else if( c <= 0xFF && !hadARange && ( j == set.length-1 || set.chars[j+1] != range_char ) ) {
	cur_set[positive].set_elm( c );

      } else if( SymbolTable::isGreekVariable(c) && vars ) {
        pos_inc = vars->lookUpEntry( set.chars+j, &value, &true_len );
	// if( set_is_complemented && !positive ) flags |= var_complemented;
	if( keep_deduct && set_is_complemented ) {
	  // keep_deduct only keeps true deduction vars (i.e. when !set_is_complemented):  ¬A ⋃ B :: d ∈ A ⋀ d ∈ B => d still ∈ ResultSet
	  if( positive ) {
	    if( !value ) vars = vars->set( set.chars+j, round, NULL, SymbolTable::set_always, &true_len );
	    else if( *value < 0 ) *value = round;   // variable was marked used by a previous run but now appears in the positive set: mark as positive and forget about the previous usage
	  }
	} else {
	  if(!value||!*value) { vars = vars->set( set.chars+j, positive ? round : -round, NULL, SymbolTable::set_always, &true_len ); }
	  else if( *value < 0 && positive ) *value = round|1;          // normal operation: was marked used by a previous round, set_is_complemented: positive side is last and will dominate
	  else if( *value == (round|1) && !positive ) *value = -prev_round;      // normal operation: was made positive in this round: reset to negative
	  else if( *value == (round) && !positive ) {
	    if( !keep_deduct ) vars->removeEntry(value);    // normal operation: set in this round and now deducted in the same round: unset again
	    else *value = -round;
	  }
	}
	j += pos_inc - 1;

      }
      if( hadARange ) {
	bool isGreek, isPrevGreek, trivial_range;
	isPrevGreek = SymbolTable::isGreekVariable(prev_c);
	isGreek = SymbolTable::isGreekVariable(c);

	if( !isPrevGreek && !isGreek && c <= 0xFF && prev_c <= 0xFF ) 
	  cur_set[positive].set_range( prev_c, c );    // ending characters of empty ranges do not get collected

	trivial_range = ( prev_c == c );
	if( trivial_range && isPrevGreek && isGreek ) {
	  assert( set.chars[ j - pos_inc ] == range_char );
	  assert( SymbolTable::isGreekVariable( set.chars[ j - pos_inc - last_pos_inc ] ) ); 
	  trivial_range = trivial_range && last_true_len == true_len;
	  trivial_range = trivial_range && !memcmp( set.chars + j - pos_inc, set.chars + j - pos_inc - last_pos_inc, sizeof(echar) * true_len );
	}
	if( !trivial_range && ( isPrevGreek || isGreek ) ) {
	  if( isPrevGreek ) flags |= open_lowerbound;
	  if( isGreek ) flags |= open_upperbound;
	  if( process_open_ranges && positive ) {   // process_open_ranges: will add any potential character value but never remove an unsure character value
	    if( !isPrevGreek ) cur_set[positive].set_range( prev_c, 0xFF );
	    if( !isGreek ) cur_set[positive].set_range( 0, c );
	  } else if( !process_open_ranges ) {       // by default just collect the fixed starting or ending character of an open range an leave the rest to the user determining the charset of an automation
	    if( !isPrevGreek && c <= 0xFF ) cur_set[positive].set_elm( prev_c );
	    if( !isGreek && c <= 0xFF ) cur_set[positive].set_elm( c );
	} }

      }
      prev_c = c; last_true_len = true_len; last_pos_inc = pos_inc; hadARange = false;
    }

    if( positive != set_is_complemented && j < set.length ) { 
      positive = !positive; assert( set.chars[j] == setminus_char );
      j++; goto collect_the_right_set;
    }

  if( !set_is_complemented ) cur_set[1].setdiff_with( cur_set[0] );   // those characters that are also in the deduction set can in deed not appear in the input alphabet (positive set)
  if( positive_set ) positive_set->union_with( cur_set[1] );
  if( used_set ) used_set->union_with( cur_set[0] );
  if( collect_variables ) { *collect_variables = vars; *round_value = round; }
  if( collect_flags ) *collect_flags = flags;
}

//
// alwaysDisjoint + aux. procs.
//

void removeDeductSymbols( SymbolTable *home, estr_const var, int *value, void *data ) {
  SymbolTable *other = (SymbolTable*) data;
  long long result = other->lookUp( var.chars );
  int val = (int) result; result >>= 32;
  if( !( result & 1 ) && val < 0 ) home->removeEntry( value );
}

void dropDeductSymbols( SymbolTable *home, estr_const var, int *value, void *data ) {
  if( *value <= 0 ) home->removeEntry( value );
}

bool ExtCharSet::alwaysDisjoint( estr_const set_a, estr_const set_b, StaticCharSet *base_set, int flags, bool *may_still_always_be_disjoint ) {
  bool neg_a = flags & 1; bool neg_b = ( flags >> 1 ) & 1;
  if( set_a.length == 1 ) {
    echar a = *set_a.chars;
    if( set_b.length == 1 ) {    // special case of α, ¬α is caught here and handled correctly
      echar b = *set_b.chars;
      if( a == b ) return ( neg_a != neg_b );
      if( SymbolTable::isGreekVariable(b) || SymbolTable::isGreekVariable(a) ) return false;
      return true;
    }
    if( !SymbolTable::isGreekVariable(a) && !neg_a ) {   // otherwise: would have to check whether set_b is empty (such as abc\abc) - done with set operations
      bool no_vars = true; for( int j=0; j < set_b.length; j++ ) if( SymbolTable::isGreekVariable( set_b.chars[j] ) ) { no_vars = false; break; }
      if( no_vars ) return neg_b ^ !elm_in( a, set_b );    // if set_a is complemented then it may have many elements; determine the result with set operations later on
  } }
  StaticCharSet chars_a, chars_b, sub_chars_a, sub_chars_b; SymbolTable *vars_a, *vars_b; int round; 
  int collect_flags = keep_all_and_only_deduction_vars | manifest_open_ranges_as_char_values; 
  chars_a.clear(); chars_b.clear(); sub_chars_a.clear(); sub_chars_b.clear(); vars_a = SymbolTable::reserveEmpty(1); vars_b = SymbolTable::reserveEmpty(1);
  collectSymbolsAndVars( set_a, neg_a, &round, &chars_a, &sub_chars_a, &vars_a, &collect_flags );
  collectSymbolsAndVars( set_b, neg_b, &round, &chars_b, &sub_chars_b, &vars_b, &collect_flags );
  if( !chars_a.isEmpty() || !chars_b.isEmpty() || !sub_chars_a.isEmpty() || !sub_chars_b.isEmpty() || ( neg_a && neg_b && ( !base_set || base_set->hasAtLeastCountElements(2) ) ) ) {
    // ( neg_a && neg_b: two sets of complemented variables !αβ !αγ may always produce an intersection result as long as there are at least two elements in base_set )
    if( neg_b ) chars_b.add_complement( sub_chars_b );
    if( neg_a ) chars_a.add_complement( sub_chars_a );  
  }; // otherwise only variables should matter
  if( base_set ) { chars_a.intersect_with(*base_set); chars_b.intersect_with(*base_set); if( base_set->isEmpty() ) return true; }
  if( may_still_always_be_disjoint ) *may_still_always_be_disjoint = !!( collect_flags && ( open_lowerbound | open_upperbound ) );
  if( !chars_a.isDisjointWith(chars_b) ) return false;            // common characters: not disjoint
  if( !neg_b ) vars_a->forallEntry( removeDeductSymbols, vars_b );
  if( !neg_a ) vars_b->forallEntry( removeDeductSymbols, vars_a );
  if( !neg_a ) vars_a->forallEntry( dropDeductSymbols );
  if( !neg_b ) vars_b->forallEntry( dropDeductSymbols );
  // one variable that can match at least one character in the other set: not guaranteed to be disjoint
  if( !vars_a->isEmpty() && !chars_b.isEmpty() && ( neg_a || !chars_b.isSubSet( sub_chars_a ) ) ) return false;
  if( !chars_a.isEmpty() && !vars_b->isEmpty() && ( neg_b || !chars_a.isSubSet( sub_chars_b ) ) ) return false;
  if( !vars_a->isEmpty() && !vars_b->isEmpty() ) return false;      // two variables that could be set the way that they are equal: not always disjoint (assuming a nonempty input alphabet)
  return true;
}


//
// printing Character Sets
//

void print_numeric( aux::IOStreamRef out, unsigned char val ) {
  out << val;
}

void print_as_achar( aux::IOStreamRef out, unsigned char val ) {
  out << aux::AChar(val);
  //putchar(val);
}

aux::echar ColonChars[3] =  { ',', ' ', 0 };

bool StaticCharSet::print( aux::IOStreamRef out, ElmPrnFunc prn_elm, aux::estr_const elm_sep ) const {
  register unsigned char first_in_range, current = 0;
  register bool this_is_set, last_was_set = false;
  aux::echar range_sep = range_char; bool the_first = true;
  for(int i=0; i < words; i++ ) {
    //register u_iword mask = 1;
    register iword this_word = word[i];
    for(register int j=0; j < bits_per_word; j++, this_word>>=1, current++ ) {
      //if( word[i] & mask ) prn_elm(out,current);
      this_is_set = this_word & 1; // word[i] & mask;
      //assert( this_is_set == elm_in(current) );
      if( !last_was_set && this_is_set ) first_in_range = current;
      else if( last_was_set && !this_is_set ) {
	if( !the_first ) out << elm_sep;
	prn_elm( out, first_in_range );
	if( first_in_range != current - 1 ) {
          out << aux::estr_const(&range_sep,1);
	  prn_elm( out, current - 1 );
	}
	the_first = false;
      }
      last_was_set = this_is_set;
    }
  }
  if( last_was_set ) {
    if( !the_first ) out << elm_sep;
    prn_elm( out, first_in_range );
    if( first_in_range != (unsigned char)(current - 1) ) {
      out << aux::estr_const(&range_sep,1);
      prn_elm( out, current - 1 );
    }
  }
  return out;
}

int StaticCharSet::count() const {
  int numElts = 0;
  for(int i=0; i < words; i++ ) {
    register iword this_word = word[i];
    for(register int j=0; j < bits_per_word; j++, this_word>>=1 ) {
      numElts += this_word & 1;
    }
  }
  return numElts;
}

bool StaticCharSet::hasAtLeastCountElements( int min_count ) const {
  int numElts = 0; if( min_count <= 0 ) return true;
  for(int i=0; i < words; i++ ) {
    register iword this_word = word[i];
    for(register int j=0; j < bits_per_word; j++, this_word>>=1 ) {
      numElts += this_word & 1;
      if( numElts >= min_count ) return true;
    }
  }
  return false;
}


//
// Simple Character Sets
//

//void StaticCharSet::set_elm( unsigned char elm ) { register int i = elm >> word_idx_shift; word[i] |= (u_iword)1 << ( elm & sub_word_mask ); };
//void StaticCharSet::union_with( StaticCharSet& other ) { for(register int i=0; i<words; i++) word[i] |= other.word[i]; };

void StaticCharSet::set_range( unsigned char first, unsigned char last ) {
  if( first > last ) return; 
  register int fi = first >> word_idx_shift; 
  register iword fm = ~( ( (u_iword)1 << ( first & sub_word_mask ) ) - 1 );
  register int li = last >> word_idx_shift; 
  register iword lm = ( ( ( (u_iword)1 << ( last & sub_word_mask ) ) - 1 ) << 1  ) + 1;
  if( li == fi )
    word[fi] |= fm & lm;
  else {
    word[fi] |= fm;
    register int j = fi+1;
    if( j != li ) {
      register iword full_mask = ~0;
      do { word[j] = full_mask; j++; } while( j != li );
    }
    word[li] |= lm;
  }
}

void StaticCharSet::unset_range( unsigned char first, unsigned char last ) {
  if( first > last ) return; 
  register int fi = first >> word_idx_shift; 
  register iword fm = ~( ( (u_iword)1 << ( first & sub_word_mask ) ) - 1 );
  register int li = last >> word_idx_shift; 
  register iword lm = ( ( ( (u_iword)1 << ( last & sub_word_mask ) ) - 1 ) << 1  ) + 1;
  if( li == fi )
    word[fi] &= ~( fm & lm );
  else {
    word[fi] &= ~fm;
    for( register int j = fi+1; j!=li; j++ ) word[j] = 0;
    word[li] &= ~lm;
  }
}

void StaticCharSet::invert_range( unsigned char first, unsigned char last ) {
  if( first > last ) return; 
  register int fi = first >> word_idx_shift; 
  register iword fm = ~( ( (u_iword)1 << ( first & sub_word_mask ) ) - 1 );
  register int li = last >> word_idx_shift; 
  register iword lm = ( ( ( (u_iword)1 << ( last & sub_word_mask ) ) - 1 ) << 1  ) + 1;
  if( li == fi )
    word[fi] ^= fm & lm;
  else {
    word[fi] ^= fm;
    for( register int j = fi+1; j!=li; j++ ) word[j] = ~word[j];
    word[li] ^= lm;
  }
}


