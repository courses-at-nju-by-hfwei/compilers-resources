#ifndef ARITHEXPR_H
#define ARITHEXPR_H
#include "auxtypes.h"
#include "symtab.h"
#include <assert.h>


//#ifndef __GNUC__
  //#warning arithexpr.cpp: the current implementation requires ranges for case labels (case 'a' ... 'z':); this may not work with a non-GNU-C++-compiler.
  //#pragma message ("arithexpr.cpp: the current implementation requires ranges for case labels (case 'a' ... 'z':); this may not work with a non-GNU-C++-compiler.")
//#endif

class ArithmeticExpression {
public:

  enum Flags { // parsing Errors
               UnexpectedCharacter = 1, UnknownOperator = 2, MissingOperator = 4, MissingOperand = 8, MissingOrLateClosingBracket = 16, RequiredDigit = 32, RangeErr = 64, InvalidBase = 128, 
	       TypeMismatch = 256, VariableNameTransgressesLength = 512, isBoolean = 1024,
	       // evaluation Flags & ErrorFlags
               VariableNotFound = 2048, Underflow = 4096, Overflow = 8192, DivisionByZero = 16384, NotAScalar = 32768, ZeroedFraction = 65536 /* i.e. negative exponent */ };

  static const int UncontinuableParsingErrors = ( UnexpectedCharacter | MissingOrLateClosingBracket | RequiredDigit | InvalidBase );

  static const char *FlagBit2Text[];
  static const int FlagBit2TextMaxShift;

protected:

  struct EvalParams { int flags; SymbolTable *localSymTab, *globalSymTab; };

  class SubExpr { public: virtual int eval( EvalParams &params ) = 0; virtual void prn(IOStream& out) { out << "??"; }; virtual ~SubExpr() {}; };

  class NumberConst : public SubExpr { 
    const int value;
  public:
    NumberConst(int val) : value(val) {};
    static SubExpr* parse( bool hadMinus, estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params ) { return value; }
    virtual void prn(IOStream& out) { out << value; };
    virtual ~NumberConst() {};
  };

  class VariableExpr : public SubExpr { 
    const echar *varName;  VariableExpr(const echar *ident) : varName(ident) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { int len = SymbolTable::varLength(varName); out << estr_const(varName,len); };
    virtual ~VariableExpr() {};
  };

  class BracketExpr { 
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
  };

  class NegateExpr : public SubExpr { 
    SubExpr *intExpr; 
  public:
    NegateExpr( SubExpr *integerExpression ) : intExpr(integerExpression) {};
    virtual int eval( EvalParams &params ) { return - ( intExpr->eval(params) ); }
    virtual void prn(IOStream& out) { out << "-("; intExpr->prn(out); out << ")"; };
    virtual ~NegateExpr() { delete intExpr; };
  };

  class FactorialExpr : public SubExpr {
    SubExpr *left, *right; enum Operator { Multiplication = 0, Division = 1, Modulo = 2 } operation;
    FactorialExpr( enum Operator op, SubExpr *left, SubExpr *right ) : left(left), right(right), operation(op) {};
  public:
    static SubExpr* parseWithHighPrecedence( bool hadMinus, estr_const str, int& pos, int& errFlags );
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; left->prn(out); out << AChar("*/%"[operation]); right->prn(out); out<<")"; };
    virtual ~FactorialExpr() { delete left; delete right; };
  };

  class ExponentialExpr : public SubExpr {
    SubExpr *basis, *exponent; ExponentialExpr( SubExpr *base, SubExpr *exp ) : basis(base), exponent(exp) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; basis->prn(out); out << AChar('^'); exponent->prn(out); out<<")"; };
    virtual ~ExponentialExpr() { delete basis; delete exponent; };
  };

  class AdditionExpr : public SubExpr {
    SubExpr *left, *right; enum Operator { Plus = 0, Minus = 1 } operation; 
    AdditionExpr( Operator op, SubExpr *left, SubExpr *right ) : left(left), right(right), operation(op) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; left->prn(out); out << AChar("+-"[operation]); right->prn(out); out << ")"; };
    virtual ~AdditionExpr() { delete left; delete right; };
  };

  class CompareExpr : public SubExpr {
  public:
    enum Operator { Less = 0, LowerEq = 1, Equal = 2, NotEqual = 3, GreaterEq = 4, More = 5 }; static const echar Operator2EChar[];
    SubExpr *left, *right; enum Operator operation; 
  private:
    CompareExpr( enum Operator op, SubExpr *left, SubExpr *right ) : left(left), right(right), operation(op) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; left->prn(out); out << EChar(Operator2EChar[operation]); right->prn(out); out << ")"; };
    virtual ~CompareExpr() { if(left) delete left; delete right; };
  };

  class NotExpr : public SubExpr {
    SubExpr *base; NotExpr( SubExpr *expr ) : base(expr) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out << "!("; base->prn(out); out << ")"; };
    virtual ~NotExpr() { delete base; };
  };

  class LogicalExpr : public SubExpr {
  public:
    enum Operator { And = 0, Or = 1, Xor = 2 };  // all values non-zero
    LogicalExpr( enum Operator op, SubExpr *left, SubExpr *right ) : left(left), right(right), operation(op) {};
  private:
    SubExpr *left, *right; enum Operator operation; 
  public:
    static SubExpr* parseXor( estr_const str, int& pos, int& errFlags );
    static SubExpr* parseAnd( estr_const str, int& pos, int& errFlags );
    static SubExpr* parseOr( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; left->prn(out); out << astr_const((achar*)"&&||^^"+(operation<<1),2); right->prn(out); out << ")"; };
    virtual ~LogicalExpr();
  };

  class ChoiceExpr : public SubExpr {
    SubExpr *condition, *whenTrue, *whenFalse;
    ChoiceExpr( SubExpr *cond, SubExpr *expr4True, SubExpr *expr4False ) : condition(cond), whenTrue(expr4True), whenFalse(expr4False) {};
  public:
    static SubExpr* parse( estr_const str, int& pos, int& errFlags );
    virtual int eval( EvalParams &params );
    virtual void prn(IOStream& out) { out<<"("; condition->prn(out); out << "?"; whenTrue->prn(out); out << ":"; whenFalse->prn(out); out << ")"; };
    virtual ~ChoiceExpr() { delete condition; delete whenTrue; delete whenFalse; } 
  };

  SubExpr *baseExpr; estr_const content;

public:

  ArithmeticExpression() { baseExpr = NULL; content = invalid_estr; };
  ArithmeticExpression( estr_const inputString, int *position = NULL, int *errFlags = NULL );

  void parse( estr_const inputString, int *position = NULL, int *errFlags = NULL );  // inout position, out errFlags

  int eval( int *flags = NULL, SymbolTable *localSymTab = NULL, SymbolTable *globalSymTab = NULL ) const { 
#ifndef _MSC_VER
    struct EvalParams params = { .flags = 0, .localSymTab = localSymTab, .globalSymTab = globalSymTab }; 
#else
    struct EvalParams params = { 0, localSymTab, globalSymTab }; 
#endif
    int result = baseExpr->eval(params); 
    if(flags) *flags = params.flags;
    return result;
  };
  
  bool isConst() const { return dynamic_cast<NumberConst*>(baseExpr) != NULL; }
  estr_const toText() const { return content; }
  bool print( IOStream &out ) const { out << content; return out; };
  bool printParseTree( IOStream &out ) const { baseExpr->prn(out); return out; };
  static bool printFlags( IOStream &out, int flags );

  // problem: copy constructors will copy the pointer 1:1 and then it gets freed multiple times:
  //~ArithmeticExpression() { cout << IOChangeVal(IOAttr::NumberBaseNextOne,16) << (u_iword)baseExpr << endl; delete baseExpr; } 
  static void freeMem( ArithmeticExpression &ae ) { delete ae.baseExpr; }
  static void free( ArithmeticExpression &ae ) { delete ae.baseExpr; ae.baseExpr = NULL; ae.content = empty_estr; }
  ~ArithmeticExpression() {  } 

};

#endif
