#ifndef FINITE_AUTOMATA_H
#define FINITE_AUTOMATA_H


#include "automatdef.h"

#ifdef QT_CORE_LIB
  #include "GraphicalNode.h"
#else
  #define EllipticalNode Node
#endif

extern const echar echars_slash[2]; 
extern const estr_const estr_slash;  // used in FA_Edge::printHead and PDA_Edge::print for out.xstr_escapeChars 

// ------------------  Finite Automata  ------------------  

class FA;

class FA_Node : public EllipticalNode {
protected:
public:
  estrbuf label;
  bool acceptorNode;
  virtual int setContent( Automaton *a, estrbuf *newlabel ) { label.moveFrom(newlabel); return -1; };
public:
  FA_Node() : EllipticalNode() { label = empty_estr; acceptorNode = false; }
  virtual estr_const getContent() const { return label; };
#ifdef QT_CORE_LIB
  virtual void callbackPrint( TextCallBack cb, void *data ) const { cbPrintSubscripted( cb, 0, false, label, data ); }
#endif
  virtual bool setFinalNode(bool is_final_acceptor);
  virtual bool isFinalNode() const;
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
};

class FA_Runtime;
extern bool FA_print_cond_as_set; 

class FAEdgeProxy : public ElementProxy {
public:
  short int cond_flags, cond_start, cond_len;
public:
  FAEdgeProxy( Element *e, short runtime_pos, short cflags, short cstart, short clen ) : ElementProxy(e,runtime_pos), cond_flags(cflags), cond_start(cstart), cond_len(clen) {};
  virtual int execLength() const;
};

class FA_Edge : public Edge {
public:
  estr_const entryCondition; int baseFlags;
   // hasASet, isEpsilonTransition, zeroReadTransition (for PDAs) only set in baseFlags not in edge_proxy.cond_flags
  enum EdgeFlags { isEpsilonTransition = 1, negatedCond = 2, simpleCond = 4, hasASet = 8, zeroReadTransition = 16 };  
  estrbuf content;
public:
  FA_Edge( Node *a, Node *b ) : Edge(a,b) { entryCondition = empty_estr; baseFlags = 0; };
  std::vector<FAEdgeProxy> edge_proxy;
  virtual int execLength() const;
protected:
  virtual int setContent( Automaton *a, estrbuf *acceptation );
  static const echar CharSetTermEChars[];       // used for estr_const below
  static const estr_const CharSetTermChars;     // used in scanCharSets
  static int scanForNeq( estr_const s, int pos );  // returns number of characters read on from pos
  int scanCharSets( estr_const s, int startPos, int flags4firstToken, int charsetCheckFlags, int *errpos );    // returns endPos
  void printHead( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos, int varLength = 0, bool escapeSlash = false ) const;
  void printTail( IOStreamRef out, int debuglevel ) const;
public:
  virtual estr_const getContent() const { return content; };
  inline int conditionLength() const { return edge_proxy.size() + 1; };
  estr_const getCond( int pos, int *flags ) const; 
  enum CondEvalResult { cerFalse = 0, cerTrue = 1, cerVarNotDefined = 2 };  // no more values allowed: i.e. ( result & 1 ) or ( result >> 1 ) is used by the implementation
  bool evalCurCond( FA_Runtime *r, int pos, achar c );
  bool evalEntryCond( FA_Runtime *r, achar firstChar );
  virtual void print( IOStreamRef out, int debuglevel = 0, bool isLookAhead = false, int relpos = 0 ) const;
#ifdef QT_CORE_LIB
protected:
  void cbPrintCond( TextCallBack cb, int i, int num, bool alreadyNegated, bool print_as_set, void *data ) const;
public:
  virtual void callbackPrint( TextCallBack cb, void *data ) const;
#endif
  virtual bool isEpsilon() const { return baseFlags & isEpsilonTransition; };
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
};

class FA;

class FA_Runtime : public Runtime {
protected:
  FA_Runtime( Automaton *a, astr_const charParam, inta_const valParam, int tracelen ) : Runtime(a,charParam,valParam,tracelen) { };
  virtual bool rememberOnceNoState() { return true; }    // if true rememberOutcome will only be called once with the NULL element and NULL data
  virtual void finalizeStep();
public:
  virtual Status getResultStatus( Element *e, Data *d );
public:
  astr_const tape; int pos;
  astr_shared *tape_alloc;
  bool deterministicAutomaton;
  FA_Runtime( FA *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos );
  virtual Status status_4_no_consecutive_state() { return dismissed; }
public:
  virtual int numTapes( ParentTapeIndex i = ParentTapeIndex() );
  virtual int getTape( astr_const *content, int *position, SymbolTable **symTab, TapeIndex idx = TapeIndex() );
  virtual void getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i = TapeIndex() );
  virtual void getOutcome( int idx, astr_shared **tape, int *pos, enum Status *status, int *step_num );
protected:
  virtual void freeMemSub( Automaton *a );
};

class FA : public Automaton {
public:

  FA() : Automaton() {};

  virtual bool posTapeCursorAtBegin() { return true; }
  virtual const char* typeStr() { return "FA"; }

  Node* createNode() {
    FA_Node *n = new FA_Node();
    allNodes.push_back(n);
    return n;
  }

  Edge* createEdge( Node *a, Node *b ) {
    FA_Edge *n = new FA_Edge( a, b );
    allEdges.push_back(n);
    return n;
  }

  Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) { 
    refreshEpsilonClosure();
    return new FA_Runtime(this,input,pos,charParam,valParam,tracelen,prepareStatePos); 
  }

};

// ------------------  Push Down Automata  ------------------  

class PDA_Data : public Data {
public:
  int usage_count; const astr_const stack;
  enum UsageState { inUse, wasACopy, hadStackData };
  PDA_Data( const achar *stack_content, int stack_length, bool isACopy ) : stack(stack_content,stack_length) { usage_count = isACopy?-1:+1; }
  bool print( IOStreamRef out );
  inline void IncUsage() { if(usage_count>0) usage_count++; else usage_count--;  }
  inline enum UsageState DecUsage() { bool isACopy; if((isACopy=usage_count<0)) usage_count++; else usage_count--; return usage_count ? inUse : isACopy ? wasACopy : hadStackData; }
};

#define memtrace false

class PDA_Runtime : public FA_Runtime {
public:
  PDA_Runtime( FA *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos );
  bool popOK( Data *base, astr_const toPop ) const;
  Data* pushPopStack( Data *base, astr_const toPush, int pop_len, bool isTemporary );    // isTemporary == false  =>  PDA_Data can be created with isACopy = true to avoid initial copying
  void pushPopStack_nomem();
  virtual inline Data* duplicateData( Data *d ) const { if(!d) return NULL; ((PDA_Data*)d)->IncUsage(); if(memtrace) cout << "duplicate_" << ((PDA_Data*)d)->usage_count << ":" << (u_iword)d << aux::endl; return d; }
  virtual void freeData( Data *data ) const { PDA_Data::UsageState u; 
    PDA_Data *d = (PDA_Data*)data; if(!d) return; assert(d->usage_count);
    //if(memtrace) { printData(cout,d,false); cout << ": "; } 
    if( ( u = d->DecUsage()) != PDA_Data::inUse ) { 
      if(memtrace) cout << "free:" << (u_iword)d << aux::endl;
      dealloc( d, sizeof(PDA_Data) +  ( u == PDA_Data::wasACopy ? 0 : d->stack.length ) ); 
    } else if(memtrace) cout << "decUsage_" << ((PDA_Data*)d)->usage_count << ":"  << (u_iword)d << aux::endl;
  }
  virtual void printData( IOStreamRef out, Data *d, bool shallPrintVars ) const; // now a pretty print of repeated chars; formerly just: { if(d) out << ((PDA_Data*)d)->stack; out << "$"; };
  virtual int compareData( Data *a, Data *b ) const { 
    if(a==b) return 0; if(!a) return -1; if(!b) return +1; 
    return ((PDA_Data*)a)->stack.binary_compare(((PDA_Data*)b)->stack); 
  }
  virtual int numTapes( ParentTapeIndex i = ParentTapeIndex() );
  virtual int getTape( astr_const *content, int *position, SymbolTable **symTab, TapeIndex idx = TapeIndex() );
  virtual void getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i = TapeIndex() );
};

#define ZRM_simple 1
#define ZRM_goback_alloca 2 
#define ZRM_goback_double_recursive 3

#ifndef ZERO_READ_MODE
  //#define ZERO_READ_MODE ZRM_simple // possible values are: simple, goback_alloca, goback_double_recursive 
  //#define ZERO_READ_MODE ZRM_goback_alloca // possible values are: simple, goback_alloca, goback_double_recursive 
  #define ZERO_READ_MODE ZRM_goback_double_recursive // possible values are: simple, goback_alloca, goback_double_recursive 
#endif

#if ZERO_READ_MODE != ZRM_simple && ZERO_READ_MODE != ZRM_goback_alloca && ZERO_READ_MODE != ZRM_goback_double_recursive && ZERO_READ_MODE != 0
  #error ZERO_READ_MODE must be one of simple, goback_alloca, goback_double_recursive (value constants != 0)
#endif

class PDA_Edge : public FA_Edge {
public:
  PDA_Edge( Node *a, Node *b ) : FA_Edge(a,b) { toPop = toPush = empty_estr; toPopAsConst = toPushAsConst = empty_astr; varLength=0; };
  estrbuf toPop, toPush; astrbuf toPopAsConst, toPushAsConst; int varLength;
protected:
  virtual int setContent( Automaton *a, estrbuf *acceptation );
public:
  virtual void print( IOStreamRef out, int debuglevel = 0, bool isLookAhead = false, int relpos = 0 ) const;
#ifdef QT_CORE_LIB
protected:
  void cbPrintStackOp( TextCallBack cb, estr_const stackstr, void *data ) const;
public:
  virtual void callbackPrint( TextCallBack cb, void *data ) const;
#endif

  bool evalEntryCond( PDA_Runtime *r, achar firstChar, Data *d, SymbolTable **tmpTransitionSymbols );
  PDA_Data* execPushPop( PDA_Runtime *r, PDA_Data *d, SymbolTable *tmpTransitionSymbols ) const;
  // lookAhead as in FA_Edge
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos );
};

class PDA_Node : public FA_Node {
public:
  int max_incoming_zeroReadCycles; int zeroReadSucc; 
  struct ZeroReadChain { PDA_Node *node; struct ZeroReadChain *prev; }; 
  static void prepareZeroReadTransitions( struct ZeroReadChain newest );
protected:
  struct SimpleLookAheadChain { 
    PDA_Node *node; PDA_Data *data; struct SimpleLookAheadChain *previous; 
    SimpleLookAheadChain(PDA_Node *n, PDA_Data *d, struct SimpleLookAheadChain *p ) : node(n), data(d), previous(p) {}; 
  };
  struct LookAheadChain : public SimpleLookAheadChain { 
    iword newDataCount; PDA_Data **newData; 
    LookAheadChain(PDA_Node *n, PDA_Data *d, struct LookAheadChain *p, iword c, PDA_Data **nd ) : SimpleLookAheadChain(n,d,p), newDataCount(c), newData(nd) {}; 
  };
  static void simpleComputeZeroReadLookAhead( Runtime *r, struct SimpleLookAheadChain this_chain_node );
#if ZERO_READ_MODE != ZRM_simple
  static void computeZeroReadLookAhead( Runtime *r, struct LookAheadChain this_chain_node, bool firstCall4Cycle );
#if ZERO_READ_MODE == ZRM_goback_double_recursive
  static void processRemainingData4ZeroReadLookAhead( Runtime *r, PDA_Node *this_node, int dataCount, PDA_Data **dataItem, struct LookAheadChain *this_chain_node, PDA_Data **childData );
#endif
#endif
public:
  virtual void zeroReadLookAhead( Runtime *r, Data *d );
  virtual void lookAhead( Runtime *r, Data *d, int relpos );
  // next yields an error as in FA_Node
};

class PDA : public FA {
public:

  PDA() : FA() {};

  virtual const char* typeStr() { return "PDA"; }
  virtual bool edgeEscapeSlash() { return true; }

  Node* createNode() {
    FA_Node *n = new PDA_Node();
    allNodes.push_back(n);
    return n;
  }

  Edge* createEdge( Node *a, Node *b ) {
    PDA_Edge *n = new PDA_Edge( a, b );
    allEdges.push_back(n);
    return n;
  }

  void prepareZeroReadTransitions();

  Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) { 
    refreshEpsilonClosure();
    prepareZeroReadTransitions();
    return new PDA_Runtime(this,input,pos,charParam,valParam,tracelen,prepareStatePos); 
  }

};

#endif
