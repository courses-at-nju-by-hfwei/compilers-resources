#ifndef AUXTYPES_H
#define AUXTYPES_H
#include <stdio.h>
#include <string.h>
#include <stdlib.h>    // aux_assert: abort()
#include <functional>
#ifndef SINGLE_IO_THREAD
  #include <pthread.h>
#endif
#ifdef QT_CORE_LIB
  #include <QtCore/QString>
  #include <QtCore/QStringList>
#endif
#include "basedefines.h"

//
// compile time constants for aux.h
//
//  #define UNLOCKED_STDIO ... faster IO: use ftput[sc]_unlocked instead of fputs/fputc also if _GNU_SOURCE is not defined
//  #define DEBUG_IO ......... execution will not continue on programming errors but abort() with a core dump instead (in Zukunft: evtl. Zahl als debug-verbosity)
//  #define SINGLE_IO_THREAD
//  #define NO_DEFAULT_IO_LOCK ... when compiled for multiple IO threads do not lock for singleton IO calls by default
//

#ifdef SINGLE_IO_THREAD
  #define NO_DEFAULT_IO_LOCK  // dann sowieso (implizit) gegeben
#endif

#if defined(_MSC_VER) && WORDSIZE == 64
  #pragma warning (disable: 4267)   // warning: convert size_t into smaller type
#endif

// needs to be redefined by direct IO function calls
#define aux_sysmsg(message) fputs(message,stderr);
#define aux_error(message) aux_sysmsg(message)
#define aux_warning(message) aux_sysmsg(message)
#define aux_sysmsg_int(value) fprintf(stderr,"%lli",(long long)value);
#define aux_sysmsg_adr(value) fprintf(stderr,"%llx",(unsigned long long)value);

#define aux_praefixed_assert(condition,praefix,message) if(unlikely(!(condition))) { aux_error(praefix "assert failed at " __FILE__ ":"); aux_sysmsg_int(__LINE__); aux_sysmsg(": " message #condition "\n\n"); abort(); }
#define aux_assert_(condition,message) aux_praefixed_assert(condition,"aux_",message " ~ ")
#define aux_assert(condition) aux_praefixed_assert(condition,"aux_","")

typedef small_int status_int;     // status code return: 0 on success, -1/error code on error

namespace aux {

// aux::IOStream:
//  * can handle multiple string formats at the same time ( utf-8 char*, utf16 echar*, latin1 unsigned char*)
//  * automatically converts into the right encoding on output (currently supported: utf-8, latin1, "asciiext" (CoAN specific encoding))
//  * better error handling (can indicate the kind of the error; std::iostreams can not)
//  * new functionality: 
//       adjustable field separation chars, lineno/col - counting, direct C-string input, numbers of any base
//       visual printing of control characters and of greek characters for latin1


template<class T> class alwaysTrue : public std::unary_function<const T&,bool> { public: bool operator()(const T& param) const { return true; } };

// char* is always assumed to be an utf-8 encoded string
// [aeu]char-s always directly represent the numeric character code they contain
//  [aeu]char* thus needs to be of a well distinguishable type towards char* (i.e. change of signedness) 
#if CHARTYPE == IS_unsigned 
 typedef signed char achar;    // latin1 or ascii 8-bit char
 typedef int16 echar;   // utf16 extended 16-bit char (without multiword sequences)
 typedef int32 wchar;     // utf32 extended 16-bit character
#else
 typedef unsigned char achar;    // latin1 or ascii 8-bit char
 typedef uint16 echar;   // utf16 extended 16-bit char (without multiword sequences)
 typedef uint32 wchar;     // utf32 extended 32-bit character
#endif

#if WORDSIZE != 16
 typedef wchar vchar;
#else
 typedef echar vchar;
#endif

typedef idx_diff strsize;	      // normal 32bit int except when addressing for 16bit systems where it is a 16 bit word
typedef uidx       unsigned_strsize;          // same but unsigned
typedef dbl_idx_diff dbl_strsize;		// twice as big: 32bit/64bit
typedef dbl_uidx       dbl_unsigned_strsize;     // twice as big: 32bit/64bit


#define EAUX_NOMEM 1                      // xstr_mutable::alloc or xstrbuf::realloc returned NULL
#define EAUX_BUF_LEN_USER_INVALID 2        // xstrbuf: buf length for user alloced buf negative (overflow or negative input string length)
#define EAUX_BUF_LEN_HEAP_INVALID 4        // same for std. heap alloced buf
#define EAUX_SHARED_STR_SIZE_INVALID 8     // xstr_shared: calculated object length exceeds size_t limit or negative input length
#define EAUX_DECODE_ERROR 16
extern small_int errnum;    // sh. similar to errno but for aux; yet an or-ed bitmask just used for indicating a few global error conditions; usually the return value of a function shall give more information
extern small_int verbose_errnum_mask;
void aux_set_err_flag(small_int new_errnum);


template<class xchar,class xchar_mutable> class xstr_abstract {
public:
  typedef xchar_mutable char_type;
  typedef xstr_abstract<const xchar_mutable,xchar_mutable> str_const;
  xstr_abstract() {};
protected:
  xstr_abstract sub_abstract( strsize pos, strsize len = MaxSigned(strsize) ) const;
public:
  xstr_abstract( xchar *c, strsize l ) : chars(c), length(l) {};
  //xstr_const( xstr_const &s ) : chars(s.chars), length(s.length) {};
  //xstr_const( xstr s ) : chars(s.chars), length(s.length) {};
  __pure inline static bool isInvalid( xstr_abstract *s ) { return !s || !s->chars; };
  __pure inline static bool isValid( xstr_abstract *s ) { return s && s->chars != NULL; };
  __pure inline static bool isEmpty( xstr_abstract *s ) { return !s || !s->length; };
  __pure inline bool isEmpty() const { return !length; };
  __pure inline bool isInvalid() const { return !chars; };
  __pure inline bool isValid() const { return chars != NULL; };
  __pure bool identical ( str_const s ) const;    // both strings allocate the same buffer with the same content
  __pure small_int binary_compare ( str_const s ) const;   // compares the content
  __pure small_int binary_compare ( const achar *s ) const;   // compares the content
  __pure inline bool operator== ( str_const s ) const { return !binary_compare(s); };
  __pure inline bool operator!= ( str_const s ) const { return !!binary_compare(s); };
  __pure inline bool operator < ( str_const s ) const { return binary_compare(s)<0; };
  __pure inline bool operator<= ( str_const s ) const { return binary_compare(s)<=0; };
  __pure inline bool operator > ( str_const s ) const { return binary_compare(s)>0; };
  __pure inline bool operator>= ( str_const s ) const { return binary_compare(s)>=0; };
  __pure inline bool operator== ( const achar *s ) const { return !binary_compare(s); };
  __pure inline bool operator!= ( const achar *s ) const { return !!binary_compare(s); };
  __pure inline bool operator < ( const achar *s ) const { return binary_compare(s)<0; };
  __pure inline bool operator<= ( const achar *s ) const { return binary_compare(s)<=0; };
  __pure inline bool operator > ( const achar *s ) const { return binary_compare(s)>0; };
  __pure inline bool operator>= ( const achar *s ) const { return binary_compare(s)>=0; };
  __pure strsize find_first_of( wchar c, strsize start = 0 ) const;
  __pure strsize find_first_of( str_const setstr, strsize start = 0 ) const;
  __pure strsize find_first_of( const achar *setstr, strsize start = 0 ) const;
  __pure strsize find_first_not_of( wchar c, strsize start = 0 ) const;
  __pure strsize find_first_not_of( str_const setstr, strsize start = 0 ) const;
  __pure strsize find_first_not_of( const achar *setstr, strsize start = 0 ) const;
  __pure strsize find_last_of( wchar c, strsize start = MaxSigned(strsize) ) const;
  __pure strsize find_last_of( str_const setstr, strsize start = MaxSigned(strsize) ) const;
  __pure strsize find_last_of( const achar *setstr, strsize start = MaxSigned(strsize) ) const;
  __pure strsize find_last_not_of( wchar c, strsize start = MaxSigned(strsize) ) const;
  __pure strsize find_last_not_of( str_const setstr, strsize start = MaxSigned(strsize) ) const;
  __pure strsize find_last_not_of( const achar *setstr, strsize start = MaxSigned(strsize) ) const;

  // sizeof(needle_xchar) > sizeof(xchar)
  template<class ychar> __pure strsize find_compound( xstr_abstract<const ychar,ychar> needle, strsize start = 0 ) const;
  inline __pure strsize find( xstr_abstract<const achar,achar> needle, strsize start = 0 ) const { return find_compound(needle,start); };
  inline __pure strsize find( xstr_abstract<const echar,echar> needle, strsize start = 0 ) const { return find_compound(needle,start); };
  inline __pure strsize find( xstr_abstract<const wchar,wchar> needle, strsize start = 0 ) const { return find_compound(needle,start); };

  template<class ychar> __pure strsize rfind_compound( xstr_abstract<const ychar,ychar> needle, strsize start = MaxSigned(strsize) ) const;
  inline __pure strsize rfind( xstr_abstract<const achar,achar> needle, strsize start = MaxSigned(strsize) ) const { return rfind_compound(needle,start); };
  inline __pure strsize rfind( xstr_abstract<const echar,echar> needle, strsize start = MaxSigned(strsize) ) const { return rfind_compound(needle,start); };
  inline __pure strsize rfind( xstr_abstract<const wchar,wchar> needle, strsize start = MaxSigned(strsize) ) const { return rfind_compound(needle,start); };

  //template<class ychar> __pure strsize rfind_x( xstr_abstract<const ychar,ychar> needle, strsize start = 0 ) const;
  xchar *chars;
  strsize length;
};

template<class xchar> class xstr_const : public xstr_abstract<const xchar,xchar> {
public:
  typedef xchar char_type;
  typedef xstr_abstract<const xchar,xchar> xstr;
  typedef xstr_abstract<xchar,xchar> xstr_mutable_abstract;
protected:
  xstr_const( const xstr& s ) : xstr(s) {};
public:
  xstr_const() {};
  xstr_const( xstr_mutable_abstract mstr ) : xstr( mstr.chars, mstr.length ) {};
  xstr_const( const xchar *c, strsize l ) : xstr(c,l) {};
  __pure inline xstr_const sub( strsize pos, strsize len = MaxSigned(strsize) ) const { return xstr_const(xstr::sub_abstract(pos,len)); };
  __pure inline xstr_const right( strsize num ) const { return xstr_const(xstr::sub_abstract(xstr::length-num,num)); };
};

typedef xstr_const<achar> astr_const;
typedef xstr_const<echar> estr_const;
typedef xstr_const<wchar> wstr_const;

typedef xstr_const<int> inta_const;
typedef xstr_const<unsigned int> uinta_const;


class utf8str_const : public xstr_const<char> {
protected:
  typedef xstr_const<char> cstr_const;
  utf8str_const( const xstr& s ) : cstr_const(s) {};
  //utf8str_const( xstr_mutable_abstract mstr ) : cstr_const(mstr) {};
public:
  utf8str_const() {};
  utf8str_const( const char *c, strsize l ) : cstr_const(c,l) {};
  utf8str_const( const char *s ) : cstr_const( s, strlen(s) ) {};
  inline utf8str_const& operator = ( const char *s ) { cstr_const::length = strlen(s); cstr_const::chars = s; return *this; }
  inline utf8str_const& operator = ( utf8str_const s ) { cstr_const::length = s.length; cstr_const::chars = s.chars; return *this; }
  __pure inline utf8str_const sub( strsize pos, strsize len = MaxSigned(strsize) ) const { return utf8str_const(xstr::sub_abstract(pos,len)); };
};



// the utf8len functions return -1 for invalid utf-8 strings
__pure strsize utf8len( register const char *buf, register strsize blen );
     strsize utf8len( const char *buf, strsize *byte_length = NULL ); 
__pure inline strsize utf8len( utf8str_const utf8str ) { return utf8len( utf8str.chars, utf8str.length ); };
// utf8decode: returns number of entities written into targetbuf; success: srcpos == srcbuf + srclen
template<class xchar> strsize utf8decode( xchar *targetbuf, strsize tglen, const char *srcbuf, strsize srclen, const char **srcpos = NULL, const xchar unknown_xchar='?', strsize *invalidchars = NULL );

extern void*(*const std_alloc)( size_t sz );
//void* std_alloc( size_t sz ); 
void std_dealloc( void* ptr, size_t sz ); 
void* std_realloc( void* ptr, size_t oldsz, size_t newsz );   // eigentl.: size_t oldsz, size_t old_used
// std_realloc as used for xstrbuf::remalloc - function is expected to attempt 
//   * shrinking the current ptr/oldsize into return-value/newsz, if newsz < oldsz
//   * enlarging ptr/oldsize into return-value/newsz if ptr does not need to change (i.e. favourably still ptr == return-value), if newsz > oldsz
//  # if the function was not successful then it needs to return NULL; otherwise it may always return a newly allocated chunk with min(oldsz,newsz) bytes of memory set to the same values as before


template<class xchar> class xstr_mutable: public xstr_abstract<xchar,xchar> {
public:
  typedef xchar char_type;
  typedef xstr_abstract<xchar,xchar> xstr;
  typedef xstr_const<xchar> str_const;
protected:
  xstr_mutable( const xstr& s ) : xstr(s) {};     // same as the implicit copy constructor
  // alloc == NULL => user deallocation by calling begin_scope and end_scope
  // alloc == NULL => input value of min_alignment_in_bufParams_out ignored / used for output only
  xstr_mutable( strsize blen, const char *s, void*(*alloc)(size_t) ); // unsigned_strsize *min_alignment_in_bufParams_out ); 
public:
  xstr_mutable() {};
  xstr_mutable( xchar *c, strsize l ) : xstr(c,l) {};
  static void*(*alloc)(size_t);		 // defaults to malloc
  static void(*dealloc)(void*,size_t);   // defaults to demalloc = free
  inline xstr_mutable( const char *s, void*(*alloc)(size_t) = NULL ) : xstr_mutable( -1, s, alloc ) {};
  void buf_free() { dealloc( xstr::chars, ( sizeof(xchar) + 1 ) * xstr::length ); xstr::chars = NULL; xstr::length = 0; };
  __pure inline xstr_mutable sub( strsize pos, strsize len = MaxSigned(strsize) ) const { return xstr_mutable(xstr::sub_abstract(pos,len)); };
  __pure inline xstr_mutable right( strsize num ) const { return xstr_mutable(xstr::sub_abstract(xstr::length-num,num)); };
  __pure str_const as_const() const { return str_const(*this); };
  __pure inline operator str_const() const { return str_const(*this); }; // { return as_const(); };
};

typedef xstr_mutable<achar> astr;
typedef xstr_mutable<echar> estr;
typedef xstr_mutable<wchar> wstr;

#define estra(s) estr(s,NULL)      // !is really the right constructor chosen?
#define wstra(s) wstr(s,NULL)
void begin_scope();  // begin of scope where estra allocs are valid / scopes must not extend beyond function bodies
void end_scope();  // end of scope where estra allocs are valid / scopes must not extend beyond function bodies


#define xstr_shared_HdrSize mem_align(sizeof(xstr_shared),sizeof(xstr_shared::char_type))   // theoretically in a 16bit environment wchar is larger than int

template<class xchar> class xstr_shared : public xstr_mutable<xchar> {
public:
  typedef xchar char_type;
  typedef xstr_abstract<xchar,xchar> xstr;
  typedef xstr_mutable<xchar> base_str;
  typedef xstr_const<xchar> str_const;
  strsize usage_count;
protected:
  xstr_shared( xchar *c, strsize l ) : base_str(c,l), usage_count(1) {};
  void buf_free();     // error: buf_free called for xstr_shared; use free instead to free the whole object.
public:
  static __malloced xstr_shared* allocate_for_len( strsize len );   // allocates including space for terminating \000
  static __malloced xstr_shared* copyFrom( str_const s );
  inline static void freeMem( xstr_shared *s ) { if(!s) return; aux_assert_( s->usage_count > 0, "xstr_shared: doubleFree");  
						 if( --s->usage_count == 0 ) base_str::dealloc( s, xstr_shared_HdrSize + ( s->length + 1 ) * sizeof(xchar) ); }
  inline static void free( xstr_shared **strAdr ) { freeMem(*strAdr); *strAdr = NULL; }
protected:
  ~xstr_shared();     // error: tried to auto-deallocate xstr_shared object; use xstr_shared::free[Mem] instead.
public:
  inline xstr_shared* duplicate() { usage_count++; return this; };
  xstr_shared* dup_replace_char( strsize pos, xchar write_char );  // does still duplicate if pos < 0
  inline __malloced xstr_shared* dup_sub( strsize pos, strsize len ) const { return copyFrom( base_str::sub(pos,len) ); }
  __pure inline bool identical( xstr_shared *s ) const { return s && xstr::identical(*s); };    // both strings allocate the same buffer with the same content
  __pure inline small_int binary_compare( xstr_shared *s ) const { return s ? xstr::binary_compare(*s) : +1; }   // compares the content
};

typedef xstr_shared<achar> astr_shared;
typedef xstr_shared<echar> estr_shared;
typedef xstr_shared<wchar> wstr_shared;

//typedef xstr_shared<int> inta_shared;
//typedef xstr_shared<unsigned int> uinta_shared;



#define xstrbuf_bufIsHeapAlloced(xsb) ( (strsize)(xsb).bufParams >= 0 )     // same as !( bufParams & bufUserAllocatedBit )
#define xstrbuf_bufIsUserAlloced(xsb) ( (strsize)(xsb).bufParams < 0 )     // same as !!( bufParams & bufUserAllocatedBit )
#define xstrbuf_bufLenHeap(xsb) (xsb).bufParams			  // whenever the bufUserAllocatedBit is not set then bufParams directly contains the bufLength (the highest bit has to be zero)
//#define xstrbuf_bufUserAllocatedBit ( (unsigned_strsize) 1 << (sizeof(unsigned_strsize)*8-1) )  // if this bit is set then it may not have been xstr_mutable::alloc-ed and auto-deallocation will be disabled
#define xstrbuf_bufUserAllocatedBit ( ( (unsigned_strsize)-1 >> 1 ) + 1 )    // x86: direct translation would save one byte of inline code
#define xstrbuf_bufLenMask ~xstrbuf_bufUserAllocatedBit       // # of characters that may be changed
#define xstrbuf_constBuf xstrbuf_bufUserAllocatedBit     // bufLength = 0 && bufUserAllocatedBit, i.e. no characters that may be changed
#define xstrbuf_bufLength(xsb) (strsize)( (xsb).bufParams & xstrbuf_bufLenMask )

template<class xchar> class xstrbuf : public xstr_mutable<xchar> {
public:
  typedef xchar char_type;   // the same: typedef typename base_str::char_type char_type;
  typedef xstr_mutable<xchar> base_str;
  typedef xstr_const<xchar> base_str_const;
public:
  unsigned_strsize bufParams;
protected:
  static small_int alloc_factor;    // allocate an additional ( required_size * alloc_factor ) >> 8 characters; defaults to 0x080 for +1/2.
  static small_int alloc_addspace;     // allocate for an additional of alloc_addspace characters; defaults to + 8 characters.
public:
  static const strsize min_alignment = sizeof(void*);   // minimum allocation request granularity at the byte level
  static void*(*realloc)(void*,size_t,size_t);   // (oldptr,oldsize,newsize) -> newptr:: function-ptr may be left NULL so that dealloc, alloc need to be used in sequence
  static small_int setAllocFactor( small_int new_alloc_factor, small_int new_alloc_addspace );    // max. 0x800 ~ 8x,  + 0x8000 ~ 32.000 characters   ( result < 0 ~ new values saturated into these bounds)
protected:
  void buf_freeMem();   // same as buf_free but leaves all member variables uninitialized
  void assignByLength( strsize blen, const char *s );
#ifdef QT_CORE_LIB
  int assignQStringByLength( QString s );
public:
  friend int fromQString( QString from, xstrbuf<achar> *buf );   // returns number of chars that failed the conversion or -1 on nomem
protected:
#endif
  // realloc_uninitialized: always performs a reallocation; i.e. query the xstrbuf_bufLength before calling this function; 
  //   min_length is considered a minimum string length (not a buffer length including a terminating '\000').
  //   does not reset length (you will need to set it yourself)
  void realloc_uninitialized( strsize new_length_4str ); 
  inline xstrbuf( xchar *c, strsize l ) : base_str( c, l ) { };
  inline xstrbuf( void *v ) : base_str(), bufParams(xstrbuf_constBuf) {}
protected:
  void prepare_replace( strsize pos, strsize count, strsize ulen );
  xstrbuf& do_replace( strsize pos, strsize count, const char *s, strsize ulen, strsize blen );
public:
  void realloc_for_len( strsize new_length_4str );    // realloc_uninitialized + error handling
  // allocate_for_len: realloc + check current capacity + allocate a bit more than base_length_4str (alloc_factor, alloc_addspace), does not change length either
  void allocate_for_len( strsize min_length_4str, strsize base_length_4str = 0 );
  void reserve( strsize min_length_4str );  // reallocates the buffer like allocate_for_len but preserving its content; does not give any guarantee about the resulting buffer length
  void free_additional_space();      // uses realloc or does nothing if realloc == NULL 
  void buf_free();                 // sets length to zero and chars to NULL: same as  myxstr = invalid_xstr;
public:
  xstrbuf() : base_str(NULL,0) { bufParams = xstrbuf_constBuf; };
// convert from utf-8
  //xstrbuf( const char *s ) : base_str( -1, s, base_str::alloc, &( bufParams = min_alignment ) ) {};
  //xstrbuf( utf8str_const s ) : base_str( s.length, s.chars, base_str::alloc, &( bufParams = min_alignment ) ) {};
  xstrbuf( const char *s );
  xstrbuf( utf8str_const s );
  xstrbuf& operator = ( const char *s );
  xstrbuf& operator = ( utf8str_const s );
#ifdef QT_CORE_LIB
  xstrbuf( QString s );
  xstrbuf& operator = (  QString s );
#endif
// assign / initialize by other xstrs
  inline xstrbuf( base_str_const s ) : bufParams(xstrbuf_constBuf) { copyFrom(s,s.length); };
  //inline xstrbuf( base_str s ) : bufParams(xstrbuf_constBuf) { copyFrom(s,s.length); };
  inline xstrbuf( const xstrbuf& s ) : bufParams(xstrbuf_constBuf) { copyFrom(s,s.length); };  
  xstrbuf& operator = ( base_str_const s ) { copyFrom(s,s.length); return *this; };
  xstrbuf& operator = ( const xstrbuf& s ) { copyFrom(s,s.length); return *this; };
  xstrbuf& referenceFrom( base_str_const other );  // this xstrbuf just holds a reference to another xstr_const
  xstrbuf& sharedRefFrom( xstrbuf *other );    // both bufs have a shared allocation; the other remains owner for deallocation.
  xstrbuf& moveFrom( xstrbuf *other );         // moves the strbuf; the other buf still contains a const reference to the new owner / the target
  xstrbuf& shareMoveFrom( xstrbuf *other );    // both bufs have a shared allocation; the target becomes owner for deallocation.
  xstrbuf& copyFrom( base_str_const other, strsize prealloc_4strlen = -1 );  // set prealloc_4strlen = other.length in order not to use alloc_factor
  xstrbuf& replace( strsize pos, strsize count, const char *s );
  xstrbuf& replace( strsize pos, strsize count, utf8str_const s );
  xstrbuf& replace( strsize pos, strsize count, base_str_const s );  // s and this must not overlap
  xstrbuf& append( const char *s );
  xstrbuf& append( utf8str_const s );
  inline xstrbuf& append( base_str_const s ) { return replace(base_str::length,0,s); }
  xstrbuf& insert( strsize pos, const char *s );
  xstrbuf& insert( strsize pos, utf8str_const s );
  inline xstrbuf& insert( strsize pos, base_str_const s ) { return replace(pos,0,s); }  // s and this must not overlap
  xstrbuf& remove( strsize pos, strsize count );
  xstrbuf& setUserAllocedBuf( void *memory, strsize newBufLen );
  static xstrbuf* assign_if_empty( xstrbuf *buf, const char *s ) { if(!buf->chars) { new(buf) xstrbuf(s); }; return buf; };
  static xstrbuf* assign_if_empty( xstrbuf *buf, utf8str_const s ) { if(!buf->chars) { new(buf) xstrbuf(s); }; return buf; };
  //__pure inline operator base_str_const() const { return base_str_const(*this); }; // { return as_const(); };
  // __pure inline operator base_str_const() const;   // valid as long as estrbuf is not changed  - same as as_str_const in base class
  ~xstrbuf();
};

// include <memory> in order to make use of the following two functions:
// use with: moveFrom & copyFrom and a target xstrbuf.
#define astrb(s) (new((astrbuf*)alloca(sizeof(astrbuf))) astrbuf(s))
#define estrb(s) (new((estrbuf*)alloca(sizeof(estrbuf))) estrbuf(s))
#define wstrb(s) (new((wstrbuf*)alloca(sizeof(wstrbuf))) wstrbuf(s))

typedef xstrbuf<achar> astrbuf;
typedef xstrbuf<echar> estrbuf;
typedef xstrbuf<wchar> wstrbuf;

typedef xstrbuf<int> intabuf;
typedef xstrbuf<unsigned int> uintabuf;

// one time initialization of estrbuf; from there on use it as xstr_const
#define astrbc(buf,s) astrbuf::assign_if_empty(&buf,s)->as_const();
#define estrbc(buf,s) estrbuf::assign_if_empty(&buf,s)->as_const();
#define wstrbc(buf,s) wstrbuf::assign_if_empty(&buf,s)->as_const();

//
// estrc, astrc: use estrbuf-s memory allocation mechanism for temporary strings
//  -> only one anchor needs to be defined to have multiple local xstr_const variables which will get auto-deallocated
//

template<class xchar> class tmp_xstrbuf_anchor {
public:

  class item : public xstrbuf<xchar> {
    typedef xstrbuf<xchar> strbuf;
  public:
    item() : xstrbuf<xchar>() { next = NULL; }
    item( item **anchor, const char *s ) : xstrbuf<xchar>( s ) { next = *anchor; *anchor = this; }
    item( item **anchor, utf8str_const s ) : xstrbuf<xchar>( s ) { next = *anchor; *anchor = this; }
    item *next;
  } *anchor;

  tmp_xstrbuf_anchor() { anchor = NULL; }

  ~tmp_xstrbuf_anchor() {  
    item *cur = anchor;
    while( cur ) {
      if( xstrbuf_bufIsHeapAlloced(*cur) ) { item::dealloc( cur->chars, sizeof(xchar) * (size_t)xstrbuf_bufLenHeap(*cur) ); }   // i.e. when bufUserAllocatedBit is not set
      cur = cur->next;
    };
    anchor = NULL;
  }

};

typedef tmp_xstrbuf_anchor<achar> astrc_anchor;
typedef tmp_xstrbuf_anchor<echar> estrc_anchor;
typedef tmp_xstrbuf_anchor<wchar> wstrc_anchor;

#define astrc(a,s) (new((tmp_xstrbuf_anchor<achar>::item*)alloca(sizeof(tmp_xstrbuf_anchor<achar>::item))) tmp_xstrbuf_anchor<achar>::item(&a.anchor,s))->as_const()
#define estrc(a,s) (new((tmp_xstrbuf_anchor<echar>::item*)alloca(sizeof(tmp_xstrbuf_anchor<echar>::item))) tmp_xstrbuf_anchor<echar>::item(&a.anchor,s))->as_const()
#define wstrc(a,s) (new((tmp_xstrbuf_anchor<wchar>::item*)alloca(sizeof(tmp_xstrbuf_anchor<wchar>::item))) tmp_xstrbuf_anchor<wchar>::item(&a.anchor,s))->as_const()



//typedef union { echar ec; achar ac; } zero_short_union;
//const zero_short_union empty_char = { ec: 0 };
//const echar* const empty_echars = &empty_char.ec;
//const achar* const empty_achars = &empty_char.ac;

// return value: src.length or -1-(error_position)

//const estr empty_estr(const_cast<echar*>(empty_echars),0);   // basically that would have to be estr_const; i.e. on de-allocation check for estr-s != empty_estr
//const astr empty_astr(const_cast<achar*>(empty_achars),0);

//const estr invalid_estr(NULL,0);
//const astr invalid_astr(NULL,0);

const wchar zero_wchar = 0;

template<class xchar>
  struct XStrTraits {
    static const xchar& zero_char; // = (xchar&)int_zero_char;
    static const xchar* const empty_xchars; // = &zero_char;
    static const xstr_mutable<xchar> empty_xstr; // ::xstr(const_cast<xchar*>(empty_xchars),0);   // basically that would have to be xstr_const; however it shall also be assignable to pure/mutable xstr-s
    static const xstr_mutable<xchar> invalid_xstr;  // ::xstr(NULL,0)
  };

extern struct XStrTraits<achar> AStrTraits;
extern struct XStrTraits<echar> EStrTraits;
extern struct XStrTraits<wchar> WStrTraits;

extern struct XStrTraits<int> IntATraits;
extern struct XStrTraits<unsigned int> UIntATraits;

#define empty_achars AstrTraits.empty_xchars
#define empty_echars EStrTraits.empty_xchars
#define empty_wchars WStrTraits.empty_xchars
#define empty_ints IntATraits.empty_xchars
#define empty_uints UIntATraits.empty_xchars

#define empty_astr AStrTraits.empty_xstr
#define empty_estr EStrTraits.empty_xstr
#define empty_wstr WStrTraits.empty_xstr
#define empty_inta IntATraits.empty_xstr
#define empty_uinta UIntATraits.empty_xstr

#define invalid_astr AStrTraits.invalid_xstr
#define invalid_estr EStrTraits.invalid_xstr
#define invalid_wstr WStrTraits.invalid_xstr
#define invalid_inta IntATraits.invalid_xstr
#define invalid_uinta UIntATraits.invalid_xstr


enum Charset { latin1 = 0, asciiext = 1, utf8 = 2, cp1250 = 3, QString_utf16, QStringList_utf16 };   // values >= 0

extern struct TerminalType {
  enum Charset charset = utf8;
  bool initialized = false;       
} terminal_type;

// extern struct TerminalType terminal_type;
void Initialize(); // InitTerminalType();



#define greek_letter_num 26
#define additional_symbol_name_num 2
#define symbol_name_num ( greek_letter_num + additional_symbol_name_num )
extern const char *symbol_to_ascii[ symbol_name_num ];
extern utf8str_const symbol_name[ symbol_name_num ];
extern const echar symbol_code[ additional_symbol_name_num ];
#define greek_letter ( symbol_name + additional_symbol_name_num )
#define greek_letter_to_ascii ( symbol_to_ascii + additional_symbol_name_num )
#define first_greek_letter 0x3B1
#define epsilon_letter 0x03B5
#define omikron_letter 0x03BF		    // only greek letter that is not allowed as variable name since it was considered too similar to the latin 'o'
#define last_greek_letter ( first_greek_letter + greek_letter_num - 1 )
extern strsize max_symbol_len;

// SymbolNameToIndex: term_char is ignored if check_4_term_char = false
template<class xchar> __pure idx_diff SymbolNameToIndex( const xchar *name, strsize max_name_len, xchar term_char, small_bool check_4_term_char = true );
template<class xchar> inline __pure idx_diff SymbolNameToIndex( xstr_const<xchar> name ) { return SymbolNameToIndex( name.chars, name.length, '\000', false ); }
__pure_const inline wchar SymbolIndexToCharCode( idx_diff index ) {
  if( index < additional_symbol_name_num ) return symbol_code[index];
  return first_greek_letter - additional_symbol_name_num + index;
}

__pure idx_diff SymbolNameToIndex( const achar *name, strsize max_name_len, achar term_char, small_bool check_4_term_char );
__pure idx_diff SymbolNameToIndex( const echar *name, strsize max_name_len, echar term_char, small_bool check_4_term_char );
__pure idx_diff SymbolNameToIndex( const wchar *name, strsize max_name_len, wchar term_char, small_bool check_4_term_char );


__pure_const const char* letter2asciiEscape( wchar letter );

//extern const echar first_greek_letter, last_greek_letter;
//extern const char *greek_letters[];
//extern const idx_diff greek_letter_num;



//extern const echar subscript_char; // small letter bottom half: f.i. used with variables: "αᴗ11 ..." ;
//extern const echar close_subscripts_char; // right tortois shell bracket: used to close all running subscript expressions; i.e.: "αᴗstartᴗ11❫", space only closes the last subscript expression; i.e. "αᴗstartᴗ11  ..."
//extern const echar subscript_space;  // U+2002: en space
#define subscript_char 0x1D17
// small letter bottom half: f.i. used with variables: "αᴗ11 ..." ;
//#define close_subscripts_char 0x3015   // right tortois shell bracket: used to close all running subscript expressions; i.e.: "αᴗstartᴗ11❫", space only closes the last subscript expression; i.e. "αᴗstartᴗ11  "
#define close_subscripts_char 0x276B   // right tortois shell bracket: used to close all running subscript expressions; i.e.: "αᴗstartᴗ11❫", space only closes the last subscript expression; i.e. "αᴗstartᴗ11  "
#define subscript_space 0x2002	       // en space
#define unicode_space 0x2423	       // open box, graphic for space
#define unicode_space_utf8 "\342\220\243"
#define range_char 0x2026	       // horizontal ellipsis: "..."
#define neq_char 0x2260		       // not equal to
#define leq_char 0x2264		       // lower or equal to
#define geq_char 0x2265		       // greater or equal to
#define setminus_char 0x2216           // utf8 set minus, like a backslash
#define setminus_4_editing_char 0x2296 // utf8 circled minus ( set minus / 0x2216 was considered too similar to the backslash as used for escaping but is merely used for user editing )
#define empty_set_char 0x2205
#define concat_char 0x2218	       // utf8 ring operator: used for string concatenation
#define SlashSeparator 0xFFFE            // this is not a valid unicode character; it would need to be converted back to a slash before output
#define NotAChar 0xFFFE

enum AStrBufCnvFlags { convert_special_space = 0x100 };
// astrbuf_from_xstr, return value: (-1) ~ good or ( (-2) ~ memory allocation error or strlen overflow, (+i) - position of first unconvertible character )
template<class xchar> strsize astrbuf_from_xstr( astrbuf *dest, xstr_const<xchar> src, small_int unknown_achar_with_flags = ((small_int)'?'|AStrBufCnvFlags::convert_special_space) );
// listing the most commonly used instantiation of a template function in the interface will make g++/c++ pick the required types more easily and without having to convert explicitly
strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<echar> src, small_int unknown_achar_with_flags );
strsize astrbuf_from_xstr( astrbuf *dest, register xstr_const<wchar> src, small_int unknown_achar_with_flags );

#define thin_space 0x2009	            // thin space: a fifth of an em
#define thin_space_utf8 "\342\200\211"   // thin space, converted as utf8 string
#define overlay_pred 0x034F                 // combining grapheme joiner  \315\217
#define not_in_range_overlay 0x0305         // combining overline: used to indicate the complement of a character (set), postfixes a single character
#define not_in_range_overlay_utf8 "\314\205"     // alternative would be: 0x0304 combining macron
#define not_in_range_pred_overlay_utf8 "\315\217\314\205"   // combining grapheme joiner + combining overline as utf8: precedes each character of a character set
#define isControlChar(c) ((c)<' ')
// combining grapheme joiner + combining overline: not applicable to the first character in a line or to a character after a control char: use thin_space before

#define unicode_hash   0x266F		      // hash or number sign that does not encode below 0x100; in deed music sharp sign
#define unicode_hash_utf8  "\342\231\257"
//#define unicode_hash   0xFF03		      // hash or number sign that does not encode below 0x100
//#define unicode_hash_utf8  "\357\274\203"
//#define corona 0x89			      // corona sign to mark # as #҉ (combining cyrillic million sign)
//#define corona_utf8 "\322\211"
#define acute_overlay 0x0301		      // combining acute accent: á, used as postfix
#define acute_overlay_utf8  "\314\201"
#define circumflex_overlay  0x0302	      // combining circumflex: â,  evtl. encode as 0x800 for latin letters / 0xB00 for greek letters on tape 
#define circumflex_overlay_utf8 "\314\202"
#define tilde_overlay 0x0303		      // combining tilde: ã, evtl. encode as 0x900 for latin letters / 0xC00 for greek letters
#define tilde_overlay_utf8 "\314\203"
#define breve_overlay 0x306		      // combining breve: ă, evtl. encode as 0xA00 for latin letters / 0xcD00 for greek letters
#define breve_overlay_utf8 "\314\206"

#define charcode_start_char 0x2039
#define charcode_end_char 0x203A
#define charcode_start_utf8 "\342\200\271"	    // "‹"
#define charcode_end_utf8 "\342\200\272"	    // "›"

__pure_const inline bool isChar4VariableIndex( register wchar c ) {
  // allow all printable characters except those with special meaning
  // subscript_char, close_subscripts_char and space return false
  if( c <= ' ' ) return false;  // control character or space
  if( c < 0xFF ) switch(c) {
    case '=': case '!': case '<': case '>': case '+': case '*': case '|': case ',': return false;
    default: return true;
  }
  if( first_greek_letter <= c && c <= last_greek_letter ) return false;  // TM_Edge.setContent() expects (c) not to be a greek letter
  switch(c) {
    case subscript_char: case close_subscripts_char: case 0xFF: case concat_char: case SlashSeparator: case setminus_char: case range_char: case neq_char: case leq_char: case geq_char:
      return false;
    default: 
      return true;
  }
}

template<class xchar> __pure_const inline bool isLatinLetter( register xchar c ) { return ( 'a' <= c && c <= 'z' ) || ( 'A' <= c && c <= 'Z' ); };
template<class xchar> __pure_const inline bool isNumeral( register xchar c ) { return '0' <= c && c <= '9'; };

// inline void ascii_out( uint c, FILE *fstream ) { if( c < ' ' || c>=255 ) fprintf_donotuseme(fstream,"<0x%0x>",c); else fputc(c,fstream); }
//inline void ascii2utf8_out( uint c, bool shall_overlay, FILE *fstream ) {
//  if( c < ' ' || c>=255 ) fprintf_donotuseme( fstream, !shall_overlay ?"‹0x%x%x›":"‹\315\217\314\2050\315\217\314\205x\315\217\314\205%x\315\217\314\205%x\315\217\314\205›", c>>4, c&0xF ); else fputc(c,fstream);
//}

template<class xchar> __pure strsize xstrlen( register const xchar *s );
template<class xchar> __malloced xchar* xstrdup( const xchar *s, strsize *length = NULL );
template<class xchar> __malloced xchar* xmemdup( const xchar *s, strsize length );

#ifdef QT_CORE_LIB
  QString toQString( estr_const from, bool escapeSlash = false );
  QString toQString( astr_const from );
  int fromQString( QString from, astrbuf *buf );   // returns number of chars that failed the conversion or -1 on nomem
#endif

class ios_base { 
public:
  enum StatusBits { badbit = 0x8000, eofbit = 0x4000, failbit = 0x2000, spuriousbit = 0x1000, usrerrbit = 0x0800, break_read_input = 0xF000, usrerr_mask = 0x0FFF };
  enum OpenMode { in = 1, out = 2, trunc = 4, app = 8 };
protected:
  const char* usrerror( small_int error_number );
};

#define EIO_NOMEM 0x1001         // a memory allocation procedure has returned NULL
#define EIO_INVAL 0x1002                  // parameter out of range
#define EIO_NOTIMPL_OR_PROGRERR 0x1003    // similar but less specific error than EIO_INVAL
#define EIO_DECODE 0x1004        // utf-8 / decodation error
#define EIO_CHARRANGE 0x1005     // char code did not fit into target either when reading from a stream or when writing to it
#define EIO_VALRANGE 0x1006      // tried to decode an integer which is larger than allowed by the target memory location for the result
#define EIO_FMT  0x1007	    // format error: f.i. number expected but other characters read-in

//#define EIO_EOF 4	    // end of file
//#define EIO_OTHERSEP 5	    // none of the required separator chars is pending to be read
//#define EIO_IO 6            // EIO - error generated by the underlying IO-system

#define MAXBASE 26

//
// comfort classes for output with IOStream-s and the << operator
//

template<class xchar> class XChar { public: XChar(xchar c) : val(c) {}; xchar val; };
typedef XChar<achar> AChar;
typedef XChar<echar> EChar;
typedef XChar<wchar> WChar;

template<class xint> class XInt { public: XInt(xint val) : value(val) {}; xint value; };
typedef XInt<max_uint> UInt;

class RepeatWrapper_4_utf8str_const : public utf8str_const { public: 
  strsize times; RepeatWrapper_4_utf8str_const ( utf8str_const str, strsize as_many_times ) : utf8str_const(str), times(as_many_times) {};
};

template<class xchar> class RepeatWrapper_4_xstr_const : public xstr_const<xchar> { public: 
  strsize times; RepeatWrapper_4_xstr_const ( xstr_const<xchar> str, strsize as_many_times ) : xstr_const<xchar>(str), times(as_many_times) {};
};

template<class xchar> class RepeatWrapper_4_XChar : public XChar<xchar> { public: 
  strsize times; RepeatWrapper_4_XChar ( XChar<xchar> c, strsize as_many_times ) : XChar<xchar>(c), times(as_many_times) {};
};

RepeatWrapper_4_utf8str_const operator * ( utf8str_const str, strsize times ); // { return RepeatWrapper_4_utf8str_const(str,times); }
template<class xchar> RepeatWrapper_4_XChar<xchar> operator * ( XChar<xchar> c, strsize times ) { return RepeatWrapper_4_XChar<xchar>(c,times); }
template<class xchar> RepeatWrapper_4_xstr_const<xchar> operator * ( xstr_const<xchar> str, strsize times ) { return RepeatWrapper_4_xstr_const<xchar>(str,times); }

class PIfErr;

class IOFlush { };   // empty class; merely here to invoke iostreamref.flush() by iostreamref << IOFlush();

// template instantiations; can make C++ find a rightly typed function
RepeatWrapper_4_XChar<achar> operator * ( XChar<achar> c, strsize times );
RepeatWrapper_4_XChar<echar> operator * ( XChar<echar> c, strsize times );
RepeatWrapper_4_XChar<wchar> operator * ( XChar<wchar> c, strsize times );
RepeatWrapper_4_xstr_const<achar> operator * ( xstr_const<achar> str, strsize times );
RepeatWrapper_4_xstr_const<echar> operator * ( xstr_const<echar> str, strsize times );
RepeatWrapper_4_xstr_const<wchar> operator * ( xstr_const<wchar> str, strsize times );



//
//  IOStream data records & classes for modifying attributes with the << operator
//

class IOStreamRef;

class IOStream_Base_Rec { public:
  IOStreamRef *flush_before;     // next_of_group: ring list (for applying changes like Δlang to all IOStreams)
  enum TypeOfUnderlying { file = 1, qstring = 2, ebuf = 3, abuf = 4 }; static const int MaxVal4UnderlyingType = TypeOfUnderlying::abuf;
#ifdef QT_CORE_LIB
  union { FILE *fstream; QString *qstr; estrbuf *ecbuf; astrbuf *acbuf; } uy;
#else
  union { FILE *fstream; estrbuf *ecbuf; astrbuf *acbuf; } uy;
#endif
  small_int uyType;  // uyType != 0 ( 1 <= uyType <= MaxVal4UnderlyingType )
  strsize lineno; strsize col; int tokNum;			// lineno and col are currently only updated on reads
  small_int errcode;				// number of the first encountered error
  small_bool last_was_a_control_character;    // updated by any output/write function: needed for correct overlining
  strsize linebuflen; // int readahead;	// 1 ~ read one character at a time
  small_int charset;			// on change updates for write* and read* methods needed
  IOStreamRef (IOStreamRef::*write_utf8) ( utf8str_const string );    // write cooked utf-8 character string
  IOStreamRef (IOStreamRef::*write_astr) ( astr_const string );	// write latin1 string, escape control characters
  IOStreamRef (IOStreamRef::*write_estr) ( estr_const string );    // write utf16 string, escape control characters
  IOStreamRef (IOStreamRef::*read_astrbuf) ( astrbuf *string );
  IOStreamRef (IOStreamRef::*read_estrbuf) ( estrbuf *string );
  IOStreamRef (IOStreamRef::*read_wstrbuf) ( wstrbuf *string );
#ifndef SINGLE_IO_THREAD
  pthread_mutex_t mutex;
#endif
  inline IOStream_Base_Rec& operator = ( IOStream_Base_Rec& another ) { memcpy(this,&another,sizeof(IOStream_Base_Rec)); return *this; }  // !!! dest & source waren vertauscht !!!
};



typedef small_uint IOFlagInt;    // sufficiently large to store the value of an attribute (current max seems 0x18/0xFF/1Byte)
typedef uint32 IOFlagDblMask;   // two masks: required to have twice as many bytes as any singleton IOFlagInt which is used as parameter of IOFlag_mkVal (small_int has at least two bytes (but usually 4))
typedef uint16 IOFlagSingleValue;       // used IOFlag_getVal to strip the epsilon-mask located in the higher bits off
// IOFlagDblMask can store a positive mask & an epsilon-mask of any combination of IOFlagInt-s
// possible combinations for IOFlagSingleValue/IOFlagInt/IOFlagDblMask
//   1Byte: uint8/small_uint/small_uint (easier for computation than uint8/uint8/uint16),  2Byte: uint16/small_uint/uint32,  4Byte: uint32/uint32/uint64 (#include <types.h> at least if !defined HAVE_INT64_T)
#define bits4HalfIOFlag (sizeof(IOFlagDblMask)*4)

#define IOFlag_mkVal(value,mask) (( (IOFlagDblMask)(mask) << bits4HalfIOFlag ) | (value) )
//#define IOFlag_getMask(ia) ( (long long)(ia) & (bits4int-1) )
#define IOFlag_getVal(ia) ( (IOFlagSingleValue)(ia) )
#define IOFlag_getMask(ia) ( (IOFlagDblMask)(ia) >> (bits4HalfIOFlag) )

// the following values of IOFlag need to accord with IOStream_Attr_Rec::Flags and EndL::toText
enum IOFlag { OverlineXStr = IOFlag_mkVal(3,3), OverlineNextXStr = IOFlag_mkVal(1,3), OverlineAfterNextXStr = IOFlag_mkVal(2,3),
              ImmediateFlush = IOFlag_mkVal(4,4), 
	      XStrSpecialOutput = IOFlag_mkVal(0x18,0x18), XStrSpecialSpace = IOFlag_mkVal(8,8), XStrVisibleControlChars = IOFlag_mkVal(0x10,0x10),
	      StdNumberIO = IOFlag_mkVal(0,0xE0), NoNumberBaseOverride = IOFlag_mkVal(0x20,0x20), NumberBaseOverride = IOFlag_mkVal(0,0x20), 
						  UpperCaseHex = IOFlag_mkVal(0,0x40), LowerCaseHex = IOFlag_mkVal(0x40,0x40), ShowPositiveSign = IOFlag_mkVal(0x80,0x80),
              ReadCombinedNewLine = IOFlag_mkVal(0,0x100), WriteLinuxNewLine = IOFlag_mkVal(0,0x600), WriteWindowsNewLine = IOFlag_mkVal(0x200,0x600),
							   WriteAppleNewLine = IOFlag_mkVal(0x400,0x600), WriteCStringNewLine = IOFlag_mkVal(0x600,0x600),
              DefaultNewLineHandling = IOFlag_mkVal(0,0x700), UseStrictLinuxNewLine = IOFlag_mkVal(0x100,0x700), UseWindowsNewLine = IOFlag_mkVal(0x200,0x700) };

class IOStream_Attr_Rec { public:
  astr_const term_chars;	  // read_xstrbuf will read up to the first term_char; other line break characters like for \r\n may be removed as well; see for ReadCombinedNewLine-comment below.
  estr_const xstr_escapeChars;    // xstr-s: escaped by a "\\" by write_* functions; however not yet converted into an octal numeric character constant
  small_int number_base; small_int prev_number_base;	  // base: for outputting numbers, reverted to prev_base after output
  uint32 lang;			  // lang: all const char* constants will be checked for translation by this value; content: 4Byte; f.i. deAT
  enum Flags { overline_next_xstr = 1, overline_xstr = 2, immediate_flush = 4, xstr_special_space = 8, xstr_view_ctrl = 0x10, no_number_base_override = 0x20, lower_case_hex = 0x40, show_positive_sign = 0x80,
               no_read_combined_newline = 0x100, undef_attr = 0x8000 };
  IOFlagInt flags;  // undef_attr may be set internally to propagate an error from an AttrChanger - object to the stream.
  static const achar IDENTIFICATION_CODE = 0xAA;
  wchar unknown_wchar; echar unknown_echar; achar unknown_achar; achar identification_code; 
  inline IOStream_Attr_Rec& operator = ( IOStream_Attr_Rec& another ) { memcpy(this,&another,sizeof(IOStream_Attr_Rec)); return *this; }  // !!! dest & source waren vertauscht !!!
};




class IOChangeFlags_AttrChanger { public:
  IOFlagInt set_if1, unset_if0;
  // any bit set in both int-s will be inverted rather than set or unset.
  explicit IOChangeFlags_AttrChanger( IOFlagDblMask mkTrue, register IOFlagInt setFalse = 0, register IOFlagInt invert = 0 );
  // if some flag is set to true other flags with continguity may automatically become reset (to false) at the same time 
  // f.i.: setting IOFlag::OverlineNextXStr will only cause the next xstr to become overlined, no matter how the setting for the following xstr-s was before.
};

inline IOChangeFlags_AttrChanger IOChangeFlags( IOFlagDblMask mkTrue, IOFlagDblMask mkFalse = 0, IOFlagDblMask mkInverted = 0 ) {
  // parameters are here large enough to always successfully receive value combinations from IOFlag::* though the epsilon mask will only be used for mkTrue
  return IOChangeFlags_AttrChanger( mkTrue, IOFlag_getVal(mkFalse), IOFlag_getVal(mkInverted) );
}



enum IOAttr { NumberBase = 3, NumberBaseNextOne = 1, NumberBaseAfterTheNextOne = 2, 
              UnknownXChar = 4, UnknownWChar = 5, UnknownEChar = 6, UnknownAChar = 7,
	      InputTermChars = 8, EscapeChars = 9
	    };

class IOChangeIntegerValue_AttrChanger { public:
  int32 value; small_int attr;
  explicit IOChangeIntegerValue_AttrChanger( small_int attribute, int32 value ) : value(value), attr(attribute) {};
};

inline IOChangeIntegerValue_AttrChanger IOChangeVal( small_int attr, int32 value ) {
  return IOChangeIntegerValue_AttrChanger(attr,value); 
}


class IOChangeAStrValue_AttrChanger { public:
  astr_const value; small_int attr;
  explicit IOChangeAStrValue_AttrChanger( small_int attribute, astr_const value ) : value(value), attr(attribute) {};
};

inline IOChangeAStrValue_AttrChanger IOChangeVal( small_int attr, astr_const value ) {
  return IOChangeAStrValue_AttrChanger(attr,value); 
}



class IOChangeEStrValue_AttrChanger { public:
  estr_const value; small_int attr;
  explicit IOChangeEStrValue_AttrChanger( small_int attribute, estr_const value ) : value(value), attr(attribute) {};
};

inline IOChangeEStrValue_AttrChanger IOChangeVal( small_int attr, estr_const value ) {
  return IOChangeEStrValue_AttrChanger(attr,value); 
}



class EndL { public:
  inline static utf8str_const toText( IOFlagInt flags ) {     // i.e. endl.toText(stream.getIOAttrFlags())
    static utf8str_const newline[4] = { utf8str_const("\n",1), utf8str_const("\r\n",2), utf8str_const("\r",1), utf8str_const("",1) };
    return newline[ (flags >> 9 ) & 3 ];
  }
  // ReadCombinedNewLine: while term_chars contains any of {'\n','\r','\000'}:  on \000 read back to \n and from \n back to \r removing them from the input string; 
  //										on \r read forward iff there is a \n and ungetc if there isn`t
};

extern EndL endl;

class RepeatWrapper_4_EndL { public:
  strsize times; RepeatWrapper_4_EndL( strsize nlCount ) : times(nlCount) {};
};

inline RepeatWrapper_4_EndL operator * ( __unused EndL endl, strsize times ) { return RepeatWrapper_4_EndL(times); };

class TermChars { public:
  astr_const term_chars;
  TermChars( astr_const termChars ) : term_chars(termChars) {};
  TermChars( const char* termChars ) : term_chars( (achar*)termChars, strlen(termChars) ) {};
};


class SkipSpace { public:
  astr_const term_chars;
  SkipSpace() : term_chars((achar*)"",0) {};
  SkipSpace( astr_const termChars ) : term_chars(termChars) {};
  SkipSpace( const char* termChars ) : term_chars( (achar*)termChars, strlen(termChars) ) {};
};

class SkipSep { public:
  astr_const term_chars;
  SkipSep( astr_const termChars ) : term_chars(termChars) {};
  SkipSep( const char* termChars ) : term_chars( (achar*)termChars, strlen(termChars) ) {};
};

class SkipAnySep { };
extern SkipAnySep skip_sep;
extern SkipSpace skip_space;

//
// actual IOStream implementation 
//

class IOStreamRef : public ios_base {

public:  // better: protected
  typedef IOStream_Attr_Rec::Flags AttrFlags;
  typedef IOStream_Base_Rec::TypeOfUnderlying TypeOfUnderlying;
  IOStream_Base_Rec *base;
  IOStream_Attr_Rec *attr;
protected:
  IOStreamRef() {}
public:
  IOStreamRef( const IOStreamRef& another ) : base(another.base), attr(another.attr) {}
  IOStreamRef( IOStream_Base_Rec* b, IOStream_Attr_Rec* a ) : base(b), attr(a) {}
  inline IOStreamRef& operator = ( const IOStreamRef another ) { base = another.base; attr = another.attr; return *this; }
#ifndef SINGLE_IO_THREAD
  inline IOStreamRef& lock() { pthread_mutex_lock(&base->mutex); return *this; }
  inline IOStreamRef& unlock() { pthread_mutex_unlock(&base->mutex); return *this; }
  inline bool tryLock() { return pthread_mutex_trylock(&base->mutex) == 0; }   // true iff locked ok
  //inline bool isLocked() { bool nowLockedByMe = pthread_mutex_trylock(&base->mutex) == 0; if(nowLockedByMe) pthread_mutex_unlock(&base->mutex); return !nowLockedByMe; }
#endif
  // checks if this is a valid IOStreamRef instance; i.e. base and attr need to point to valid records (currently checked by an identification code for attr and the value range of base->uyType)
  bool isValidNoCatch() const;           // may cause a SIGSEGV or a SIGBUS if the referenced memory location is invalid; no locking
  bool isValid() const;                  // shall always return under Unix/Linux/BSD; locks a global mutex during the check
  static void startValidityChecking();
  inline bool isValidRegionCheck() const;        // same as isValid; however requiring to execute startValidityChecking before and nomoreValidityChecking after a sequence of such calls keeping the same global mutex as isValid 
  static void endValidityChecking();
public:
  // all of the following .setXXX functions require lock & unlock to be executed before and afterwards; use also: IOStreamLocker
  bool open( const char* filename, small_int mode );
  bool close();
  status_int setFlushBefore( IOStreamRef *flushBefore );   // flush-loop detected: returns -1 and sets flush_before NULL
  status_int setTermChars( astr_const termchars );   // deallocated by user; only ascii chars allowed; required to be non-null; otherwise: does nothing, sets EIO_INVAL, returns -1
  inline status_int setLineBufLen( size_t alloclen ) { base->linebuflen = alloclen; return 0; }
  void setCharset( small_int cs ) { 
    switch(cs) {
      case utf8:
	  base->write_utf8 = &IOStreamRef::write_utf8str_as_utf8;
	  base->write_astr = &IOStreamRef::write_astr_as_utf8;
	  base->write_estr = &IOStreamRef::write_estr_as_utf8;
	  base->read_astrbuf = &IOStreamRef::read_xstrbuf_from_utf8<achar>;
	  base->read_estrbuf = &IOStreamRef::read_xstrbuf_from_utf8<echar>;
	  base->read_wstrbuf = &IOStreamRef::read_xstrbuf_from_utf8<wchar>;
	break;
      case latin1:
	  base->write_utf8 = &IOStreamRef::write_utf8str_as_latin1;
	  base->write_astr = &IOStreamRef::write_astr_as_latin1;
	  base->write_estr = &IOStreamRef::write_estr_as_latin1;
	  base->read_astrbuf = &IOStreamRef::read_xstrbuf_from_latin1<achar>;
	  base->read_estrbuf = &IOStreamRef::read_xstrbuf_from_latin1<echar>;
	  base->read_wstrbuf = &IOStreamRef::read_xstrbuf_from_latin1<wchar>;
	break;
      case asciiext:
	  base->write_utf8 = &IOStreamRef::write_utf8str_as_undef;
	  base->write_astr = &IOStreamRef::write_astr_as_undef;
	  base->write_estr = &IOStreamRef::write_estr_as_undef;
	  base->read_astrbuf = &IOStreamRef::read_xstrbuf_from_asciiext<achar>;
	  base->read_estrbuf = &IOStreamRef::read_xstrbuf_from_asciiext<echar>;
	  base->read_wstrbuf = &IOStreamRef::read_xstrbuf_from_asciiext<wchar>;
	break;
#ifdef QT_CORE_LIB
      case QString_utf16:
	  base->write_utf8 = &IOStreamRef::write_utf8str_as_QString;
	  base->write_astr = &IOStreamRef::write_xstr_as_QString<achar>;
	  base->write_estr = &IOStreamRef::write_xstr_as_QString<echar>;
	  base->read_astrbuf = &IOStreamRef::read_xstrbuf_from_QString<achar>;
	  base->read_estrbuf = &IOStreamRef::read_xstrbuf_from_QString<echar>;
	  base->read_wstrbuf = &IOStreamRef::read_xstrbuf_from_QString<wchar>;
	break;
#endif
    }
    base->charset = cs;
  }
  // all functions below are shielded against race conditions if NO_DEFAULT_IO_LOCK remains undefined
  inline IOStreamRef operator << ( utf8str_const string ) { return (this->*(this->base->write_utf8))(string); }
  inline IOStreamRef operator << ( const char *string ) { return (this->*(base->write_utf8))(utf8str_const(string)); }
  inline IOStreamRef operator << ( AChar c ) { return (this->*(base->write_astr))(astr_const(&c.val,1)); }
  inline IOStreamRef operator << ( EChar c ) { return (this->*(base->write_estr))(estr_const(&c.val,1)); }
  inline IOStreamRef operator << ( astr_const string ) { return (this->*(base->write_astr))(string); }
  inline IOStreamRef operator << ( estr_const string ) { return (this->*(base->write_estr))(string); }
#ifdef QT_CORE_LIB
  inline IOStreamRef operator << ( QString string ) { estrbuf buf = string; return (this->*(base->write_estr))(buf); }
#endif
  // iostream.getIOAttrFlags(): get the attribute flags changeable with out << IOChangeFlags(); attribute flags are unique to every IOStreamAttr and every IOStream object
  inline IOFlagInt getIOAttrFlags() { return attr->flags; };
  // iostream.resetIOAttrFlags(prev_getted_flags):  fast procedure just for restoring the attribute flags (but not any other attributes with non-flag-value); preferred way is thus to use IOStreamAttr
  inline IOStreamRef restoreIOAttrFlags( IOFlagInt flags2install ) { attr->flags = flags2install; return *this; };
         IOStreamRef operator << ( IOChangeFlags_AttrChanger flagChanger );
         IOStreamRef operator << ( IOChangeIntegerValue_AttrChanger intValChanger );
         IOStreamRef operator << ( IOChangeAStrValue_AttrChanger astrChanger );
         IOStreamRef operator << ( IOChangeEStrValue_AttrChanger estrChanger );
  inline IOStreamRef operator >> ( IOChangeFlags_AttrChanger flagChanger ) { return *this << flagChanger; };
  inline IOStreamRef operator >> ( IOChangeIntegerValue_AttrChanger intValChanger ) { return *this << intValChanger; };
  inline IOStreamRef operator >> ( IOChangeAStrValue_AttrChanger astrChanger ) { return *this << astrChanger; };
  inline IOStreamRef operator >> ( IOChangeEStrValue_AttrChanger estrChanger ) { return *this << estrChanger; };
  inline IOStreamRef operator << ( RepeatWrapper_4_utf8str_const strRep ) { for( register strsize i = strRep.times; i>0; i-- ) *this = (this->*(this->base->write_utf8))(strRep); return *this; }
  inline IOStreamRef operator << ( RepeatWrapper_4_XChar<achar> acr ) { for( register strsize i = acr.times; i>0; i-- ) *this = (this->*(this->base->write_astr))(astr_const(&acr.val,1)); return *this; }
  inline IOStreamRef operator << ( RepeatWrapper_4_XChar<echar> ecr ) { for( register strsize i = ecr.times; i>0; i-- ) *this = (this->*(this->base->write_estr))(estr_const(&ecr.val,1)); return *this; }
  inline IOStreamRef operator << ( RepeatWrapper_4_xstr_const<achar> strRep ) { for( register strsize i = strRep.times; i>0; i-- ) *this = (this->*(this->base->write_astr))(strRep); return *this; }
  inline IOStreamRef operator << ( RepeatWrapper_4_xstr_const<echar> strRep ) { for( register strsize i = strRep.times; i>0; i-- ) *this = (this->*(this->base->write_estr))(strRep); return *this; }
  inline IOStreamRef operator << ( RepeatWrapper_4_EndL nlRep ) { utf8str_const cur_endl = EndL::toText(attr->flags); for( register strsize i = nlRep.times; i>0; i-- ) *this << cur_endl; return *this; }
  inline IOStreamRef operator << ( __unused EndL endl ) { *this << EndL::toText(attr->flags); return *this; }
protected:
  template<class xint> IOStreamRef write_xint( xint value );
  template<class xint> IOStreamRef read_xint ( xint *value );
  __pure bool isTermChar( small_int c ) const;   // c needs to be a simple achar
  small_int readTermCharTrailer( small_int c, FILE *fstream );
  void UnReadTermCharHeader( small_int c, char *linebuf, int &blen );
public:
  inline IOStreamRef operator << ( max_int value ) { return write_xint(value); }
  inline IOStreamRef operator << ( UInt valObj ) { return write_xint(valObj.value); };
         IOStreamRef operator >> ( EndL endl );	    // currently does not set failbit; only eofbit when there is no more newline
  inline IOStreamRef operator >> ( TermChars termChars ) { setTermChars( termChars.term_chars ); return *this; }
  //inline IOStreamRef operator >> ( TermChars termChars ) { attr->term_chars = termChars.term_chars; return *this; }
         IOStreamRef operator >> ( SkipSpace skipper );
         IOStreamRef operator >> ( SkipSep skipper );      // skip the given separators
         IOStreamRef operator >> ( SkipAnySep skipper );   // actual parameter will be empty class: skip_sep -> skip attr->term_chars
  inline IOStreamRef operator >> ( astrbuf *string ) { return (this->*(base->read_astrbuf))(string); }
  inline IOStreamRef operator >> ( estrbuf *string ) { return (this->*(base->read_estrbuf))(string); }
  inline IOStreamRef operator >> ( wstrbuf *string ) { return (this->*(base->read_wstrbuf))(string); }
#ifdef QT_CORE_LIB
  inline IOStreamRef operator >> ( QString *string ) { estrbuf buf; (this->*(base->read_estrbuf))(&buf); *string = toQString(buf); return *this; }
#endif
  inline IOStreamRef operator >> ( max_int *value ) { return read_xint(value); }
  inline IOStreamRef operator >> ( max_uint *value ) { return read_xint(value); }
#ifdef HAVE_INT64      // max_int == int64 => also instantiate int32 
  inline IOStreamRef operator >> ( int32 *value ) { return read_xint(value); }
  inline IOStreamRef operator >> ( uint32 *value ) { return read_xint(value); }
#endif
  inline IOStreamRef operator >> ( int16 *value ) { return read_xint(value); }
  inline IOStreamRef operator >> ( uint16 *value ) { return read_xint(value); }
  //inline IOStreamRef operator>> ( int16 *value ) { max_int val; read_xint(&val); *value = val; if(*value!=val && !base->errnum) base->errnum=EIO_VALRANGE; return *this; }
public:
  __pure inline operator const void*() const { return base->errcode ? NULL : (void*)1; };    // used as bool value
  //inline bool operator~() const { if( attr->flags & AttrFlags::immediate_flush ) flush(); return base->errnum != 0; }
  IOStreamRef operator << ( PIfErr errObj );
  const char* strerror();       // return error as string and reset errcode, not threadsafe
  const char* str_usrerror();   // return error message for a given usrerr and reset that error condition; does not check ios_abse::badbit, eofbit and failbit, threadsafe
  void perror(const char *errmsg);   // always prints to sterr / stderr
  void perror(utf8str_const errmsg);
  inline small_int rdstate() const { return base->errcode; }
  inline void clear( small_int state = 0 ) { base->errcode = state; }
  inline void clear_swerr() { base->errcode &= ~(failbit|spuriousbit|usrerrbit|usrerr_mask); }
  inline void clear_failbit() { base->errcode &= ~failbit; }
  inline void clear_spuriousbit() { base->errcode &= ~spuriousbit; }
  inline void setstate( small_int state = 0 ) { base->errcode |= state; }
  inline bool eof() const { return base->errcode & eofbit ; }
  inline bool anyerr() const { return base->errcode & ~eofbit; }
  inline bool fail() const { return base->errcode & (badbit|failbit); }
  inline bool spurious() const { return base->errcode & spuriousbit; }
  inline bool bad() const { return base->errcode & badbit ; }
  inline int getTokenNum() const { return base->tokNum; }
  inline int getLineNum() const { return base->lineno; }
  inline int getCol() const { return base->col; }
protected:
  inline void setUsrError( small_int errnum ) { if(!( base->errcode & ios_base::usrerr_mask )) base->errcode |= errnum; }
public:
  inline IOStreamRef operator << ( __unused IOFlush flushobj ) { flush(); return *this; }
  void flush() const;

protected:
  IOStreamRef write_utf8str_as_undef ( utf8str_const string );
  IOStreamRef write_utf8str_as_utf8 ( utf8str_const string );
  IOStreamRef write_utf8str_as_latin1 ( utf8str_const string );
  IOStreamRef write_astr_as_undef ( astr_const string );
  IOStreamRef write_astr_as_utf8 ( astr_const string );
  IOStreamRef write_astr_as_latin1 ( astr_const string );
  IOStreamRef write_estr_as_undef ( estr_const string );
  IOStreamRef write_estr_as_utf8 ( estr_const string );
  IOStreamRef write_estr_as_latin1 ( estr_const string );
  template<class xchar> IOStreamRef read_xstrbuf_prepare ( xstrbuf<xchar> *string, strsize &ulen, char *linebuf, strsize &blen, bool utf8decode );
  template<class xchar> IOStreamRef read_xstrbuf_from_asciiext ( xstrbuf<xchar> *string );
  template<class xchar> IOStreamRef read_xstrbuf_from_utf8 ( xstrbuf<xchar> *string );
  template<class xchar> IOStreamRef read_xstrbuf_from_latin1 ( xstrbuf<xchar> *string );
  template<class xchar>	IOStreamRef read_xstrbuf_from_QString ( xstrbuf<xchar> *string );
#ifdef QT_CORE_LIB
  IOStreamRef write_utf8str_as_QString( utf8str_const string );
  template<class xchar> IOStreamRef write_xstr_as_QString( xstr_const<xchar> string );
#endif
};

#ifndef SINGLE_IO_THREAD
class IOStreamLocker { public:
  pthread_mutex_t *baseMutex;
  IOStreamLocker( IOStreamRef ios ) { baseMutex = &ios.base->mutex; pthread_mutex_lock(baseMutex); }
  ~IOStreamLocker() { pthread_mutex_unlock(baseMutex); }
};
#endif

class PIfErr { public: 
  IOStreamRef baseStream; utf8str_const message; small_int bitfield; 
  enum BitField { nl = 1, nl2 = 2, nl3 = 3, praefix = 4, onSuccess = 8 };
  static const small_int defaultMode = nl | praefix;    // praefix: print "aux::IOStream - "
  PIfErr( IOStreamRef iostream ) : baseStream(iostream), message(utf8str_const("",0)), bitfield(defaultMode) {}; 
  PIfErr( IOStreamRef iostream, const char *msg, small_int flags = defaultMode ) : baseStream(iostream), message(msg), bitfield(flags) {}; 
  PIfErr( IOStreamRef iostream, utf8str_const msg, small_int flags = defaultMode ) : baseStream(iostream), message(msg), bitfield(flags) {}; 
};


class IOStreamAttr : public IOStreamRef {
protected:
  IOStreamAttr() {};
  IOStream_Attr_Rec attrRec;
public:
  IOStreamAttr( IOStreamRef &another ) { base = another.base; attr = &attrRec; attrRec = *(another.attr); }
  inline IOStreamRef& operator = ( IOStreamRef another ) { base = another.base; attr = &attrRec; attrRec = *(another.attr); return *this; }
};


class IOStream : public IOStreamAttr {
protected:
  IOStream_Base_Rec baseRec;
public:
  IOStream( FILE *stdio_stream = NULL, IOStreamRef *flushBefore = NULL, bool flushImmediate = false );
#ifdef QT_CORE_LIB
  IOStream( QString *qstr );
#endif
  ~IOStream();
};


class IOStreamGroup { 
public:
  struct Compound { IOStreamRef *ref[3]; struct Compound *next; } primaryCompound;
  const small_int refs_per_compound = sizeof(primaryCompound.ref)/sizeof(IOStreamRef*); 
public:
  IOStreamGroup( IOStreamRef *first = NULL, ... );     // list of IOStreamRef - pointers
  IOStreamGroup& operator<< ( IOChangeFlags_AttrChanger flagChanger );
  void immediateFlush( bool state );
  void flushAll();
  status_int addIOStreamRef();        // 0 ~ added, 1 ~ was already present before, -1 ~ error (malloc)
  status_int removeIOStreamRef();     // 0 ~ removed, 1 ~ not found
  ~IOStreamGroup();  
};


extern class IOStream cin, cout, cerr;     // io-channels for the standard file descriptors 0, 1 and 2.
extern class IOStreamRef clog;             // by default pointing to cerr; may be used to indicate programming errors
extern class IOStreamGroup cgstd;	   // standard io-channel-group: comprises cin, cout and cerr by default

/*  // moved upwards in this file
#ifdef QT_CORE_LIB
  QString toQString( estr_const from, bool escapeSlash = false );
  QString toQString( astr_const from );
  int fromQString( QString from, astrbuf *buf );   // returns number of chars that failed the conversion or -1 on nomem
#endif
*/

}  // end aux namespace

// binary time constants to query with hindsight whether the given CPP macros had been set before at compile time
extern const bool COMPILED_with_UNLOCKED_STDIO;
extern const bool COMPILED_with_DEBUG_IO;
extern const bool COMPILED_with_SINGLE_IO_THREAD;
extern const bool COMPILED_with_NO_DEFAULT_IO_LOCK;
extern const bool COMPILED_with_UCONTEXT_SUPPORT;
status_int print_aux_config( aux::IOStreamRef out );   // print the above constants and return ~out;

//#if defined(_MSC_VER) && WORDSIZE == 64
//  #pragma warning (default: 4267)   // warning: convert size_t into smaller type
//#endif

#endif
