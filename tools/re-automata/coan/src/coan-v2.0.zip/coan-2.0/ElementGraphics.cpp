
#ifdef QT_CORE_LIB
  #include <QtGui/QPainter>
  #include <QtGui/QFontMetrics>
  #include <QtCore/QtMath>
  #include <QtWidgets/QWidget>
 #include <QtCore/QTextStream>
#endif

#include "automatdef.h"



using namespace std;
//using namespace aux;

//
//     Qt based methods 
// ========================



#ifdef QT_CORE_LIB

//
//     GraphElement::  & Automaton::
// ================================


u_iword emptyCursor[1+(65537-1)/(sizeof(u_iword)*4)] = { 0 };

// CursorRefLen: account for an additional u_iword if len would fit exactly into the last long
//               see nextCursor: incrementation + deref of reference must be possible after the last used value
#define CursorRefLen(len) (int)(1+(len+1-1)/CursorPack)

// setCursor: allocated array gets deallocated on FA_/MS_Runtime::freeMemSub

void GraphElement::setCursor( int relpos, int type ) {
  int len = execLength(); u_iword *ref; type &= 3;
  if( len < CursorPack ) ref = &cursorSet.val; else { 
    if(!cursorSet.ref) cursorSet.ref = (u_iword*) calloc(CursorRefLen(len),sizeof(u_iword));
    ref = cursorSet.ref + relpos/CursorPack; relpos %= CursorPack; 
  }
  *ref |= type << (relpos*2);
}

void GraphElement::resetCursor() {
  int len = execLength();
  if( len < CursorPack ) cursorSet.val = 0; 
  else if(cursorSet.ref) for( int i=0; i < CursorRefLen(len); i++ ) cursorSet.ref[i] = 0;
}


QFont elmLabelFont;

class TextExtentCallStruct { public:
  QFontMetricsF *metric[3], metric0,metric1,metric2; QFont font[3];
  struct TextExtent rect; qreal upperIndex, lowerIndex; bool hadUpperIndex; int lowerIndexCount;
  TextExtentCallStruct( QPaintDevice *device, QFont elmLabelFont, QFont sub1Font, QFont sub2Font ) : 
    metric0(QFontMetricsF(elmLabelFont,device)), metric1(QFontMetricsF(sub1Font,device)), metric2(QFontMetricsF(sub2Font,device)),
#ifdef _MSC_VER
    rect( { metric0.ascent(), metric0.descent(), 0 } ) { 
#else
    rect( { .ascent = metric0.ascent(), .descent = metric0.descent(), .width = 0 } ) { 
#endif
      metric[0] = &metric0; metric[1] = &metric1; metric[2] = &metric2;
      font[0] = elmLabelFont; font[1] = sub1Font; font[2] = sub2Font;
      upperIndex = lowerIndex = 0; hadUpperIndex = false; lowerIndexCount = 0;
  };
};

void getTextExtentCallBack( int baseline, int subscriptcount, bool overlined, estr_const string, void *data ) {
  TextExtentCallStruct *d = (TextExtentCallStruct*)data;
  if( baseline == -3 ) { 
    d->rect.width += qMax(d->upperIndex,d->lowerIndex) + 3;
    d->upperIndex = d->lowerIndex = 0;
    return; 
  }
  int subcount = (baseline!=0) + subscriptcount; int index; if(subcount>2) index = 2; else index = subcount;
  QString text; IOStream(&text) << string;
  if( baseline == 0 ) {
    d->rect.width += qMax(d->upperIndex,d->lowerIndex) + (*d->metric[index]).width(text) + 2;
    d->upperIndex = d->lowerIndex = 0;
  } else if( baseline == -1 ) {
    if(!d->hadUpperIndex) { d->rect.ascent += (*d->metric[1]).ascent()*2/5; d->hadUpperIndex = true; }
    d->upperIndex += (*d->metric[index]).width(text);
  } else if( baseline == +1 ) {
    if( d->lowerIndexCount < subcount ) {  // indices must be drawn sequentially; i.e. before index level #2 comes something must be printed at index level #1
      qreal increment = (*d->metric[index]).ascent()/2 + (*d->metric[index]).descent() - (*d->metric[index-1]).descent();
      if( increment > 0 ) d->rect.descent += increment; 
      d->lowerIndexCount++; 
    }
    d->lowerIndex += (*d->metric[index]).width(text);
  }
}

struct TextExtent GraphElement::getTextExtent( QPaintDevice *device ) const {
  QFont sub1Font(elmLabelFont), sub2Font(elmLabelFont); sub1Font.setPointSize(elmLabelFont.pointSize()-2); sub2Font.setPointSize(elmLabelFont.pointSize()-3);
  struct TextExtentCallStruct data( device, elmLabelFont, sub1Font, sub2Font );
  callbackPrint( getTextExtentCallBack,  &data );
  data.rect.width += qMax(data.upperIndex,data.lowerIndex);
  return data.rect;
}

class drawTextCallStruct { public:
  QPainter *painter; QFontMetricsF *metric[3], metric0,metric1,metric2; QFont font[3];
  qreal ypos; qreal upperXPos, lowerXPos;
  drawTextCallStruct( QPainter *painter, QPointF pos, QFont elmLabelFont, QFont sub1Font, QFont sub2Font ) : 
    painter(painter), ypos(pos.y()), metric0(QFontMetricsF(elmLabelFont,painter->device())), metric1(QFontMetricsF(sub1Font,painter->device())), metric2(QFontMetricsF(sub2Font,painter->device())) { 
      metric[0] = &metric0; metric[1] = &metric1; metric[2] = &metric2;
      font[0] = elmLabelFont; font[1] = sub1Font; font[2] = sub2Font;
      upperXPos = pos.x(); lowerXPos = pos.x();
  };
};

QTextStream qcerr(stderr);

void drawTextCallBack( int baseline, int subscriptcount, bool overlined, estr_const string, void *data ) {
  drawTextCallStruct *d = (drawTextCallStruct*)data;
  if( baseline == -3 ) {  // print cursor
    d->painter->setPen(QPen(QColor(0xD0,0,0)));
    qreal xpos = qMax( d->upperXPos, d->lowerXPos ) + 1, ypos = d->ypos;
    d->painter->drawLine( xpos, ypos - d->metric0.ascent(), xpos, ypos + d->metric0.descent() );
    if( subscriptcount > 0 ) {
      d->painter->drawLine( xpos-1, ypos - d->metric0.ascent(), xpos+1, ypos - d->metric0.ascent() );
      d->painter->drawLine( xpos-1, ypos + d->metric0.descent(), xpos+1, ypos + d->metric0.descent() );
    }
    d->painter->setPen(QPen(Qt::black));
    xpos += 2; d->upperXPos = xpos; d->lowerXPos = xpos;
    return; 
  }
  int subcount = (baseline!=0) + subscriptcount; int index; if(subcount>2) index = 2; else index = subcount;
  QString text = toQString(string); // IOStream(&text) << string;
  d->painter->setFont(d->font[index]);
  //qcerr << index << ": " << text << ", ";
  if( baseline == 0 ) {
    qreal xpos = qMax( d->upperXPos, d->lowerXPos );
    d->painter->drawText( xpos, d->ypos, text );
    qreal new_xpos = xpos + (*d->metric[0]).width(text) + 2;
    //qcerr << xpos << "->" << new_xpos << ", ";
    if(overlined) { qreal ylinepos = d->ypos - (*d->metric[0]).ascent() + 0; d->painter->drawLine( xpos, ylinepos, new_xpos, ylinepos ); }   // + 0: under windows there is no additional space between the top of a character and its ascent
    d->upperXPos = new_xpos; d->lowerXPos = new_xpos;
  } else if( baseline == -1 ) {  // no overlining available for superscripts; not needed up to now
    qreal thisYPos = d->ypos - (*d->metric[0]).ascent(); for( int i = 1; i <= subcount; i++ ) thisYPos += (*d->metric[i<2?i:2]).ascent() * 3 / 5;
    d->painter->drawText( d->upperXPos, thisYPos, text );
    d->upperXPos += (*d->metric[index]).width(text);
  } else if( baseline == +1 ) {
    qreal thisYPos = d->ypos; for( int i = 1; i <= subcount; i++ ) thisYPos += (*d->metric[i<2?i:2]).ascent() / 2;
    d->painter->drawText( d->lowerXPos, thisYPos, text );
    qreal new_xpos = d->lowerXPos + (*d->metric[index]).width(text);
    if(overlined) { qreal ylinepos = d->ypos - (*d->metric[0]).ascent() - 3; d->painter->drawLine( d->lowerXPos, ylinepos, new_xpos, ylinepos ); }
    d->lowerXPos = new_xpos;
  }
  //qcerr << "\n"; qcerr.flush();
}

void GraphElement::drawText( QPainter *painter ) const {
  QFont sub1Font(elmLabelFont), sub2Font(elmLabelFont); sub1Font.setPointSize(elmLabelFont.pointSize()-2); sub2Font.setPointSize(elmLabelFont.pointSize()-3);
  //qcerr << relTextPos.x() << "," << relTextPos.y() << "\n"; qcerr.flush();
  painter->setPen(QPen(Qt::black)); painter->setBrush(QBrush(Qt::NoBrush));
  struct drawTextCallStruct data( painter, pos + relTextPos, elmLabelFont, sub1Font, sub2Font );
  callbackPrint( drawTextCallBack, &data );
}

echar subscript_chars[3] = { subscript_char, close_subscripts_char, ' ' };

struct TextExtent getVariableTextExtent( QPainter *painter, estr_const text ) {
  QFont sub1Font(painter->font()), sub2Font(painter->font()); sub1Font.setPointSize(painter->font().pointSize()-2); sub2Font.setPointSize(painter->font().pointSize()-3);
  struct TextExtentCallStruct data( painter->device(), painter->font(), sub1Font, sub2Font );
  int i=0, j, subcount = 0;
  while( i < text.length ) {
    j = text.find_first_of( estr_const(subscript_chars,subcount>0?3:2), i );
    getTextExtentCallBack( subcount>0 ? 1 : 0, subcount>1 ? subcount-1 : 0, false, text.sub(i,j-i), &data );
    if( j < text.length ) switch(text.chars[j]) { case subscript_char: subcount++; break; case close_subscripts_char: subcount = 0; break; case ' ': subcount--; break; default: break; };
    i = j + 1;
  }
  data.rect.width += qMax(data.upperIndex,data.lowerIndex);
  return data.rect;
}

void drawVariableText( QPainter *painter, QPointF pos, estr_const text ) {
  QFont sub1Font(painter->font()), sub2Font(painter->font()); sub1Font.setPointSize(painter->font().pointSize()-2); sub2Font.setPointSize(painter->font().pointSize()-3);
  struct drawTextCallStruct data( painter, pos, painter->font(), sub1Font, sub2Font );
  int i=0, j, subcount = 0;
  while( i < text.length ) {
    j = text.find_first_of( estr_const(subscript_chars,subcount>0?3:2), i );
    drawTextCallBack( subcount>0 ? 1 : 0, subcount>1 ? subcount-1 : 0, false, text.sub(i,j-i), &data );
    if( j < text.length ) switch(text.chars[j]) { case subscript_char: subcount++; break; case close_subscripts_char: subcount = 0; break; case ' ': subcount--; break; default: break; };
    i = j + 1;
  }
  painter->setFont(data.font[0]);
}

QString variableTextAsQString( estr_const text ) {
  QString result = ""; int i=0, j, subcount = 0;
  while( i < text.length ) {
    j = text.find_first_of( estr_const(subscript_chars,subcount>0?3:2), i );
    result.append(toQString(text.sub(i,j-i)));
    if( j < text.length ) switch(text.chars[j]) { 
      case subscript_char: result.append("<sub>"); subcount++; break; 
      case close_subscripts_char: while(subcount>0) { result.append("</sub>"); subcount--; } break; 
      case ' ': result.append("</sub>"); subcount--; break; 
      default: break; 
    };
    i = j + 1;
  }
  return result;
}

void GraphElement::doUpdateGeometry( QPaintDevice *d, struct TextExtent ext ) {
  relTextPos.setX( -( ext.width / 2 ) );
  //qcerr << ( ext.descent >> 1 ) << "," << ( ext.ascent >> 1  ) << "," << ( ( ext.descent - ext.ascent ) >> 1 )  << "\n";  
  relTextPos.setY( ( ext.ascent - ext.descent ) / 2  );
}

bool debug = false;

void Node::doUpdateGeometry( QPaintDevice *d, struct TextExtent ext ) {
  GraphElement::doUpdateGeometry( d, ext );
  for( Edges::iterator ie = pred.begin(); ie != pred.end(); ie++ ) { Edge *e = *ie; if(e) e->trackNodes(e->from->pos,this->pos); }
  for( Edges::iterator ie = succ.begin(); ie != succ.end(); ie++ ) { Edge *e = *ie; if(e) e->trackNodes(this->pos,e->to->pos); }      // if(((MS_Edge*)e)->content==(achar*)"#") debug=true; else debug=false; 
}

void Automaton::updateGeometry( QPaintDevice *d ) {
  for(std::list<Node*>::iterator in = allNodes.begin(); in != allNodes.end(); in++ ) (*in)->updateGeometry(d);
  for(list<Edge*>::iterator ie = allEdges.begin(); ie != allEdges.end(); ie++ ) (*ie)->updateGeometry(d);
}

//
//     Edge:: 
// =================

// enum Modus { normal = 0, selected = 1, erroneous = 2, erroneous_selected = 3, inexec = 4, inexec_selected = 5, inexec_erroneous = 6, inexec_erroneous_selected = 7, moving = 8, creating_edge = 9 };
// extern struct PaintSettings { QPen pen; QBrush brush; } paintsettings[10];
PaintSettings paintsettings[10] = { { QPen(Qt::black,1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(Qt::white,Qt::SolidPattern) },	    // normal
		                    { QPen(Qt::black,3,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(Qt::white,Qt::SolidPattern) },	    // selected
		                    { QPen(QColor(0xC0,0,0),1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xE0,0xE0),Qt::SolidPattern) },  // erroneous
		                    { QPen(QColor(0xC0,0,0),3,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xE0,0xE0),Qt::SolidPattern) },  // erroneous_selected
		                    { QPen(QColor(0,0xA0,0),2,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xFF,0x88),Qt::SolidPattern) },    // inexec
		                    { QPen(QColor(0,0x80,0),3,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xFF,0x88),Qt::SolidPattern) },    // inexec_selected
		                    { QPen(QColor(0x90,0x30,0),1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xE0,0xE0),Qt::SolidPattern) },	// inexec_erroneous
		                    { QPen(QColor(0x90,0x30,0),3,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(QColor(0xFF,0xE0,0xE0),Qt::SolidPattern) },	// inexec_erroneous_selected
		                    { QPen(Qt::black,1,Qt::DashLine,Qt::RoundCap,Qt::RoundJoin), QBrush(Qt::NoBrush) },				// moving
				    { QPen(Qt::black,1,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin), QBrush(Qt::white,Qt::SolidPattern) } };	// creating edge

void GraphElement::setNormalModus() {
  if( errpos < 0 ) modus = normal; else modus = erroneous; 
}

QPen lineCubicHandle = QPen(QColor(0,0xE0,0),2);


QPainterPath Edge::painterPath() const {
  QPainterPath path;
  path.moveTo(track[0]);
  int i; for( i = 0; i < (int)track.size()-3; i+=3 )
    path.cubicTo(track[i+1],track[i+2],track[i+3]);
  if(unlikely(i!=track.size()-1)) {
    cout << "Edge" << from->nodenum << "-" << to->nodenum << ": " << track.size() << aux::endl;
    for( i = 0; i < (int)track.size(); i++ ) cout << track[i].x() << ";" << track[i].y() << aux::endl;
    assert(i==track.size()-1);
  }
  return path;
}

QPainterPath Edge::doublePainterPath() const {
  QPainterPath path;
  path.moveTo(track[0]);
  int i; for( i = 0; i < (int)track.size()-3; i+=3 )
    path.cubicTo(track[i+1],track[i+2],track[i+3]);
  assert(i==track.size()-1);
  for( i-=3; i>=0; i-=3 )
    path.cubicTo(track[i+2],track[i+1],track[i]);
  assert(i==-3);
  return path;
}

void Edge::draw( QPainter *painter, Automaton *atmt ) const {
  painter->setPen(paintsettings[modus].pen); //cout << getContent() << "(" << modus << "), " << IOFlush();
  painter->drawPath(painterPath()); int i = track.size()-1; 
  if( modus == Modus::creating_edge ) return;
  QPointF acclivity = track[i] - track[i-1];
  qreal alpha = qAtan2( acclivity.y(), acclivity.x() );
  painter->drawLine( track[i].x(), track[i].y(), track[i].x() + arrowLen * qCos(alpha + 5/6.0*M_PI), track[i].y()  + arrowLen * qSin(alpha + 5/6.0*M_PI) );
  painter->drawLine( track[i].x(), track[i].y(), track[i].x() + arrowLen * qCos(alpha - 5/6.0*M_PI), track[i].y()  + arrowLen * qSin(alpha - 5/6.0*M_PI) );
  if( modus ==  Modus::selected ) {
    for( i = 3; i < (int)track.size()-3; i+=3 ) {
      painter->drawEllipse( track[i], handleRadius, handleRadius );
    }
    painter->setPen(lineCubicHandle); painter->setBrush(QBrush(Qt::white,Qt::SolidPattern));
    QPointF adjustPos = QPointF( -1, -1 );
    for( i = 0; i < (int)track.size() - 3; i+=3 ) {
      painter->drawLine( track[i]+adjustPos, track[i+1]+adjustPos );
      painter->drawEllipse( track[i+1]+adjustPos, handleRadius, handleRadius );
      if( i+3 < (int)track.size() ) {
	painter->drawLine( track[i+3]+adjustPos, track[i+2]+adjustPos );
	painter->drawEllipse( track[i+2]+adjustPos, handleRadius, handleRadius );
    } }
  }
  painter->fillRect( pos.x()-a, pos.y()-b, 2*a, 2*b, paintsettings[modus].brush );  // QBrush(Qt::white,Qt::SolidPattern))
  GraphElement::drawText(painter);
}

QRectF QRectF_addMargins( QRectF source, qreal margin ) {
  source.moveLeft( source.x() - margin );
  source.moveTop( source.y() - margin  );
  source.setWidth( source.width() + margin + margin );
  source.setHeight( source.height() + margin + margin );
  return source;
}

QRectF Edge::boundingRect() const {
  // painterPath().controlPointRect() and painterPath().boundingRect() return faulty rectangle
  return QRectF_addMargins(painterPath().controlPointRect(),isThereRadius).united(GraphElement::boundingRect());
}

bool Edge::isThere( QPointF pos ) const {
  QRectF labelRect = GraphElement::boundingRect(); if( labelRect.contains(pos) )return true;
  QPainterPath path = doublePainterPath(); // if( !QRectF_addMargins(path.controlPointRect(),isThereRadius).contains(pos) ) return false;
  QPainterPath ellipse; ellipse.addEllipse( pos, isThereRadius, isThereRadius );
  return ellipse.intersects(path);
  //return path.intersects(ellipse);
  //QRectF cursor( pos.x() - isThereRadius, pos.y() - isThereRadius, 2*isThereRadius, 2*isThereRadius ); 
  //return path.intersects(cursor);
}

void Edge::doUpdateGeometry( QPaintDevice *d, struct TextExtent ext ) {
  if( track.size() < 4 && from && to ) {
    track.resize(4);
    track[0] = from->getSecant(to->pos);
    track[3] = to->getSecant(from->pos);
    track[1] = track[0]*(3/4.0) + track[3]*(1/4.0);
    track[2] = track[0]*(1/4.0) + track[3]*(3/4.0);
    pos = ( track[0] + track[3] ) / 2;
  } else pos = painterPath().pointAtPercent(0.5);
  a = ext.width / 2 + 6; b = ( ext.ascent + ext.descent ) / 2 + 6;
  GraphElement::doUpdateGeometry(d,ext);
}

qreal vector_length( QPointF vec ) { return qSqrt( vec.x()*vec.x() + vec.y() * vec.y() ); }

void Edge::trackEdges( QPointF *newpos ) {
  int i, j, newposCount = (track.size()+2) / 3;
  QPointF acclivityBegin, acclivityEnd, connection;
  qreal alpha, beta, gamma, delta; qreal lenSum, lenBegin, lenEnd;
  i = newposCount - 1;
  newpos[0] = from->pos; newpos[i] = to->pos;
  newpos[0] = from->getSecant(newpos[1]); newpos[i] = to->getSecant(newpos[i-1]);
  for( i=0, j=0; i < newposCount-1; i++, j+=3 ) {
    if( track[j+0] == newpos[i+0] && track[j+3] == newpos[i+1] ) continue;
    acclivityBegin = track[j+1] - track[j+0]; acclivityEnd = track[j+2] - track[j+3]; connection = track[j+3] - track[j+0];
    alpha = qAtan2( acclivityBegin.y(), acclivityBegin.x() ); beta = qAtan2( acclivityEnd.y(), acclivityEnd.x() );
    gamma = qAtan2( connection.y(), connection.x() ); alpha -= gamma;  beta -= gamma;
    lenSum = vector_length(connection); lenBegin = vector_length(acclivityBegin)/lenSum; lenEnd = vector_length(acclivityEnd)/lenSum;
    connection = newpos[i+1] - newpos[i+0]; delta = qAtan2( connection.y(), connection.x() ); alpha += delta; beta += delta;
    lenSum = vector_length(connection); lenBegin *= lenSum; lenEnd *= lenSum;
    track[j+1] = QPointF( newpos[i+0].x() + lenBegin * qCos(alpha), newpos[i+0].y() + lenBegin * qSin(alpha) );
    track[j+2] = QPointF( newpos[i+1].x() + lenEnd * qCos(beta), newpos[i+1].y() + lenEnd * qSin(beta) );
  }
  for( i=0, j=0; i < newposCount-1; i++, j+=3 ) {
    track[j+0] = newpos[i+0];
    track[j+3] = newpos[i+1];
  }
  pos = painterPath().pointAtPercent(0.5);
}

void Edge::trackNodes( QPointF oldFromNodePos, QPointF oldToNodePos ) {
 /* if( track.size() == 4 && false ) {
    QPointF acclivityBegin = track[1] - track[0], acclivityEnd = track[2] - track[3], conn_before = track[3] - track[0];
    qreal alpha = qAtan2( acclivityBegin.y(), acclivityBegin.x() ), beta = qAtan2( acclivityEnd.y(), acclivityEnd.x() );
    qreal gamma = qAtan2( conn_before.y(), conn_before.x() ); alpha -= gamma;  beta -= gamma;
    qreal lenSum = vector_length(conn_before), lenBegin = vector_length(acclivityBegin)/lenSum, lenEnd = vector_length(acclivityEnd)/lenSum;
    track[0] = from->getSecant(to->pos);
    track[3] = to->getSecant(from->pos);
    QPointF connection = track[3] - track[0]; qreal delta = qAtan2( connection.y(), connection.x() ); alpha += delta; beta += delta;
    lenSum = vector_length(connection); lenBegin *= lenSum; lenEnd *= lenSum;
    track[1] = QPointF( track[0].x() + lenBegin * qCos(alpha), track[0].y() + lenBegin * qSin(alpha) );
    track[2] = QPointF( track[3].x() + lenEnd * qCos(beta), track[3].y() + lenEnd * qSin(beta) );
    //track[1] = ( track[0] + track[3] ) /2 ;
    //track[2] = ( track[0] + track[3] ) /2 ;
    pos = painterPath().pointAtPercent(0.5); // qcerr << "b"; qcerr.flush();
  }*/
  if( track.size() < 4 ) return; // Edge has not yet been initialized by doUpdateGeometry;
  if( !from || !to ) return;  // Edge has not yet been set up to connect two nodes
  int i, j, newposCount = (track.size()+2) / 3; QPointF *newpos = (QPointF*)malloc(sizeof(QPointF)*newposCount); // QPointF newpos[ newposCount ];
  QPointF fromMoved = from->pos - oldFromNodePos, toMoved = to->pos - oldToNodePos;
  for( i=1, j=3; i < newposCount-1; i++, j+=3 ) {
    qreal midFactor = (qreal)i / (qreal)(newposCount-1);
    newpos[i] = track[j] + midFactor * fromMoved + (1-midFactor) * toMoved;
    //newpos[i] = track[j];
  }
  Edge::trackEdges( newpos );
  free(newpos);
}

int Edge::setTrack( const std::vector<int> *data ) {
  std::vector<int>::const_iterator cur = data->begin(); int x, y, count = data->size(), errpos;
  if( count < 2 ) return 0;
  track.clear(); track.reserve(count/2); 
  x = *cur++; y = *cur++; track.push_back( QPointF( x, y ) );
  count -= 2;
  errpos = count % 6; count /= 6; if(errpos) errpos = 2 + count * 6 + errpos; else errpos = -1;
  while( count-- ) {
    x = *cur++; y = *cur++; track.push_back( QPointF( x, y ) );
    x = *cur++; y = *cur++; track.push_back( QPointF( x, y ) );
    x = *cur++; y = *cur++; track.push_back( QPointF( x, y ) );
  }
  return errpos;
}

void Edge::addLinearTrackNode( QPointF pos ) {
  if(track.empty()) { track.push_back(pos); return; }
  QPointF back = track.back();
  track.push_back( QPointF( back.x()*3/4 + pos.x()/4, back.y()*3/4 + pos.y()/4 ) );
  track.push_back( QPointF( back.x()/4 + pos.x()*3/4, back.y()/4 + pos.y()*3/4 ) );
  track.push_back( pos );
}

int Edge::setLinearTrack( const std::vector<int> *data ) {
  std::vector<int>::const_iterator cur = data->begin(); int count = data->size(), errpos;
  errpos = count % 2; count /= 2; if(errpos) errpos = count * 2 + 1; else errpos = -1;
  track.clear(); track.reserve(count); 
  while( count-- ) {
    int x = *cur++; int y = *cur++; addLinearTrackNode( QPointF( x, y ) );
  };  
  return errpos;
}

#endif

