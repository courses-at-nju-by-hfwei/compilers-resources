#include "MainWindow.h"

#include <QtWidgets/QLabel>
#include <QtGui/QKeyEvent>
#include <QtGui/QPainter>
#include <QtGui/QIcon>
#include <QtCore/QStringList>
#include <QtCore/QSettings>
#include <QtCore/QFileInfo>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QDesktopWidget>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QAction>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFileDialog>
#include <QtCore/QTimer>
#include "AtmtCanvas.h"
#include "InputSelector.h"
#include "AtmtExec.h"
#include "ExecEnv.h"
#include "TuringMachine.h"     // check whether current automaton is a MS in order to hide/show additional buttons on ButtonSidebar in changeStack(int)
#include "MainAuxDialogs.h"
#include "SVGExport.h"
#include "Settings.h"

void MainWindow::saveCurrentDescription( QTreeWidgetItem *previous ) {
  if(!previous) return;
  struct AtmtTreeNode *prev_node = qvariant_cast<struct AtmtTreeNode*>(previous->data(0,Qt::UserRole));
  prev_node->description = unescape_html( editDescription->toPlainText() );
}

void MainWindow::treeViewItemChanged( QTreeWidgetItem *current, QTreeWidgetItem *previous ) {
  saveCurrentDescription(previous);
  if(!current) { setAutomaton(NULL); editDescription->clear(); viewDescription->clear(); return; }
  if( current == previous ) return;
  struct AtmtTreeNode *node = qvariant_cast<struct AtmtTreeNode*>(current->data(0,Qt::UserRole));
  setAutomaton(node->atmt);  // automaton must be set before setInputList
  if(node->atmt) {
    viewTape->setInputList( &node->default_inputs );
    viewTape->inputSelector->pickLast();
  }
  descriptionIsEdited = false; 
  editDescription->clear(); editDescription->insertPlainText( node->description );
  viewDescription->clear(); viewDescription->insertHtml( node->description );
  atmtTreeWidget->setFocus();
}

void FTextEdit::focusInEvent(QFocusEvent * event) {   // object is view description
  mainWindow->descriptionStack->setCurrentIndex(1);    // edit description
  mainWindow->editDescription->setFocus();
  if(!mainWindow->buttonDock) mainWindow->buttonDock = new ButtonDockWidget(mainWindow);
  mainWindow->buttonDock->show();
  mainWindow->descriptionIsEdited = true; 
}

void FPlainTextEdit::lostFocus(QWidget *lost_to) {  // object is edit description, because of ButtonDockWidget this is not the focusOutEvent handler
  setPlainText( unescape_html( toPlainText() ) );
  mainWindow->viewDescription->clear(); mainWindow->viewDescription->insertHtml(mainWindow->editDescription->toPlainText());
  mainWindow->descriptionStack->setCurrentIndex(0);  // view description
  if(mainWindow->buttonDock) mainWindow->buttonDock->hide();
  mainWindow->descriptionIsEdited = false; 
}

void MainWindow::focusChanged( QWidget *old, QWidget *now ) {
  //if( descriptionStack->currentIndex() == 0 ) return; // editDescription not visible
  if( ( old == editDescription || ( old && old == buttonDock ) ) && \
      now != editDescription && now != buttonDock && now != NULL ) editDescription->lostFocus(now);
}

bool FPlainTextEdit::event(QEvent *event) {
  if( event->type() == QEvent::KeyPress ) {
    QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
    if( keyEvent->key() == Qt::Key_Tab ) {
      if( keyEvent->modifiers() ) insertPlainText("\t"); 
      else mainWindow->atmtTreeWidget->setFocus();
      return true;
    }
  }
  return QPlainTextEdit::event(event);
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ButtonDockWidget::ButtonDockWidget( MainWindow *mainWin ) : QWidget( mainWin, Qt::Tool ) {
  QVBoxLayout *mainLayout = new QVBoxLayout();
  QGridLayout *buttonGrid = new QGridLayout(); QPushButton *butt; int i=0, j=0;
  const char *butts[] = { "<sub>", "</sub>", "<sup>", "</sup>" };
  for( int k=0; k < sizeof(butts)/sizeof(const char*); k++ ) {
    butt = new QPushButton(butts[k]); butt->setFocusPolicy(Qt::NoFocus);
    connect( butt, SIGNAL(clicked()), mainWin, SLOT(buttonDockWidgetClicked()) );
    buttonGrid->addWidget( butt, i, j );
    j++; if( j > 1 ) { i++; j=0; }
  }
  mainLayout->addLayout(buttonGrid); i=0; j=0;
  buttonGrid = new QGridLayout();
  const echar specialChar[] = { concat_char, neq_char, range_char, setminus_char, leq_char, geq_char, subscript_char, close_subscripts_char };
  for( int k=0; k < sizeof(specialChar)/sizeof(echar); k++ ) {
    butt = new QuadrPushButton(QString(QChar(specialChar[k]))); butt->setFocusPolicy(Qt::NoFocus);
    connect( butt, SIGNAL(clicked()), mainWin, SLOT(buttonDockWidgetClicked()) );
    buttonGrid->addWidget( butt, i, j );
    j++; if( j > 5 ) { i++; j=0; }
  }
  for( echar c = first_greek_letter; c < first_greek_letter + greek_letter_num; c++ ) {
    if( !SymbolTable::isGreekVariable(c) && c != epsilon_letter ) continue;
    butt = new QuadrPushButton(QString(QChar(c))); butt->setFocusPolicy(Qt::NoFocus);
    connect( butt, SIGNAL(clicked()), mainWin, SLOT(buttonDockWidgetClicked()) );
    buttonGrid->addWidget( butt, i, j );
    j++; if( j > 5 ) { i++; j=0; }
  }
  mainLayout->addLayout(buttonGrid);
  setLayout(mainLayout);
  setWindowTitle(tr("symbol key buttons"));
}

void MainWindow::buttonDockWidgetClicked() {
  if( descriptionStack->currentIndex() == 0 ) return; // editDescription not visible
  QPushButton *pushbutton = qobject_cast<QPushButton*>(sender()); if(!pushbutton) return;
  QString instext = pushbutton->text();
  editDescription->insertPlainText(instext);
  setFocus(Qt::ActiveWindowFocusReason);   // does not work
  editDescription->setFocus(Qt::FocusReason::OtherFocusReason);
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

const char *MS_predef_machine[MS_predef_machine_count] = { " L^2", " R^2", " L:#", " R:#", " Copy_2"  };
const struct SubscriptedText MS_predef_machine_fmt[MS_predef_machine_count] = { SubscriptedText("L","2",""), SubscriptedText("R","2",""), 
  SubscriptedText("L","","#"), SubscriptedText("R","","#"), SubscriptedText("Copy","","2") };  //, SubscriptedText(), SubscriptedText() } ;

SubscriptedPushButton::SubscriptedPushButton( const struct SubscriptedText *st, QString resultText, QFont baseFont, QWidget *parent ) : 
			resultText(resultText), baseText(st->baseText), upperIdxText(st->upperIdxText), lowerIdxText(st->lowerIdxText), baseFont(baseFont), QPushButton(parent) {
  sub1Font = baseFont; sub1Font.setPointSize(baseFont.pointSize()-2);  
  QFontMetrics baseFontM(baseFont,this), sub1FontM(sub1Font,this);
  int minwidth = baseFontM.width(baseText) + qMax( sub1FontM.width(lowerIdxText), sub1FontM.width(upperIdxText) ) + baseFontM.averageCharWidth()/3;
  int minheight = baseFontM.ascent() + baseFontM.descent();
  minheight += sub1FontM.ascent()*2/5;  // account for upper index height
  if( baseFontM.descent() < sub1FontM.ascent()/2 + sub1FontM.descent() ) // account for lower index height
    minheight += sub1FontM.ascent()/2 + sub1FontM.descent() - baseFontM.descent();
  setMinimumWidth( minwidth );
  setMinimumHeight( minheight );
};

void SubscriptedPushButton::paintEvent(QPaintEvent *event) {
  QPushButton::paintEvent(event);
  QPainter painter(this);
  QFontMetrics baseFontM(baseFont,this), sub1FontM(sub1Font,this);
  int basetxtlen = baseFontM.width(baseText);
  int posx = ( width() - basetxtlen - qMax( sub1FontM.width(lowerIdxText), sub1FontM.width(upperIdxText) ) ) / 2;
  int posy = baseFontM.ascent() + sub1FontM.ascent()*2/5;
  painter.drawText( posx, posy, baseText );
  posx += basetxtlen;
  // see also ElementGraphics.cpp / drawTextCallBack
  int posy_upper = posy - baseFontM.ascent() + sub1FontM.ascent()*3/5;
  int posy_lower = posy + sub1FontM.ascent()/2;
  painter.drawText( posx, posy_upper, upperIdxText );
  painter.drawText( posx, posy_lower, lowerIdxText );
}


ButtonSidebar::ButtonSidebar( QWidget *receiver ) {
  QVBoxLayout *mainLayout = new QVBoxLayout(); int i, j; QPushButton *butt;
  mainLayout->addStretch();
   QGridLayout *MS_predefs_Layout = new QGridLayout(); i=0; j=0; SubscriptedPushButton *ssbutt;
   for( int k=0; k < MS_predef_machine_count; k++ ) {
     ssbutt = new SubscriptedPushButton ( &MS_predef_machine_fmt[k], MS_predef_machine[k], elmLabelFont, this );
     MS_predef_machines_button[k] = ssbutt;
     connect( ssbutt, SIGNAL(clicked()), receiver, SLOT(unicodeLetterButtonClicked()) );
     MS_predefs_Layout->addWidget( ssbutt, i, j );
     j++; if( j > 5 ) { i++; j=0; }
   }
  mainLayout->addLayout(MS_predefs_Layout);
  mainLayout->addStretch();
   QGridLayout *specialCharsLayout = new QGridLayout(); i=0; j=0;
   echar specialChar[] = { concat_char, neq_char, range_char, setminus_char, leq_char, geq_char, subscript_char, close_subscripts_char };
   for( int k=0; k < sizeof(specialChar)/sizeof(echar); k++ ) {
     butt = new QPushButton(QString(QChar(specialChar[k])));
     connect( butt, SIGNAL(clicked()), receiver, SLOT(unicodeLetterButtonClicked()) );
     specialCharsLayout->addWidget( butt, i, j );
     j++; if( j > 5 ) { i++; j=0; }
   }
  mainLayout->addLayout(specialCharsLayout);
  mainLayout->addStretch();
   QGridLayout *greekButtonLayout = new QGridLayout(); i=0; j=0;
   for( echar c = first_greek_letter; c < first_greek_letter + greek_letter_num; c++ ) {
     if( !SymbolTable::isGreekVariable(c) && c != epsilon_letter ) continue;
     butt = new QPushButton(QString(QChar(c)));
     connect( butt, SIGNAL(clicked()), receiver, SLOT(unicodeLetterButtonClicked()) );
     greekButtonLayout->addWidget( butt, i, j );
     j++; if( j > 5 ) { i++; j=0; }
   }
  mainLayout->addLayout(greekButtonLayout);
  mainLayout->addStretch();
  setLayout(mainLayout);
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MainWindow::MainWindow() : treeBase() {  // crash if treeBase constructor not called explicitly
  statusBar()->addWidget( statusBarLabel = new QLabel() );
  treeViewSplitter = new QSplitter(Qt::Horizontal);
  treeViewSplitter->setHandleWidth(4);
   descriptionSplitter = new QSplitter(Qt::Vertical);
   descriptionSplitter->setHandleWidth(4);
    leftstack = new QStackedWidget();
     atmtTreeWidget = new AtmtTreeWidget(&treeBase);
     connect( atmtTreeWidget, SIGNAL(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)), this, SLOT(treeViewItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)) );
    leftstack->addWidget(atmtTreeWidget);
   descriptionSplitter->addWidget(leftstack);
    descriptionStack = new QStackedWidget();
     viewDescription = new FTextEdit(this); viewDescription->setReadOnly(true); descriptionStack->addWidget(viewDescription);
     editDescription = new FPlainTextEdit(this); descriptionStack->addWidget(editDescription);
     connect( editDescription, SIGNAL(textChanged()), this, SLOT(setModifiedIfEditingDescription()) );
   descriptionSplitter->addWidget(descriptionStack);
  treeViewSplitter->addWidget(descriptionSplitter);
   mainstack = new QStackedWidget();
    viewOnlyAtmt = new AtmtWatch(this);
    QScrollArea *viewOnlyAtmtScroll = new QScrollArea(); viewOnlyAtmtScroll->setWidget(viewOnlyAtmt); viewOnlyAtmtScroll->setWidgetResizable(true);
   mainstack->addWidget(viewOnlyAtmtScroll);
    editAtmt = new AtmtCanvas();
    connect( editAtmt, SIGNAL(changed()), this, SLOT(setModified()) );
    QScrollArea *editAtmtScroll = new QScrollArea(); editAtmtScroll->setWidget(editAtmt); editAtmtScroll->setWidgetResizable(true);
   mainstack->addWidget(editAtmtScroll);
    tapeSplitter = new QSplitter(Qt::Vertical);
    tapeSplitter->setHandleWidth(4);
     viewAtmt = new AtmtWatch(this); viewTape = new TapeWatch();
     QScrollArea *viewAtmtScroll = new QScrollArea(); viewAtmtScroll->setWidget(viewAtmt); viewAtmtScroll->setWidgetResizable(true);
     QScrollArea *viewTapeScroll = new QScrollArea(); viewTapeScroll->setWidget(viewTape); viewTapeScroll->setWidgetResizable(true);
    tapeSplitter->addWidget(viewAtmtScroll);
    tapeSplitter->addWidget(viewTapeScroll);
    tapeSplitter->setStretchFactor(0,1);
   mainstack->addWidget(tapeSplitter);
    buttonSidebar = new ButtonSidebar(editAtmt);
   leftstack->addWidget(buttonSidebar);
    addTapeView = new TapeWatch(true);
    QScrollArea *addTapeViewScroll = new QScrollArea(); addTapeViewScroll->setWidget(addTapeView); addTapeViewScroll->setWidgetResizable(true);
   leftstack->addWidget(addTapeViewScroll);
     execEnv = new ExecEnv( viewAtmt, viewTape, addTapeView, statusBar(), statusBarLabel );
  treeViewSplitter->addWidget(mainstack);
  treeViewSplitter->setStretchFactor(1,1);
  setCentralWidget(treeViewSplitter);
  viewQuickHelpDialog = NULL; selectNewAtmt = NULL; atmtSettings = NULL; // viewCFSLDialog = NULL; 
  createActions();
  createMenus();
  enableExecMenu( mainstack->currentIndex() == 2 );  // false, 0 at the beginning
  setWindowTitle( tr("%1[*] - CoAn").arg(tr("Untitled")) );
  setWindowIcon(QIcon(":/images/coan-ico.png"));
  connect( qApp, SIGNAL(focusChanged(QWidget*,QWidget*)), this, SLOT(focusChanged(QWidget*,QWidget*)) );
  curFile = ""; isUntitled = true; descriptionIsEdited = false; buttonDock = NULL;
  setAttribute(Qt::WA_DeleteOnClose);
}

void MainWindow::setModified() { setWindowModified(true); }
void MainWindow::setModifiedIfEditingDescription() { if(descriptionIsEdited) setWindowModified(true); }

void MainWindow::createActions() {
  //QAction *newAction, *openAction, *saveAction, *saveAsAction, *closeAction, *exitAllAction, *quickHelp, *aboutAction, *aboutQtAction;
  //QAction *overviewMode, *editMode, *execMode, *moveMachineUp, *moveMachineDown, *deleteMachine, *newMachine, *machineSettings;
  //QAction *resetExec, *simulateExec, *singleStepExec, *runExec;
  //cout << (u_iword)this << aux::endl << IOFlush();
   newAction = new QAction(tr("&New"),this);
   newAction->setIcon(QIcon(":/images/new.png"));
   newAction->setShortcut(QKeySequence::New);
   newAction->setStatusTip(tr("Create a new automaton file"));
  connect( newAction, SIGNAL(triggered()), this, SLOT(newFile()) );
   openAction = new QAction(tr("&Open ..."),this);
   openAction->setIcon(QIcon(":/images/open.png"));
   openAction->setShortcut(QKeySequence::Open);
   openAction->setStatusTip(tr("Open an automaton file"));
  connect( openAction, SIGNAL(triggered()), this, SLOT(open()) );
   saveAction = new QAction(tr("&Save"),this);
   saveAction->setIcon(QIcon(":/images/save.png"));
   saveAction->setShortcut(QKeySequence::Save);
   saveAction->setStatusTip(tr("Save current automata collection to disk"));
  connect( saveAction, SIGNAL(triggered()), this, SLOT(save()) );
   saveAsAction = new QAction(tr("&Save As ..."),this);
   saveAsAction->setStatusTip(tr("Save current automata collection under a different filename"));
  connect( saveAsAction, SIGNAL(triggered()), this, SLOT(saveAs()) );
  for( int i=0; i < MaxRecentFiles; i++ ) {
    recentFileActions[i] = new QAction(this);
    recentFileActions[i]->setVisible(false);
    connect( recentFileActions[i], SIGNAL(triggered()), this, SLOT(openRecentFile()) );
  }
   importAction = new QAction(tr("&Import ..."),this);
   importAction->setStatusTip(tr("Import all automatons of the given file into the current automaton collection."));
  connect( importAction, SIGNAL(triggered()), this, SLOT(import()) );
   exportAction = new QAction(tr("&Export as SVG ..."),this);
   exportAction->setStatusTip(tr("Export the current automaton as Scalable Vector Graphic."));
  connect( exportAction, SIGNAL(triggered()), this, SLOT(SVGexport()) );
   closeAction = new QAction(tr("&Close"),this);
   closeAction->setShortcut(QKeySequence::Close);
   closeAction->setStatusTip(tr("Close this window"));
  connect( closeAction, SIGNAL(triggered()), this, SLOT(close()) );
   exitAllAction = new QAction(tr("E&xit All"),this);
   exitAllAction->setShortcut(tr("Ctrl+Q"));
   exitAllAction->setStatusTip(tr("Exit the whole application by closing all windows"));
  connect( exitAllAction, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()) );
   printAtmtTreeAction = new QAction(tr("Print Automaton &Tree on the Console"),this);
   printAtmtTreeAction->setStatusTip(tr("print the current internal automaton tree on the console for debugging; it should match the visible tree."));
  connect( printAtmtTreeAction, SIGNAL(triggered()), this, SLOT(printAtmtTree()) ); 
   quickHelpAction = new QAction(tr("View the Quick &Help Page"),this);
   quickHelpAction->setShortcut(Qt::Key_F1);
   quickHelpAction->setStatusTip(tr("View a quick help page with shortkeys, mouse button and syntax descriptions"));
  connect( quickHelpAction, SIGNAL(triggered()), this, SLOT(quickHelp()) ); 
   //viewCFSLAction = new QAction(tr("View &C-FSL v1.1"),this);
   //viewCFSLAction->setStatusTip(tr("View the Convertible Free Software License C-FSL v1.1"));
  //connect( viewCFSLAction, SIGNAL(triggered()), this, SLOT(viewCFSL()) ); 
   aboutAction = new QAction(tr("About &CoAn"),this);
   aboutAction->setStatusTip(tr("Show the About box for the CoAn application"));
  connect( aboutAction, SIGNAL(triggered()), this, SLOT(about()) ); 
   aboutQtAction = new QAction(tr("About &Qt"),this);
   aboutQtAction->setStatusTip(tr("Show the Qt library´s About box"));
  connect( aboutQtAction, SIGNAL(triggered()), qApp, SLOT(aboutQt()) ); 
   overviewModeAction = new QAction(tr("&Overview\tF4"),this);
   overviewModeAction->setStatusTip(tr("View and select one automata from the tree view"));
   overviewModeAction->setCheckable(true); overviewModeAction->setChecked(true);
  connect( overviewModeAction, SIGNAL(triggered()), this, SLOT(overviewMode()) );
   editModeAction = new QAction(tr("&Edit Automaton\tF4"),this);
   editModeAction->setStatusTip(tr("Change or edit the current automaton"));
   editModeAction->setCheckable(true);
  connect( editModeAction, SIGNAL(triggered()), this, SLOT(editMode()) );
   execModeAction = new QAction(tr("E&xecute\tF4"),this);
   execModeAction->setStatusTip(tr("Run or simulate the current automaton"));
   execModeAction->setCheckable(true);
  QActionGroup *modeGroup = new QActionGroup(this);
   modeGroup->addAction(overviewModeAction); modeGroup->addAction(editModeAction); modeGroup->addAction(execModeAction);
  connect( execModeAction, SIGNAL(triggered()), this, SLOT(execMode()) );
   moveMachineUpAction = new QAction(tr("Move Automaton Up\tAlt+Up"),this);
   moveMachineUpAction->setStatusTip(tr("move the current automaton one position up in the tree view"));
  connect( moveMachineUpAction, SIGNAL(triggered()), this, SLOT(moveMachineUp()) );
   moveMachineDownAction = new QAction(tr("Move Automaton Down\tAlt+Down"),this);
   moveMachineDownAction->setStatusTip(tr("move the current automaton one position down in the tree view"));
  connect( moveMachineDownAction, SIGNAL(triggered()), this, SLOT(moveMachineDown()) );
   deleteMachineAction = new QAction(tr("Delete Current Automaton\tEntf/Shift+Entf"),this);
   //deleteMachineAction->setShortcut(Qt::Key_Delete); - this would override the key definition when editing automata
   deleteMachineAction->setStatusTip(tr("delete the current automaton"));
  connect( deleteMachineAction, SIGNAL(triggered()), this, SLOT(askDeleteMachine()) );
   newMachineAction = new QAction(tr("&Create a New Automaton ..."),this);
   newMachineAction->setShortcut(Qt::Key_F10);
   newMachineAction->setStatusTip(tr("create a new automaton by selecting the automaton type from a list"));
  connect( newMachineAction, SIGNAL(triggered()), this, SLOT(newMachine()) );
   newDirectoryAction = new QAction(tr("&Create a New Directory"),this);
   newDirectoryAction->setShortcut(Qt::Key_F11);
   newDirectoryAction->setStatusTip(tr("create a new directory"));
  connect( newDirectoryAction, SIGNAL(triggered()), this, SLOT(newDirectory()) );
   machineSettingsAction = new QAction(tr("Machine &Settings"),this);
   machineSettingsAction->setShortcut(Qt::Key_F12);
   machineSettingsAction->setStatusTip(tr("edit the settings of the current machine"));
  connect( machineSettingsAction, SIGNAL(triggered()), this, SLOT(machineSettings()) );
   execResetAction = new QAction(tr("&Reset\tF5"),this); 
   execResetAction->setStatusTip(tr("reset the current execution state as to before execution"));
  connect( execResetAction, SIGNAL(triggered()), execEnv, SLOT(reset()) );
   execSimulateAction = new QAction(tr("&Simulate\tF6"),this); 
   execSimulateAction->setStatusTip(tr("make a singlestep every few fraction of a second"));
  connect( execSimulateAction, SIGNAL(triggered()), execEnv, SLOT(startstop_simulation()) );
   execSingleStepAction = new QAction(tr("Sin&gle Step\tF8"),this); 
   execSingleStepAction->setStatusTip(tr("make a singleton step forward in execution"));
  connect( execSingleStepAction, SIGNAL(triggered()), execEnv, SLOT(step_forward()) );
   execRunAction = new QAction(tr("&Run till result\tF9"),this); 
   execRunAction->setStatusTip(tr("execute until the automaton would terminate"));
  connect( execRunAction, SIGNAL(triggered()), execEnv, SLOT(run_till_result()) );
   execRunThroughAction = new QAction(tr("&Run through\tShift/Alt/Ctrl+F9"),this); 
   execRunThroughAction->setStatusTip(tr("execute until the automaton would terminate"));
  connect( execRunThroughAction, SIGNAL(triggered()), execEnv, SLOT(run_through()) );
   execSelectInputAction = new QAction(tr("Select &Input\tright/double click"),this); 
   execSelectInputAction->setStatusTip(tr("select the input tape and parameters"));
  connect( execSelectInputAction, SIGNAL(triggered()), execEnv, SLOT(change_tape()) );
   execOutcomeAction = new QAction(tr("View &Outcome\tright/double click"),this); 
   execOutcomeAction->setStatusTip(tr("view the outcome of a non deterministic Turing machine or from a machine schema"));
  connect( execOutcomeAction, SIGNAL(triggered()), execEnv, SLOT(view_outcome()) );
}

void MainWindow::enableTreeViewMenu(bool enabled) {
  moveMachineUpAction->setEnabled(enabled); moveMachineDownAction->setEnabled(enabled); deleteMachineAction->setEnabled(enabled); newMachineAction->setEnabled(enabled); 
  newDirectoryAction->setEnabled(enabled); 
}

void MainWindow::enableExecMenu(bool enabled) {
  //execMenu->setEnabled(enabled);
  execResetAction->setEnabled(enabled); execSimulateAction->setEnabled(enabled); execSingleStepAction->setEnabled(enabled); 
  execRunAction->setEnabled(enabled); execRunThroughAction->setEnabled(enabled); execSelectInputAction->setEnabled(enabled); execOutcomeAction->setEnabled(enabled);
}

void MainWindow::createMenus() {
  QMenu *fileMenu, *viewMenu, *editMenu, *execMenu, *helpMenu;
  fileMenu = menuBar()->addMenu(tr("&File"));
   fileMenu->addAction(newAction); fileMenu->addAction(openAction); fileMenu->addAction(saveAction); fileMenu->addAction(saveAsAction);
   separatorAction = fileMenu->addSeparator();
   for( int i=0; i < MaxRecentFiles; i++ )
     fileMenu->addAction(recentFileActions[i]);
   fileMenu->addSeparator();
   fileMenu->addAction(importAction); fileMenu->addAction(exportAction); fileMenu->addSeparator();
   fileMenu->addAction(closeAction); fileMenu->addAction(exitAllAction);
  viewMenu = menuBar()->addMenu(tr("&View"));
   viewMenu->addAction(overviewModeAction); viewMenu->addAction(editModeAction); viewMenu->addAction(execModeAction);
  editMenu = menuBar()->addMenu(tr("&Edit"));
   editMenu->addAction(moveMachineUpAction); editMenu->addAction(moveMachineDownAction); editMenu->addSeparator();
   editMenu->addAction(deleteMachineAction); editMenu->addAction(newMachineAction); editMenu->addAction(newDirectoryAction); editMenu->addSeparator(); 
   editMenu->addAction(machineSettingsAction);
  execMenu = menuBar()->addMenu(tr("&Execute"));
   execMenu->addAction(execResetAction); execMenu->addAction(execSimulateAction); execMenu->addAction(execSingleStepAction); 
   execMenu->addAction(execRunAction); execMenu->addAction(execRunThroughAction);
   execMenu->addSeparator();
   execMenu->addAction(execSelectInputAction);
   execMenu->addAction(execOutcomeAction);
  menuBar()->addSeparator();
  helpMenu = menuBar()->addMenu(tr("&Help"));
   QMenu *debugMenu = helpMenu->addMenu(tr("&Debug"));
    debugMenu->addAction(printAtmtTreeAction);
   helpMenu->addAction(quickHelpAction); /* helpMenu->addAction(viewCFSLAction); */ helpMenu->addSeparator();
   helpMenu->addAction(aboutAction); helpMenu->addAction(aboutQtAction);
}

bool MainWindow::okToContinue() {
  if(isWindowModified()) {
    int r = QMessageBox::warning( this, tr("CoAn"), tr("The document has been modified.\n" "Do you want to save your changes?"), 
				  QMessageBox::Yes|QMessageBox::No|QMessageBox::Cancel );
    if( r == QMessageBox::Yes ) return save();
    else if( r == QMessageBox::Cancel ) return false;
  }
  return true;
}

void MainWindow::writeSettings() {
  QSettings settings("elstel.org","CoAn");
  settings.beginGroup("mainWindow");
  settings.setValue("geometry",saveGeometry());
  settings.setValue( "treeViewSplitter", treeViewSplitter->saveState() );
  settings.setValue( "tapeSplitter", tapeSplitter->saveState() );
  settings.setValue( "descriptionSplitter", descriptionSplitter->saveState() );
  settings.endGroup();
  settings.setValue("recentFiles",recentFiles);
}

void MainWindow::readSettings() {
  QSettings settings("elstel.org","CoAn");
  settings.beginGroup("mainWindow");
  restoreGeometry( settings.value("geometry").toByteArray() );
  treeViewSplitter->restoreState( settings.value("treeViewSplitter").toByteArray() );
  tapeSplitter->restoreState( settings.value("tapeSplitter").toByteArray() );
  descriptionSplitter->restoreState( settings.value("descriptionSplitter").toByteArray() );
  settings.endGroup();
  recentFiles = settings.value("recentFiles").toStringList();
  updateRecentFileActions();
}

void MainWindow::closeEvent(QCloseEvent *event) {
  if(okToContinue()) { writeSettings(); event->accept(); }
  else event->ignore();
}

QString MainWindow::strippedFileName(QString fullFileName) {
  return QFileInfo(fullFileName).fileName();
}

void MainWindow::setCurrentFileName(QString fileName) {
  curFile = QFileInfo(fileName).absoluteFilePath(); QString showName;
  setWindowModified(false);
  if(curFile.isEmpty()) {
    showName = tr("Untitled"); isUntitled = true;
  } else { 
    showName = strippedFileName(curFile);
    recentFiles.removeAll(curFile);
    recentFiles.prepend(curFile);
    updateAllRecentFileActions();
    isUntitled = false;
  }
  setWindowTitle( tr("%1[*] - CoAn").arg(showName) );
}

bool MainWindow::openFile( QString filename ) {
  MainWindow *mainWin; 
  if( !isWindowModified() && isUntitled ) mainWin = this;
  else mainWin = new MainWindow(); 
  deleteAtmtTree( &mainWin->treeBase );
  if( !LoadAllAtmts( &mainWin->treeBase, filename.toUtf8().data() ) ) {
    statusBar()->showMessage( tr("Error loading file."), 2000 );
    if( mainWin != this ) delete mainWin;
    return false;
  }
  updateAllAutomataGeometry( mainWin->treeBase.atmtTree, mainWin->viewAtmt );
  mainWin->atmtTreeWidget->setModel( &mainWin->treeBase );
  mainWin->setCurrentFileName(filename);
  mainWin->show();
  mainWin->treeViewItemChanged( mainWin->atmtTreeWidget->currentItem(), NULL );
  if( mainWin->atmtTreeWidget->topLevelItemCount() > 0 )
    mainWin->atmtTreeWidget->setCurrentItem( mainWin->atmtTreeWidget->topLevelItem(0) );
  if( mainWin != this ) {
    statusBar()->showMessage( tr("File '%1' opened in new window.").arg(filename), 2000 );
  }; mainWin->statusBar()->showMessage( tr("File '%1' opened.").arg(filename), 2000 );
  return true;
}

QStringList recentFiles;

void MainWindow::openRecentFile() {
  QAction *action = qobject_cast<QAction*>(sender());
  if(action) openFile(action->data().toString());
}

void MainWindow::updateRecentFileActions() {
  QMutableStringListIterator i(recentFiles);
  while(i.hasNext()) if(!QFile::exists(i.next())) i.remove();
  for( int j=0; j < MaxRecentFiles; j++ ) {
    if( j < recentFiles.count() ) {
      QString text = tr("&%1 %2").arg( j+1 ).arg( strippedFileName(recentFiles[j]) );
      recentFileActions[j]->setText(text);
      recentFileActions[j]->setData(recentFiles[j]);
      recentFileActions[j]->setVisible(true);
    } else recentFileActions[j]->setVisible(false);
  }
  separatorAction->setVisible(!recentFiles.isEmpty());
}

void MainWindow::updateAllRecentFileActions() {
  foreach( QWidget *win, QApplication::topLevelWidgets() )
    if( MainWindow *mainWin = qobject_cast<MainWindow*>(win) )
      mainWin->updateRecentFileActions();
}

bool MainWindow::saveFile(QString filename) {
  saveCurrentDescription( atmtTreeWidget->currentItem() );
  bool success = SaveAllAtmts( &treeBase, filename.toUtf8().data() );
  if(!success) {
    QMessageBox::critical( this, tr("Error saving file"), tr("File '%1' could not be saved: An error occured.").arg(filename), QMessageBox::Ok );
    statusBar()->showMessage( tr("Error saving file '%1'.").arg(filename), 2000 );
    return false;
  } 
  setCurrentFileName(filename);
  statusBar()->showMessage( tr("File '%1' saved.").arg(curFile), 2000 );
  return true;
}

void MainWindow::newFile() {
  MainWindow *mainWin = new MainWindow(); 
  mainWin->show();
}

bool MainWindow::open() {
  QString fileName = QFileDialog::getOpenFileName( this, tr("Open Automata File"), ".", tr("Automata files (*.atm)") );
  if(fileName.isEmpty()) return false;
  return openFile(fileName);
}

bool MainWindow::save() {
  if( mainstack->currentIndex() == 1 ) editAtmt->finishEditing(); 
  if(isUntitled) return saveAs();
  else return saveFile(curFile);
}

bool MainWindow::saveAs() {
  if( mainstack->currentIndex() == 1 ) editAtmt->finishEditing(); 
  QString fileName = QFileDialog::getSaveFileName( this, tr("Save Automata File"), ".", tr("Automata files (*.atm)") ); 
  if(fileName.isEmpty()) return false;
  return saveFile(fileName);
}

bool MainWindow::import() {
  QString fileName = QFileDialog::getOpenFileName( this, tr("Import Automata File"), ".", tr("Automata files (*.atm)") );
  if(fileName.isEmpty()) return false;
  bool didExist; struct AtmtTreeItemAndNode parent = atmtTreeWidget->createDirectory( QFileInfo(fileName).baseName(), NULL, &didExist );
  if( !LoadAllAtmts( &treeBase, fileName.toUtf8().data(), parent.node ) ) {
    statusBar()->showMessage( tr("Error importing file."), 2000 );
    return false;
  }
  //PrintAtmtTree(&treeBase);
  updateAllAutomataGeometry( parent.node->child, viewAtmt );
  if(didExist) atmtTreeWidget->deleteShadowTree( parent.item );
  atmtTreeWidget->insertTreeNodes( parent.item, parent.node->child );
  statusBar()->showMessage( tr("File has been imported successfully."), 2000 );
  return true;
}

bool MainWindow::SVGexport() {
  QTreeWidgetItem *item = atmtTreeWidget->currentItem();
  if(!viewAtmt->atmt||!item) { QMessageBox::warning(this,tr("Export as SVG"),tr("Please mark the automaton that should be exported in the tree view first.")); return false; }
  QString fileName = QFileDialog::getSaveFileName( this, tr("Export as SVG"), ".", tr("Scalable Vector Graphic (*.svg)") );
  if(fileName.isEmpty()) return false;
  bool result = createSVG( viewAtmt->atmt, item->text(0), fileName, viewAtmt );
  if(result) statusBar()->showMessage( tr("Current automaton has been exported as %1.").arg(fileName), 6000 );
  else statusBar()->showMessage( tr("Error exporting current automaton as %1.").arg(fileName), 6000 );
  return result;
}

//void MainWindow::viewCFSL() { if(!viewCFSLDialog) viewCFSLDialog = new ViewCFSL(); viewCFSLDialog->exec(); }
void MainWindow::quickHelp() { 
  if(!viewQuickHelpDialog) viewQuickHelpDialog = new ViewQuickHelp(); 
  viewQuickHelpDialog->show(); viewQuickHelpDialog->raise(); viewQuickHelpDialog->activateWindow(); 
}

void MainWindow::about() {
  QMessageBox::about(this, tr("About QCoAn"), tr("<h1>QCoAn</h1>"
	"<p>compiler & automaton network simulator</p>" 
	"This program may be used under the terms of GPLv3; see: <a href=\"https://www.gnu.org/licenses/gpl-3.0.en.html\">https://www.gnu.org/licenses/gpl-3.0.en.html</a><br>"
        "If you apply changes please sign our contributor license agreement at <a href=\"https://www.elstel.org/license/CLA-elstel.pdf\">https://www.elstel.org/license/CLA-elstel.pdf</a><br>"
        "so that your changes can be included into the main trunk at <a href=\"https://www.elstel.org/coan/\">www.elstel.org/coan/</a>."
	"<p>© copyright by Elmar Stellnberger 2018</p>"
	"find more interesting stuff at our webpage <a href=\"https://www.elstel.org\">https://www.elstel.org</a>.</p>"
	"<p> send bug reports to <a href=\"mailto:estellnb@elstel.org\">estellnb@elstel.org</a> </p>"));
}

void MainWindow::setAutomaton( Automaton *a ) {
  viewOnlyAtmt->setAutomaton(a);
  editAtmt->setAutomaton(a);
  execEnv->setAutomaton(a);
  switch(mainstack->currentIndex()) {
    case 0: viewOnlyAtmt->update(); break;
    case 1: editAtmt->update(); break;
    case 2: execEnv->viewAtmt->update(); break;
  }
}

void MainWindow::changeStack( int stackpos ) {
  int prevstackpos = mainstack->currentIndex(); stackpos = stackpos % 3;
  if(!viewOnlyAtmt->atmt) stackpos = 0; 
  overviewModeAction->setChecked( stackpos == 0 );
  editModeAction->setChecked( stackpos == 1 );
  execModeAction->setChecked( stackpos == 2 ); 
  if ( stackpos == prevstackpos ) return;
  switch(prevstackpos) {
    case 1: editAtmt->finishEditing(); break;
    case 2: execEnv->leave(); break;
  }
  mainstack->setCurrentIndex( stackpos );
  leftstack->setCurrentIndex( stackpos );
  enableTreeViewMenu( stackpos == 0 );
  enableExecMenu( stackpos == 2 );
  descriptionStack->setVisible( stackpos == 0 );
  machineSettingsAction->setEnabled( stackpos != 2 );
  if( stackpos == 1 || prevstackpos == 1 ) {
    Automaton *a = dynamic_cast<MS*>(execEnv->atmt);
    for( int k=0; k < MS_predef_machine_count; k++ ) 
      buttonSidebar->MS_predef_machines_button[k]->setVisible(a!=NULL);
  }
  if( stackpos != 0 ) {
    QString statusTxt = stackpos == 1 ? tr("editing "): tr("execution mode for "); statusTxt.append(execEnv->atmt->typeStr());
    QTreeWidgetItem *item = atmtTreeWidget->currentItem(); if(item) { statusTxt.append(tr(" '%1'.").arg(item->text(0))); }
    statusBarLabel->setText(statusTxt);
  } else statusBarLabel->setText("");
  if( stackpos == 2 ) viewTape->setFocus();   // set the focus so that key strokes can take an effect
}

void MainWindow::overviewMode() { changeStack(0); }
void MainWindow::editMode() { changeStack(1); } 
void MainWindow::execMode() { changeStack(2); }

void MainWindow::askDeleteMachine() { atmtTreeWidget->deleteCurrentMachine( true, this ); }

void MainWindow::keyPressEvent(QKeyEvent *event) {
  switch(event->key()) {
    case Qt::Key_F2: save(); break;
    case Qt::Key_F3: open(); break;
    case Qt::Key_F4: changeStack( mainstack->currentIndex() + 1 ); break;
    case Qt::Key_Tab: if( mainstack->currentIndex() == 0 ) viewDescription->setFocus(); break;
    default:
	bool handled = false;
	//if( mainstack->currentIndex()!=0 || !atmtTreeWidget->keyPressed(event) ) QMainWindow::keyPressEvent(event);
	switch( mainstack->currentIndex() ) { 
	  case 0: if(atmtTreeWidget->keyPressed(event)) handled = true; break;
	  case 1: if(editAtmt->keyPressed(event)) handled = true; break;
	  case 2: if(execEnv->keyPressed(event)) handled = true; break;
	}
	if(!handled) QMainWindow::keyPressEvent(event);
      break;
  }
}

void MainWindow::moveMachineUp() { atmtTreeWidget->moveCurrentUp(); }
void MainWindow::moveMachineDown() { atmtTreeWidget->moveCurrentDown(); }


void MainWindow::newMachine() {
  if(!selectNewAtmt) selectNewAtmt = new SelectNewAtmt();
  if(!selectNewAtmt->exec()) return;
  struct AtmtTreeNode *node  = new AtmtTreeNode();
  node->atmt = CreateAutomaton( &treeBase, selectNewAtmt->type );
  if(!node->atmt) { QMessageBox::critical( this, tr("Error Creating Automaton"), tr("internal error: Automaton of this type is not known."), QMessageBox::Ok); return; }
  node->atmt->flags = selectNewAtmt->flags;
  atmtTreeWidget->insertAtCurrent( &treeBase, node, false );  // atmt shall be set in node, ident is assigned "NewAutomaton"
}

void MainWindow::printAtmtTree() { PrintAtmtTree(&treeBase); }

void MainWindow::newDirectory() {
  struct AtmtTreeNode *node  = new AtmtTreeNode();
  node->atmt = NULL;
  atmtTreeWidget->insertAtCurrent( &treeBase, node, true );  // atmt shall be set in node, ident is assigned "NewDirectory"
}

void MainWindow::machineSettings() { 
  if(!viewOnlyAtmt->atmt) return;
  if(!atmtSettings) atmtSettings = new AtmtSettings(this);
  atmtSettings->setAutomaton(viewOnlyAtmt->atmt);
  if(atmtSettings->exec()) {
    if(viewTape->inputSelector) viewTape->inputSelector->setFormalParams();
  }
}

QSize MainWindow::sizeHint() const { 
  QDesktopWidget desktop;
  QRect geometry = desktop.screenGeometry(desktop.primaryScreen());
  //QSize viewAtmtIdealSize = viewAtmt->sizeHint();
  //QSize viewTapeIdealSize = viewTape->sizeHint(); 
  //return QSize( qMax( geometry.width()*1600/3840, qMax( viewAtmtIdealSize.width(), viewTapeIdealSize.width() ) ), \
  //              qMax( geometry.height()*1200/2160, viewAtmtIdealSize.height() + viewTapeIdealSize.height() + 16 ) ); 
  //return QSize( geometry.width()*1600/3840, geometry.height()*1200/2160 ); 
  return QSize( geometry.width()*3000/3840, geometry.height()*1200/2160 ); 
}
