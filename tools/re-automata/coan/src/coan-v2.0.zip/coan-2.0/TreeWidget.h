#ifndef TREE_WIDGET_H
#define TREE_WIDGET_H
#include <QtWidgets/QTreeWidget>
#include "auxtypes.h"
#include "LoadSaveAtmt.h"

class QLineEdit; class QEvent;

Q_DECLARE_METATYPE( struct AtmtTreeNode* );

struct AtmtTreeItemAndNode { QTreeWidgetItem *item; struct AtmtTreeNode *node; };


class AtmtTreeWidget : public QTreeWidget {
  Q_OBJECT
protected:
  bool eventFilter(QObject *target,QEvent *event); void keyPressEvent(QKeyEvent *event);
  void mousePressEvent(QMouseEvent *event);
  struct AtmtTreeBase *base; QLineEdit *lineEdit; QTreeWidgetItem *edited_item;
public:
  AtmtTreeWidget( struct AtmtTreeBase *treeBase );
  bool keyPressed(QKeyEvent *event); 
  void deleteShadowTree( QTreeWidgetItem *parent );
  struct AtmtTreeItemAndNode createDirectory( QString dirName, QTreeWidgetItem *parentItem, bool *didExist );
  void insertTreeNodes( QTreeWidgetItem *parent, struct AtmtTreeNode *parentNode );
  void setModel( struct AtmtTreeBase *base );
  void prepareLineEdit( QTreeWidgetItem *item );
  QTreeWidgetItem* insertAtCurrent( struct AtmtTreeBase *base, struct AtmtTreeNode *node, bool isDirectory ); // atmt shall be set in node, ident is assigned "NewAutomaton"
  bool deleteCurrentMachine( bool ask, QWidget *parent );
  void moveCurrentUp();
  void moveCurrentDown();
protected slots:
  void treeViewItemEdited();
};


#endif
