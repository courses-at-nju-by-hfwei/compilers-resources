#ifndef INPUT_SELECTOR_H
#define INPUT_SELECTOR_H
#include <QtGui/QValidator>
#include <QtWidgets/QDialog>
#include "auxtypes.h"
#include "LoadSaveAtmt.h"

class QLineEdit; class QListWidget; class QLabel; class QRegExpValidator; class QKeyEvent;
class TapeWatch; class ValidateChars;

QString inta2QStr( aux::inta_const vals );


class InputSelector : public QDialog {
  Q_OBJECT
public:
  InputSelector(TapeWatch *tapeWatch);
  QString itemRepr4List( RuntimeParams *params );
  void setFormalParams();
  void setInputList( std::vector<RuntimeParams> *params );
  void pickLast();
  void done(int result);
protected:
  void swapEntries( int idxa, int idxb );
  bool eventFilter(QObject *target,QEvent *event);
  void keyPressEvent(QKeyEvent *event);
public:
  QListWidget *predefInputsListWidget; QLineEdit *tapeEdit, *charParamEdit, *valParamEdit; 
  QLabel *charParamLabel, *valParamLabel; QRegExpValidator *valparam_validator; ValidateChars *charparam_validator;
  TapeWatch *tapeWatch; // int currentlyUsedIndex; //astrbuf charparams_cached;
  std::vector<RuntimeParams> *predefInputsList; //std::list<RuntimeParams>::iterator current_item;
  enum SetWhat { Tape = 1, CharParam = 2, ValParam = 4 }; 
public slots:
  void listItemSelected( int currentRow );
  void listItemEdited( int setWhat );
  void listItemTapeEdited(); void listItemCharParamEdited(); void listItemValParamEdited(); 
};


class ValidateChars : public QValidator {
public:
  ValidateChars( int maxc, InputSelector *inputSelector ) : maxlen(maxc), /*inputSelector(inputSelector),*/ QValidator(inputSelector) {};  // inputSelector is parent
  QValidator::State validate( QString& input, int &pos ) const; 
  int maxlen; //InputSelector *inputSelector; // mutable aux::estrbuf input;
};


#endif
