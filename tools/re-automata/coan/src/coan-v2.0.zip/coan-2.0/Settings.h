#ifndef SETTINGS_H
#define SETTINGS_H

#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtGui/QFont>
#include "auxtypes.h"
#include "symtab.h"

class QCheckBox; class QLineEdit; 
class Automaton;


class DisplayVars : public QWidget {
protected:
  void paintEvent(QPaintEvent *event);
  QSize sizeHint() const { return QSize(xvirtual,yvirtual); }
public:
  DisplayVars( enum SymbolMode symbolMode, QWidget *parent );
  void setVariables(const QString& newcontent);
public:
  const int min_xvirtual = 60, min_yvirtual = 20;
  aux::estrbuf variables; enum SymbolMode symbolMode;
  int xvirtual, yvirtual; QFont varFont;
};


class QuadrPushButton : public QPushButton {
public:
  QuadrPushButton(const QString & text, QWidget * parent = 0);
  //void resizeEvent(QResizeEvent * event);
};

class AtmtSettings : public QDialog {
  Q_OBJECT
public:
  AtmtSettings(QWidget *parent);
  void setAutomaton( Automaton *a );
  void done(int result);
  Automaton *atmt;
  QCheckBox *isDeterministic, *allowVarRanges; 
  QLineEdit *charFormalParams, *valFormalParams;
  DisplayVars *displayCharFormals, *displayValFormals;
protected slots:
  void unicodeLetterButtonClicked();
public slots:
  void charFormalParamsChanged(const QString& newcontent);
  void valFormalParamsChanged(const QString& newcontent);
};


#endif
