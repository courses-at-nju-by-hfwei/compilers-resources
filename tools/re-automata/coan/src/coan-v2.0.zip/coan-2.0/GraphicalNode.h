#ifndef GRAPHICAL_NODE_H
#define GRAPHICAL_NODE_H

#include "automatdef.h"

extern qreal square_root_of_two; 

class EllipticalNode : public Node {
public:
  virtual void draw( QPainter *painter, Automaton *atmt ) const;
  virtual void doUpdateGeometry( QPaintDevice *d, struct TextExtent ext );
  virtual bool isThere( QPointF pos ) const;
  virtual QPointF getSecant( QPointF from ) const;
};

class RectangularNode : public Node {
public:
  static const int roundness = 6;
  virtual void draw( QPainter *painter, Automaton *atmt ) const;
  virtual void doUpdateGeometry( QPaintDevice *d, struct TextExtent ext );
  virtual bool isThere( QPointF pos ) const;
  virtual QPointF getSecant( QPointF from ) const;
};

#endif
