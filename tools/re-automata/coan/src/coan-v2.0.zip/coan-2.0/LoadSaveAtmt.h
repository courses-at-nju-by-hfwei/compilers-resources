#ifndef LOAD_SAVE_ATMT_H
#define LOAD_SAVE_ATMT_H 

#include <map>
#include "auxtypes.h"
#include "automatdef.h"

using namespace aux;

/*
class estr_compare_less : public std::binary_function<State,State,bool> {
public:
  //estr_compare_less() {}
  bool operator()(const estr_const &x, const estr_const &y) const {
    if( !x.chars && y.chars ) return true; else if(!y.chars) return false;
    return x.binary_compare(y) < 0;
  }
};*/

struct RuntimeParams {
  astrbuf tape;
  astrbuf charparams;
  intabuf valparams; 
};

typedef std::vector<RuntimeParams> RuntimeParamVector; 

struct AtmtTreeNode {
  struct AtmtTreeNode *prev, *next, *parent, *child;
  estr_const ident;
  RuntimeParamVector default_inputs;
  Automaton *atmt;
#ifdef QT_CORE_LIB
  QString description;
#endif
};
typedef struct AtmtTreeNode AtmtTreeNode;

typedef std::multimap<estrbuf,AtmtTreeNode*> AtmtIndex;

struct AtmtTreeBase {
  //AtmtTreeBase() : atmtIndex(), globalRuntimeParams() {}  // crash if constructor explicitly defined
  AtmtTreeNode *atmtTree;
  AtmtIndex atmtIndex; //(estr_compare_less());
  std::vector<RuntimeParams> globalRuntimeParams;
};

enum AtmtType { Type_FA = 0, Type_PDA = 1, Type_TM = 2, Type_MS = 3 }; 

Automaton* CreateAutomaton( struct AtmtTreeBase *base, estr_const atmtType );
Automaton* CreateAutomaton( struct AtmtTreeBase *base, int atmtType );
bool LoadAllAtmts( struct AtmtTreeBase *base, const char *filename, AtmtTreeNode *parentNode = NULL );
#ifdef QT_CORE_LIB
bool SaveAllAtmts( struct AtmtTreeBase *base, const char *filename );
#endif
void doPrintAtmtTree(  int indent, AtmtTreeNode *node );
void PrintAtmtTree( struct AtmtTreeBase *base );
bool isPredefinedIdentifier( estr_const ident );

void setAtmtIndexName( struct AtmtTreeBase *base, AtmtTreeNode *node, estr_const new_ident );
void insertAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *parent, AtmtTreeNode *previous, AtmtTreeNode *node, bool insertFirst = true );
void unlinkIndexEntry( struct AtmtTreeBase *base, AtmtTreeNode *node );
AtmtTreeNode* unlinkAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *node );
void deleteAtmtTreeNode( struct AtmtTreeBase *base, AtmtTreeNode *node );
void deleteAtmtTree( struct AtmtTreeBase *base );

#ifdef QT_CORE_LIB
  class QPaintDevice;

  void updateAllAutomataGeometry( struct AtmtTreeNode *root, QPaintDevice *device );
#endif

// class definitions for nullAtmt as returned by CreateAutomaton for an unknown automaton type name

extern Automaton* nullAtmt;
extern Node* nullNode;
extern Edge* nullEdge;

class NullNode : public Node {
public:
  virtual int setContent( Automaton *a, estrbuf *acceptation ) { acceptation->buf_free(); return -1; };
  virtual estr_const getContent() const { return empty_estr; }
  virtual bool setFinalNode(bool isFinalNode) { return !isFinalNode; }
  virtual bool isFinalNode() const { return false; }
  virtual void lookAhead( Runtime *r, Data *d, int relpos = 0 ) {};
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos = 0 ) {};
};

class NullEdge : public Edge {
public:
  NullEdge() : Edge(NULL,NULL) {};
  virtual int setContent( Automaton *a, estrbuf *acceptation ) { acceptation->buf_free(); return -1; };
  virtual estr_const getContent() const { return empty_estr; }
  virtual bool isFinalNode() const { return false; }
  virtual void lookAhead( Runtime *r, Data *d, int relpos = 0 ) {};
  virtual void next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos = 0 ) {};
};

class NullAtmt : public Automaton {
public:
  NullAtmt() : Automaton() {};
  virtual const char* typeStr() { return "NULLATMT"; }
  virtual bool posTapeCursorAtBegin() { return true; }
  Node* createNode() { return nullNode; }
  Edge* createEdge( Node *a, Node *b ) { return nullEdge; }
  virtual Runtime* createRuntime( astr_shared *input, int pos = -1, astr_const charParam = empty_astr, inta_const valParam = empty_inta, int tracelen = 2, bool prepareStatePos = true ) {
    return NULL;
  };
};

#endif
