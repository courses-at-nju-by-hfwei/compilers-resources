#include "auxtypes.h"
#include "arithexpr.h"
//#include "automatdef.h"
//#include <iostream>
//#include <map>
#include <algorithm>
#include <assert.h>
#include "errno.h"

using namespace aux;

int error_num = 0;

void prnVar( SymbolTable *s, echar *var, achar expected_value, bool print_good = false ) {
  long long res = s->lookUp(var);
  achar value = res & 0xFF;
  res >>= 32; bool defined = !( res & 1 );
  int varlen = res >> 1;
  if( !defined ) { cout << varlen << "undefined variable " << estr(var,varlen) << "." << endl; error_num++; return; }
  if( value != expected_value ) { cout << "!! "; error_num++; }
  if( value != expected_value || print_good )
    cout << estr( var, varlen > 8 ? 8 : varlen ) << "_=_(expected:) " <<  AChar( expected_value ) << " = (real:)" << AChar( value ) << endl;
}

void prnVar_length( SymbolTable *s, echar *var, achar expected_value, int expected_truelen, int expected_skiplen  ) {
  int skip_len, true_len, *content;
  int vl_skiplen, vl_truelen;
  skip_len = s->lookUpEntry(var,&content,&true_len);
  vl_skiplen = s->varLength(var,&vl_truelen);
  cout << "true_len: " << true_len; if(true_len != expected_truelen ) cout << "!! ";
  cout << "/" << vl_truelen; if( vl_truelen != expected_truelen ) cout << "!! ";
  cout << ", skip_len: " << skip_len; if(skip_len != expected_skiplen ) cout << "!! ";
  cout << "/" << vl_skiplen; if( vl_skiplen != expected_skiplen ) cout << "!! "; cout << ", ";
  if( true_len == expected_truelen && skip_len == expected_skiplen &&\
      vl_truelen == expected_truelen && vl_skiplen == expected_skiplen ) cout <<  "(OK) "; else { cout << "(Error) "; error_num++; }
  cout << "_(truelen)_" << estr( var, true_len ) << "_=_(skiplen)_" << estr( var, skip_len ) << "_";
  if( !content ) {  cout << ", undefined variable " << estr(var,true_len) << "." << endl; return; }
  if( *content != expected_value ) cout << "!! ";
     cout << " = (expected:) " <<  AChar( expected_value ) << " = (real:)" << AChar( *content ) << endl;
}

void simple_test() {
  cout << "*** simple_test ***" << endl; int prev_errnum = error_num;
  echar var1[2] = { first_greek_letter, ' ' };
  echar var2[5] = { (echar)( first_greek_letter + 3 ), subscript_char, '1', '1', 3 };
  echar var3[5] = { (echar)( first_greek_letter + 5 ), subscript_char, '1', '1', ' ' };
  echar var4[12] = { (echar)( first_greek_letter + 1 ), subscript_char, 'a', 'a', subscript_char, '1', '1', ' ', 'c', ' ', 'X', 'X' };
  echar var5[11] = { (echar)( first_greek_letter + 2 ), subscript_char, 'a', 'a', subscript_char, '1', '1', ' ', 3, 'X', 'X' };

  SymbolTable* s[2]; int si = 0;
  s[!si] = emptySymbolTable.set_and_copy( var1, 'x' ); si = !si;
  prnVar( s[si], var1, 'x', true );
  s[!si] = s[si]->set_and_copy( var1, 'y' ); SymbolTable::free(s+si); si = !si;
  prnVar( s[si], var1, 'y', true);

  s[!si] = s[si]->set_and_copy( var2, 'a' ); SymbolTable::free(s+si); si = !si;
  prnVar( s[si], var1, 'y', false);
  prnVar( s[si], var2, 'a', true);
  s[!si] = s[si]->set_and_copy( var1, 'z' ); SymbolTable::free(s+si); si = !si;
  prnVar( s[si], var2, 'a', true);
  prnVar( s[si], var1, 'z', true);
  s[!si] = s[si]->set_and_copy( var2, 'b' ); SymbolTable::free(s+si); si = !si;
  prnVar( s[si], var1, 'z', false);
  prnVar( s[si], var2, 'b', true);
  SymbolTable::free(s+si);

  s[si] = SymbolTable::reserveEmpty(3);
  s[si] = s[si]->set( var3, 'q' );
  s[si] = s[si]->set( var4, 'm' );
  s[si] = s[si]->set( var5, 'n' );
  prnVar_length( s[si], var1, 'z', 1, 1 );
  prnVar_length( s[si], var2, 'b', 4, 4 );
  prnVar_length( s[si], var3, 'q', 4, 5 );
  prnVar_length( s[si], var4, 'm', 9, 10 );
  prnVar_length( s[si], var5, 'n', 7, 8 );

  cout << error_num - prev_errnum << " errors detected." << endl * 2;
}

void extended_one_char_var_test( bool quiet = false, int reuse = 1, int max_var_num = 0 ) {
  bool allOK = true;
  cout << "*** one_char_var_test ***" << endl; int prev_errnum = error_num;
  if( max_var_num <= 0 ) max_var_num = greek_letter_num - 1;
  int i, l, u, r; echar var[max_var_num+1]; int value[max_var_num];
  SymbolTable* s[2]; int si = 0; s[si] = emptySymbolTable.anotherInstance();
  int var_num;
  for( var_num=0, l=0; l < greek_letter_num && var_num < max_var_num; l++ ) { 
    if( SymbolTable::isGreekVariable( first_greek_letter + l ) )
      var[var_num++] = first_greek_letter + l;
  }
  var[var_num] = 'x'; // termination char
  std::random_shuffle( var, var+var_num ); 
  cout << var_num << " Variables: " << estr(var,var_num) << endl;
  for( l=-1, u=0; u < var_num; u++ ) { 
    for( r=0; r < reuse; r++ ) {      // variable reuse is not necessary to test for correctness; only here for benchmarking
      for( i=u; i >= 0; i-- ) {
	value[i] = rand();
	s[!si] = s[si]->set_and_copy( var+i, value[i] ); SymbolTable::free(s+si); si = !si;
      }
      for( i=0; i <= u; i++ ) {
	long long res = s[si]->lookUp(var+i);
	int real_value = res & 0xFFFFFFFF; res >>= 32;
	assert(( res & 1 ) == 0 );  // not undefined
	assert( res >> 1  == 1 );  // variable length is one
	if( real_value != value[i] ) {
	  if( l != u ) { cout << "iteration #" << u << ", variable #" << i << ":" << endl; l=u; }
	  cout << estr( var+i, 1 ) << " shall be '" <<  value[i] << "' but in deed is '" << real_value << "' !!" << endl;
	  allOK = false; error_num++;
	}
      }
    }
  }
  SymbolTable::free(s+si);
  if( allOK && !quiet ) cout << "one character variable correctness test passed for 100%." << endl * 2;
  else cout << error_num - prev_errnum << " errors detected." << endl * 2;
}

void direct_table_benchmark_extended( int reuse = 1, int var_num = 0 ) {
  cout << "*** direct_table_benchmark ***" << endl;
  if( var_num <= 0 ) var_num = greek_letter_num - 1;
  achar* s[2]; int si = 0; s[si] = (achar*)malloc(var_num); 
  int i; achar value[var_num];
  for( int u=0; u < var_num; u++ )
    for( int r=0; r < reuse; r++ ) {
      for( i=u; i >= 0; i-- ) {
	value[i] = rand();
	s[!si] = (achar*)malloc(var_num);
	memcpy( s[!si], s[si], var_num );
	free(s[si]); si=!si;
	s[si][i] = value[i];
      }
      for( i=0; i <= u; i++ ) {
	achar real_value = s[si][i]; echar var = i + first_greek_letter;
	if( real_value != value[i] ) {
	  cout << estr( &var, 1 ) << " shall be '" <<  astr( value+i, 1 ) << "' but in deed is '" << astr( &real_value, 1 ) << "' !!" << endl;
	}
      }
    }
  free(s[si]); cout << endl;
}

void extended_multi_char_var_test( int verbosity = 2, bool correct_vars = false, int var_num = 10, int max_var_len = 7 ) {
  bool allOK = true;
  echar var[var_num][max_var_len+7]; int value[var_num];
  unsigned int varlen[var_num];
  echar avar[max_var_len+4];
  SymbolTable* s[2]; int si = 0; s[si] = emptySymbolTable.anotherInstance();
  int i, l, u;
  int var_num_ok = 24; assert( max_var_len > 2 );
  for( int j=2; j < max_var_len; j++ ) { var_num_ok *= 0x80; if( var_num_ok > var_num ) break; }
  assert( var_num < var_num_ok );   // at least 24 possible different possible character values per character

  for( i=0; i < var_num; i++ ) {
    bool noDuplicate;
    do {
      var[i][0] = first_greek_letter + ( rand() % ( greek_letter_num - 1 ) );
      if( var[i][0] == epsilon_letter ) var[i][0]++;
      varlen[i] = rand() % ( max_var_len - 2 ) + 1;
      if( varlen[i] == 1 ) {
	var[i][1] = ' ' + rand() % ( 0x7F - ' ' );
      } else {
	unsigned int j;
	var[i][1] = subscript_char; varlen[i]++;
	int subscript_nest = 0; bool last_was_subscript = true; // shall basically be true to generate correctly formed variables
        for( j=2; j < varlen[i]; j++ ) {
	  if(!correct_vars) last_was_subscript = false;
	  var[i][j] = (' '+1)  + rand() % ( 0x7F - ' ' - 1 + ( !last_was_subscript ) + ( subscript_nest > 0 && !last_was_subscript ) ); 
	  if( var[i][j] == 0x7F ) { if( j < varlen[i]-1 ) { assert(!last_was_subscript ); var[i][j] = subscript_char; subscript_nest++; } else var[i][j] = 'x'; }
	  else if( var[i][j] == 0x80 ) { assert( subscript_nest > 0 && !last_was_subscript ); var[i][j]=' '; subscript_nest--; }
	  last_was_subscript = var[i][j] == subscript_char;
	  if( var[i][j] != subscript_char && var[i][j] != ' ' && !isChar4VariableIndex(var[i][j]) ) var[i][j] = 'x';
	  //if( !last_was_subscript && var[i][j] != ' ' && !isChar4VariableIndex(var[i][j]) ) var[i][j] = 'x';
	}
	int k; for(k=j-1; k>0; k--) if(var[i][k]!=' ') break;
	varlen[i]=k+1;
        int spaceterm =  1 + rand() % ( subscript_nest + 1 );
	int excess_free = 6;
	while( spaceterm > 0 && excess_free > 0 ) {
	  var[i][j++] = ' ';
	  spaceterm--; excess_free--; subscript_nest--;
	}
	if( subscript_nest >= 0 )
	  var[i][j++] = !(rand()&3) ? 0 : close_subscripts_char;
	else var[i][j++] = 'x';
        for(; j < varlen[i]+7; j++ ) var[i][j] = 'z';
      }
      noDuplicate = true;
      for( int j=0; j<i; j++ )
        if( varlen[j] == varlen[i] && !memcmp( var[i], var[j], sizeof(echar)*varlen[i] ) ) {
	  noDuplicate = false;
	  break;
	}
    } while(!noDuplicate);
    //if( SymbolTable::varLength(var[i]) != (int) varlen[i] ) { }
    if( verbosity > 1 ) {
      cout << estr(var[i],varlen[i]); int j=varlen[i]; while( var[i][j] == ' ' || var[i][j] == subscript_char ) j++; cout << "#" << estr( var[i]+varlen[i], j+1 - varlen[i] ) << "#" << endl;
    }
  }

  for( l=-1, u=0; u < var_num; u++ ) { 
    for( i=u; i >= 0; i-- ) {
      value[i] = rand();
      s[!si] = s[si]->set_and_copy( var[i], value[i] ); SymbolTable::free(s+si); si = !si;
    }
    for( i=0; i <= u; i++ ) {
      memcpy( avar, var[i], sizeof(echar)*varlen[i] );
      int j=varlen[i], spaces=rand()&3; while( spaces-- > 0 ) avar[j++]=' '; avar[j++]=close_subscripts_char; avar[j]='x';
      long long res = s[si]->lookUp(avar);
      int real_value = (int)res; res >>= 32;
      if( res & 1 ) { // undefined
	cout << "#variables = " << u << ", variable #" << i << endl;
	cout << "base var (len=" << varlen[i] << "): " << estr( var[i], varlen[i]+7 ) << "#" << endl;
	cout << "undefined lookup (len+termlen=" << j << "): " << estr( avar, j ) << "#" << endl;
	abort();
      }
      if( res >> 1  < varlen[i] ) { int true_len; // variable length + termination sequence
	cout << "recognized lookUp variable length too short: " << ( res >> 1 ) << " < , necessary variable length: " << varlen[i] << " from " << estr( var[i], varlen[i]+7 ) << endl;
	cout << "SymbolTable::varLength(var): " << SymbolTable::varLength(var[i],&true_len); cout << " with truelen: " << true_len <<  endl;
	abort();
      }
      if( real_value != value[i] ) {
	if( l != u ) { cout << "iteration #" << u << "variable #" << i << ":" << endl; l=u; }
	cout << estr( var[i], varlen[i] ) << " shall be '" <<  value[i] << "' but in deed is '" << real_value << "' !!" << endl;
	allOK = false;
      }
    }
  }
  SymbolTable::free(s+si);
  if( allOK && verbosity > 0 ) cout << "multi character variable correctness test passed for 100%." << endl;
}

void ArithExprCalcTest( int verbosity = 2 ) {
  ArithmeticExpression ae; estrbuf aeat; int pos, parseFlags, evalFlags, result; bool isGood, allGood = true; estrc_anchor an;
  SymbolTable *local = SymbolTable::reserveEmpty(3); local = local->set(estrc(an,"a").chars,1); local = local->set(estrc(an,"b").chars,2); local = local->set(estrc(an,"c").chars,3);
  SymbolTable *global = SymbolTable::reserveEmpty(1); global = global->set(estrc(an,"kᴗ12❫").chars,12);
  struct AEA { const char *cstr; int expected_result; } aea[] = { 
    { "123", 123 }, { "-12", -12 }, { "1", 1 }, { "1+1", 2 }, { " 1 + 1 ", 2 }, { " ( 2 + 3 ) ", 5 }, { "(7-2)", 5 }, 
    { "8--2^2", 4 }, { "1+2*3", 7 }, { "0+(1+2)*3", 9 }, { "3<=3<=3", 1 },  { "1<2", 1 },  { " 1<2<3>-1 ", 1 },  { " -1<-2<-3 ", 0 }, { " -1<-2<-3 ? -2 : 1<2<3 ? 1+-1^2 : -1 ", 2 },
    { "0  || 1 == 2 && 2 != 3 ", 0 }, { "! 1 == 0 ", 1 }, { "! 1 == 1 + 3 ", 1 }, { "0^^1", 1 },
    { "2*bc^ab+8-3", 77 }, { "2ckᴗ12❫", 72 }, { "abc+cba", 12 }
  };
  const int aes = sizeof(aea) / sizeof(struct AEA);
  for( int i=0; i < aes; i++ ) {
    aeat = aea[i].cstr; pos = 0; if(verbosity>0) cout << aeat;
    ae.parse( aeat, &pos, &parseFlags ); if(verbosity>1) { cout << " ~ "; ae.printParseTree(cout); }
    if(verbosity>0) { cout << " ("; ArithmeticExpression::printFlags( cout, parseFlags ); cout << ")"; cout.flush(); }
    result = ae.eval( &evalFlags, local, global ); isGood = result == aea[i].expected_result;
    if( verbosity<=0 && !isGood ) { cout << aeat << " ("; ArithmeticExpression::printFlags( cout, parseFlags ); cout << ")"; }
    if( verbosity>0 || !isGood ) {
      cout << ( isGood ? ", result = " : ", ¡¡ result = " ) << result << " ("; ArithmeticExpression::printFlags( cout, evalFlags ); cout << ( isGood ? ") " : ") !! " ) << endl;
      if( parseFlags )
        cout << aeat.sub(0,pos) << "|" << aeat.sub(pos) << endl;
    }
    allGood = allGood && isGood;
    // cout << endl << endl;
    cout.flush(); // stin >> &aeat;
  }
  if(allGood) cout << "ArithExprCalcTest: all tests passed successfully." << endl;
  cout << endl;
}

void NormalizationTest() {
  cout << "*** NormalizationTest ***" << endl;
  estrbuf testbuf("--\\n--\\111-\\{111}--\\x11-\\{0x11}--\\/--\\xFF--");  // \111 is an upper case i ('I')
  cout << "\"" << testbuf << "\"" << endl;
  SymbolTable::normalize(&testbuf);
  cout << "normalized: \"" << testbuf << "\"" << endl;

  estrbuf testbuf2("--‹0x0A›-‹111›-‹alpha›--");  // \111 is an upper case i ('I')
  cout << "\"" << testbuf2 << "\"" << endl;
  SymbolTable::normalize(&testbuf2);
  cout << "normalized: \"" << testbuf2 << "\"" << endl;

  estrbuf varbuf1_TM("  ( abc def, \\L ) ");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf1_TM << "\"" << endl;
  SymbolTable::normalize( &varbuf1_TM, mode_TM );
  cout << "norm: \"" << varbuf1_TM << "\"" << endl;
  SymbolTable::normalize(&varbuf1_TM, mode_TM );
  cout << "norm: \"" << varbuf1_TM << "\"" << endl;

  estrbuf varbuf2_TM("   abc def, \\L  ");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf2_TM << "\"" << endl;
  SymbolTable::normalize( &varbuf2_TM, mode_TM );
  cout << "norm: \"" << varbuf2_TM << "\"" << endl;
  SymbolTable::normalize(&varbuf2_TM, mode_TM );
  cout << "norm: \"" << varbuf2_TM << "\"" << endl;

  estrbuf varbuf0("\\{psi}\\{sub}start\\{sub}11\\{endsub}\\:alpha:\\:beta:\\:gamma:\\:delta:\\:epsilon:\\:zeta:\\:eta:\\:theta:\\:iota:\\:kappa:\\:lambda:\\:my:\\:ny:\\:xi:\\:omikron:\\:pi:\\:rho:\\:final_sigma:\\:sigma:\\:tau:\\:ypsilon:\\:phi:\\:chi:\\:psi:\\:omega:\\:dialytik_iota");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf0 << "\"" << endl;
  SymbolTable::normalize(&varbuf0);
  cout << "norm: \"" << varbuf0 << "\"" << endl;

  estrbuf varbuf("αᴗ11 αᴗstartᴗ1  αᴗᴗ1ᴗᴗ2 3  ;αᴗgood❫αᴗ❫αᴗ11ᴗ\\xFFαᴗ11\\xFFαᴗ\\000α\\000αᴗ  .");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf << "\"" << endl;
  SymbolTable::normalize(&varbuf);
  cout << "norm: \"" << varbuf << "\"" << endl;
  SymbolTable::normalize(&varbuf);
  cout << "2xnm: \"" << varbuf << "\"" << endl;

  estrbuf varbuf2("β\\!={1,2\\+2,3}\\-αᴗ1\001αᴗ2\001");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf2 << "\"" << endl;
  SymbolTable::normalize(&varbuf2);
  cout << "norm: \"" << varbuf2 << "\"" << endl;
  cout << endl;

  estrbuf varbuf3("αᴗgood\\");  // \111 is an upper case i ('I')		!!! fehlerhaft, oder !!! - entweder ? oder \0x00, schließender Varindex zu spät
  cout << "prev: \"" << varbuf3 << "\"" << endl;
  SymbolTable::normalize(&varbuf3);
  cout << "norm: \"" << varbuf3 << "\"" << endl;
  estrbuf varbuf3_1("αᴗgood\\L");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf3_1 << "\"" << endl;
  SymbolTable::normalize(&varbuf3_1);
  cout << "norm: \"" << varbuf3_1 << "\"" << endl;
  estrbuf varbuf3_2("αᴗfirst∘αᴗmid\001αᴗlast");  // \111 is an upper case i ('I')          !!! falsch, oder !!!  - excess ∘αᴗm❫, doppelt falsch: ∘ !isChar4VariableIndex
  cout << "prev: \"" << varbuf3_2 << "\"" << endl;
  cout << varbuf3_2.length << "," << xstrbuf_bufLength(varbuf3_2) << endl;
  SymbolTable::normalize(&varbuf3_2);
  cout << "norm: \"" << varbuf3_2 << "\"" << endl;
  cout << varbuf3_2.length << "," << xstrbuf_bufLength(varbuf3_2) << endl;
  cout << endl;

  estrbuf varbuf4("αᴗgood\\xFF\\");  // \111 is an upper case i ('I')
  //estrbuf copybuf = varbuf4.as_const(); // error! copybuf.bufParams = xstrbuf_constBuf;
  estrbuf copybuf = varbuf4.as_const(); // copybuf.bufParams = xstrbuf_constBuf;
  cout << IOChangeVal(IOAttr::NumberBaseNextOne,16) << copybuf.bufParams << endl;
  cout << "prev: \"" << copybuf << "\"" << endl;
  SymbolTable::normalize(&copybuf);
  cout << "norm: \"" << copybuf << "\"" << endl;
  cout << "-------" << endl;
  cout << "prev: \"" << varbuf4 << "\"" << endl;	      // !! falsch, oder !!! - excess ‹0x00›\  -- normalize(&copybuf) ändert den string!!
  SymbolTable::normalize(&varbuf4);
  cout << "norm: \"" << varbuf4 << "\"" << endl;
 
  estrbuf varbuf5("ε\\ \\..A αᴗ\\ 1\\ +\\ 1\\ 23 24");  // + may not be index char, ε ~ nullstring - will be eliminated
  cout << "prev: \"" << varbuf5 << "\"" << endl;
  SymbolTable::normalize(&varbuf5);
  cout << "norm: \"" << varbuf5 << "\"" << endl;   // space must not be cropped !

  estrbuf varbuf6("ᴗindex❫\\xFFα");  // + may not be index char, ε ~ nullstring - will be eliminated
  cout << "prev: \"" << varbuf6 << "\"" << endl;
  SymbolTable::normalize(&varbuf6);
  cout << "norm: \"" << varbuf6 << "\"" << endl;   // space must not be cropped !

  cout << endl << "codes above can only be controlled by hand" << endl * 2;
  return;
}

void NormalizationVarlistTest() { int varnum;
  cout << "*** NormalizationVarlistTest ***" << endl;
  estrbuf varbuf0("\\{psi}\\:alpha:xhq\\:alpha:\\:beta:\\:gamma:\\:beta:\\:gamma:");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf0 << "\"" << endl;
  varnum = SymbolTable::normalize(&varbuf0,mode_grVarList);
  cout << "norm: \"" << varbuf0 << "\", #variables = " << varnum << endl;

  estrbuf varbuf1("πᴗaaᴗ11  πᴗaaᴗ11❫α");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf1 << "\"" << endl;
  varnum = SymbolTable::normalize(&varbuf1,mode_grVarList);
  cout << "norm: \"" << varbuf1 << "\", #variables = " << varnum << endl;

  estrbuf varbuf2("πᴗbbᴗ22\001πᴗaaᴗ11\001πᴗaaᴗ11❫α");  // \111 is an upper case i ('I')
  cout << "prev: \"" << varbuf2 << "\"" << endl;
  varnum = SymbolTable::normalize(&varbuf2,mode_grVarList);
  cout << "norm: \"" << varbuf2 << "\", #variables = " << varnum << endl;

  estrbuf varlistbuf("ᴗxᴗ11❫xxγsβcαᴗ11 αᴗstartᴗ1  αᴗᴗ1ᴗᴗ2 3  ;αᴗgood❫ᴗαᴗ❫αᴗ11ᴗ\\xFFαᴗ11\\xFFαᴗ\\000α\\000αᴗ  .");  // \111 is an upper case i ('I')
  cout << "rawstr: " << varlistbuf << endl;
  cout << "#vars = " << SymbolTable::normalize(&varlistbuf,SymbolMode::mode_grVarList) << ", \""; cout << varlistbuf << "\"" << endl;
  cout << "#vars = " << SymbolTable::normalize(&varlistbuf,SymbolMode::mode_grVarList) << ", \""; cout << varlistbuf << "\"" << endl;
  cout << "codes above can only be controlled by hand" << endl * 2;

  return;
}

int main( int argc, char *argv[] ) {
  //echar *readstring; 
  //long long hug;
  cout << IOChangeFlags( IOFlag::ImmediateFlush );
  cout << "Symbol Table Test" << endl * 2;
  // int minus_one = -1; iword hug = (iword)(unsigned int)minus_one; printf("%lx\n", hug ); cout << (int)hug << endl; exit(0);
  srand(time(NULL)); // cout << "#greek letters: " << greek_letter_num << endl;

  //simple_test();

  //extended_one_char_var_test();

  if(false) {
    cout << "*** extended_multi_char_var_test ***" << endl;
    for( int j=0; j<10; j++ )
      extended_multi_char_var_test( j==0, false, 1000, 12 );
    cout << "10 repetitions of the last test have succeeded." << endl;
  }

  //estrbuf varbuf3("αᴗgood\\");  // \111 is an upper case i ('I')		!!! fehlerhaft, oder !!! - entweder ? oder \0x00, schließender Varindex zu spät
  //cout << "prev: \"" << varbuf3 << "\"" << endl;
  //SymbolTable::normalize(&varbuf3);
  //cout << "norm: \"" << varbuf3 << "\"" << endl;

//  NormalizationTest();
  //NormalizationVarlistTest();

  //SimpleOutput();

  ArithExprCalcTest();

  //NormalizationTest();


  /*
  int iters = 100000; // 10000;
  cout << "extended SymbolTable test: " << iters << " times ..." << endl;
  for( int i=0; i < iters; i++ ) extended_one_char_var_test(true);
  //cout << "extended array as 1-char-variable symboltable benchmark: " << iters << " times ..." << endl;
  //for( int i=0; i < iters; i++ ) direct_table_benchmark_extended();
  // cout << endl;
  */

  cout << endl;
  cout.flush();
  return 0;
}
