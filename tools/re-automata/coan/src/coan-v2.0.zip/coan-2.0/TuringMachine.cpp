#include "TuringMachine.h"
#include "auxtypes.h"
#include "LoadSaveAtmt.h"

using namespace aux;

const echar echars_one[2] = { '1', 0 };
const estr_const estr_one( echars_one, 1 );

// ~~~~~~~~~~~~~~~~~~  Turing Machines  ~~~~~~~~~~~~~~~~~~

int MSNodeProxy::execLength() const { return ((MS_Node*)main)->command.size()+1; }
int MS_Node::execLength() const { return command.size()+1; }

// ------------ printing edges ------------ 

void MS_Edge::printHead( IOStreamRef out, int debuglevel ) const {
  if( debuglevel > 1 ) out << from->getContent() << "-("; else out << "(";
  if( flags & isEmptyTransition ) {
    out << estr_epsilon;
  } else {
    if(!variable.isInvalid()) out << variable << ( flags & negatedCond ? EChar(neq_char) : EChar('=') ); 
    else if( flags & negatedCond ) out << IOChangeFlags( IOFlag::OverlineNextXStr );
    if( condition.length ) out << condition; 
    else out << EChar(empty_set_char);
  }
}

void MS_Edge::printTail( IOStreamRef out, int debuglevel ) const {
  estr_const to_label = to ? to->getContent() : estrbc(dangling_node_buf,"<dangling_node>"); 
  if( debuglevel > 1 ) out << ")-" << to_label; else out << ")";
}

void MS_Edge::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  printHead( out, debuglevel );
  printTail( out, debuglevel );
}

#ifdef QT_CORE_LIB

void MS_Edge::callbackPrint( TextCallBack cb, void *data ) const {
  if( flags & isEmptyTransition ) { cb( 0, 0, false, estr_epsilon, data ); return; }
  if(!variable.isInvalid()) {
    cbPrintSubscripted( cb, 0, false, variable, data ); 
    if( flags & negatedCond ) cb( 0, 0, false, estr_neq_char, data ); else cb( 0, 0, false, estr_eq_char, data ); 
  }
  if( condition.length ) cbPrintSubscripted( cb, 0, flags & negatedCond && variable.isInvalid(), condition, data ); 
  else cb( 0, 0 , flags & negatedCond && variable.isInvalid(), estr_empty_set_char, data );
}

#endif

void TM_Edge::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  printHead( out, debuglevel ); 
  out << ","; 
  if( move_position ) {
    out << ( move_position < 0 ? "L" : "R" );
    if( move_position != -1 && move_position != +1 ) out << "^" << ( move_position > 0 ? move_position : -move_position );
  } else if( !write_variable ) {
    if( write_char == 'L' || write_char == 'R' ) out << AChar('\\');
    out << EChar(write_char);
  } else {
    int len = content.length; if( len > 0 && content.chars[len-1] == ')' ) --len;
    iword offset = write_variable - content.chars;
    if( 0 <= offset && offset < len ) out << estr_const( write_variable, len - offset );
    else out << "<invalid write_variable pointer>";
  }
  printTail( out, debuglevel );
}

const echar echars_open_bracket[2] = { '(', 0 }, echars_close_bracket[2] = { ')', 0 };
const estr_const estr_open_bracket(echars_open_bracket,1), estr_close_bracket(echars_close_bracket,1); 

const echar echars_L[2] = { 'L', 0 }, echars_R[2] = { 'R', 0 }, echars_space[2] = { ' ', 0 };
const estr_const estr_L( echars_L, 1 ), estr_R( echars_R, 1 ), estr_space( echars_space, 1 );


#ifdef QT_CORE_LIB

void TM_Edge::callbackPrint( TextCallBack cb, void *data ) const {
  cb( 0, 0, false, estr_open_bracket, data );
  MS_Edge::callbackPrint(cb,data);
  cb( 0, 0, false, estr_comma, data );
  if( move_position ) {
    cb( 0, 0, false, move_position < 0 ? estr_L : estr_R, data );
    //if( move_position != -1 && move_position != +1 ) out << "^" << ( move_position > 0 ? move_position : -move_position );
  } else if( !write_variable ) {
    if( write_char == 'L' || write_char == 'R' ) cb( 0, 0, false, estr_backslash, data );
    cb( 0, 0, false, estr_const(&write_char,1), data );
  } else {
    int len = content.length; if( len > 0 && content.chars[len-1] == ')' ) --len;
    iword offset = write_variable - content.chars;
    if( 0 <= offset && offset < len ) cbPrintSubscripted( cb, 0, false, estr_const( write_variable, len - offset ), data ); 
    else cb( 0, 0, false, estrbuf("<invalid write_variable pointer>"), data );
  }
  cb( 0, 0, false, estr_close_bracket, data );
}

#endif

// ------------ setContent ------------ 

void MS_Edge::scan4VariableAndCondition( int startPos, int onePastEnd, int *trueVarLen, int *errpos ) {
  int pos = startPos;
  if(trueVarLen) *trueVarLen = 0;
  // scan for variable
  if( SymbolTable::isGreekVariable(content.chars[pos]) ) {
    variable.chars = content.chars + pos;
    variable.length = SymbolTable::varLength( variable.chars, trueVarLen );
    pos += variable.length;
    if( pos > onePastEnd && ( *errpos < 0 || onePastEnd < *errpos ) ) *errpos = onePastEnd;  // variable extends beyond the scanning bounds given to scan4Variable
    bool foundAssignmentOperator = true;
    if( pos < content.length ) {
      if( content.chars[pos] == '=' ) pos++;
      else if( content.chars[pos] == neq_char ) { flags |= negatedCond; pos++; }
      else if( content.chars[pos] == '!' && pos+1 < content.length && content.chars[pos+1] == '=' ) { flags |= negatedCond; pos+=2; }
      else foundAssignmentOperator = false; 
    } else foundAssignmentOperator = false; 
    if( !foundAssignmentOperator ) {
      pos = startPos;
      variable = invalid_estr;
      if(trueVarLen) *trueVarLen = 0;
    }
  } else {
    if( pos < content.length ) {
      if( content.chars[pos] == neq_char ) { flags |= negatedCond; pos++; }
      else if( content.chars[pos] == '!' && pos+1 < content.length && content.chars[pos+1] == '=' ) { flags |= negatedCond; pos+=2; }
    }
    variable = invalid_estr;
  }
  // content is now at pos
  condition = content.sub( pos, onePastEnd - pos );
  if( condition.isEmpty() && !( flags & negatedCond ) ) { flags |= simpleCond;
    if( *errpos < 0 || pos < *errpos ) *errpos = pos;
    return;
  }
  int condChkFlags, condErr = ExtCharSet::first_error_position( condition, 0, &condChkFlags );
  if( condChkFlags & ExtCharSet::has_variables ) flags |= needsPreviousVar;
  else if( condChkFlags & ExtCharSet::is_a_simple_range ) flags |= simpleCond;
  if( condErr >= 0 && ( *errpos < 0 || pos + condErr < *errpos ) ) *errpos = pos + condErr;
}

bool MS_Edge::check4Epsilon( estrbuf *label ) {
  if( estr::isEmpty(label) || *label == estr_epsilon) {   // basically TM do not have Epsilon-transitions; however an ε-based NDTM can be reduced to a non ε-based one
    condition = content = estr_epsilon; flags = isEmptyTransition; 
    if(!label->identical(estr_epsilon)) label->buf_free();
    return true; 
  }
  return false;
}

int MS_Edge::setContent( Automaton *a, estrbuf *label ) { 
  variable = invalid_estr; 
  if( check4Epsilon(label) ) return -1;
  int errpos = SymbolTable::normalize( label, SymbolMode::mode_MS );
  content.moveFrom(label); flags = 0; *label = invalid_estr; 
  scan4VariableAndCondition( 0, content.length, NULL, &errpos );
  return errpos;
}

int TM_Edge::setContent( Automaton *a, estrbuf *label ) { 
  variable = invalid_estr; move_position = 0; write_char = SymbolTable::unknown_achar; write_variable = NULL;    // reset most edge variables
  if( check4Epsilon(label) ) return -1;
  int errpos = SymbolTable::normalize( label, SymbolMode::mode_TM ); int definedVar_len4Cmp, writeVar_len4Cmp = 0;
  flags = 0; condition = empty_estr;   // reset the reset of the edge variables
  content.moveFrom(label); *label = invalid_estr;
  bool hasBrackets = content.chars[0] == '(' && content.chars[content.length-1] == ')';
  int cooked_length = content.length - ( hasBrackets << 1 );
  if( cooked_length < 3 ) { errpos = hasBrackets; return errpos; }
  int cmdPos = content.length - hasBrackets - 1; bool maybeMoveCommand = true; 
  if( content.chars[cmdPos] == close_subscripts_char || content.chars[cmdPos] == ' ' ) {
    int i = cmdPos - 1;  // write_variable: preceeded by condition character and a colon (','); after the following loop: i >= 2 + hasBrackets
    while( i > 3 + hasBrackets && ( isChar4VariableIndex(content.chars[i]) || content.chars[i] == subscript_char || content.chars[i] == ' ' ) ) --i;
    if( SymbolTable::isGreekVariable(content.chars[i]) && SymbolTable::varLength(content.chars + i, &writeVar_len4Cmp ) == cmdPos - i + 1 ) {
      write_variable = content.chars + i; 
      cmdPos = i;
    }
  } // cmdPos >= 2 + hasBrackets
  if( content.chars[cmdPos-1] != ',' ) {
    if( write_variable ) { if( errpos < 0 || cmdPos-1 < errpos ) errpos = cmdPos-1; return errpos; }
    else if( content.chars[cmdPos-1] != '\\' || content.chars[cmdPos-2] != ',' ) { if( errpos < 0 || cmdPos-2 < errpos ) errpos = cmdPos-2; return errpos; };
    maybeMoveCommand = false; 
  }
  if( !write_variable ) { 
    int cmd = content.chars[cmdPos];
    if( maybeMoveCommand && cmd == 'L' ) move_position = -1;
    else if( maybeMoveCommand && cmd == 'R' ) move_position = +1;
    else if( SymbolTable::isGreekVariable(cmd) ) { write_variable = content.chars + cmdPos; writeVar_len4Cmp = 1; }
    else write_char = cmd;
    if( !maybeMoveCommand ) cmdPos--;   // there was an escaped (\\c) write_char: jump to one character before; i.e. to the backslash ('\\')
  }
  cmdPos--; assert( content.chars[cmdPos] == ',' ); // jump to the ',' separating condition and command
  // below: detect empty pre-command field (variable + condition): edge-transition would never get executed ( same as: cmdPos <= 0 && !hasBrackets || cmdPos <= 1 && hasBrackets )
  if( cmdPos <= (int)hasBrackets ) { if( errpos < 0 || (int)hasBrackets < errpos ) errpos = (int)hasBrackets; return errpos; }
  scan4VariableAndCondition( hasBrackets, cmdPos, &definedVar_len4Cmp, &errpos );   // prospective start of the condition
  if( writeVar_len4Cmp > 0 && !( flags & needsPreviousVar ) && ( variable.isInvalid() || estr_const(variable.chars,definedVar_len4Cmp) != estr_const(write_variable,writeVar_len4Cmp) ) ) {
    // written variable has been defined before i.e. not in this step
    flags |= needsPreviousVar;
  }
  return errpos;
};

// ------------ execution / runtime logic ------------ 

inline bool MS_Edge::evalConditionAndAssignment( Runtime *r, TM_Data *d, achar curChar, SymbolTable **tmpTransitionSymbols ) {
  bool neg = ( flags & negatedCond ) != 0;
  if( flags & needsPreviousVar ) r->setCondition( Runtime::will_read_variable );
  if( variable.isValid() ) r->setCondition( Runtime::will_write_variable );
  *tmpTransitionSymbols = variable.isValid() ? emptySymbolTable.set_and_copy(variable.chars,curChar) : NULL;
  if( flags & simpleCond ) 
    return neg ^ ( condition.find_first_of(curChar) < condition.length );
  bool result, undef_var = false;
  result = neg ^ ExtCharSet::elm_in( curChar, condition, d->localSymTab, r->paramSymTab, &undef_var );
  if( undef_var ) { r->setCondition( Runtime::undefined_variable_during_lookahead ); r->addErrorWithElement(this); }
  return result;
}

inline void TM_MS_do_lookAhead( Node *n, TM_Runtime *r, TM_Data *d, int relpos ) {
  if( d->pos < 0 ) return;
  int cur_char = d->tape->chars[d->pos];
  for( Edges::const_iterator ie = n->succ.begin() + n->epsilonSucc; ie != n->succ.end(); ie++ ) { 
    TM_Edge *edge = (TM_Edge*)*ie; SymbolTable *symtab = NULL;
    if( edge->flags & MS_Edge::isEmptyTransition || edge->evalConditionAndAssignment( r, d, cur_char, &symtab ) ) 
      r->addLookAhead( IntermedState( edge, d, symtab ) );
  }
}

void TM_Node::lookAhead( Runtime *rg, Data *dg, int relpos ) {
  TM_MS_do_lookAhead( this, (TM_Runtime*)rg, (TM_Data*)dg, relpos );
}

void MS_Edge::next( Runtime *rg, Data *data, SymbolTable *tmpTransitionSymbols, int relpos ) {
  TM_Runtime *r = (TM_Runtime*)rg; Data *d;
  if( !tmpTransitionSymbols || tmpTransitionSymbols->isEmpty() )
    r->addState( State( to, d = r->duplicateData( data ) ) );
  else r->addState( State( to, d = r->dataAcquireSymTab( data, tmpTransitionSymbols ) ) );
}

void TM_Edge::next( Runtime *rg, Data *dg, SymbolTable *tmpTransitionSymbols, int relpos ) {
  TM_Runtime *r = (TM_Runtime*)rg; TM_Data *data = (TM_Data*)dg, *d; register achar write_me; 
  SymbolTable *newSymTab = data->localSymTab;
  if( tmpTransitionSymbols ) newSymTab = newSymTab->copy_acquireSymsFrom( tmpTransitionSymbols );
  else newSymTab = newSymTab->anotherInstance();
  if( write_variable ) { 
    register long long result = newSymTab->lookUp(write_variable);
    if( result & SymbolTable::var_is_undefined ) result = r->paramSymTab->lookUp(write_variable) ;
    if( result & SymbolTable::var_is_undefined ) r->setCondition( Runtime::undefined_variable_during_next );
    write_me = (achar) result;
  } else write_me = write_char;
  r->addState( State( to, d = r->dataChangeTape( data, write_me, move_position, newSymTab ) ) );
}

void MS_Edge::lookAhead( Runtime *rg, Data *dg, int relpos ) {
  cerr << "internal error: MS/TM_Edge::lookAhead was called; i.e. an edge was in the current state set." << endl;
  abort();
}

void TM_Node::next( Runtime *r, Data *d, SymbolTable *tmpTransitionSymbols, int relpos ) {
  cerr << "internal error: TM_Node::next was called; i.e. a node was in the lookahead set." << endl;
  abort();
}

void*(*TM_Runtime::alloc)(size_t) = malloc;
void(*TM_Runtime::dealloc)(void*,size_t) = aux::std_dealloc;

TM_Data* TM_Runtime::createInitialData( astr_shared *input, int position ) {
  // the default position is one after the last character if the last character != '#'
  // if input->chars[valid_pos] == '#' && valid_pos + 1 is invalid: ( sub + 1 ) == ( -1 + +1 ) == 0; otherwise add +1 for one after the last
  int target_pos, target_len; TM_Data *initial_data;
  if( position < 0 ) {
    if( input->length && input->chars[input->length-1] == '#' ) target_pos = input->length-1; else target_pos = input->length;
    target_len = target_pos + 1;
  } else if( position >= input->length ) {
    target_pos = position;      // only one # can be added at the tail
    target_len = position + 1;
  } else {
    target_pos = position; // find_last_no_of returns an index rather than a length so add one to get a length, keep first target_pos + 1 chars
    target_len = target_pos + 2 + input->sub(target_pos+1).find_last_not_of('#');
  }
  if( target_len != input->length )
    initial_data = new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( input->sub(0,target_len), target_pos );
  else 
    initial_data = new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( input, target_pos, NULL );
  //cout << position << "," << target_pos << "," << target_len << "," << *input << endl;
  //int valid_pos = position >= input->length ? input->length-1 : position; if( valid_pos < 0 ) valid_pos = 0;
  //int at_the_end = valid_pos + ( input->sub(valid_pos).find_last_not_of('#') + 1 );
  //Data *initial_data = new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( input->sub(0,at_the_end+1), position < 0 || position > at_the_end ? at_the_end : position );
  return initial_data;
} 

TM_Runtime::TM_Runtime( TM *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos ) : Runtime(a,charParam,valParam,tracelen) {
  if(a->startNode) {
    Data *initial_data = createInitialData(input,position);
    addState( State( a->startNode, initial_data ) ); 
    lookAhead( prepareStatePos );
  } else {
    cur->status = no_successor; cur->conditions |= at_lookAhead;
    setCondition( Condition::no_startNode ); 
  }
}

MS_Runtime::MS_Runtime( TM *a, astr_shared *input, int position, astr_const charParam, inta_const valParam, int tracelen, bool prepareStatePos ) : TM_Runtime(a,charParam,valParam,tracelen) {
  // copy and paste of the constructor was necessary because TM_Runtime::TM_Runtime calls virtual functions of Turing Machines instead of Machine Schematas
  if(a->startNode) {
    Data *initial_data = createInitialData(input,position);
    addState( State( a->startNode, initial_data ) ); 
    lookAhead( prepareStatePos );
  } else {
    cur->status = no_successor; cur->conditions |= at_lookAhead;
    setCondition( Condition::no_startNode ); 
  }
}

int TM_Runtime::compareData( Data *a0, Data *b0 ) const { 
  TM_Data *a = (TM_Data*)a0, *b = (TM_Data*)b0; 
  if( a == b ) return 0;
  register int res = a->tape->binary_compare(b->tape);   // at first compare the tape: easier to read for users
  if( res ) return res;
  if( a->pos != b->pos ) return a->pos < b->pos ? -1 : +1; 
  return a->localSymTab->compare( b->localSymTab );
}

Status TM_Runtime::getResultStatus( Element *e, Data *data ) {
  TM_Data *d = (TM_Data*)data;
  if( d->pos < 0 ) return Status::hanging;
  if( e && e->isFinalNode() ) {
    TM_Node *haltnode = (TM_Node*)e;  // edge can never be a final node
    if( haltnode->label.length > 2 ) {
      echar indicator = haltnode->label.chars[2];
      if( indicator == '1' || indicator == 'a' ) return Status::accepted;
      else return Status::dismissed;
    } else {
      if( d->tape->right(3) == astr_const((const achar*)"#Y#",3) ) return Status::accepted;
      if( d->tape->right(3) == astr_const((const achar*)"#N#",3) ) return Status::dismissed;
    }
    return Status::halted;
  }
  return Status::stepDone;
}

// ------------ Machine Schemata ------------ 

void MS_Node::printCmd( IOStreamRef out, int i ) const {
  const MSNodeProxy *cmd= &command[i]; int j; //echar c;
  out << cmdd.sub(cmd->start,cmd->len);
  if( !( cmd->potency.isConst() && cmd->potency.eval() == 1 ) ) {
    out << "^" << cmd->potency.toText();
  }
  if( cmd->int_param_count > 0 ) {
    out << "_"; for( j=0; j < cmd->int_param_count; j++ ) { if(j) out << ","; out << cmd->int_param[j].toText(); }
  }
  if( cmd->char_param_count > 0 ) {
    out << ":"; for( j=0; j < cmd->char_param_count; j++ ) { if(j) out << ","; /*c = cmd->char_param[j].chars[0]; if(c=='L'||c=='R') out << AChar('\\');*/ out << cmd->char_param[j]; }
  }
}

void MS_Node::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  int i;
  for( i=0; i < relpos; i++) { if(i) out << " "; printCmd(out,i); }
  out << "|";
  for( ; i < (int)command.size(); i++) { if(i!=relpos) out << " "; printCmd(out,i); }
}

#ifdef QT_CORE_LIB

//typedef void(*TextCallBack)(int baseline,int subscriptcount,bool overlined,estr_const text,void *data);

void MS_Node::cbPrintCmd( TextCallBack cb, int i, void *data ) const {
  const MSNodeProxy *cmd= &command[i]; int j, k;
  cb( 0, 0, false, estr_space, data );
  cb( 0, 0, false, cmdd.sub(cmd->start,cmd->len), data );
  if( !( cmd->potency.isConst() && cmd->potency.eval() == 1 ) ) {
    cbPrintSubscripted( cb, -1, false, cmd->potency.toText(), data );
  }
  for( j=0; j < cmd->int_param_count; j++ ) { 
    if(j)  cb( +1, 0, false, estr_comma, data );
    cbPrintSubscripted( cb, +1, false, cmd->int_param[j].toText(), data ); 
  }
  for( k=0; k < cmd->char_param_count; k++ ) { 
    if(j||k)  cb( +1, 0, false, estr_comma, data );
    cbPrintSubscripted( cb, +1, false, cmd->char_param[k], data ); 
  }
  cb( 0, 0, false, estr_space, data );
}

void MS_Node::callbackPrint( TextCallBack cb, void *data ) const {
  int i, num = (int)command.size(), val; struct CursorCounter cc; InitCursorCounter(&cc);    // execLength is size()+1 !
  for( i=0; i < num; i++) {
    val = nextCursor(&cc); if(val) cb( -3, val>1, false, empty_estr, data );
    cbPrintCmd(cb,i,data);
  }
  val = nextCursor(&cc); if(val) cb( -3, val>1, false, empty_estr, data );
}

#endif

void MS_Node::clear_commands() { 
  std::vector<MSNodeProxy>::iterator ci; int i;
  for( ci = command.begin(); ci != command.end(); ci++ ) {
    ArithmeticExpression::freeMem(ci->potency); 
    for( i=0; i < ci->int_param_count; i++ ) ArithmeticExpression::freeMem(ci->int_param[i]); 
  }
  command.clear();
}

int find_first_unescaped_of( estr_const str, achar *findstr, int pos ) {
  int result = str.find_first_of(findstr,pos);
  if( 0 < result ) while( result < str.length && findstr[result-1] == '\\' ) result = str.find_first_of(findstr,result+1);
  return result;
}

int MS_Node::setContent( Automaton *a, estrbuf *acceptation ) {
  int pos, nxt, remember_pos, err = -1, shallbe_len; int i = 0, j; estr_const power, numparams, charparams; int errFlags, expr_pos;
  cmdd.moveFrom(acceptation); *acceptation = invalid_estr; clear_commands();
  pos = cmdd.find_first_not_of((achar*)" \t");
  while( pos < cmdd.length ) {
    MSNodeProxy cmd(this,i+1);
    cmd.start = pos; power = empty_estr; numparams = empty_estr; charparams = empty_estr;
    nxt = cmdd.find_first_of((achar*)" \t^_:",pos);
    if( ( cmdd.chars[nxt] == ' ' || cmdd.chars[nxt] == '\t' ) && nxt > 0 && cmdd.chars[nxt-1] == '\\' ) {
      cmd.start = nxt; cmd.len = 1; cmd.action = MS::Print; pos = cmdd.find_first_not_of( (achar*)" \t", nxt + 1 );
      continue;
    }
    cmd.len = nxt - pos;   // check later on for this str to be non-empty
    for( j=0; j < 3; j++ ) {
      pos = nxt + 1;
      if( pos-1 < cmdd.length ) switch(cmdd.chars[pos-1]) {
	case '^': nxt = find_first_unescaped_of(cmdd,(achar*)" \t:_",pos); power = estr_const( cmdd.chars + pos, nxt - pos );  break;
	case '_': nxt = find_first_unescaped_of(cmdd,(achar*)" \t:",pos); numparams = estr_const( cmdd.chars + pos, nxt - pos ); break;
	case ':': nxt = find_first_unescaped_of(cmdd,(achar*)" \t",pos); charparams = estr_const( cmdd.chars + pos, nxt - pos ); break;
    } }; remember_pos = nxt;

    if( power.length > 0 ) {
      cmd.potency.parse( power, &( expr_pos = 0 ), &errFlags );
      if( errFlags || expr_pos < power.length - 1 ) { 
	cerr <<  "error parsing potency of command #" << i+1 << ": "; ArithmeticExpression::printFlags(cerr,errFlags); cerr << endl;
	err = ( power.chars - cmdd.chars ) + expr_pos;
    } }

    j=0; pos=0; while( pos < numparams.length && j < MAX_NUM_PARAM ) {
      nxt = numparams.find_first_of(',',pos);
      cmd.int_param[j].parse( numparams.sub(pos,nxt-pos), &( expr_pos = 0 ), &errFlags );
      if( errFlags || expr_pos < nxt - pos ) { 
	cerr <<  "error parsing number parameter #" << j+1 << " of command #" << i+1 << ": "; ArithmeticExpression::printFlags(cerr,errFlags); cerr << endl;
	err = ( numparams.chars - cmdd.chars ) + pos + expr_pos;
      }
      j++; pos = nxt + 1;
    }
    cmd.int_param_count = j;
    if( pos < numparams.length ) cerr << "command #" << i+1 << ": max. " << MAX_NUM_PARAM << "number parameters allowed." << endl;

    j=0; pos=0; while( pos < charparams.length && j < MAX_CHAR_PARAM ) {
      nxt = charparams.find_first_of(',',pos);
      if( SymbolTable::isGreekVariable(charparams.chars[pos]) ) shallbe_len = SymbolTable::varLength(charparams.chars+pos); else shallbe_len = 1;
      if( charparams.chars[pos] == '\\' && pos+1 < charparams.length ) { pos++; if( nxt==pos ) nxt++; }
      if( nxt - pos > shallbe_len ) cerr << "spurious characters in char param #" << j+1 << " of command #" << i+1 << " (" << charparams << ") of " << cmdd << endl;
      cmd.char_param[j] = estr_const( charparams.chars + pos, nxt - pos );
      j++; pos = nxt + 1;
    }
    cmd.char_param_count = j;
    if( pos < charparams.length ) cerr << "command #" << i+1 << ": max. " << MAX_CHAR_PARAM << "character parameters allowed." << endl;

    estr_const commandstr = estr_const( cmdd.chars + cmd.start, cmd.len );
    if( commandstr.length == 0 ) { err = cmd.start; cerr << "command #" << i+1 << " is empty: " << cmdd << endl; }
    else if( commandstr == (achar*)"L" ) cmd.action =  cmd.char_param_count ==  0 ? MS::Left : MS::SearchLeft;
    else if( commandstr == (achar*)"R" ) cmd.action =  cmd.char_param_count ==  0 ? MS::Right : MS::SearchRight;
    else if( cmd.char_param_count == 0 && cmd.int_param_count == 0 && ( commandstr.length == 1 || ( commandstr.length == 2 && commandstr.chars[0] == '\\' ) )  ) { 
      if( commandstr.length == 2 ) { cmd.start++; cmd.len--; }; cmd.action = MS::Print;
    } else cmd.action = MS::Exec;

    pos = cmdd.find_first_not_of( (achar*)" \t", remember_pos + 1 );
    command.push_back(cmd); i++;
  }
  return err;
}


bool MS::backpatchAtmtRefs(bool refreshAll) {
  std::list<Node*>::iterator ni;
  std::vector<MSNodeProxy>::iterator ci;
  bool good = true;
  for( ni = allNodes.begin(); ni != allNodes.end(); ni++ ) {
    MS_Node *node = (MS_Node*)*ni;
    for( ci = node->command.begin(); ci != node->command.end(); ci++ ) {
      MSNodeProxy *cmd= &*ci;
      if( cmd->action == Exec && ( !cmd->atmt || refreshAll ) ) {
	estr_const atmt_ident = node->cmdd.sub( cmd->start, cmd->len );
	AtmtIndex::const_iterator treeNodePair = atmtIndex->find(atmt_ident);
	if( treeNodePair != atmtIndex->end() && treeNodePair->second->atmt ) {
	  cmd->atmt = treeNodePair->second->atmt; 
	  if( cmd->atmt == this ) { cmd->atmt = NULL; good = false; cerr << "error: attempted recursion for automaton " << atmt_ident << endl; }
	} else {
	  if(refreshAll) cmd->atmt = NULL;
	  good = false; cerr << "error at backpatching: automaton called " << atmt_ident << " not found." << endl;
      } }
  } }
  return good;
}

Status MS_Runtime::getResultStatus( Element *e, Data *data ) {
  /*if( e->isFinalNode() ) {   // this would halt one step too early
    MS_Node *n = (MS_Node*)e;
    if( n->getRelPos() >= n->command.size() ) return halted;
  }*/
  TM_Data *d = (TM_Data*)data;
  if( d->pos < 0 ) return Status::hanging;
  /*if( e && e->isFinalNode() ) {
    TM_Node *haltnode = (TM_Node*)e;  // edge can never be a final node
    if( haltnode->label.length > 2 ) {
      echar indicator = haltnode->label.chars[2];
      if( indicator == '1' || indicator == 'a' ) return Status::accepted;
      else return Status::dismissed;
    } else {
      if( d->tape->right(3) == astr_const((const achar*)"#Y#",3) ) return Status::accepted;
      if( d->tape->right(3) == astr_const((const achar*)"#N#",3) ) return Status::dismissed;
    }
    return Status::halted;
  } */
  return stepDone;
}

Status MS_Runtime::status_4_no_successor( const State *state ) {  
  TM_Data *d = (TM_Data*)state->data; Status cur_status = Status::no_successor;
  if( d->pos < 0 ) cur_status = Status::hanging;
  else if( state->elm->isFinalNode() ) {
    if( d->tape->right(3) == astr_const((const achar*)"#Y#",3) ) cur_status = Status::accepted;
    else if( d->tape->right(3) == astr_const((const achar*)"#N#",3) ) cur_status = Status::dismissed;
    else cur_status = Status::halted;
  }
  if( cur_status > Status::stepDone ) rememberOutcome( state->elm, state->data, cur_status );
  return cur_status;
}


void MS_Runtime::freeMemSub( Automaton *atmt ) {
#ifdef QT_CORE_LIB
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) {
    if( (*in)->execLength() >= CursorPack && (*in)->cursorSet.ref ) { free((*in)->cursorSet.ref); (*in)->cursorSet.ref = NULL; } else (*in)->cursorSet.val = 0;
  }
#endif
  Runtime::freeMemSub(atmt); 
}

void MS_Node::lookAhead( Runtime *r, Data *d, int relpos ) {
  if( relpos >= (int)command.size() ) TM_MS_do_lookAhead( this, (TM_Runtime*)r, (TM_Data*)d, relpos );
  else r->addLookAhead( IntermedState( &command[relpos], d, NULL ) );
} 

int lookupChar( TM_Runtime *r, TM_Data *d, const echar *ident ) {
  if( SymbolTable::isGreekVariable(ident[0]) ) {
    long long result = SymbolTable::var_is_undefined;
    if( d->localSymTab ) result = d->localSymTab->lookUp(ident);
    if( r->paramSymTab && result & SymbolTable::var_is_undefined ) result = r->paramSymTab->lookUp(ident);
    if( result & SymbolTable::var_is_undefined ) { result = '#'; r->setCondition( Runtime::undefined_variable_during_next ); }
    return result;
  } else return ident[0];
}

struct Config { astr_shared *tape; int pos; enum Status status; };
typedef std::vector<Config> Configs;

void MS_Node::next( Runtime *rg, Data *dg, SymbolTable *tmpTransitionSymbols, int relpos ) {
  TM_Runtime *r = (TM_Runtime*)rg; TM_Data *d = (TM_Data*)dg;
  Runtime *runtime; MSNodeProxy *cmd = &command[--relpos]; int errFlags, i, n;
  int power =  cmd->potency.eval( &errFlags, NULL, r->paramSymTab );
  if(errFlags) { cerr << "error evaluating potency of command #" << relpos+1 << ": "; ArithmeticExpression::printFlags(cerr,errFlags); cerr << endl; }
  int* act_int_param = (int*)alloca( cmd->int_param_count * sizeof(int) ); 
  achar* act_char_param = (achar*)alloca( cmd->char_param_count * sizeof(achar) );
  for( i=0; i < cmd->int_param_count; i++ ) {
    act_int_param[i] = cmd->int_param[i].eval( &errFlags, NULL, r->paramSymTab );
    if(errFlags) { cerr << "error evaluating number param # " << i+1 << " of command #" << relpos+1 << ": "; ArithmeticExpression::printFlags(cerr,errFlags); cerr << endl; }
  }
  for( i=0; i < cmd->char_param_count; i++ ) {
    act_char_param[i] = lookupChar( r, d, cmd->char_param[i].chars );
  }
  switch(cmd->action) {
    case MS::Print: r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) 
			  TM_Data( d, lookupChar( r, d, cmdd.chars + cmd->start ) , 0, d->localSymTab->anotherInstance() ) )); break;
    case MS::Left: { 
	int target_pos = d->pos - power; int target_len = d->tape->length;
        // find_last_no_of returns an index rather than a length so add one to get a length, keep first target_pos + 1 chars
        if( d->pos == d->tape->length - 1 ) target_len = target_pos + 2 + d->tape->sub(target_pos+1).find_last_not_of('#');
	if( target_len < d->tape->length ) 
	  r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( d->tape->sub(0,target_len), target_pos, d->localSymTab->anotherInstance() ) ));
	else r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( d->tape, d->pos - power, d->localSymTab->anotherInstance() ) )); 
      }; break;
    case MS::Right: r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( d->tape, d->pos + power, d->localSymTab->anotherInstance() ) )); break;
    case MS::SearchLeft: { 
	int pos = d->pos; astr_const tape = *d->tape, searchfor = astr_const(act_char_param,cmd->char_param_count);
	bool lastPos = ( pos == tape.length - 1 ); int target_len = tape.length;
	while( power > 0 ) { pos = tape.find_last_of(searchfor,pos-1); power--; }
	if( pos < 0 ) pos = -1;
        // find_last_no_of returns an index rather than a length so add one to get a length, keep first target_pos + 1 chars
        if(lastPos) target_len = ( pos >= 0 ? pos : 0 ) + 2 + tape.sub(pos+1).find_last_not_of('#');
	if( target_len < tape.length ) 
	  r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( tape.sub(0,target_len), pos, d->localSymTab->anotherInstance() ) ));
	else r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( d->tape, pos, d->localSymTab->anotherInstance() ) ));
      }; break;
    case MS::SearchRight: {
	int pos = d->pos; astr_const tape = *d->tape, searchfor = astr_const(act_char_param,cmd->char_param_count);
	while( power > 0 ) { pos = tape.find_first_of(searchfor,pos+1); power--; }
	if( pos >= tape.length && searchfor.find_first_of((achar)'#') >= searchfor.length ) {
          r->setCondition( Runtime::endless_search );
	} else { 
          r->addState(State( &command[relpos], new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( d->tape, pos, d->localSymTab->anotherInstance() ) ));
	}
      }; break;
    default:
	if(!cmd->atmt) { r->setCondition( Runtime::undefined_automaton ); return; }
	Configs cfgs[2]; bool act = 0; Configs::const_iterator ci; Config cfg;
#ifdef _MSC_VER
	cfgs[act].push_back( Config{ d->tape->duplicate(), d->pos, halted } );
#else
	cfgs[act].push_back( Config{ .tape = d->tape->duplicate(), .pos = d->pos, .status = halted } );
#endif
	while( power > 0 ) {
	  for( ci = cfgs[!act].begin(); ci != cfgs[!act].end(); ci++ ) astr_shared::freeMem(ci->tape); 
	  cfgs[!act].clear();
	  for( ci = cfgs[act].begin(); ci != cfgs[act].end(); ci++ ) {
	    runtime = cmd->atmt->createRuntime( ci->tape, ci->pos, astr_const(act_char_param,cmd->char_param_count), inta_const(act_int_param,cmd->int_param_count), 2, false );
	    runtime->setIgnoreErrorMask(-1); runtime->exec();
	    for( i=0, n=runtime->numOutcomes(); i < n; i++ ) {
	      runtime->getOutcome( i, &cfg.tape, &cfg.pos, &cfg.status, NULL );
	      if( cfg.status >= Status::halted ) cfgs[!act].push_back(cfg);
	    }
	    if(cfgs[!act].empty()) 
	      for( i=0, n=runtime->numOutcomes(); i < n; i++ ) {
		runtime->getOutcome( i, &cfg.tape, &cfg.pos, &cfg.status, NULL );
		if( cfg.status == Status::hanging ) cfgs[!act].push_back(cfg);
	      }
	    cmd->atmt->freeRuntime(runtime);
	  }
	  power--; act = !act;
	}
	for( ci = cfgs[act].begin(); ci != cfgs[act].end(); ci++ ) {
	  //cout << *(ci->tape) << endl;
	  TM_Data *data = new((TM_Data*)alloc(sizeof(TM_Data))) TM_Data( ci->tape, ci->pos, d->localSymTab->anotherInstance() );
	  r->addState( State( &command[relpos], data ) ); astr_shared::freeMem(ci->tape);  
	}
	for( ci = cfgs[!act].begin(); ci != cfgs[!act].end(); ci++ ) astr_shared::freeMem(ci->tape); 
      break;
  }
}


// ------------ user interface: viewing a TM ------------ 

void TM_Runtime::printData( IOStreamRef out, Data *data, bool shallPrintVars ) const { 
  TM_Data *d = (TM_Data*)data; astr_const tape = d->tape->as_const(); int pos = d->pos; const char *cursor_left, *cursor_right; 
  if( terminal_type.charset == Charset::utf8 ) { cursor_left = "⟪"; cursor_right = "⟫";} else { cursor_left = "<<"; cursor_right = ">>"; }
  //out << tape.sub(0,pos) << "[" << tape.sub(pos,1) << "]" << tape.sub(pos+1); 
  out << tape.sub(0,pos) << cursor_left << tape.sub(pos,1) << cursor_right << tape.sub(pos+1); 
  if( !SymbolTable::isEmpty(d->localSymTab) && ( shallPrintVars || d->localSymTab->getUsageCount() <= 1 ) ) { 
    out << ","; d->localSymTab->print(out,","); 
  } else if( shallPrintVars ) {
    out << ",no vars"; 
  }
};

int TM_Runtime::numTapes( ParentTapeIndex i ) { 
  if(unlikely( !i.isRootAnchor() )) return 0;
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  return (int)cur->new_data_pos.size() - 1; 
};

int TM_Runtime::getTape( astr_const *content, int *pos, SymbolTable **symTab, TapeIndex i ) {
  if(unlikely( i.subidx >= 0 )) return nonExistantTape(content,pos,symTab);
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  if(unlikely( i.topidx >= (int)cur->new_data_pos.size() - 1 || i.topidx < 0 )) return nonExistantTape(content,pos,symTab);
  TM_Data *data = (TM_Data*) cur->new_data_pos[i.topidx].state_pos->data;
  if(content) *content = *(data->tape); if(pos) *pos = data->pos; 
  if(symTab) *symTab = data->localSymTab != &emptySymbolTable ? data->localSymTab : NULL; 
  return 0;
};

void TM_Runtime::getStatesAndLookAheadForTape( struct StatesAndLookAhead *standlh, TapeIndex i ) { 
  if(unlikely( i.subidx >= 0 )) { getEmptyStatesAndLookAhead( standlh ); return; }
  if( i.topidx <= -1 ) { getAllStatesWithLookAhead( standlh ); return; }
  if(unlikely( cur->new_data_pos.empty() )) init_new_data_pos();
  if(unlikely( i.topidx >= (int)cur->new_data_pos.size() - 1 )) { getEmptyStatesAndLookAhead( standlh ); return; }
  TraceStep::StatePosVec::const_iterator spos = cur->new_data_pos.begin() + i.topidx;
  standlh->first_state = spos->state_pos;
  standlh->first_lookahead = spos->lhd_pos;
  spos++;
  standlh->last_state = spos->state_pos;
  standlh->last_lookahead = spos->lhd_pos;
};

void TM_Runtime::getOutcome( int idx, astr_shared **tape, int *position, enum Status *status, int *step_num ) {
  if( idx < (int)finalStates.size() ) {
    FinalState *f = &finalStates[idx];
    TM_Data *d = (TM_Data*)f->data;
    if(position) *position = d->pos;
    if(tape) *tape = d->tape->duplicate();
    if(status) *status = f->status;
    if(step_num) *step_num = f->step_num;
  } else {
    if(tape) *tape = NULL; if(position) *position = -1;
    if(status) *status = Status::stepDone;
    if(step_num) *step_num = cur_step;
  }
}

