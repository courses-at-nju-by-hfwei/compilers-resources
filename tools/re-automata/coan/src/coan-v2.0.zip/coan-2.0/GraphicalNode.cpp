//#include <math.h>
#include <QtGui/QPainter>
#include <QtCore/QtMath>
#include "GraphicalNode.h"

qreal square_root_of_two = qSqrt(2); 

void drawStartNodeArrow( QPainter *painter, qreal x, qreal y ) {
  painter->drawLine( x, y, x + Edge::arrowLen * qCos(+5/6.0*M_PI), y + Edge::arrowLen * qSin(+5/6.0*M_PI) );
  painter->drawLine( x, y, x + Edge::arrowLen * qCos(-5/6.0*M_PI), y + Edge::arrowLen * qSin(-5/6.0*M_PI) );
  painter->drawLine( x - 2*Edge::arrowLen, y, x, y ); 
}

const int finalNodeDoubleSpacing = 3;

void EllipticalNode::draw( QPainter *painter, Automaton *atmt ) const {
  painter->setPen(paintsettings[modus].pen); painter->setBrush(QBrush(Qt::NoBrush));
  if(isFinalNode()) {
    int d = finalNodeDoubleSpacing, dd = 2 * finalNodeDoubleSpacing;
    painter->drawEllipse( pos.x()-a-d, pos.y()-b-d, a*2+dd, b*2+dd );
  }
  painter->setBrush(paintsettings[modus].brush);
  painter->drawEllipse( pos.x()-a, pos.y()-b, a*2, b*2 );
  if( atmt->startNode == this ) {
    int d = isFinalNode() ? finalNodeDoubleSpacing : 0;
    drawStartNodeArrow( painter, pos.x()-a-d, pos.y() );
  }
  if( modus != Modus::moving ) GraphElement::drawText(painter);
}

void EllipticalNode::doUpdateGeometry( QPaintDevice *d, struct TextExtent ext ) {
  a = ( ext.width ) / 2 * square_root_of_two;
  b = ( ext.ascent + ext.descent ) / 2 * square_root_of_two;
  if( a < b ) a = b;
  Node::doUpdateGeometry( d, ext );
}

bool EllipticalNode::isThere( QPointF where ) const {
  //if(!( pos.x()-a <= where.x() && where.x() <= pos.x()+a && pos.y()-b <= where.y() && where.y() <= pos.y()+b )) return false; 
  if(!boundingRect().contains(where)) return false;
  QPointF relpos = where - pos;
  return relpos.x()*relpos.x() / (a*a) + relpos.y()*relpos.y() / (b*b) <= 1.0;
}

QPointF EllipticalNode::getSecant( QPointF from ) const {
  QPointF delta = from - pos;
  qreal len = qSqrt( delta.x()*delta.x() + delta.y() * delta.y() );
  qreal aa = a, bb = b; if(isFinalNode()) { aa += 3; bb += 3; }
  return QPointF( pos.x() + delta.x() * aa / len, pos.y() + delta.y() * bb / len ); 
}


void RectangularNode::draw( QPainter *painter, Automaton *atmt ) const {
  painter->setPen(paintsettings[modus].pen); painter->setBrush(paintsettings[modus].brush);
  painter->drawRoundedRect( pos.x()-a, pos.y()-b, a*2, b*2, roundness, roundness );
  if( atmt->startNode == this ) {
    int d = isFinalNode() ? finalNodeDoubleSpacing : 0;
    drawStartNodeArrow( painter, pos.x()-a-d, pos.y() );
  }
  if( modus != Modus::moving ) GraphElement::drawText(painter);
}

void RectangularNode::doUpdateGeometry( QPaintDevice *d, struct TextExtent ext ) {
  a = ( ext.width + 11 ) / 2;
  b = ( ext.ascent + ext.descent + 7 ) / 2;
  if( a < b ) a = b;
  Node::doUpdateGeometry( d, ext );
}

bool RectangularNode::isThere( QPointF where ) const {
  return boundingRect().contains(where);
  //return pos.x()-a <= where.x() && where.x() <= pos.x()+a && pos.y()-b <= where.y() && where.y() <= pos.y()+b;
}

QPointF RectangularNode::getSecant( QPointF from ) const {
  QPointF delta = from - pos;
  if( qAbs(delta.x()) < 0.8 ) return QPointF( pos.x(), from.y() < pos.y() ? pos.y() - b : pos.y() + b );
  qreal acclivity = qAbs(delta.y()) / qAbs(delta.x()), acclivityOfEdge = b / a;
  if( acclivity > acclivityOfEdge ) {
    qreal bb = delta.y()<0 ? -b : +b;
    return QPointF( pos.x() + delta.x() * bb / delta.y(), pos.y() + bb );
  } else {
    qreal aa = delta.x()<0 ? -a : +a;
    return QPointF( pos.x() + aa, pos.y() + delta.y() * aa / delta.x() );
  }
}


