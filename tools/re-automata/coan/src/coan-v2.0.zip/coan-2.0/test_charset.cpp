#include "auxtypes.h"
#include "symtab.h"
#include "charset.h"
//#include <iostream>
//#include <map>
#include <algorithm>
#include <assert.h>
#include <time.h>
#include "errno.h"

using namespace aux;

const char* bool2str[2] = { "bad", "good" };
const char* in_or_not[2] = { "not in", "in" };

void printSimpleSetTest() {
  cout << "****** printSimpleSetTest ******" << endl;
  StaticCharSet a, b, c;
  a.clear(); a.set_elm(133); a.set_elm(12); a.set_elm(13); a.set_elm(0); a.set_elm(255);
  a.set_range(3,67);
  a.print(cout,print_numeric); cout << endl;
  b.clear();
  b.set_elm('a'); b.set_elm('b'); b.set_elm('c');
  b.print(cout); cout << endl;
  c.fill();
  c.unset_elm(64); c.invert_range(28,130);
  c.print(cout,print_numeric); cout << endl << endl;
}

void inCharSetTest() {
  cout << "****** inCharSetTest ******" << endl;
  int err_pos;
  estrbuf fixedcharset("1…9␣…bβᴗ12 ∖γ"); 
  err_pos = ExtCharSet::first_error_position(fixedcharset,0);
  cout << fixedcharset << ": check is " <<  bool2str[err_pos==-1]; if(err_pos>=0) cout << " on from " << fixedcharset.sub(err_pos); cout << endl;
  fixedcharset.moveFrom(estrb("1…9b…␣βᴗ12 0∖3γ"));
  err_pos = ExtCharSet::first_error_position(fixedcharset,0);
  cout << fixedcharset << ": check is " <<  bool2str[err_pos==-1]; if(err_pos>=0) cout << " on from " << fixedcharset.sub(err_pos); cout << endl;

  estrbuf mycharset("␣1…9αᴗ11 …βᴗ12 0∖3γ");
  err_pos = ExtCharSet::first_error_position(mycharset,0);
  cout << mycharset << ": check is " <<  bool2str[err_pos==-1]; if(err_pos>=0) cout << " on from " << mycharset.sub(err_pos); cout << endl;
  err_pos = ExtCharSet::first_error_position(mycharset,ExtCharSet::allow_var_ranges);
  cout << mycharset << ": allow_var_ranges check is " <<  bool2str[err_pos==-1]; if(err_pos>=0) cout << " on from " << mycharset.sub(err_pos); cout << endl;

  estrbuf test_output_set("ραᴗ11 …βᴗ12 ∖a∖c,{}∖∖∖q");
  ExtCharSet::print(cout,test_output_set,false,true); cout << endl * 2;

  estrbuf my_test_chars(" 12ab0h3gx"); estrbuf my_vars("αᴗ11 βᴗ12 γ");
  SymbolTable *local = SymbolTable::reserveEmpty(2);
  SymbolTable *global = emptySymbolTable.copy();
  int pos = 0; int pos1, pos2;
  local = local->set( my_vars.chars + pos, 'a', &pos, SymbolTable::set_always ); pos1 = pos; assert( pos < my_vars.length ); 
  local = local->set( my_vars.chars + pos, 'h', &pos, SymbolTable::set_if_undefined ); pos2 = pos; assert( pos < my_vars.length ); 
  global = global->set( my_vars.chars + pos, 'g', &pos, SymbolTable::set_always );

  achar a_content = local->lookUp( my_vars.chars ); cout << my_vars.sub(0,pos1-1) << " = " << astr(&a_content,1) << ", ";
  achar b_content = local->lookUp( my_vars.chars + pos1 ); cout << my_vars.sub(pos1,pos2-pos1-1) << " = " << astr(&b_content,1) << ", ";
  achar g_content = global->lookUp( my_vars.chars + pos2 ); cout << my_vars.sub(pos2) << " = " << astr(&g_content,1) << ", ";
  cout << "testing for: " << mycharset << " or "; ExtCharSet::print(cout,mycharset); cout << endl;

  for( int i=0; i < my_test_chars.length; i++ ) {
    bool had_undefined = false;
    cout << "character '" << my_test_chars.sub(i,1) << "' is " << in_or_not[ \
      ExtCharSet::elm_in( my_test_chars.chars[i], mycharset, local, global, &had_undefined ) \
    ] << " this character set.";
    if( had_undefined ) cout << "( there was an undefined variable)";
    cout << endl;
  }
  cout << endl << endl;
}

void printVar( SymbolTable *home, estr_const var, int value, void *data ) {
  bool *first = (bool*)data;
  if( !first || !*first ) cout << ", "; if(first) *first = false;
  cout << ( value < 0 ? "-" : "+" ) << var;
}


estr_const hug1, hug2;

void hugAssign() { estrc_anchor a; hug1 = estrc(a,"abc"); hug2 = estrc(a,"xyz"); }  // as the anchor is of local scope the content of hug1 and hug2 is no more valid after return

void collectSingleCharSetTest() {
  cout << "****** collectSingleCharSetTest ******" << endl;
  // does not work as local variable: estr_const test_set[] = { estr("abc∖cd")/*, estr("1…9b…␣βᴗ12 0∖3γ")*/ };
  StaticCharSet positive_set, used_set; SymbolTable *symtab = NULL; bool first; // int flags = 0;
  const char* test_set[] = { "abc∖cd", "1…9b…␣βᴗ12 0∖3γ", "αβ∖αγ" };
  int num_test_sets = sizeof(test_set) / sizeof(const char*);
  int coll_round, errpos; cout << endl; estrbuf set;

  for( int i=0; i < num_test_sets; i++ ) {
    for( int neg=0; neg <= 1; neg++ ) {
      if(neg) cout << IOChangeFlags( IOFlag::OverlineNextXStr );
      cout << ( set = test_set[i] ) << endl; positive_set.clear(); used_set.clear();
      if(( errpos = ExtCharSet::first_error_position( set ) ) >= 0 ) {
	cout << "!! detected error at pos " << errpos << " " << set.sub(0,errpos-1) << "|" << set.sub(errpos) << endl;
      }

      ExtCharSet::collectSymbolsAndVars( set, neg, &coll_round, &positive_set, &used_set, &symtab, NULL );
      //ExtCharSet::collectSymbolsAndVars( set, false, NULL, &positive_set, &used_set, NULL, NULL );
      if(!positive_set.isEmpty()) { cout << "positive_set: "; positive_set.print(cout); cout << "." << endl; }
      if(!used_set.isEmpty()) { cout << "used_set: "; used_set.print(cout); cout << "." << endl; }
      if(!symtab->isEmpty()) { cout << "variables: "; first=false; symtab->forall(printVar,&first); cout << "." << endl; }
      SymbolTable::free(&symtab);
      cout << endl;
  } }
  cout << endl;
}

void collectCharSetSeqTest() {
  cout << "****** collectCharSetSeqTest ******" << endl;
  // does not work as local variable: estr_const test_set[] = { estr("abc∖cd")/*, estr("1…9b…␣βᴗ12 0∖3γ")*/ };
  StaticCharSet positive_set, used_set; SymbolTable *symtab = NULL; bool first; estrc_anchor ean; // int flags = 0;
  const struct SeqItem { const char *set; bool neg; } testSeq[] = { 
    { "2α∖2β", 0 }, { "3∖α", 0 }, { "α∖3α", 0 },  { "ζγ0∖ζδ1", 1 }, { "1ζ", 1 }
  };
  int seqLen = sizeof(testSeq) / sizeof(SeqItem); 
  int coll_round, errpos; cout << endl;
  positive_set.clear(); used_set.clear();

  for( int i=0; i < seqLen; i++ ) {
    bool neg = testSeq[i].neg; estr_const set = estrc(ean,testSeq[i].set);
    if(neg) cout << IOChangeFlags( IOFlag::OverlineNextXStr );
    cout << set << endl;
    if(( errpos = ExtCharSet::first_error_position( set ) ) >= 0 ) { cout << "!! detected error at pos " << errpos << set.sub(0,errpos-1) << "|" << set.sub(errpos) << endl; }

    ExtCharSet::collectSymbolsAndVars( set, neg, &coll_round, &positive_set, &used_set, &symtab, NULL );
    if(!positive_set.isEmpty()) { cout << "positive_set: "; positive_set.print(cout); cout << "." << endl; }
    if(!used_set.isEmpty()) { cout << "used_set: "; used_set.print(cout); cout << "." << endl; }
    if(!symtab->isEmpty()) { cout << "variables: "; first=true; symtab->forall(printVar,&first); cout << "." << endl; }
    cout << endl;
  }
  used_set.setdiff_with( positive_set );
  cout << "final used_set: "; used_set.print(cout); cout << "." << endl;
  SymbolTable::free(&symtab);
  cout << endl;
}

void intersectTest() {
  cout << "****** intersectTest ******" << endl;
  assert( ExtCharSet::complement_set_a == 1 && ExtCharSet::complement_set_b == 2 );
  // eine Var (α): alle 256 Möglichkeiten durchtesten
  struct IsctTest { int res; const char *set_a, *set_b, *base_set; int flags[5]; } *it, isctTest[] =
   { { 1, "a…b", "c…e", "a…e", { 0, 3, -1 } }, { 0, "a…b", "c…e", "a…e", { 1, 2, -1 } }, 
     { 0, "a…c", "b…e", "a…e", { 0, 1, 2, -1 } }, { 1, "a…b", "b…e", "a…e", { 3, -1 } }, 
     { 1, "a…c", "b", NULL, { 1, -1 } }, { 1, "b", "a…c", NULL, { 2, -1 } },
     { 0, "a", "α", NULL, { 0, 1, 2, 3, -1 } }, { 0, "xα", "a", NULL, { 0, 1, 2, 3, -1 } }, { 0, "α", "β", NULL, { 0, 1, 2, 3, -1 } }, 
     { 1, "α", "α", NULL, { 1, 2, -1 } }, { 0, "αᴗ11 ", "αᴗ11 ", NULL, { 0, 3, -1 } }, { 1, "αβ", "αβ", NULL, { 1, 2, -1 } }, { 0, "αβ", "αβ", NULL, { 0, 3, -1 } }, 
     { 1, "a", "α∖ab", NULL, { 0, -1 } }, { 0, "a", "α∖a", NULL, { 1, 2, 3, -1 } }, 
     { 1, "a", "aα", NULL, { 2, -1 } },
     { 1, "α", "ab∖α", NULL, { 0, -1 } }, { 0, "α", "ab∖α", NULL, { 1, 2, 3, -1 } },
     { 1, "α", "β∖α", NULL, { 0, -1 } }, { 1, "xα", "β∖xα", NULL, { 0, -1 }  }
   };
  int isctTestNum = sizeof(isctTest) / sizeof(struct IsctTest);
  const char* disjointness2str[2] = { "not_always_disjoint", "disjoint" };
  const char* negstr[2] = { "", "!" };
  StaticCharSet baseSet; bool hasBaseSet; estrbuf setA, setB;
  for( int i=0; i < isctTestNum; i++ ) {
    it = isctTest + i; setA = it->set_a; setB = it->set_b; 
    if(( hasBaseSet = it->base_set )) {
      baseSet.clear(); estrbuf base_set_str( it->base_set );
      ExtCharSet::collectSymbolsAndVars( base_set_str, false, NULL, &baseSet );
    } else baseSet.fill();
    for( int *flags = it->flags; *flags != -1; flags++ ) {
      /*if( ++testnum < 3 ) continue; else { 
	cout << "testing: " << negstr[!!( *flags & ExtCharSet::complement_set_a )] << setA << " ~ " << negstr[!!( *flags & ExtCharSet::complement_set_b )] << setB << " ("; 
	if(hasBaseSet) baseSet.print(cout); else cout << "no base set"; cout << ")" << endl;
      }*/
      StaticCharSet baseSetCpy = baseSet;
      bool result = ExtCharSet::alwaysDisjoint( setA, setB, hasBaseSet ? &baseSetCpy : NULL, *flags, NULL );
      assert( baseSet == baseSetCpy );
      if( result != it->res ) {
	cout << negstr[!!( *flags & ExtCharSet::complement_set_a )] << setA << " ~ " << negstr[!!( *flags & ExtCharSet::complement_set_b )] << setB << " ("; 
	if(hasBaseSet) baseSet.print(cout); else cout << "no base set"; cout << ")" << endl;
	cout << "  shall be: " << disjointness2str[it->res] << "  but is: " << disjointness2str[result] << endl << endl;
      } else {
	cout << "good: " << negstr[!!( *flags & ExtCharSet::complement_set_a )] << setA << " ~ " << negstr[!!( *flags & ExtCharSet::complement_set_b )] << setB;
	if(hasBaseSet) { cout << ": "; baseSet.print(cout); }
	cout << "  (" << disjointness2str[result] << ")" << endl;
      }
    }
  }
  cout << endl;
}


int main( int argc, char *argv[] ) {
  //echar *readstring; 
  //long long hug;
  cout << IOChangeFlags( IOFlag::ImmediateFlush );
  cout << "CharSet Test" << endl;
  // int minus_one = -1; iword hug = (iword)(unsigned int)minus_one; printf("%lx\n", hug ); cout << (int)hug << endl; exit(0);
  srand(time(NULL)); 

  // printSimpleSetTest();
  // inCharSetTest();

  collectSingleCharSetTest();
  collectCharSetSeqTest();
  intersectTest();

////  hugAssign(); // already freed: free((void*)hug1.chars);

  cout.flush();
  return 0;
}
