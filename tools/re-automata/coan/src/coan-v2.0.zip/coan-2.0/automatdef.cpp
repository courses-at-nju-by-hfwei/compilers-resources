#include <iterator>
#include <algorithm>
#include <assert.h>
#include <signal.h>
#include "automatdef.h"

using namespace std;
using namespace aux;
#define endl aux::endl

const char *Status2Chars[] = { "no successor defined", "internal error", "stepDone", "fatal error", "hanging", "halted", "dismissed", "accepted" };
const int numStatus2Chars = sizeof(Status2Chars) / sizeof(const char*);

estrbuf dangling_node_buf;  // initialized on demand

//
// Automata implementation: generic procedures
//

//
//     data structure initialization / disposure
// ==================================================


Automaton::Automaton() {
  startNode = NULL; flags = 0; charsetCheckFlags = 0;
  charFormalParamCount = valFormalParamCount = 0;
  charFormalParams = valFormalParams = empty_estr;
};

void propagateEpsilon( Node *from, Node *to ) {
  Nodes *from_closure = &(from->epsilonClosure);
  // stout << from->getContent() << "->" << to->getContent() << endl;  stout.flush();
  if( find( from_closure->begin(), from_closure->end(), to ) != from_closure->end() ) return;    // not needed as closure is reflexive: from == to || ...
  from_closure->push_back( to );
  for(Edges::const_iterator itr_before = from->pred.begin(); itr_before != from->pred.end(); itr_before++ )
    if((*itr_before)->isEpsilon()) propagateEpsilon( (*itr_before)->from, to );
}

void Automaton::refreshEpsilonClosure() {
  for(list<Node*>::const_iterator in = allNodes.begin(); in != allNodes.end(); in++ ) {
    Node *n = *in;
    n->epsilonClosure.resize(1,n);    // i.e. closure is reflexive (and transitive)
    n->epsilonSucc = std::partition( n->succ.begin(), n->succ.end(), mem_fun(&Edge::isEpsilon) ) - n->succ.begin();
  }
  for(list<Edge*>::const_iterator ie = allEdges.begin(); ie != allEdges.end(); ie++ ) {
    Edge *e = *ie;
    if(e->isEpsilon()) propagateEpsilon( e->from, e->to );
  }
}


int Automaton::setFormalCharParams( estrbuf *formalParams ) {
  charFormalParamCount = SymbolTable::normalize( formalParams, SymbolMode::mode_grVarList );
  charFormalParams.moveFrom( formalParams );
  return charFormalParamCount;
}

int Automaton::setFormalValParams( estrbuf *formalParams ) {
  valFormalParamCount = SymbolTable::normalize( formalParams, SymbolMode::mode_latVarList );
  valFormalParams.moveFrom( formalParams );
  return valFormalParamCount;
}

template<class Base> int Runtime::InitVars( estr_const formalParams, xstr_const<Base> actualParams, Base zeroparam, int formalParamCount ) {
  int len = formalParams.length; const echar *varnames = formalParams.chars; int pos = 0; int errval = 0;
  int unusedActParamCount = actualParams.length; const Base *val = actualParams.chars; bool hadActuals = unusedActParamCount > 0;
  while( pos < len && unusedActParamCount > 0 ) {
    paramSymTab = paramSymTab->set( varnames + pos, *val, &pos );
    unusedActParamCount--; val++; formalParamCount--;
  }
  val--; while( pos < len ) {
    if(hadActuals) paramSymTab = paramSymTab->set( varnames + pos, *val, &pos );
              else paramSymTab = paramSymTab->set( varnames + pos, zeroparam, &pos );
    formalParamCount--;
  }
  // error detection: check internal consistency conditions: read beyond end of the formalParams - estr_const, formalParamCount had an incorrect value (only checked if enough actual parameters were given)
  if(unlikely( pos > len )) {
    cerr << "Runtime::InitVars: read beyond indicated/consistent length of formalParams by the SymbolTable (could have read undefined/corrupted memory)." << endl; errval = -1; }
  if(unlikely( formalParamCount != 0 )) {
    cerr << "Runtime::InitVars: " << formalParamCount << " more formal params are defined than indicated by formalParamCount." << endl; errval = -1; }
  // check for user errors
  if(unlikely( unusedActParamCount > 0 )) {
    cerr << "Runtime::InitVars: more actual params passed in than formal params declared previously (" << unusedActParamCount << " superfluous actual params)." << endl;
    errval = -1;
  }
  return errval;
}

Runtime::Runtime( Automaton *a, astr_const charParam, inta_const valParam, int trace_len ) : state_compare(this) { 
  if( trace_len < 2 ) trace_len = 2; 
  trace = (struct TraceStep*) malloc( sizeof(struct TraceStep) * trace_len );
  for(int i=0; i<trace_len; i++ ) new(&trace[i]) TraceStep(state_compare);
  //for(int i=0; i<trace_len; i++ ) assert( ((State_compare_less)trace[i].states.key_comp()).runtime == this ); 
  tlen = trace_len; tpos = 0; prev = NULL; cur = trace; cur_step = 0;
  accruedConditions = 0; accruedStatus = no_successor; stopOnErrorMask = IsAnError; cur->conditions = is_the_initial_step | all_done; cur->zeroReadEdgeNum = 0;
  cur->status = internal_error; // needs to be set by the respective descendant constructor and has to be equivalent to the return value of acceptByTapeContent( NULL, NULL, stepDone )
  if( a->charFormalParamCount + a->valFormalParamCount ) {
    paramSymTab = SymbolTable::reserveEmpty( a->charFormalParamCount + a->valFormalParamCount );
    InitVars( a->charFormalParams, charParam, (achar)'#', a->charFormalParamCount );
    InitVars( a->valFormalParams, valParam, 1, a->valFormalParamCount );
  } else paramSymTab = emptySymbolTable.anotherInstance();
};

void Runtime::rememberOutcome( Element *e, Data *d, enum Status status ) {
  if( !e || e->isFinalNode() || status <= Status::hanging )
    finalStates.push_back( FinalState( e, duplicateData(d), status, cur_step ) );
}

void Runtime::freeLookAheadElements( struct TraceStep *ctr ) {
  for( ImStateVector::const_iterator s = ctr->lookahead.begin(); s!=ctr->lookahead.end(); s++ ) {  
    if( s->tmpSmbls ) SymbolTable::freeMem( s->tmpSmbls ); }
}

void Runtime::TraceStep::freeMemSub( Runtime *r, struct TraceStep *trs ) {
  for( States::const_iterator s = trs->states.begin(); s != trs->states.end(); s++ ) { if(s->data) r->freeData(s->data); }
  r->freeLookAheadElements( trs );
  // trs->states.~States(); trs->lookahead.~ImStateVector(); trs->zeroReadEdges.~ZeroReadEdges(); trs->new_data_pos.~StatePosVec();
  trs->~TraceStep();
}

void Runtime::freeMemSub( Automaton *a ) { 
  for(int i=0; i < tlen; i++ ) TraceStep::freeMemSub( this, trace + i );
  free(trace); 
  for(FinalStates::iterator fi = finalStates.begin(); fi != finalStates.end(); fi++ ) { if(fi->data) freeData(fi->data); };
  SymbolTable::freeMem(paramSymTab); 
}

void Runtime::printConditions( IOStreamRef out, int conditions ) {
  bool first = true;
  if( conditions & is_the_initial_step ) out << "initial step: ";
  if( conditions & no_startNode ) { out << "no starting node defined"; first = false; }
  if( ( conditions & undefined_variable_during_lookahead ) && ( conditions & undefined_variable_during_next ) ) { 
    if(!first) out << ", "; out << "undefined variable ( at nextStep/when writing to tape + in lookAhead/when checking a condition )"; first = false; 
  } else {
    if( conditions & undefined_variable_during_lookahead ) { if(!first) out << ", "; out << "undefined variable (in lookAhead/when checking a condition)"; first = false; }
    if( conditions & undefined_variable_during_next ) { if(!first) out << ", "; out << "undefined variable (at nextStep/when writing to tape)"; first = false; }
  }
  if( conditions & had_an_illegal_epsilon_loop ) { if(!first) out << ", "; out << "illegal epsilon loop"; first = false; }
  if( conditions & undefined_automaton ) { if(!first) out << ", "; out << "undefined automaton"; first = false; }
  if( conditions & endless_search ) { if(!first) out << ", "; out << "endless search"; first = false; }
}

//
//     execution
// ================


void Runtime::resetTraceStep( struct TraceStep *cur ) {
  for(States::const_iterator s = cur->states.begin(); s!=cur->states.end(); s++ ) { if(s->data) freeData(s->data); }
  freeLookAheadElements( cur ); 
  cur->new_data_pos.clear(); cur->states.clear(); cur->lookahead.clear(); cur->viewOnlyElements.clear(); cur->zeroReadEdgeNum = 0;
}

void Runtime::addZeroReadEdge( Element *edge ) { 
  assert( cur->conditions & adding_zeroreads );
  if( find( cur->viewOnlyElements.begin(), cur->viewOnlyElements.end(), edge ) == cur->viewOnlyElements.end() ) 
    cur->viewOnlyElements.push_back( edge ); 
}

void Runtime::addErrorWithElement( Element *element ) { 
  assert( cur->conditions & at_lookAhead );
  if( find( cur->viewOnlyElements.begin() + cur->zeroReadEdgeNum, cur->viewOnlyElements.end(), element ) == cur->viewOnlyElements.end() ) 
    cur->viewOnlyElements.push_back( element ); 
}

inline bool Runtime::needed2AddEpsilonEdgesOf( Node *node ) {
  // EpsilonEdges in node->succ.begin() ... node->succ.begin() + node->epsilonSucc - 1
  if( !node->epsilonSucc ) return false;
  return find( cur->viewOnlyElements.begin(), cur->viewOnlyElements.end(), *(node->succ.begin()) ) == cur->viewOnlyElements.end();
}

inline bool Runtime::lookForSameElement( States::iterator pos, Node *node ) {
  States::iterator sibling = pos; // assert( pos->elm == node );
  if( pos != cur->states.begin() ) { --sibling; if( sibling->elm == node ) return true; sibling = pos; } 
  if( sibling == cur->states.end() ) return false;
  ++sibling; if( sibling != cur->states.end() ) { if( sibling->elm == node ) return true; }
  return false;
}

inline void Runtime::addEpsilonEdgesOf( Node *node ) { 
  if( !node->epsilonSucc ) return; // faster when there are no ε-edges
  cur->viewOnlyElements.insert( cur->viewOnlyElements.end(), node->succ.begin(), node->succ.begin() + node->epsilonSucc );
}

bool Runtime::addState( State next ) {
  assert( !( cur->conditions & at_lookAhead ) ); assert( next.elm );
  std::pair<States::iterator,bool> insertPos;
  insertPos = cur->states.insert(next);  // bool is true when elm was inserted
  if( !insertPos.second ) { if(next.data) freeData(next.data); return false; }
  Status thisStatus = getResultStatus( next.elm, next.data ); if( cur->status < thisStatus ) cur->status = thisStatus;
  if( thisStatus == Status::stepDone ) cur->conditions &= ~Condition::all_done;
  else if( Status::stepDone < thisStatus && !rememberOnceNoState() ) rememberOutcome( next.elm, next.data, thisStatus ); 
  Node *node = dynamic_cast<Node*>(next.elm);
  if(!node) return true;
  // if the same node is already here then the ε-edges of this node must already have been marked as viewOnlyElements
  // ¡¡ if there is no adjacent State with the same node the same node may still be found in the context of other data !! -> do not mark the same ε-edges twice, then
  bool epsilonNotHereYet = !lookForSameElement( insertPos.first, node ) && needed2AddEpsilonEdgesOf( node );
  if(epsilonNotHereYet) addEpsilonEdgesOf( node );
  if( !( cur->conditions & adding_zeroreads ) ) node->zeroReadLookAhead( this, next.data );
  if( node->epsilonClosure.begin() != node->epsilonClosure.end() )
    for( Nodes::const_iterator in = node->epsilonClosure.begin(); ++in < node->epsilonClosure.end(); ) {  // ++in: jump over first element: reflexive closure
      Data *dupData = duplicateData(next.data);
      insertPos = cur->states.insert( State( *in, dupData ) );
      if( !insertPos.second ) { if(dupData) freeData(dupData); continue; }
      Status thisStatus = getResultStatus( *in, next.data ); if( cur->status < thisStatus ) cur->status = thisStatus;
      if( thisStatus == Status::stepDone ) cur->conditions &= ~Condition::all_done;
      else if( Status::stepDone < thisStatus && !rememberOnceNoState() ) rememberOutcome( *in, next.data, thisStatus ); 
      if( epsilonNotHereYet ) {
	if( !lookForSameElement( insertPos.first, *in ) && needed2AddEpsilonEdgesOf( *in ) ) addEpsilonEdgesOf( *in );
      } else assert( !(*in)->epsilonSucc || !needed2AddEpsilonEdgesOf( *in ) );
      if( !( cur->conditions & adding_zeroreads ) ) (*in)->zeroReadLookAhead( this, next.data );
    }
  return true;
}

enum Status Runtime::nextStep( bool prepareStatePos ) {
  if( cur->conditions & all_done ) return cur->status;
  prev = cur; tpos++; if( tpos >= tlen ) tpos = 0;  cur = trace + tpos; cur_step++;
  accruedConditions |=  prev->conditions & ~Condition::is_the_initial_step;
  if( prev->status > accruedStatus ) accruedStatus = prev->status;
  resetTraceStep( cur );
  cur->conditions = all_done; cur->status = Status::no_successor;
  finalizeStep();    // Finite Automata: progress one position on the tape; i.e. actual character has now finally been read
  for(ImStateVector::const_iterator s = prev->lookahead.begin(); s!=prev->lookahead.end(); s++ )
     s->elm->next( this, s->data, s->tmpSmbls );
  return lookAhead( prepareStatePos );
}

inline void Runtime::lookAhead_simple() {
  int prev_lh_size = 0, lh_size;
  for(States::const_iterator s = cur->states.begin(); s!=cur->states.end(); s++ ) { 
    s->elm->lookAhead( this, s->data );
    lh_size = cur->lookahead.size();
    if( prev_lh_size == lh_size ) {
      Status cur_status = status_4_no_successor(&*s);
      if( cur_status > cur->status ) cur->status = cur_status;
    };
    prev_lh_size = lh_size;
  }
}

enum Status Runtime::lookAhead( bool prepareStatePos ) {
  assert( !( cur->conditions & at_lookAhead ) );
  cur->zeroReadEdgeNum = cur->viewOnlyElements.size(); 
  cur->conditions |= at_lookAhead;
  if( !( cur->conditions & ( FatalErrors | Condition::all_done ) ) ) {
    if( prepareStatePos ) lookAhead_with_StatePos(true); else lookAhead_simple();
    if( cur->lookahead.empty() ) { 
      if( cur->status == stepDone ) cur->status = status_4_no_consecutive_state();
      cur->conditions |= all_done;
  } }
  if( cur->conditions & Condition::all_done ) { 
    if( rememberOnceNoState() ) rememberOutcome( NULL, NULL, cur->status );
    accruedConditions |=  cur->conditions & ~Condition::is_the_initial_step; 
  }
  if( cur->status > accruedStatus ) accruedStatus = cur->status; 
  return cur->status;
}

bool Runtime::exec( bool stopOnResult, int maxsteps ) {
  while( !(cur->conditions & all_done) && ( maxsteps != 0 ) ) { 
    nextStep(false);
    if( cur->conditions & stopOnErrorMask ) break;
    if( stopOnResult && cur->status > Status::stepDone ) break;
    if( maxsteps > 0 ) maxsteps--;
  }
  return maxsteps != 0 || ( cur->conditions & ( all_done | stopOnErrorMask) ) || ( stopOnResult && cur->status > Status::stepDone );
}


//
//     print aware execution methods
// =====================================

Runtime* Runtime::exec_traced( IOStreamRef out, bool stopOnResult, int debuglevel, int maxsteps ) {
  const char *rightArrow, *doubleArrow, *backArrow;
  if( terminal_type.charset == Charset::utf8 ) { rightArrow = " → "; doubleArrow = " ⥂ "; backArrow = " ↩ "; }
  else { rightArrow = " ->> "; doubleArrow = " <->> "; backArrow = " <- "; }
  Status status = cur->status; int stepnum = 0;
  if( getErrorConditions() & FatalErrors ) { 
    out << "fatal: "; printConditions( out, getErrorConditions() & FatalErrors ); out << endl; 
    return this;
  };
  do {
    int lastStepCond = cur->conditions; int lastStepErr = lastStepCond & IsAnError;
    bool do_print_first = ( lastStepCond  & is_the_initial_step ) || ( ( lastStepErr & NextStepErrors ) && !( lastStepErr & LookAheadErrors ) );
    while( mightContinue() && ( maxsteps < 0 || stepnum < maxsteps ) ) {
      if( do_print_first ) { // just initialized or lookAhead not printed in the last step / set true later on
	if( numTapes() == 1 ) { prnTape(out); out << ": "; }; 
	prnStates( out, cur, debuglevel ); out << ( !cur->zeroReadEdgeNum ? rightArrow : doubleArrow ); 
	prnLookAhead( out, cur, debuglevel );
	out << endl;
      }; do_print_first = true;
      status = nextStep(); stepnum++;
      if( cur->conditions & ( stopOnErrorMask | all_done ) ) break;
      if( cur->status != stepDone ) break;
    }
    if( numTapes() == 1 ) { prnTape(out); out << ": "; }; 
    prnStates( out, cur, debuglevel ); 
    int cur_errors = cur->conditions & IsAnError;
    int cur_next_errors = cur_errors & NextStepErrors;
    int numViewOnlyElements = (int)cur->viewOnlyElements.size();
    if( cur_next_errors ) {
      register bool stop_because_of_next_error = cur_next_errors & stopOnErrorMask;    // FatalErrors is always included in stopOnErrorMask
      register bool have_lookahead = !cur->lookahead.empty() || numViewOnlyElements;
      out <<  ( stop_because_of_next_error ? " stopping at error" : " with error" ) << ( have_lookahead ? " / " : "." );
    }
    bool haveErrorEdges = cur->zeroReadEdgeNum < numViewOnlyElements;
    register bool error_free_lookahead = !cur->lookahead.empty() || cur->zeroReadEdgeNum;
    if( error_free_lookahead || haveErrorEdges ) {
      register bool backward_active = cur->zeroReadEdgeNum;
      register bool forward_active = !cur->lookahead.empty();
      // assert( forward_active || backward_active ); // 
      out << ( forward_active ? ( !backward_active ? rightArrow : doubleArrow ) : backArrow ); 
      register bool justPrintErrorElts = !error_free_lookahead && haveErrorEdges; // also: && numViewOnlyElements; - because !error_free_lookahead -> cur->zeroReadEdgeNum == 0
      prnLookAhead( out, cur, debuglevel, justPrintErrorElts );
    }
    out << endl;
    bool interestingStatus = status != stepDone && status != fatal_error;
    bool runAsFarAsPossible = status != stepDone && stopOnErrorMask == FatalErrors;  // status != stepDone => cur_errors is a subset of accruedConditions (see: lookAhead(), maxsteps)
    if( cur_errors ) {
      int fatal = cur_errors & FatalErrors;
      int other_err = cur_errors & ~FatalErrors;
      if( fatal ) { out << "fatal: "; printConditions( out, fatal ); }
      if( fatal && other_err ) out << " & ";
      if( other_err ) {
	if(!runAsFarAsPossible) { out << "error: "; printConditions( out, other_err ); }
	else cur_errors &= ~other_err;   // print them later with accruedConditions
      }
      if( interestingStatus ) out << endl; 
    }
    if( interestingStatus || !cur_errors ) {
      out << Status2Chars[status];
    }
    if( accruedConditions & ~cur_errors & ~NotAnError ) {
      out << ( runAsFarAsPossible && ( cur->conditions & IsAnError ) ? " (errors: " : " (from before: " );  
      printConditions( out, accruedConditions & ~cur_errors & ~NotAnError ); out << ")";
    }
    out << endl;
  } while( !stopOnResult && !( cur->conditions & all_done ) );
  if( status < accruedStatus ) 
    out << "finally: " << Status2Chars[accruedStatus] << endl;
  return this;
}

int Runtime::nonExistantTape( astr_const *content, int *pos, SymbolTable **symTab ) { 
  if(content) *content = empty_astr; if(pos) *pos = -3; 
  if(symTab) *symTab = NULL; 
  return -1; 
}

void Runtime::getEmptyStatesAndLookAhead( struct StatesAndLookAhead *sl ) { 
  sl->first_state = sl->last_state = cur->states.end(); 
  sl->first_lookahead = sl->last_lookahead = cur->lookahead.end(); 
}

void Runtime::getAllStatesWithLookAhead( struct StatesAndLookAhead *standlh ) {
  standlh->first_state = cur->states.begin();
  standlh->last_state = cur->states.end();
  standlh->first_lookahead = cur->lookahead.begin();
  standlh->last_lookahead = cur->lookahead.end();
}

void Runtime::lookAhead_with_StatePos(bool remember) {
  States::const_iterator si_begin_of_region = cur->states.begin();
  States::const_iterator end_of_states = cur->states.end();
  States::const_iterator si = si_begin_of_region;
  ImStateVector::const_iterator any_lhd_pos = cur->lookahead.end();  // the position of the not yet inserted element (not defined by STL)
  int prev_lh_size = 0, lh_size;
  int i=0, max_size = cur->states.size();
  int *lookahead_pos = (int*)alloca( max_size * sizeof(int) ); cur->new_data_pos.reserve( max_size ); 
  if( si != end_of_states ) {
#ifdef _MSC_VER
    lookahead_pos[i++] = 0; cur->new_data_pos.push_back( TraceStep::StatePos{ si, any_lhd_pos } );
#else
    lookahead_pos[i++] = 0; cur->new_data_pos.push_back( TraceStep::StatePos{ .state_pos = si, .lhd_pos = any_lhd_pos } );
#endif
    while( si != end_of_states ) {
      si->elm->lookAhead( this, si->data );
      if(remember) {
	lh_size = cur->lookahead.size();
	if( prev_lh_size == lh_size ) {
	  Status cur_status = status_4_no_successor(&*si);
	  if( cur_status > cur->status ) cur->status = cur_status;
	};
	prev_lh_size = lh_size;
      }
      if( compareData( si_begin_of_region->data, si->data ) != 0 ) {
	//lookahead_pos[i++] = cur->new_data_pos.size();
	lookahead_pos[i++] = cur->lookahead.size();
	cur->new_data_pos.push_back( TraceStep::StatePos{ si, any_lhd_pos } );
	si_begin_of_region = si;
      }
      si++;
    }
    TraceStep::StatePosVec::iterator pi = cur->new_data_pos.begin();
    for( i=0; pi != cur->new_data_pos.end(); pi++, i++ ) pi->lhd_pos = cur->lookahead.begin() + lookahead_pos[i];
  }
  cur->new_data_pos.push_back( TraceStep::StatePos{ end_of_states, cur->lookahead.end() } );
}

void Runtime::init_new_data_pos() {
  assert( cur->conditions & at_lookAhead );   // precondition: lookAhead has already been performed before for this TraceStep; init_new_data_pos just populates new_data_pos
  if( !cur->new_data_pos.empty() ) return;
  freeLookAheadElements( trace + tpos );
  cur->lookahead.clear();   // now re-calculate the lookahead including TraceStep::StatePos values
  lookAhead_with_StatePos(false);
}


// ProxyTable allocation with variables: see for SymbolTable::countVariables

/*
Element* ProxyTable::getSameProxyOrElement( Element *main, int pos ) {
  if( pos <= 0 ) return main;
  if( pos <= (int)next_proxy.size() ) return &next_proxy[pos-1];
  assert(false);
}

Element* ProxyTable::getNextProxy( Element *main, int pos ) {
  assert( pos >= 0 );
  if( pos < (int)next_proxy.size() ) return &next_proxy[pos];
  next_proxy.reserve(pos+1);
  for( int i = (int)next_proxy.size(); i <= pos; i++ ) next_proxy.push_back(ElementProxy(main,i+1));
  return &next_proxy.back();
}

int ProxyTable::getNextPosition( int curpos ) {
  if( curpos < 0 ) return 0; if( curpos >= (int)next_proxy.size() ) return curpos + 1;
  return next_proxy[curpos].relative_runtime_position;
}

void ProxyTable::createEntry4LongVar( Element *main, int curpos, int nextpos ) {
  assert(!( curpos + 1 >= nextpos ));   // assert fails: not a longVar (i.e. just a one-letter-var)
  int i; int sz = (int)next_proxy.size();
  next_proxy.reserve( main ? nextpos + 1 : curpos + 1 );
  assert( sz-1 < curpos );
  for( i = sz; i < curpos; i++ ) next_proxy.push_back(ElementProxy(main,i+1));
  next_proxy.push_back(ElementProxy(main,nextpos)); i++;   // i ~ size():  next_proxy[curpos].relative_runtime_position = nextpos: jump forward
  if( !main ) { assert( i-1 == curpos ); return; }
  for(; i < nextpos - 3; i++ ) next_proxy.push_back(ElementProxy(NULL,-1));  // invalid elements in the middle
  next_proxy.push_back(ElementProxy(main,nextpos)); i++;    // next_proxy[nextpos-1].relative_runtime_position = nextpos: re-get the same element / jump back
  assert( i-2 == nextpos );   // i.e. last element that was written is the element directly before nextpos
}
*/

//
//     methods for printing/ output
// ====================================

const astr_const node_as_text((achar*)"node",4);
const astr_const edge_as_text((achar*)"edge",4);

void Runtime::prnTape( IOStreamRef out ) {
  astr_const tape = getTapeContent(); int pos = getTapePos(); const char *cursor_left, *cursor_right;
  if( terminal_type.charset == Charset::utf8 ) { cursor_left = "⟪"; cursor_right = "⟫";} else { cursor_left = "<<"; cursor_right = ">>"; }
  //out << tape.sub(0,pos) << "[" << tape.sub(pos,1) << "]" << tape.sub(pos+1);
  out << tape.sub(0,pos) << cursor_left << tape.sub(pos,1) << cursor_right << tape.sub(pos+1);
}

void Element::print( IOStreamRef out, int debuglevel, bool isLookAhead, int relpos ) const {
  out << getContent(); if(relpos) out << "~" << relpos;
}

/*
struct PrintOptions {
  utf8str_const separator[4], introSub[2], finalizeSub[2], msgForNoStates;
  utf8str_const rightArrow, doubleArrow, backArrow, errorEltIndicator, cursor_left, cursor_right;
  enum OptionCategory { TransitionFreq = 0x3, Precedence = 0x4, VarPrintage = 0x18, LineBreaks = 0x60 };
  static const int Bits4Spacing = 3;
  enum ShiftedOptions { outerSpacing = 7, midSpacing = 7 + Bits4Spacing, innerSpacing = 7 + 2*Bits4Spacing };
  static const int SpacingMask = (1<<Bits4Spacing)-1;
  enum TransitionFreq { oneCompoundTransition = 0x1, oneTransitionPerLevel1Data = 0x2, oneTransitionByElement = 0x3 };
  enum Precedence { dataOriented = 0x0, stateOriented = 0x4 };
  enum VarPrintage { printAlways = 0x0, printBeforeRead = 0x8, printAfterWrite = 0x10 }; 
  enum LineBreaks { oneLine = 0x0, multiLine = 0x20, indentedLines = 0x40 };
  static const int defaultModeFields = oneCompoundTransition | stateOriented | printBeforeRead | printAfterWrite | oneLine | ( 2 & SpacingMask ) << outerSpacing | ( 1 & SpacingMask ) << midSpacing;
  //static const int defaultModeFields = oneTransitionPerLevel1Data | stateOriented | printBeforeRead | printAfterWrite | multiLine | ( 2 & SpacingMask ) << outerSpacing | ( 1 & SpacingMask ) << midSpacing;
  int modeFields;
};

*/

int Runtime::initPrintOptions( struct PrintOptions *o, int printMode, int charset ) {
  if( charset < 0 ) charset = terminal_type.charset;
  if( charset == Charset::utf8 ) { 
    o->rightArrow = " → "; o->doubleArrow = " ⥂ "; o->backArrow = " ↩ "; o->errorEltIndicator = " + ↯"; 
    o->cursor_left = "⟪"; o->cursor_right = "⟫";
  } else { 
    o->rightArrow = " ->> "; o->doubleArrow = " <->> "; o->backArrow = " <- "; o->errorEltIndicator = " + error_elts "; 
    o->cursor_left = "<<"; o->cursor_right = ">>";
  }
  switch( printMode & PrintOptions::LineBreaks ) { // "\n" = endl.toText(stdout.getIOAttrFlags())
    case PrintOptions::oneLine:
        o->introSub[0] = ": "; o->finalizeSub[0] = "";
        o->introSub[1] = "("; o->finalizeSub[2] = ")";
	o->separator[0] = "\n"; o->separator[1] = ", "; o->separator[2] = ",";
      break;
    case PrintOptions::multiLine:
        o->introSub[0] = ":\n  "; o->finalizeSub[0] = "";
        o->introSub[1] = "("; o->finalizeSub[2] = ")";
	o->separator[0] = "\n"; o->separator[1] = "\n  "; o->separator[2] = ",";
      break;
    default: // like case indentedLines:
      break;
  }
  return 0;
}

Runtime* Runtime::printCurState( IOStreamRef out, const struct PrintOptions *prnopts ) {
  return this;
}

void State::print( IOStreamRef out, const Runtime_Base *r, int debuglevel, bool isLookAhead, bool shallPrintVars ) const {
  if( debuglevel > 0 ) out << elm->getType().sub(0,1) << ":"; 
  elm->print(out,debuglevel,isLookAhead);
  if( data && !isLookAhead ) {
    out << "("; r->printData(out,data,shallPrintVars); out << ")";
  }
}

//template<class InputIterator,class Predicate> 
//  void Runtime::prnStates( IOStreamRef out, InputIterator first, InputIterator last, Predicate shallPrint, int debuglevel, bool asLookAhead ) const {

void Runtime::prnStates( IOStreamRef out, struct TraceStep *ctr, int debuglevel ) const {
  States::const_iterator first = ctr->states.begin(), last = ctr->states.end();
  bool first2print = true;
  out << "{";
  while ( first != last ) { 
    out << ( first2print ? " " : ", " ); first->print( out, this, debuglevel, false, ( ctr->conditions & will_read_variable ) );
    first++; first2print = false; 
  }
  out << ( first2print ? "}" : " }" );
}

void Runtime::prnLookAhead( IOStreamRef out, struct TraceStep *ctr, int debuglevel, bool justPrintErrorElts ) const {
  //States::const_iterator first = ctr->states.begin(), last = ctr->states.end();
  //set<Element*> alreadyMarkedEpsilonClosure;
  ImStateVector::const_iterator curLH = ctr->lookahead.begin(), lastLH = ctr->lookahead.end(), prevLH; 
  ViewOnlyElements::const_iterator curVOE = ctr->viewOnlyElements.begin(), lastVOE = ctr->viewOnlyElements.end();
  const char *errorEltIndicator; bool first2print;
  if( terminal_type.charset == Charset::utf8 ) { errorEltIndicator = " + ↯"; } else { errorEltIndicator = " + error_elts "; }
  if( !justPrintErrorElts ) {
    out << "{"; first2print = true;
    while ( curLH != lastLH ) { 
      if( first2print || prevLH->elm != curLH->elm ) {  // lookAhead: do not print data or symbols
	out << ( first2print ? " " : ", " ); first2print = false; 
	curLH->print(out,this,debuglevel,true,false); 
	prevLH = curLH; 
      }
      curLH++; 
    }
    for( int i=0; i < ctr->zeroReadEdgeNum; i++ ) {
      out << ( first2print ? " " : ", " ); first2print = false; 
      (*curVOE)->print(out,debuglevel,true);
      curVOE++;
    }
    out << ( first2print ? "}" : " }" );
  } else curVOE += ctr->zeroReadEdgeNum;
  if( curVOE != lastVOE ) {
    out << errorEltIndicator << "{ "; first2print = true; 
    do { 
      if(!first2print) out << ", "; first2print = false;  
      (*curVOE)->print(out,debuglevel,true);
      curVOE++;
    } while ( curVOE != lastVOE );
    out << " }";
  }
}

// SymbolTable* IntermedState::OtherDataForSameTransition = &emptySymbolTable;

//
//    non Qt based methods 
// ===========================



#ifndef QT_CORE_LIB

int Edge::setTrack( const std::vector<int> *data ) {
  return -1;
}

int Edge::setLinearTrack( const std::vector<int> *data ) {
  return -1;
}

#endif

//
//     methods for removing elements
// =======================================

void Edge::removeUniqueFromVector( Edges *vec, Edge *elm ) {
  Edges::iterator new_lastpos;
  new_lastpos = std::remove( vec->begin(), vec->end(), elm );
  assert ( new_lastpos == vec->end() - 1 );   // exactly one element got removed
  vec->erase( new_lastpos );
}

Edge::~Edge() {
  if(from) Edge::removeUniqueFromVector( &(from->succ), this );
  if(to) Edge::removeUniqueFromVector( &(to->pred), this );
}

Node::~Node() {
  if( unlikely( pred.begin() != pred.end() || succ.begin() != succ.end() ) ) {
    for(Edges::const_iterator ie = pred.begin(); ie != pred.end(); ie++ ) { Edge *e = *ie; e->to = NULL; }
    for(Edges::const_iterator ie = succ.begin(); ie != succ.end(); ie++ ) { Edge *e = *ie; e->from = NULL; }
    cerr << "Automaton::~Node: node with edge-connections removed: dangling edges created!" << endl;
  }
}

bool Automaton::elementIsPartOf( GraphElement *elm ) {  // returns true if Element belongs to this automaton
  if( std::find( allEdges.begin(), allEdges.end(), elm ) != allEdges.end() ) return true;
  if( std::find( allNodes.begin(), allNodes.end(), elm ) != allNodes.end() ) return true;
  return false;
}

template<class Element> bool Automaton::typedRemoveElement( Element *elm, std::list<Element*> *allElementsOfThisType ) {
  typename std::list<Element*>::iterator elmHomeLocation = std::find( allElementsOfThisType->begin(), allElementsOfThisType->end(), elm );
  if( elmHomeLocation == allElementsOfThisType->end() ) return false;
  allElementsOfThisType->erase( elmHomeLocation );
  delete elm;
  return true;
}

template bool Automaton::typedRemoveElement( Node *elm, std::list<Node*> *allElementsOfThisType );
template bool Automaton::typedRemoveElement( Edge *elm, std::list<Edge*> *allElementsOfThisType );

bool Automaton::removeEdge( Edge *edge ) { 
  if(likely( typedRemoveElement( edge, &allEdges ) )) return true; 
  if(edge) cerr << "Automaton::removeEdge: edge to be removed was called with the wrong automaton." << endl;
  else cerr << "Automaton::removeEdge was called with NULL edge." << endl;
  return false;
}

bool Automaton::removeNode( Node *node ) { bool ok2remove = true;
  Edges::const_iterator ie, ie_prev;
  do {
    ie = node->pred.begin(); if( ie == node->pred.end() ) break;
    Edge *edge = *ie; if(unlikely(! typedRemoveElement( edge, &allEdges ) )) { ok2remove = false;
      cerr << "Automaton::removeNode: removed predecessor edge did not belong to the current automaton." << endl;
    };
  } while(true);
  do {
    ie = node->succ.begin(); if( ie == node->succ.end() ) break;
    Edge *edge = *ie; if(unlikely(! typedRemoveElement( edge, &allEdges ) )) { ok2remove = false;
      cerr << "Automaton::removeNode: removed successor edge did not belong to the current automaton." << endl;
    };
  } while(true);
  /*for(Edges::const_iterator ie = node->pred.begin(); ie != node->pred.end(); ie++ ) { 
    Edge *edge = *ie; if(edge->from) Edge::removeUniqueFromVector( &(edge->from->succ), edge );
    if(unlikely(! typedRemoveElement( edge, &allEdges ) )) { edge->from->succ.push_back( edge ); ok2remove = false;
      cerr << "Automaton::removeNode: removed edge did not have a predecessor node which belongs to the current automaton." << endl;
    } else edge->to = NULL;
  }
  for(Edges::const_iterator ie = node->succ.begin(); ie != node->succ.end(); ie++ ) { 
    Edge *edge = *ie; if(edge->to) Edge::removeUniqueFromVector( &(edge->to->pred), edge );
    if(unlikely(! typedRemoveElement( edge, &allEdges ) )) { edge->to->pred.push_back( edge ); ok2remove = false;
      cerr << "Automaton::removeNode: removed edge did not have a successor node which belongs to the current automaton." << endl;
    } else edge->from = NULL;
  }*/
  if(unlikely(!( 
	ok2remove && typedRemoveElement( node, &allNodes ) 
     ))) { cerr << "Automaton::removeNode: node to be removed was called with the wrong automaton." << endl; return false; }
  return true;
}

bool Automaton::removeElement( GraphElement *elm ) {
  if(!elm) return false;
  Edge *asEdge = dynamic_cast<Edge*>(elm); if(asEdge) return removeEdge( asEdge );
  Node *asNode = dynamic_cast<Node*>(elm); if(asNode) return removeNode( asNode );
  return false;
}

int Automaton::removeDanglingEdges() {
  int numRemoved = 0;
  list<Edge*>::iterator ie = allEdges.begin(), ie_prev = allEdges.end();
  while( ie != allEdges.end() ) { Edge *edge = *ie;
    if( !edge ) { ie = allEdges.erase(ie); ie = ie_prev; cerr << "Automaton::removeDanglingEdges: NULL-edge contained in allEdges!" << endl; }
    else if( !edge->from || !edge->to ) { ie = allEdges.erase(ie); ie = ie_prev; delete edge; numRemoved++; }
    if( ie_prev == allEdges.end() && ie == allEdges.end() ) ie = allEdges.begin();
    else { ie_prev = ie; ie++; }
  }    
  return numRemoved;
}

Automaton::~Automaton() {
  startNode = NULL;
  for(list<Edge*>::iterator ie = allEdges.begin(); ie != allEdges.end(); ie++ )
    delete *ie;
  for(list<Node*>::iterator in = allNodes.begin(); in != allNodes.end(); in++ )
    delete *in;
}

