#ifndef EXEC_ENV_H
#define EXEC_ENV_H

#include <QtGui/QValidator>
#include <QtWidgets/QWidget>
#include <QtWidgets/QDialog>
#include "auxtypes.h"

class Automaton; class Runtime;
class AtmtWatch; class TapeWatch;
class QLineEdit; class QListWidget; class QLabel; class QTimer; class QStatusBar;

class ExecEnv : public QObject {
  Q_OBJECT
protected:
  void start_exec(); void unmark(); void mark(); void updateStatusBar();
protected slots:
  void simulation_step();
public:
  ExecEnv( AtmtWatch *atmtWatch, TapeWatch *tapeWatch, TapeWatch *addTapeWatch, QStatusBar *appStatusBar, QLabel *atmtStatus );
  void setAutomaton( Automaton *atmt );
  void run(bool stopOnResult); 
public slots:
  void reset(); void startstop_simulation(); void step_backward(); void step_forward(); void run_through(); void run_till_result();
  void change_tape(); void view_outcome();
public:
  bool keyPressed(QKeyEvent *event);
  void leave();
  AtmtWatch *viewAtmt; TapeWatch *viewTape; TapeWatch *addTapeView; QStatusBar *statusBar; QLabel *statusBarLabel;
  Automaton *atmt; Runtime *rt; 
  int tracelen; QTimer *simulateTimer;
};

#endif
