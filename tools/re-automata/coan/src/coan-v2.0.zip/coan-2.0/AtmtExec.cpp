#include "AtmtExec.h"

#include <QtGui/QPainter>
#include <QtGui/QResizeEvent>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QDesktopWidget>

#include "symtab.h"
#include "automatdef.h"
#include "LoadSaveAtmt.h"
#include "InputSelector.h"
#include "ExecEnv.h"
#include "MainWindow.h"

using namespace aux;

QPen rubberPen = QPen(QColor(0,0,0xE0),2);

AtmtWatch::AtmtWatch(MainWindow *mainWin) : mainWindow(mainWin) {
  setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
  setFocusPolicy(Qt::StrongFocus);
  QPalette pal = palette();
  pal.setColor(QPalette::Normal,QPalette::Background,QColor(0xE6,0xE2,0xE0));
  pal.setColor(QPalette::Inactive,QPalette::Background,QColor(0xD6,0xD2,0xD0));   // this would be the usual background color
  setPalette(pal);
  atmt = NULL; xvirtual = 320; yvirtual = 200; 
}

void AtmtWatch::paintEvent(QPaintEvent *event) {
  QPainter painter(this);
  painter.setRenderHints(QPainter::Antialiasing,true);
  //painter.setBackground(QBrush(QColor(0xE0,0xE0,0xE0),Qt::SolidPattern));
  //painter.setBackgroundMode(Qt::OpaqueMode);
  painter.fillRect( QRect( QPoint(0,0), size() ), palette().color(QPalette::Background) );
  if(!atmt) return;
  painter.setPen(QPen(Qt::SolidLine)); painter.setBrush(QBrush(Qt::NoBrush));
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) {
    Node *n = *in; struct TextExtent ext = n->getTextExtent(this);
    n->draw(&painter,atmt); QPointF pos = n->pos + n->relTextPos;
    //painter.drawRect(pos.x(),pos.y()-ext.ascent,ext.width,ext.ascent+ext.descent);
    //qcerr << "xxx: " << ;
  }
  for(std::list<Edge*>::const_iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ ) (*ie)->draw(&painter,atmt);
  if( rubberLine ) {
    painter.setPen(rubberPen);
    painter.drawLine(rubberLineStart,rubberLineEnd);
  }
}

void AtmtWatch::setMaxCoords( QPointF pos ) {
  if( pos.x() + pad_xvirtual > xvirtual ) { xvirtual = pos.x() + pad_xvirtual; }
  if( pos.y() + pad_yvirtual > yvirtual ) { yvirtual = pos.y() + pad_yvirtual; }
}

void AtmtWatch::setAutomaton( Automaton *a ) {
  if( atmt == a ) return;
  atmt = a; xvirtual = 320; yvirtual = 200; if(!a) return;
  for(std::list<Node*>::const_iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) {
    setMaxCoords( (*in)->pos + QPointF( (*in)->a, (*in)->b ) );
  }
  for(std::list<Edge*>::const_iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ ) {
    setMaxCoords( (*ie)->pos + QPointF( (*ie)->a, (*ie)->b ) );
    for(std::vector<QPointF>::const_iterator it = (*ie)->track.begin(); it != (*ie)->track.end(); it++ ) 
      setMaxCoords( *it );
  }
  //cout << "setAutomaton" << (u_iword)a <<  ", x:" << xvirtual << ", y:" << yvirtual <<aux::endl;
  updateGeometry();
  setMinimumSize(QSize(xvirtual,yvirtual));  // this will make sizeHint() ignored
}

bool AtmtWatch::event(QEvent *event) {
  if( event->type() == QEvent::KeyPress ) {
    QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
    if( /* keyEvent->key() == Qt::Key_Tab && */ mainWindow ) {
      mainWindow->keyPressEvent(keyEvent);
      return true;
    }
  }
  return QWidget::event(event);
}



//void AtmtWatch::resizeEvent(QResizeEvent *event) {
//  cur_xvirtual = qMax( xvirtual, event->size().width() );
//  cur_yvirtual = qMax( yvirtual, event->size().height() );
//}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


OutcomeView::OutcomeView(int pointsize) : pointsize(pointsize)  { 
  setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
  setFocusPolicy(Qt::StrongFocus);
  xvirtual = 100; yvirtual = 50; // xvirtual = 1600; yvirtual = 200;
  tapeLetterFont.setPointSize(pointsize); tapeLetterFont.setFamily("Helvetica"); 
  paramsFont.setPointSize(pointsize>=16?pointsize-6:pointsize-2); paramsFont.setFamily("Helvetica");   
  QPalette pal = palette();
  pal.setColor(QPalette::Normal,QPalette::Background,QColor(0xD6,0xD2,0xD0));
  pal.setColor(QPalette::Inactive,QPalette::Background,QColor(0xC6,0xC2,0xC0));
  setPalette(pal);
  rt = NULL; viewWhat = ViewAccepted | ViewHalted;
};


int OutcomeView::drawTape( QPainter *painter, int xpos, int ypos, astr_const tape, int cursor, int *maxx ) {
  QBrush brushWhite(Qt::white,Qt::SolidPattern); QColor lightYellow(0xFF,0xFF,0x90); QBrush brushLightYellow(lightYellow);
  QColor brown(0x44,0x47,0x49); painter->setPen(Qt::black); painter->setBrush(QBrush(brown)); QBrush textbg = brushWhite;
  QFontMetrics tapeLetterMetrics(tapeLetterFont,this);
  int ascent = tapeLetterMetrics.ascent(), descent = tapeLetterMetrics.descent(), xHeight = tapeLetterMetrics.xHeight();
  int i, spacing = tapeLetterMetrics.averageCharWidth()/5;
  painter->setFont(tapeLetterFont); painter->setBackgroundMode(Qt::OpaqueMode); painter->setBackground(( textbg = brushWhite ));
  ypos += ascent;
  if( cursor == -1 ) { painter->setPen(QPen(brown));
    painter->drawRoundedRect( xpos-7*spacing+2, ypos-ascent-4*spacing, 2*spacing, ascent+descent+8*spacing, 2, 2 );
    painter->setPen(Qt::black);
  }
  for( i=0; i < tape.length; i++ ) {
    QString thisLetter; if( tape.chars[i] >= ' ' ) thisLetter = tape.chars[i]; else thisLetter = (tape.chars[i]<=0x0F?"\\x0":"\\x") +QString::number(tape.chars[i],16).toUpper(); 
    int letterWidth = tapeLetterMetrics.width(thisLetter); 
    if( i == cursor ) { painter->setPen(QPen(brown)); 
      painter->drawRoundedRect( xpos-4*spacing+2, ypos-ascent-4*spacing, 2*spacing, ascent+descent+8*spacing, 2, 2 );
      painter->drawRoundedRect( QRectF( xpos-2*spacing, ypos-ascent-3*spacing/2.0, letterWidth+4*spacing, ascent+descent+3*spacing ), 2, 2 );
      painter->setPen(Qt::black);
      painter->setBackground(( textbg = brushLightYellow ));
    }
    painter->drawText(xpos,ypos,thisLetter); 
    painter->fillRect( xpos-spacing, ypos-ascent, spacing, ascent+descent, textbg );
    painter->fillRect( xpos+letterWidth, ypos-ascent, spacing, ascent+descent, textbg );
    if( i == cursor )  painter->setBackground(( textbg = brushWhite ));
    xpos += letterWidth + 7*spacing;
  }; 
  if( cursor == -2 || cursor >= tape.length ) { painter->setPen(QPen(brown));
    painter->drawRoundedRect( xpos-3*spacing, ypos-ascent-4*spacing, 2*spacing, ascent+descent+8*spacing, 2, 2 );
    painter->setPen(Qt::black);
  }
  painter->setBackgroundMode(Qt::TransparentMode);
  if( *maxx < xpos ) *maxx = xpos;
  ypos += descent + xHeight/4;
  return ypos;
}

int OutcomeView::tapeExtent( int ypos, astr_const tape, int *maxx ) {
  QFontMetrics tapeLetterMetrics(tapeLetterFont,this);
  int ascent = tapeLetterMetrics.ascent(), descent = tapeLetterMetrics.descent(), xHeight = tapeLetterMetrics.xHeight();
  int i, spacing = tapeLetterMetrics.averageCharWidth()/5; int xpos = 12*spacing; 
  ypos += ascent;
  for( i=0; i < tape.length; i++ ) {
    QString thisLetter; if( tape.chars[i] >= ' ' ) thisLetter = tape.chars[i]; else thisLetter = (tape.chars[i]<=0x0F?"\\x0":"\\x") +QString::number(tape.chars[i],16).toUpper(); 
    int letterWidth = tapeLetterMetrics.width(thisLetter); 
    xpos += letterWidth + 7*spacing;
  }; 
  if( *maxx < xpos ) *maxx = xpos;
  ypos += descent + xHeight/4;
  return ypos;
}

void OutcomeView::paintEvent(QPaintEvent *event) {
  QPainter painter(this); painter.setRenderHints(QPainter::Antialiasing,true); QFontMetrics tapeLetterMetrics(tapeLetterFont,this); if(!rt) return;
  int spacing = tapeLetterMetrics.averageCharWidth()/5; int xpos = 12*spacing; int ypos = tapeLetterMetrics.xHeight(); int maxx = 0;
  int num = rt->numOutcomes(); int old_xvirtual = xvirtual, old_yvirtual = yvirtual; xvirtual = 100; yvirtual = 50; 
  for( int idx=0; idx < num; idx++ ) {
    int pos; astr_shared *tape; enum Status status; int step_num; bool doPrint;
    rt->getOutcome( idx, &tape, &pos, &status, &step_num );  // step_num may be NULL; all other pointers are required
     // enum Status { no_successor, internal_error, stepDone, fatal_error, hanging, halted, dismissed, accepted };
    switch(status) {
      case Status::accepted: doPrint = viewWhat & ViewAccepted; break;
      case Status::halted: doPrint = viewWhat & ViewHalted; break;
      case Status::dismissed: doPrint = viewWhat & ViewDismissed; break;
      default: doPrint = viewWhat & ViewErroneous; break;
    }
    if(doPrint) {
      ypos = drawTape( &painter, xpos, ypos, *tape, pos, &maxx );
    }
    astr_shared::free(&tape);
  }
  if( yvirtual < ypos ) yvirtual = ypos;
  if( xvirtual < maxx ) xvirtual = maxx;
  if( old_yvirtual != yvirtual || old_xvirtual != xvirtual ) updateGeometry();
}

QSize OutcomeView::calcExtent() {
  QFontMetrics tapeLetterMetrics(tapeLetterFont,this); if(!rt) return QSize(100,50);
  int ypos = tapeLetterMetrics.xHeight(); int maxx = 0;
  int num = rt->numOutcomes(); int old_xvirtual = xvirtual, old_yvirtual = yvirtual; xvirtual = 100; yvirtual = 50; 
  for( int idx=0; idx < num; idx++ ) {
    int pos; astr_shared *tape; enum Status status; int step_num; bool doPrint;
    rt->getOutcome( idx, &tape, &pos, &status, &step_num );  // step_num may be NULL; all other pointers are required
     // enum Status { no_successor, internal_error, stepDone, fatal_error, hanging, halted, dismissed, accepted };
    switch(status) {
      case Status::accepted: doPrint = viewWhat & ViewAccepted; break;
      case Status::halted: doPrint = viewWhat & ViewHalted; break;
      case Status::dismissed: doPrint = viewWhat & ViewDismissed; break;
      default: doPrint = viewWhat & ViewErroneous; break;
    }
    if(doPrint) {
      ypos = tapeExtent( ypos, *tape, &maxx );
    }
    astr_shared::free(&tape);
  }
  if( yvirtual < ypos ) yvirtual = ypos;
  if( xvirtual < maxx ) xvirtual = maxx;
  if( old_yvirtual != yvirtual || old_xvirtual != xvirtual ) updateGeometry();
  return QSize( xvirtual, yvirtual );
}

void OutcomeDialog::cbToggled( bool isChecked ) {
  int newViewMode = 0;
  if( checkAccepted->isChecked() ) newViewMode |= OutcomeView::ViewAccepted;
  if( checkHalted->isChecked() ) newViewMode |=  OutcomeView::ViewHalted;
  if( checkDismissed->isChecked() ) newViewMode |=  OutcomeView::ViewDismissed;
  if( checkErroneous->isChecked() ) newViewMode |=  OutcomeView::ViewErroneous;
  view->viewWhat = newViewMode;
  view->update();
}

void OutcomeDialog::adjustSize() {
  QDesktopWidget desktop; QRect geometry = desktop.screenGeometry(this);
  int maxx = geometry.width()*2/3; int maxy = geometry.height()*2/3;
  QSize idealSize = view->calcExtent();
  //cout << idealSize.width() << "," << idealSize.height() << aux::endl << IOFlush();
  int addHeight = height() - view->height();
  idealSize.setHeight( idealSize.height() + addHeight + 20 );
  idealSize.setWidth( idealSize.width() + 20 );
  if( idealSize.width() > maxx ) idealSize.setWidth(maxx);
  if( idealSize.height() > maxy ) idealSize.setHeight(maxy);
  if( height() < idealSize.height() || width() < idealSize.width() )
    resize(idealSize);
}

OutcomeDialog::OutcomeDialog() {
  QVBoxLayout *vlyo = new QVBoxLayout();
  view = new OutcomeView(10);
  QScrollArea *viewScroll = new QScrollArea(); viewScroll->setWidget(view); viewScroll->setWidgetResizable(true);
  vlyo->addWidget(viewScroll);
  QGridLayout *glyo = new QGridLayout();
  checkAccepted = new QCheckBox("accepted"); checkHalted = new QCheckBox("halted"); checkDismissed = new QCheckBox("dismissed"); checkErroneous = new QCheckBox("has errors");
  checkAccepted->setChecked( view->viewWhat & OutcomeView::ViewAccepted ); checkHalted->setChecked( view->viewWhat & OutcomeView::ViewHalted );
  checkDismissed->setChecked( view->viewWhat & OutcomeView::ViewDismissed ); checkErroneous->setChecked( view->viewWhat & OutcomeView::ViewErroneous );
  glyo->addWidget(checkAccepted,0,0); glyo->addWidget(checkHalted,0,1); glyo->addWidget(checkDismissed,0,2); glyo->addWidget(checkErroneous,0,3); 
  connect( checkAccepted, SIGNAL(toggled(bool)), this, SLOT(cbToggled(bool)) ); connect( checkHalted, SIGNAL(toggled(bool)), this, SLOT(cbToggled(bool)) );
  connect( checkDismissed, SIGNAL(toggled(bool)), this, SLOT(cbToggled(bool)) ); connect( checkErroneous, SIGNAL(toggled(bool)), this, SLOT(cbToggled(bool)) );
  vlyo->addLayout(glyo);
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok);
  vlyo->addWidget(dialogButtons);
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(close()) );
  setLayout(vlyo);
  setWindowTitle("View the Outcome");
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


TapeWatch::TapeWatch( bool lsv ) : limitedSidebarView(lsv), OutcomeView(lsv?10:16)  { 
  tape = charparams = aux::empty_astr; valparams = aux::empty_inta; // xvirtual = 1600; yvirtual = 200;
  inputSelector = new InputSelector(this);
  atmt = NULL; execEnv = NULL; outcomeDialog = NULL;
};


void TapeWatch::tape_click( int flags ) {
  bool shouldView = rt != NULL;
  if( ( flags & ChangeOnly ) && rt && ( rt->getConditions() & Runtime::all_done ) ) shouldView = false;
  if( shouldView && ( rt->getConditions() & Runtime::all_done ) && !( flags & ViewOnly ) && !limitedSidebarView && ( rt->numOutcomes() <= 1 ) )  shouldView = false;
  if( shouldView ) {
    // open view window
    if( flags & ChangeOnly ) {
      if( flags & ShowMessageBox ) QMessageBox::warning( this, tr("Change Tape"), tr("Can not change tape content during execution. Please do reset the machine first (F5).") ); 
      return; 
    }
    if(!outcomeDialog) { outcomeDialog = new OutcomeDialog(); outcomeDialog->show(); }
    outcomeDialog->view->rt = rt; outcomeDialog->adjustSize();
    outcomeDialog->show(); outcomeDialog->raise(); outcomeDialog->activateWindow();
    return;
  }
  //open change window
  if(limitedSidebarView) return;
  if( flags & ViewOnly ) {
    if( flags & ShowMessageBox ) QMessageBox::warning( this, tr("View Outcome"), tr("Machine is not executed and thus the outcome can not be viewed.") ); 
    return; 
  }
  if( inputSelector->exec() ) execEnv->reset();
}

void TapeWatch::mouseDoubleClickEvent(QMouseEvent *event) { tape_click(); }
void TapeWatch::mousePressEvent(QMouseEvent *event) { if( event->button() == Qt::RightButton ) tape_click(); }

void TapeWatch::setInputList( std::vector<RuntimeParams> *params ) { 
  inputSelector->setInputList(params); 
}

QString TapeWatch::getValParam( int i, bool addcolon ) {
  QString value = " = "; if(!valparams.length) value.append("1"); else value.append(QString::number(valparams.chars[i<valparams.length?i:valparams.length-1])); 
  if( addcolon ) value.append(", "); 
  return value;
}

QString TapeWatch::getCharParam( int i, bool addcolon ) {
  QString value = " = "; if(!charparams.length) value.append("#"); else {
    achar c = charparams.chars[i<charparams.length?i:charparams.length-1];
    if( c >= ' ' ) value.append(QChar(c)); else value.append( (c<=0x0F?"\\x0":"\\x") +QString::number(c,16).toUpper() );
  }
  if( addcolon ) value.append(", "); 
  return value;
}

int TapeWatch::drawParams( QPainter *painter, int xpos, int ypos, aux::estr_const formalParams, QString(TapeWatch::*getParam)(int,bool), int *maxheight ) {
  struct TextExtent txtext; int i, j, len; QFontMetrics paramsFontMetrics(paramsFont,this); painter->setFont(paramsFont); ypos += paramsFontMetrics.ascent();
  i=0; j=0; while( j < formalParams.length ) {
     len = qMax( qMin( SymbolTable::varLength( formalParams.chars + j ), formalParams.length - j ), 1);
     txtext = getVariableTextExtent( painter, formalParams.sub(j,len) );
     if( txtext.descent + txtext.ascent > *maxheight ) *maxheight = txtext.descent + txtext.ascent;
     drawVariableText( painter, QPointF(xpos,ypos), formalParams.sub(j,len) ); xpos += txtext.width;
     QString value = (this->*getParam)( i, j < formalParams.length-1 || ( formalParams.chars == atmt->valFormalParams.chars && atmt->charFormalParams.length ) ); 
     painter->drawText( xpos, ypos, value );
     xpos += paramsFontMetrics.width(value);
     j += len; i++; 
  }
  return xpos;
}

struct OutputVarCallStruct { 
  OutputVarCallStruct(QPainter *painter, QFontMetrics fm) : painter(painter), paramsFontMetrics(fm) {};
  QPainter *painter; QFontMetrics paramsFontMetrics; qreal xpos, ypos; int maxdescent; bool firstone;
};

void OutputVar( SymbolTable *home, estr_const var, int value, void *data ) {
  struct OutputVarCallStruct *d = (OutputVarCallStruct*)data; struct TextExtent txtext; 
  if(!d->firstone) {
    d->painter->drawText( d->xpos, d->ypos, ", " );
    d->xpos += d->paramsFontMetrics.width(", ");
  }; d->firstone = false;
  txtext = getVariableTextExtent( d->painter, var );
  if( txtext.descent > d->maxdescent) d->maxdescent = txtext.descent;
  drawVariableText( d->painter, QPointF(d->xpos,d->ypos), var ); d->xpos += txtext.width;
  QString value_str = "="; if( SymbolTable::isGreekVariable(var.chars[0]) ) {
    if( value >= ' ' ) value_str.append(QChar(value)); else value_str.append( (value<=0x0F?"\\x0":"\\x") +QString::number(value,16).toUpper() );
  } else { 
    value_str.append(QString::number(value));
  }
  d->painter->drawText( d->xpos, d->ypos, value_str );
  d->xpos += d->paramsFontMetrics.width(value_str);
}

void TapeWatch::paintEvent(QPaintEvent *event) {
  QPainter painter(this); painter.setRenderHints(QPainter::Antialiasing,true);
  painter.fillRect( QRect( QPoint(0,0), size() ), palette().color(QPalette::Background) ); if(!atmt) return;
  QFontMetrics tapeLetterMetrics(tapeLetterFont,this), paramsFontMetrics(paramsFont,this);
  int spacing = tapeLetterMetrics.averageCharWidth()/5, xHeight = tapeLetterMetrics.xHeight();
  int xpos = 12*spacing, ypos = xHeight; int maxdescent = 0, maxx = 0; xvirtual = 100; yvirtual = 50;  
  if(!rt) {
    int pos; if ( atmt->posTapeCursorAtBegin() ) pos = -1; else pos = !tape.length || tape.chars[tape.length-1] != '#' ? tape.length : tape.length-1;
    ypos = drawTape( &painter, xpos, ypos, tape, pos, &maxx );
    if(!limitedSidebarView) {
      xpos = drawParams( &painter, xpos, ypos, atmt->valFormalParams, &TapeWatch::getValParam, &maxdescent );
      xpos = drawParams( &painter, xpos, ypos, atmt->charFormalParams, &TapeWatch::getCharParam, &maxdescent );
    }
    ypos += maxdescent; if( xpos > maxx ) maxx = xpos;
  } else {
    struct OutputVarCallStruct outVar(&painter,paramsFontMetrics);
    if( rt->paramSymTab && !rt->paramSymTab->isEmpty() ) { 
      ypos += paramsFontMetrics.ascent(); painter.setFont(paramsFont);
      outVar.maxdescent = 0; outVar.xpos = xpos; outVar.ypos = ypos; outVar.firstone = true; 
      rt->paramSymTab->forall( OutputVar, &outVar );
      ypos += outVar.maxdescent + 3*spacing;
    }
    int toplevel_numTapes = rt->numTapes();
    for( int i=0; i < toplevel_numTapes; i++ ) {
      astr_const tape_content; int tape_pos; SymbolTable *tape_symTab;
      rt->getTape( &tape_content, &tape_pos, &tape_symTab, Runtime::TapeIndex(i) );
      ypos = drawTape( &painter, xpos, ypos, tape_content, tape_pos, &maxx );
      if( tape_symTab && !tape_symTab->isEmpty() ) { 
	ypos += paramsFontMetrics.ascent(); painter.setFont(paramsFont);
        outVar.maxdescent = 0; outVar.xpos = xpos; outVar.ypos = ypos; outVar.firstone = true; 
	tape_symTab->forall( OutputVar, &outVar );
	ypos += outVar.maxdescent;
      }
      ypos += 8*spacing;
      int sublevel_numTapes = rt->numTapes( Runtime::ParentTapeIndex(i) );
      xpos += 7*spacing;
      for( int j=0;  j < sublevel_numTapes; j++ ) {
	rt->getTape( &tape_content, &tape_pos, &tape_symTab, Runtime::TapeIndex(i,j) );
	ypos = drawTape( &painter, xpos, ypos, tape_content, tape_pos, &maxx );
	if( tape_symTab && !tape_symTab->isEmpty() ) { 
	  ypos += paramsFontMetrics.ascent(); painter.setFont(paramsFont);
	  outVar.maxdescent = 0; outVar.xpos = xpos; outVar.ypos = ypos; outVar.firstone = true; 
	  tape_symTab->forall( OutputVar, &outVar );
	  ypos += outVar.maxdescent;
	}
	ypos += 8*spacing;
      }
      xpos -= 7*spacing;
      if( i < toplevel_numTapes - 1 )
        ypos += 10*spacing;
    }
  }
  if( yvirtual < ypos || xvirtual < maxx ) updateGeometry();
  if( yvirtual < ypos ) yvirtual = ypos;
  if( xvirtual < maxx ) xvirtual = maxx;
}


