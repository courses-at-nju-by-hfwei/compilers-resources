#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtCore/QTextStream>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QDialogButtonBox>

#include "automatdef.h"
#include "LoadSaveAtmt.h"
#include "MainAuxDialogs.h"

/*
ViewCFSL::ViewCFSL() {
  QVBoxLayout *vlayout = new QVBoxLayout();
  plainTextEdit = new QPlainTextEdit();
  QFile licenseFile(":/C-FSL-v1.1.txt"); licenseFile.open(QFile::ReadOnly|QFile::Text); QTextStream readLicenseFile(&licenseFile);
  //document = new QTextDocument(plainTextEdit); document->setPlainText(readLicenseFile.readAll()); licenseFile.close();
  //document->setDocumentLayout(new QPlainTextDocumentLayout(document)); plainTextEdit->setDocument(document); 
  plainTextEdit->setPlainText(readLicenseFile.readAll()); licenseFile.close(); 
  plainTextEdit->setReadOnly(true);
  QHBoxLayout *hlayout = new QHBoxLayout();
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok );
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(close()) );
  vlayout->addWidget(plainTextEdit);
  hlayout->addWidget(new QLabel("zoom in/out with +/-"));
  hlayout->addWidget(dialogButtons);
  vlayout->addLayout(hlayout);
  setLayout(vlayout);
  setWindowTitle("Covertible Free Software License v1.1");
}

void ViewCFSL::keyPressEvent(QKeyEvent *event) {
  switch(event->key()) {
    case Qt::Key_Minus: plainTextEdit->zoomOut(1); break;
    case Qt::Key_Plus: plainTextEdit->zoomIn(1); break;
    default: QDialog::keyPressEvent(event); break;
} }

QSize ViewCFSL::sizeHint() const {
  QFontMetrics metrics(elmLabelFont);
  return QSize(metrics.averageCharWidth()*160,metrics.height()*40 );
}
*/

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ViewQuickHelp::ViewQuickHelp() {
  QVBoxLayout *vlayout = new QVBoxLayout();
  browser = new QTextBrowser();
  QFile quickHelpFile(":/html/QuickHelp.html"); quickHelpFile.open(QFile::ReadOnly|QFile::Text); QTextStream readQuickHelpFile(&quickHelpFile);
  //document = new QTextDocument(plainTextEdit); document->setPlainText(readLicenseFile.readAll()); licenseFile.close();
  //document->setDocumentLayout(new QPlainTextDocumentLayout(document)); plainTextEdit->setDocument(document); 
  browser->setText(readQuickHelpFile.readAll()); quickHelpFile.close(); 
  QHBoxLayout *hlayout = new QHBoxLayout();
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok );
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(close()) );
  vlayout->addWidget(browser);
  hlayout->addWidget(new QLabel("zoom in/out with +/-"));
  hlayout->addWidget(dialogButtons);
  vlayout->addLayout(hlayout);
  setLayout(vlayout);
  setWindowTitle("Quick Help");
}

void ViewQuickHelp::keyPressEvent(QKeyEvent *event) {
  switch(event->key()) {
    case Qt::Key_Minus: browser->zoomOut(1); break;
    case Qt::Key_Plus: browser->zoomIn(1); break;
    default: QDialog::keyPressEvent(event); break;
} }

QSize ViewQuickHelp::sizeHint() const {
  QFontMetrics metrics(elmLabelFont);
  return QSize(metrics.averageCharWidth()*160,metrics.height()*40 );
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SelectNewAtmt::SelectNewAtmt() {
  StrValRadioButton *radio; QVBoxLayout *vlayout = new QVBoxLayout;
  //radio = new StrValRadioButton( tr("Deterministic Finite Automaton (DFA)"), "FA", Automaton::isDeterministic, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  //radio = new StrValRadioButton( tr("Non-deterministic Finite Automaton (NFA)"), "FA", 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  //radio = new StrValRadioButton( tr("Deterministic PushDown Automaton (DPDA)"), "PDA", Automaton::isDeterministic, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  //radio = new StrValRadioButton( tr("Non-deterministic PushDown Automaton (DPDA)"), "PDA", 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  radio = new StrValRadioButton( tr("Finite Automaton (FA)"), type = Type_FA, flags = 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) ); 
   radio->setChecked(true);
  radio = new StrValRadioButton( tr("PushDown Automaton (PDA)"), Type_PDA, 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  radio = new StrValRadioButton( tr("Turing Machine (TM)"), Type_TM, 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  radio = new StrValRadioButton( tr("Machine Schema (MS)"), Type_MS, 0, this ); vlayout->addWidget(radio); connect( radio, SIGNAL(clicked()), this, SLOT(radioSelected()) );
  setWindowTitle("Select New Automaton");
  QDialogButtonBox *dialogButtons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
  connect( dialogButtons, SIGNAL(accepted()), this, SLOT(accept()) );
  connect( dialogButtons, SIGNAL(rejected()), this, SLOT(reject()) );
  vlayout->addWidget(dialogButtons);
  setLayout(vlayout);
}

void SelectNewAtmt::radioSelected() {
  StrValRadioButton *butt = dynamic_cast<StrValRadioButton*>(sender());
  if(butt) { type = butt->type; flags = butt->flags; }
}
