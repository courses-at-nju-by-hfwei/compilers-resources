#include <QtGui/QPainter>
#include <QtGui/QMouseEvent>
#include <QtWidgets/QMenu>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QMessageBox>
#include "AtmtCanvas.h"
#include "MainWindow.h"


GraphElement* AtmtCanvas::isThere( QPointF pos ) {
  for(std::list<Node*>::iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) 
    if( (*in)->isThere(pos) ) return *in;
  for(std::list<Edge*>::iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ )
    if( (*ie)->isThere(pos) ) return *ie;
  return NULL;
}

void AtmtCanvas::setActiveNode( Node *node ) {
  if(activeElement) activeElement->modus &= ~Modus::selected;
  activeElement = activeNode = node; activeEdge = NULL;
  activeElement->modus |= Modus::selected;
}

void AtmtCanvas::setActiveEdge( Edge *edge ) {
  if(activeElement) activeElement->modus &= ~Modus::selected;
  activeElement = activeEdge = edge; activeNode = NULL;
  activeElement->modus |= Modus::selected;
}

void AtmtCanvas::setAutomaton( Automaton *a ) {
  AtmtWatch::setAutomaton(a); // atmt = a; 
  if( a ) escapeSlash = a->edgeEscapeSlash(); else escapeSlash = false;
}

void AtmtCanvas::setupContextMenus() {
  // edge context menu
  edgeContextMenu = new QMenu(this);
  QAction *editAction = new QAction(tr("&Edit"),this); edgeContextMenu->addAction(editAction);
  QMenu *changeLabelPositionMenu = edgeContextMenu->addMenu(tr("&position of the label"));
  QAction *positionOneThird = new QAction(tr("one &thrid"),this); changeLabelPositionMenu->addAction(positionOneThird);
  QAction *positionOneHalf = new QAction(tr("one &half"),this); changeLabelPositionMenu->addAction(positionOneHalf);
  QAction *positionTwoThirds = new QAction(tr("t&wo thrids"),this); changeLabelPositionMenu->addAction(positionTwoThirds);
  connect( positionOneThird, SIGNAL(triggered()), this, SLOT(setLabelPosOneThird()) );
  connect( positionOneHalf, SIGNAL(triggered()), this, SLOT(setLabelPosOneHalf()) );
  connect( positionTwoThirds, SIGNAL(triggered()), this, SLOT(setLabelPosTwoThirds()) );
  QAction *deleteAction = new QAction(tr("&Delete"),this); edgeContextMenu->addAction(deleteAction);
  connect( editAction, SIGNAL(triggered()), this, SLOT(editElement()) );
  connect( deleteAction, SIGNAL(triggered()), this, SLOT(deleteElement()) );
  edgeContextMenu->show(); edgeContextMenu->hide();
  // node context menu
  nodeContextMenu = new QMenu(this);
  setStartNodeAction = new QAction(tr("&start node"),this); setStartNodeAction->setCheckable(true); nodeContextMenu->addAction(setStartNodeAction);
  setFinalNodeAction = new QAction(tr("&final node"),this); setFinalNodeAction->setCheckable(true); nodeContextMenu->addAction(setFinalNodeAction);
  connect( setStartNodeAction, SIGNAL(toggled(bool)), this, SLOT(toggleStartNode(bool)) );
  connect( setFinalNodeAction, SIGNAL(toggled(bool)), this, SLOT(toggleFinalNode(bool)) );
  nodeContextMenu->addSeparator();
  nodeContextMenu->addAction(editAction);
  nodeContextMenu->addAction(deleteAction);
  nodeContextMenu->show(); nodeContextMenu->hide();
  set_by_program = false;
}

void AtmtCanvas::toggleStartNode(bool isStartNode) { if(set_by_program) return; atmt->startNode = isStartNode ? activeNode : NULL; emit changed(); update(); }
void AtmtCanvas::toggleFinalNode(bool isFinalNode) { if(set_by_program) return;
  if(activeNode) { 
    if (activeNode->setFinalNode(isFinalNode)) { activeNode->updateGeometry(this); emit changed(); update(); } 
    else QMessageBox::warning(this,tr("Warning"),tr("It was not possible to change the final-node-setting of this node. Maybe this type of automaton does not allow to set "
	   "arbitrary nodes as final nodes. For Turing Machines the end node must be labelled with 'h' (whether indexed or not)."), QMessageBox::Ok ); 
} }

void AtmtCanvas::setLabelPosOneThird() { if(activeEdge) { activeEdge->pos = activeEdge->painterPath().pointAtPercent(0.333); emit changed(); } update(); }
void AtmtCanvas::setLabelPosOneHalf() { if(activeEdge) { activeEdge->pos = activeEdge->painterPath().pointAtPercent(0.5); emit changed(); } update(); }
void AtmtCanvas::setLabelPosTwoThirds() { if(activeEdge) { activeEdge->pos = activeEdge->painterPath().pointAtPercent(0.666); emit changed(); } update(); }

void AtmtCanvas::editElement() { if(activeElement) { prepareLineEdit(activeElement,toQString( activeElement->getContent(), escapeSlash && activeEdge )); update(); } }
void AtmtCanvas::deleteElement() { if(activeElement) { if(activeElement) atmt->removeElement(activeElement); emit changed(); update(); } }

AtmtCanvas::AtmtCanvas() {
  setAttribute(Qt::WA_StaticContents);
  setMouseTracking(true);
  lineEdit = new QLineEdit(this); lineEdit->hide(); lineEdit->adjustSize();
  connect( lineEdit, SIGNAL(returnPressed()), this, SLOT(lineEditFinished()) );
  movingNode = NULL; rubberLine = false; rubberLineStartNode = NULL; curCreatedEdge = NULL;
  activeNode = NULL; activeEdge = NULL; activeElement = NULL; edgeNodeTracked = -2; escapeSlash = false;
  lineEdit->installEventFilter(this);
  setupContextMenus();
}

void AtmtCanvas::finishEditing() {
  if(movingNode) {
    atmt->removeNode(movingNode); movingNode = NULL; update(); 
  }
  if(curCreatedEdge) {
    atmt->removeEdge(curCreatedEdge);
    curCreatedEdge = NULL;
  }
  rubberLine = false; rubberLineStartNode = NULL;
  edgeNodeTracked = -2;
  if(activeElement) activeElement->modus &= ~Modus::selected;
  activeElement = NULL; activeEdge = NULL; activeNode = NULL;
  setMouseTracking(true);
}

void AtmtCanvas::lineEditFinished() {
  if(editedElement) {
    estrbuf new_acceptation( lineEdit->text() );
    editedElement->assignContent(atmt,&new_acceptation);
    editedElement->updateGeometry(this);
    setMaxCoords( editedElement->pos + QPointF( editedElement->a, editedElement->b ) );
    emit changed();
    update();
  }
  setMouseTracking(true); editedElement = NULL;
  lineEdit->hide();
}

void AtmtCanvas::prepareLineEdit( GraphElement *elm, QString editwhat ) {
  lineEdit->setText(editwhat); editedElement = elm;
  lineEdit->move( elm->pos.x() - elm->a - 12, elm->pos.y() - elm->b + ( 2*elm->b - lineEdit->height() ) / 2 ); 
  int width = qMax( lineEdit->fontMetrics().averageCharWidth()*21, lineEdit->fontMetrics().width(editwhat) + lineEdit->fontMetrics().averageCharWidth()*8 );
  width = qMin( width, this->width() - lineEdit->pos().x() );
  lineEdit->setFixedWidth(width);
  lineEdit->show(); lineEdit->setFocus(Qt::MouseFocusReason);
}

bool AtmtCanvas::eventFilter(QObject *target,QEvent *event) {
  if( target == lineEdit && event->type() == QEvent::KeyPress ) {
    QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
    if( keyEvent->key() == Qt::Key_Escape) {
      setMouseTracking(true); editedElement = NULL; lineEdit->hide();
      return true;
  } }
  return AtmtWatch::eventFilter(target,event);
}

void AtmtCanvas::unicodeLetterButtonClicked() {
  QString instext; SubscriptedPushButton *subsbutton = dynamic_cast<SubscriptedPushButton*>(sender()); 
  if(subsbutton) instext = subsbutton->getResultText();
  else {
    QPushButton *pushbutton = qobject_cast<QPushButton*>(sender()); if(!pushbutton) return;
    instext = pushbutton->text();
  }
  QString newtext = lineEdit->text(); int pos = lineEdit->cursorPosition();
  newtext.insert( pos, instext );
  lineEdit->setText(newtext);
  lineEdit->setFocus(Qt::FocusReason::TabFocusReason);
  lineEdit->setCursorPosition( pos + instext.length() );
}

void AtmtCanvas::mouseDoubleClickEvent(QMouseEvent *event) {
  if(!atmt) return;
  activateCurElm(event->pos());
  if( event->button() == Qt::LeftButton && !activeElement ) {
    Node *node = atmt->createNode()->setCoords(event->pos());
    node->updateGeometry(this); setActiveNode(node); 
    prepareLineEdit(node,"");
    //cerr << "hugo" << ( 2*node->b - lineEdit->height() ) << ", " << node->b  << ", " << lineEdit->height() << aux::endl;
    setMaxCoords( node->pos + QPointF( node->a, node->b ) );
    emit changed();
    update();
  }
}
  
bool AtmtCanvas::keyPressed(QKeyEvent *event) {
  // keyPressEvent did sometimes not report Key_Delete
  //cerr << "kk:"<< IOChangeVal(IOAttr::NumberBaseNextOne,16) << event->key() << "," << IOChangeVal(IOAttr::NumberBaseNextOne,16) << Qt::Key_Delete << aux::endl;
  if(!atmt) return false;
  switch(event->key()) {
    case Qt::Key_Delete: 
        if(activeElement) { atmt->removeElement(activeElement); activeElement = NULL; activeNode = NULL; activeEdge = NULL; emit changed(); update(); }
      break;
    default: return false;
  }
  return true;
}

void AtmtCanvas::keyPressEvent(QKeyEvent *event) {
  if(!keyPressed(event)) QWidget::keyPressEvent(event); 
}

GraphElement* AtmtCanvas::activateCurElm( QPointF pos, int kindOf ) {
  Element *previouslyActive = activeElement;
  if(activeElement) activeElement->modus &= ~Modus::selected; 
  activeElement = NULL; activeNode = NULL; activeEdge = NULL;
  if( kindOf & KindOfElm::edges )
    for(std::list<Edge*>::iterator ie = atmt->allEdges.begin(); ie != atmt->allEdges.end(); ie++ )
      if( (*ie)->isThere(pos) ) { activeEdge = *ie; activeElement = *ie; break; }
  if( !activeElement &&  kindOf & KindOfElm::nodes )
    for(std::list<Node*>::iterator in = atmt->allNodes.begin(); in != atmt->allNodes.end(); in++ ) 
      if( (*in)->isThere(pos) ) { activeNode = *in; activeElement = *in; break; }
  if(activeElement) activeElement->modus |= Modus::selected;
  //if(activeElement) cerr << (u_iword)activeElement << aux::endl;
  if( activeElement != previouslyActive ) update();
  return activeElement;
};

void AtmtCanvas::mouseMoveEvent( QMouseEvent *event ) {
  if(!atmt) return;
  if(movingNode) { 
    if( event->buttons() & Qt::RightButton ) {
      movingNode->pos = event->pos(); 
      setMaxCoords( movingNode->pos + QPointF( movingNode->a, movingNode->b ) );
      update(); 
      return; 
    } else {
      atmt->removeNode(movingNode); movingNode = NULL; update(); 
      return;
  } }
  if( event->buttons() & Qt::RightButton ) {
    qreal distance = vector_length( event->pos() - rightClickPosition );
    if( distance > isThereRadius ) { 
      if( activeNode ) {
        movingNode = atmt->createNode()->assignParams(activeNode);
        movingNode->modus = Modus::moving;
      } else if( activeEdge && edgeNodeTracked >= 0 ) {
	if( edgeNodeTracked % 3  ) 
	  activeEdge->track[edgeNodeTracked] = event->pos();
	else {
	  int i, j, newposCount = (activeEdge->track.size()+2) / 3; QPointF *newpos = (QPointF*)malloc(sizeof(QPointF)*newposCount); // QPointF newpos[ newposCount ];
	  for( i=0, j=0; i < newposCount; i++, j+=3 ) {
	    if( j !=  edgeNodeTracked ) newpos[i] = activeEdge->track[j];
	    else newpos[i] = event->pos();
	  }
	  activeEdge->trackEdges( newpos );
	  free(newpos);
	}
	update();
      } else if( activeEdge && edgeNodeTracked == -1 ) {
	edgeNodeTracked = -2;
	for(int i=1; i < (int)activeEdge->track.size()-1; i++ ) {
	  qreal distance = vector_length( rightClickPosition - activeEdge->track[i] );
	  if( distance <= handleRadius ) { edgeNodeTracked = i; emit changed(); break; }
      } }
    }
    return;
  }
  activateCurElm( event->pos(), rubberLine ? (KindOfElm::nodes) : (KindOfElm::nodes|KindOfElm::edges) );
  if( event->buttons() & Qt::LeftButton ) {
    if( rubberLineStartNode && activeElement != rubberLineStartNode ) {
      rubberLine = true;
    }
    if(rubberLine) {
      rubberLineEnd = event->pos();
      if(rubberLineStartNode) rubberLineStart = rubberLineStartNode->getSecant(rubberLineEnd);
      update();
    }
  } else {
    if(curCreatedEdge) {
      atmt->removeEdge(curCreatedEdge);
      curCreatedEdge = NULL;
    }
    rubberLine = false; rubberLineStartNode = NULL;
  }
}

void AtmtCanvas::mousePressEvent(QMouseEvent *event) {
  if(!atmt) return;
  //curButton |= event->button();
  if(movingNode) return;
  if( event->button() == Qt::LeftButton ) {
    activateCurElm(event->pos());
    if( !activeElement ) {
      if(!lineEdit->isHidden()) lineEditFinished(); 
    } else {
      if( activeNode ) { 
	rubberLineStartNode = activeNode; if(curCreatedEdge) cerr << "curCreaetedEdge was not null" << aux::endl;
	curCreatedEdge = NULL;
      } else if( activeEdge && activeEdge->atLabel(event->pos()) ) editedLabelEdge = activeEdge;
    }
    setMouseTracking(true); 
  } else if( event->button() == Qt::RightButton ) {
    rightClickPosition = event->pos();
    edgeNodeTracked = -1; didTrackBeforeClick = hasMouseTracking();
    setMouseTracking(true);
  }
}

void AtmtCanvas::mouseReleaseEvent(QMouseEvent *event) {
  if(!atmt) return;
  //curButton &= ~event->button();
  if( event->button() & Qt::LeftButton ) {
    activateCurElm( event->pos(), rubberLine ? (KindOfElm::nodes) : (KindOfElm::nodes|KindOfElm::edges) );
    if( rubberLine ) {
      if(!activeNode) { 
	if(curCreatedEdge) atmt->removeEdge(curCreatedEdge); 
      } else {
	if(!rubberLineStartNode) {
	  curCreatedEdge->addLinearTrackNode( activeNode->getSecant(curCreatedEdge->track.back()) );
	  curCreatedEdge->to = activeNode; if(activeNode) activeNode->pred.push_back(curCreatedEdge);
	  curCreatedEdge->modus = Modus::normal; // set an empty label by default
	} else {
	  curCreatedEdge = atmt->createEdge(rubberLineStartNode,activeNode);
	}
	curCreatedEdge->updateGeometry(this);
	setActiveEdge(curCreatedEdge);
	prepareLineEdit(curCreatedEdge,"");
	setMouseTracking(false);
	emit changed();
      }
      curCreatedEdge = NULL;
      update();
    } else if( activeElement ) { // !rubberLine
      if( ( activeNode && activeNode == rubberLineStartNode && !rubberLine ) || ( activeEdge && activeEdge == editedLabelEdge && editedLabelEdge->atLabel(event->pos()) ) ) {
        prepareLineEdit( activeElement, toQString( activeElement->getContent(), escapeSlash && activeEdge ) );
      }
      setMouseTracking(false); //!hasMouseTracking());
    }
    rubberLineStartNode = NULL;
    editedLabelEdge = NULL;
    rubberLine = false;
  } else if( event->button() & Qt::RightButton ) {
    if(rubberLine) {
      if(!curCreatedEdge) {
	curCreatedEdge = atmt->createEdge(rubberLineStartNode,NULL);
	curCreatedEdge->addLinearTrackNode(rubberLineStart);
	curCreatedEdge->modus = Modus::creating_edge;
      }
      curCreatedEdge->addLinearTrackNode(rubberLineEnd);
      rubberLineStart = rubberLineEnd; rubberLineStartNode = NULL;
    } else if(movingNode) {
      if(!activeNode) { atmt->removeNode(movingNode); movingNode = NULL; update(); } else {
       QPointF formerPos = activeNode->pos;
       activeNode->assignParams(movingNode);
       atmt->removeNode(movingNode); movingNode = NULL;
       for( Edges::iterator ie = activeNode->pred.begin(); ie != activeNode->pred.end(); ie++ ) (*ie)->trackNodes( (*ie)->from->pos, formerPos );
       for( Edges::iterator ie = activeNode->succ.begin(); ie != activeNode->succ.end(); ie++ ) (*ie)->trackNodes( formerPos, (*ie)->to->pos );
       emit changed();
       update();
    }} else { 
      qreal distance = vector_length( event->pos() - rightClickPosition );
      if( distance < isThereRadius ) {
	if(activeNode) {
	  set_by_program = true;
	  setStartNodeAction->setChecked(activeNode==atmt->startNode);
	  setFinalNodeAction->setChecked(activeNode->isFinalNode());
	  set_by_program = false;
	  nodeContextMenu->move(mapToGlobal( event->pos() - QPoint(nodeContextMenu->width()/3,nodeContextMenu->height()/3) ));
	  nodeContextMenu->exec();
	} else if(activeEdge) {
	  edgeContextMenu->move(mapToGlobal( event->pos() - QPoint(edgeContextMenu->width()/3,edgeContextMenu->height()/3) ));
	  edgeContextMenu->exec();
      } }
      if( edgeNodeTracked >= 0 && activeEdge ) {
	activeEdge->pos = activeEdge->painterPath().pointAtPercent(0.5); update();
	setMouseTracking(didTrackBeforeClick);
      }
      edgeNodeTracked = -2;
  } }
}

