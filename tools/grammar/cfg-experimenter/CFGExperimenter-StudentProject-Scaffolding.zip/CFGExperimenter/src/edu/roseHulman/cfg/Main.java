/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg;

import edu.roseHulman.cfg.ui.CFGExperimentFrame;

/**
 * Main entry class for program.
 * 
 * @author cclifton
 */
public class Main {
	/**
	 * Main entry point for program.
	 * 
	 * @param args
	 *            ignored
	 */
	public static void main(String[] args) {
		// Tells Mac OS X to ignore Java convention of placing menu bar in the
		// window.
		System.setProperty("apple.laf.useScreenMenuBar", "true");
		CFGExperimentFrame.start();
	}

}
