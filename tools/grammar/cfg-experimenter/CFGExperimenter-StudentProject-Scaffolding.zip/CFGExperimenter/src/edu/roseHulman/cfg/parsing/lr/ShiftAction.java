/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;


/**
 * This immutable class represents a shift action in the Action Table.
 *
 * @author clifton.
 *         Created Mar 18, 2007.
 * @author kelleybt
 */
public class ShiftAction extends Action {

	private final int nextState;

	/**
	 * Construct an action representing shifting to the given next state.
	 *
	 * @param nextState
	 */
	public ShiftAction(int nextState) {
		this.nextState = nextState;
	}

	@Override
	public String toString() {
		return "shift " + nextState;
	}

	/**
	 * @return the index of the state to which this action shifts the parser
	 */
	public int getNextState() {
		return this.nextState;
	}
}
