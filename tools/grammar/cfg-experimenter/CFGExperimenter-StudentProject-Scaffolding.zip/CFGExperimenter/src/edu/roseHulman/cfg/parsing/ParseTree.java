/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * Subclasses of this class record the actions taken by a parser during the
 * parse of a string. The parser code calls methods of this class to record each
 * step that the parser takes. Once the parse is concluded, the user interface
 * can use the record of actions to display an animated parse tree.
 * 
 * @author kelleybt
 * @author clifton
 */
public abstract class ParseTree {

	/**
	 * Records whether the parse tree adds nodes from left to right under a
	 * given node.
	 */
	private boolean isLeftToRight;

	/**
	 * Records whether the parse tree grows down from an initial root node. If
	 * false, then the tree grows up by merging existing trees using new root
	 * nodes.
	 */
	private boolean isTopDown;

	/** ParseTreeNodes for this ParseTree in order parsed. */
	private List<ParseTreeNode> nodes;

	/** Indicates whether the tree is finished building. */
	private boolean hasFinishedConstruction;

	/**
	 * Stores all the actions requested on this parse tree by the parsing
	 * algorithm.
	 */
	protected final List<ParseAction> actionTrace = new ArrayList<ParseAction>();

	/**
	 * This immutable class represents an action taken during a parse, such as
	 * parsing a token, parsing a production, or encountering an error. A list
	 * of actions is recorded for debugging and reporting. For example, in the
	 * user interface hovering the mouse point over the parse tree display will
	 * reveal a tool-tip giving the steps taken during the parse.
	 */
	public static class ParseAction {
		private final String kind;
		private final Object data;

		/**
		 * Constructs an action of the given kind with the given supporting
		 * data.
		 * 
		 * @param kind
		 * @param data
		 */
		protected ParseAction(String kind, Object data) {
			this.kind = kind;
			this.data = data;
		}

		/**
		 * Constructs an action of the given kind with no supporting data.
		 * 
		 * @param kind
		 */
		protected ParseAction(String kind) {
			this(kind, null);
		}

		@Override
		public String toString() {
			if (this.data == null) {
				return this.kind;
			} else {
				return this.kind + ": " + this.data;
			}
		}
	}

	/**
	 * Factory method creates the appropriate ParseTree class.
	 * 
	 * @param isLeftToRight
	 *            true if the algorithm parses left-to-right, otherwise false
	 * @param isTopDown
	 *            true if the algorithm parses top-to-bottom, otherwise false
	 * @return A ParseTree that builds itself according to the algorithm
	 *         specified
	 */
	public static ParseTree createParseTree(boolean isLeftToRight,
			boolean isTopDown) {
		if (isTopDown) {
			return new TopDownParseTree(isLeftToRight);
		}
		return new BottomUpParseTree(isLeftToRight);
	}

	/**
	 * Construct a new, empty parse tree.
	 * 
	 * @param isLeftToRight
	 *            whether the parse tree adds nodes from left to right under a
	 *            given node.
	 * 
	 * 
	 * @param isTopDown
	 *            whether the parse tree grows down from an initial root node.
	 *            If false, then the tree grows up by merging existing trees
	 *            using new root nodes.
	 */
	protected ParseTree(boolean isLeftToRight, boolean isTopDown) {
		this.hasFinishedConstruction = false;

		this.isLeftToRight = isLeftToRight;
		this.isTopDown = isTopDown;
		this.nodes = new ArrayList<ParseTreeNode>();
	}

	/*
	 * Parsing
	 */

	/**
	 * Call when the parser has parsed any subclass of Token. This method is
	 * applicable for both LL(1) and LR(1) parsing.
	 * 
	 * @param token
	 *            the token that was parsed
	 * 
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 */
	public abstract void parsedToken(Token token);

	/*
	 * LL(1) Parsing Methods
	 */

	/**
	 * Call when the LL(1) parser is going to push a production onto its stack.
	 * 
	 * @param prod
	 *            the production that will be pushed
	 * 
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 * @throws UnsupportedOperationException
	 *             if this method is not appropriate for the current parsing
	 *             method.
	 */
	public abstract void willParseProduction(Production prod);

	/**
	 * Call when the LL(1) parser cannot match the non-terminal symbol on the
	 * top of the stack. <b>Note:</b> invokes finishConstruction().
	 * 
	 * @param token
	 *            The token that caused the parse error
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 * @throws UnsupportedOperationException
	 *             if this method is not appropriate for the current parsing
	 *             method.
	 */
	public abstract void errorExpandingTopOfStack(Token token);

	/**
	 * Call when the LL(1) parser cannot match the terminal symbol with that on
	 * the top of the stack. <b>Note:</b> invokes finishConstruction().
	 * 
	 * @param token
	 *            The token that caused the parse error
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 * @throws UnsupportedOperationException
	 *             if this method is not appropriate for the current parsing
	 *             method.
	 */
	public abstract void errorLookingForTopOfStack(Token token);

	/*
	 * LR(1) Parsing Methods
	 */

	/**
	 * Call when the LR(1) parser has just successfully completed the parse of a
	 * production.
	 * 
	 * @param prod
	 *            The production that has just been parsed
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 * @throws UnsupportedOperationException
	 *             if this method is not appropriate for the current parsing
	 *             method.
	 */
	public abstract void parsedProduction(Production prod);

	/**
	 * Call when the LR(1) parser encounters a syntax error. <b>Note:</b>
	 * invokes finishConstruction().
	 * 
	 * @param token
	 *            The token that caused the syntax error
	 * @throws IllegalStateException
	 *             if the tree has finished construction.
	 * @throws UnsupportedOperationException
	 *             if this method is not appropriate for the current parsing
	 *             method.
	 */
	public abstract void reportSyntaxError(Token token);

	/*
	 * Common Methods
	 */

	/**
	 * Finalizes the parse tree. No further modifications can be made after this
	 * method is invoked. There is no harm in calling this method multiple
	 * times.
	 */
	public void finishConstruction() {
		this.actionTrace.add(new ParseAction("finishConstruction"));
		if (!this.hasFinishedConstruction) {
			finish();
			this.hasFinishedConstruction = true;
		}
	}

	/**
	 * Gets the node the represents the goal production in the tree.
	 * <b>Note:</b>This method may invoke finishContruction(), so only invoke
	 * after all parsing is completed. Reserved for drawing code.
	 * 
	 * @return the goal non-terminal of this tree
	 */
	public abstract ParseTreeNode getRootNode();

	/**
	 * Appends a ParseTreeNode to the end of the list of parsed nodes. Nodes are
	 * displayed in the order found.
	 * 
	 * @param node
	 * 
	 * @throws IllegalStateException
	 *             if this instance has finished construction
	 */
	protected void addParseTreeNode(ParseTreeNode node) {
		if (hasFinishedConstruction()) {
			throw new IllegalStateException();
		}
		this.nodes.add(node);
	}

	/**
	 * Invoked only once by finishConstruction() so the subclass can do any
	 * processing to finish the tree.
	 */
	protected abstract void finish();

	/*
	 * Properties
	 */

	/**
	 * Gets whether or not this ParseTree has been finalized. If true, the parse
	 * tree cannot be modified further.
	 * 
	 * @return whether or not this tree has been finalized
	 */
	public boolean hasFinishedConstruction() {
		return this.hasFinishedConstruction;
	}

	/**
	 * @return an immutable list of ParseTreeNodes in the order parsed
	 */
	public List<ParseTreeNode> getParsedNodeList() {
		return Collections.unmodifiableList(this.nodes);
	}

	/**
	 * @return an immutable list representing the upper frontier of the parse
	 *         tree forest
	 */
	public List<ParseTreeNode> getUpperFrontier() {
		ArrayList<ParseTreeNode> frontier = new ArrayList<ParseTreeNode>();
		HashSet<ParseTreeNode> nodesOnFrontier = new HashSet<ParseTreeNode>();
		for (ParseTreeNode node : this.nodes) {
			ParseTreeNode treeRoot = node.getRoot();
			if (!nodesOnFrontier.contains(treeRoot)) {
				nodesOnFrontier.add(treeRoot);
				frontier.add(treeRoot);
			}
		}
		return Collections.unmodifiableList(frontier);
	}

	/**
	 * @return true if the algorithm building this tree parses left-to-right,
	 *         otherwise false
	 */
	public boolean isLeftToRight() {
		return this.isLeftToRight;
	}

	/**
	 * @return true if the algorithm building this tree parses top-down,
	 *         otherwise false
	 */
	public boolean isTopDown() {
		return this.isTopDown;
	}

	/**
	 * @return an immutable list of the actions taken to build this parse tree
	 */
	public final List<ParseAction> actionsList() {
		return Collections.unmodifiableList(this.actionTrace);
	}
}
