/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.io.File;

import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Creates a text area that can keep track of whether it has changed (become
 * dirty) since last being marked as clean.
 * 
 * @author cclifton
 */
public class DirtiableTextArea extends JTextArea {

	private DocumentListener dirtyingListener = new DocumentListener() {

		private void threadSafeSetDirty() {
			new Thread(DirtiableTextArea.this.dirtier).start();
		}

		public void insertUpdate(DocumentEvent arg0) {
			this.threadSafeSetDirty();
		}

		public void removeUpdate(DocumentEvent arg0) {
			this.threadSafeSetDirty();
		}

		public void changedUpdate(DocumentEvent arg0) {
			this.threadSafeSetDirty();
		}

	};

	private static final long serialVersionUID = -5239563782498112538L;

	// Synchronize access!
	private boolean isDirty = false;

	private Runnable dirtier = new Runnable() {
		public void run() {
			synchronized (DirtiableTextArea.this) {
				DirtiableTextArea.this.isDirty = true;
			}
		}
	};

	private File theFile = null;

	private final String title;
	private final TitledBorder border;


	/**
	 * Creates a text area with the given initial text, title, and border.
	 * 
	 * @param initialText
	 * @param title 
	 * @param border 
	 */
	public DirtiableTextArea(String initialText, String title, TitledBorder border) {
		super(initialText);
		this.getDocument().addDocumentListener(this.dirtyingListener);
		this.title = title;
		this.border = border;
	}

	/**
	 * Marks this text area as clean until the text is changed.
	 */
	public synchronized void markClean() {
		this.isDirty = false;
	}

	/**
	 * @return true if this text area has been changed since the last time it
	 *         was marked clean
	 */
	public synchronized boolean isDirty() {
		return this.isDirty;
	}

	/**
	 * Records the file with which this text area is associated
	 * 
	 * @param theFile
	 */
	public void setFile(File theFile) {
		this.theFile = theFile;
		this.border.setTitle(this.title + (theFile != null ? (": " + theFile.getName()) : ""));
		// Grotesque hack to climb up to the panel that holds the border:
		this.getParent().getParent().getParent().repaint();
	}

	/**
	 * @return the file with which this text area is associated or null if none
	 */
	public File getFile() {
		return this.theFile;
	}

	/**
	 * Unregisters the dirty-document listener, replaces the text with the given
	 * string, marks this as clean, and re-registers the listener.
	 * 
	 * @param string
	 */
	public void silentSetText(String string) {
		getDocument().removeDocumentListener(this.dirtyingListener);
		setText(string);
		markClean();
		getDocument().addDocumentListener(this.dirtyingListener);
	}

	/**
	 * Connects the given result panel to this so that changes to the text of
	 * this will cause the result panel to be reset.
	 * 
	 * @param resultArea
	 */
	public void connect(final Resetable resultArea) {
		DocumentListener dl = new DocumentListener() {
			public void insertUpdate(DocumentEvent arg0) {
				resultArea.reset();
			}

			public void removeUpdate(DocumentEvent arg0) {
				resultArea.reset();
			}

			public void changedUpdate(DocumentEvent arg0) {
				resultArea.reset();
			}
		};
		getDocument().addDocumentListener(dl);
	}

}
