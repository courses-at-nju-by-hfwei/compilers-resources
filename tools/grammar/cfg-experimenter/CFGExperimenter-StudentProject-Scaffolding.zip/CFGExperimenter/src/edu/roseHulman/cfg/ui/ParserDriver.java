/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.io.StringReader;

import javax.swing.JTextArea;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.Parser;
import edu.roseHulman.cfg.parsing.StringInputScanner;
import edu.roseHulman.cfg.parsing.ll.LL1Parser;
import edu.roseHulman.cfg.parsing.lr.ActionTableConflict;
import edu.roseHulman.cfg.parsing.lr.LR1Parser;

/**
 * The parser driver for the string input. Manages the analysis of the grammar
 * to be parsed and the parsing of input strings.
 * 
 * @author kelleybt
 * @author clifton
 */
public class ParserDriver {

	private JTextArea inputStringArea;

	private GrammarResultPanel grammarInfo;

	private ParseResultsPanel treePanel;

	private LL1Parser ll1Parser;

	private LR1Parser lr1Parser;

	/**
	 * Constructs a new ParserDriver with the selected input and output panels.
	 * 
	 * @param inputStringArea
	 *            The text area accepting the string to be parsed
	 * @param grammarInfo
	 *            the panel to which grammar information is displayed
	 * @param treePanel
	 *            The panel to which to output the parsing results
	 */
	public ParserDriver(JTextArea inputStringArea,
			GrammarResultPanel grammarInfo, ParseResultsPanel treePanel) {
		this.inputStringArea = inputStringArea;
		this.grammarInfo = grammarInfo;
		this.treePanel = treePanel;
	}

	/**
	 * Analyzes the given grammar, displaying results on the grammar analysis
	 * panel.
	 * 
	 * @param g
	 */
	public void analyzeGrammar(Grammar g) {
		g.finalizeGrammar();

		grammarInfo.reset();

		grammarInfo.displayHeading("Productions Found");
		for (Production p : g.productions()) {
			grammarInfo.display(p.toString() + '\n');
		}

		grammarInfo.displaySet(g.nullableNonterminals().getSet(),
				"Nullable Non-terminals");

		grammarInfo.displayMap(g.firstSets().getMap(), "First Sets");

		grammarInfo.displayMap(g.followSets().getMap(), "Follow Sets");

		ll1Parser = new LL1Parser(g);
		grammarInfo.displayParseability(ll1Parser);

		lr1Parser = new LR1Parser(g);

		grammarInfo.displayList(lr1Parser.getCanonicalCollection().getSets(),
				"CC Sets");
		grammarInfo.displayMap(lr1Parser.getCanonicalCollection()
				.getTransitionFunction(), "CC Transition Function");

		grammarInfo.displayMap(
				lr1Parser.getActionAndGotoTables().getActionTable(),
				"Action Table");
		grammarInfo.displayMap(lr1Parser.getActionAndGotoTables().getGotoTable(),
				"Goto Table");

		if (!lr1Parser.isParseable()) {
			grammarInfo.displayHeading("Action Table Conflicts");
			for (ActionTableConflict c : lr1Parser.getActionAndGotoTables()
					.getConflicts()) {
				grammarInfo.display(c.toString() + "\n");
			}
		}

		grammarInfo.displayParseability(lr1Parser);
	}

	/**
	 * Displays the given exception on the grammar analysis panel.
	 * 
	 * @param e
	 */
	public void displayError(Exception e) {
		this.grammarInfo.displayError(e);
	}

	/**
	 * Parses the string input using the provided scanner and sets up for
	 * animation.
	 * 
	 * @param parser
	 */
	public void parse(Parser parser) {
		StringInputScanner scanner = new StringInputScanner(new StringReader(
				inputStringArea.getText()));
		ParseTree tree = parser.parse(scanner);
		this.treePanel.setParseTreeDisplayer(new ParseTreeDisplayer(tree));
	}

	/**
	 * @return the LL-1 parser for the grammar most recently analyzed by this
	 */
	public LL1Parser getLL1Parser() {
		return this.ll1Parser;
	}

	/**
	 * @return the LR-1 parser for the grammar most recently analyzed by this
	 */
	public LR1Parser getLR1Parser() {
		return this.lr1Parser;
	}
}
