/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * This class implements a menu item and handler for opening files into an
 * associated text area.
 * 
 * @author cclifton
 */
public class TextAreaOpenMenuItem extends TextAreaMenuItem {

	private static final long serialVersionUID = -6753236098642716188L;

	/**
	 * Creates a menu item labeled Open label File.
	 * 
	 * @param textArea
	 * @param label
	 */
	public TextAreaOpenMenuItem(DirtiableTextArea textArea, String label) {
		super(textArea, "Open ", label, " File...");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.TextAreaMenuItem#doMenuAction()
	 */
	@Override
	protected boolean doMenuAction() {
		// Prompts first
		if (textArea.isDirty()) {
			int result = JOptionPane.showConfirmDialog(this.textArea, new String[] {
					this.label + " has been changed.",
					"Do you really want to overwrite the contents?" }, this.label + " Changed",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
			if (result == JOptionPane.NO_OPTION) {
				return false;
			}
		}

		// Gets file
		JFileChooser chooser = new JFileChooser(currentDirectory);
		chooser.setMultiSelectionEnabled(false);
		int result = chooser.showOpenDialog(textArea);
		if (result == JFileChooser.CANCEL_OPTION) {
			return false;
		}

		// Opens file
		File theFile = chooser.getSelectedFile();
		currentDirectory = theFile.getParentFile();
		// CONSIDER: track current directory across launches
		StringBuffer contents = new StringBuffer();
		try {
			Reader r = new BufferedReader(new FileReader(theFile));
			int ch = r.read();
			while (ch >= 0) {
				contents.append((char) ch);
				ch = r.read();
			}
			r.close();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(textArea, "Problem opening file " + theFile.getName(),
					"Error Opening File", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		this.textArea.setFile(theFile);
		this.textArea.silentSetText(contents.toString());
		return true;
	}

}
