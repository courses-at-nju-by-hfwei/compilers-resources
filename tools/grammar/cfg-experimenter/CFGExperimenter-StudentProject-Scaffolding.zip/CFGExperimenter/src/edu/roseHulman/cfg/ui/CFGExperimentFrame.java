/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.border.TitledBorder;

import edu.roseHulman.cfg.CFGParser;
import edu.roseHulman.cfg.parsing.Parser;

/**
 * Base class for the GUI.
 * 
 * @author cclifton
 * @author kelleybt
 */
public class CFGExperimentFrame extends JFrame implements Resetable {
	private static final String INITIAL_GRAMMAR = "<S>\t::=\tbaa <S>\n\t|\te\n";

	private static final long serialVersionUID = 1L;

	private static final Dimension PREFERRED_SCROLL_PANE_SIZE = new Dimension(
			300, 200);

	private static final Dimension PREFERRED_RESULT_PANE_SIZE = new Dimension(
			600, 600);

	private static final int BORDER_WIDTH = 15;

	private static final int GAP_WIDTH = 10;

	/**
	 * The font size to use for the GUI.
	 */
	static final int FONT_SIZE = 14;

	private static final String ABOUT_MESSAGE = "by Curtis Clifton and Brian T. Kelley\n" + "Copyright � 2007-2010\n" + "\n" + "Version 1.0";

	private CFGParser cfgParser;

	private ParserDriver driver;

	private JTabbedPane resultTabs;

	private ParseResultsPanel parseResultArea;

	private TextAreaSaveMenuItem grammarSaver;

	private TextAreaSaveMenuItem inputSaver;

	private JButton parseButton;

	private final GrammarResultPanel grammarResultArea;

	private CFGExperimentFrame() {
		// Initializes frame information
		this.setTitle("CFG Experimenter");
		this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				CFGExperimentFrame.this.handleClose();
			}
		});

		// Adds frame contents
		JPanel contents = new JPanel();
		contents.setLayout(new BoxLayout(contents, BoxLayout.PAGE_AXIS));
		contents.setBorder(BorderFactory.createEmptyBorder(BORDER_WIDTH,
				BORDER_WIDTH, BORDER_WIDTH, BORDER_WIDTH));

		// Panel for input side of frame
		JPanel inputContents = new JPanel();
		inputContents.setLayout(new BoxLayout(inputContents,
				BoxLayout.PAGE_AXIS));
		inputContents.setBorder(BorderFactory.createEmptyBorder(GAP_WIDTH,
				GAP_WIDTH, GAP_WIDTH, GAP_WIDTH));

		// Grammar input
		JPanel grammarPanel = new JPanel();
		TitledBorder titledBorder = BorderFactory.createTitledBorder("Grammar");
		grammarPanel.setBorder(titledBorder);
		grammarPanel.setAlignmentX(LEFT_ALIGNMENT);
		grammarPanel.setLayout(new GridLayout(1, 1));
		DirtiableTextArea grammarTextArea = new DirtiableTextArea(
				INITIAL_GRAMMAR, "Grammar", titledBorder);
		grammarTextArea.setFont(new Font("Monospaced", Font.PLAIN, FONT_SIZE));
		JScrollPane scrollPane = new JScrollPane(grammarTextArea,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setPreferredSize(PREFERRED_SCROLL_PANE_SIZE);
		grammarPanel.add(scrollPane);

		// String input
		JPanel inputPanel = new JPanel();
		titledBorder = BorderFactory.createTitledBorder("Input String");
		inputPanel.setBorder(titledBorder);
		inputPanel.setAlignmentX(LEFT_ALIGNMENT);
		inputPanel.setLayout(new GridLayout(1, 1));
		DirtiableTextArea stringInputTextArea = new DirtiableTextArea("",
				"Input String", titledBorder);
		stringInputTextArea.setFont(new Font("Monospaced", Font.PLAIN,
				FONT_SIZE));
		scrollPane = new JScrollPane(stringInputTextArea,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setPreferredSize(PREFERRED_SCROLL_PANE_SIZE);
		inputPanel.add(scrollPane);

		// Input splitter
		JSplitPane inputSplitter = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				grammarPanel, inputPanel);
		inputSplitter.setAlignmentX(LEFT_ALIGNMENT);
		inputSplitter.setResizeWeight(0.5);
		inputSplitter.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		inputContents.add(inputSplitter);

		// Results display
		// Creates a panel holding a tabbed display
		JPanel outputContents = new JPanel();
		outputContents.setLayout(new GridLayout(1, 1));
		outputContents.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		this.resultTabs = new JTabbedPane();
		resultTabs.setPreferredSize(PREFERRED_RESULT_PANE_SIZE);
		outputContents.add(resultTabs);

		grammarResultArea = new GrammarResultPanel();
		resultTabs.addTab("Grammar Analysis", this.grammarResultArea);

		// Adds a parse tree display tab
		this.parseResultArea = new ParseResultsPanel();
		resultTabs.addTab("Parse Results", this.parseResultArea);

		// Full splitter
		JSplitPane fullSplitter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				inputContents, outputContents);
		fullSplitter.setAlignmentX(LEFT_ALIGNMENT);
		contents.add(fullSplitter);

		// Controls
		contents.add(Box.createVerticalStrut(GAP_WIDTH));
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		buttonPanel.setAlignmentX(LEFT_ALIGNMENT);
		buttonPanel.add(Box.createHorizontalGlue());
		JButton helpButton = new JButton("Help");
		helpButton.addActionListener(new ActionHandler() {
			@Override
			protected void handleAction(ActionEvent ev) {
				CFGExperimentFrame.this.displayHelp();
			}
		});
		buttonPanel.add(helpButton);
		buttonPanel.add(Box.createHorizontalStrut(GAP_WIDTH));
		JButton checkButton = new JButton("Check Grammar");
		checkButton.addActionListener(new ActionHandler() {
			@Override
			protected void handleAction(ActionEvent ev) {
				CFGExperimentFrame.this.checkGrammar();
			}
		});
		buttonPanel.add(checkButton);
		buttonPanel.add(Box.createHorizontalStrut(GAP_WIDTH));
		parseButton = new JButton("Parse");
		parseButton.setEnabled(false);
		parseButton.addActionListener(new ActionHandler() {
			@Override
			protected void handleAction(ActionEvent ev) {
				CFGExperimentFrame.this.parseInput();
			}
		});
		buttonPanel.add(parseButton);
		contents.add(buttonPanel);
		this.getRootPane().setDefaultButton(parseButton);

		// Configures the menu bar
		JMenuBar menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);
		// Configures the File menu
		// CONSIDER: add hot keys to menu items
		JMenu fileMenu = new JMenu("File");
		menuBar.add(fileMenu);
		fileMenu.add(new TextAreaNewMenuItem(grammarTextArea, "Grammar"));
		fileMenu.add(new TextAreaOpenMenuItem(grammarTextArea, "Grammar"));
		fileMenu.add(new TextAreaNewMenuItem(stringInputTextArea, "Input"));
		fileMenu.add(new TextAreaOpenMenuItem(stringInputTextArea, "Input"));
		fileMenu.add(new JSeparator());
		this.grammarSaver = new TextAreaSaveMenuItem(grammarTextArea, "Grammar");
		fileMenu.add(this.grammarSaver);
		fileMenu.add(new TextAreaSaveAsMenuItem(grammarTextArea, "Grammar"));
		this.inputSaver = new TextAreaSaveMenuItem(stringInputTextArea, "Input");
		fileMenu.add(this.inputSaver);
		fileMenu.add(new TextAreaSaveAsMenuItem(stringInputTextArea, "Input"));
		fileMenu.add(new JSeparator());
		JMenuItem abouter = new JMenuItem("About...");
		abouter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(CFGExperimentFrame.this, ABOUT_MESSAGE, "CFG Experimenter", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		fileMenu.add(abouter);
		fileMenu.add(new JSeparator());
		JMenuItem exitter = new JMenuItem("Exit");
		exitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CFGExperimentFrame.this.handleClose();
			}
		});
		fileMenu.add(exitter);

		// Wires together the processing objects and the input/display objects
		grammarTextArea.connect(grammarResultArea);
		grammarTextArea.connect(parseResultArea);
		grammarTextArea.connect(this);
		stringInputTextArea.connect(parseResultArea);
		this.driver = new ParserDriver(stringInputTextArea, grammarResultArea,
				parseResultArea);
		this.cfgParser = new CFGParser(grammarTextArea, driver);

		this.add(contents);
		this.pack();
	}

	/**
	 * Handles closing of the main window.
	 */
	protected void handleClose() {
		Runnable r = new Runnable() {
			public void run() {
				if (!CFGExperimentFrame.this.grammarSaver.willClose()) {
					return;
				}
				if (!CFGExperimentFrame.this.inputSaver.willClose()) {
					return;
				}
				CFGExperimentFrame.this.dispose();
				System.exit(0);
			}
		};
		new Thread(r).start();
	}

	/**
	 * Displays a help window.
	 */
	protected void displayHelp() {
		JOptionPane.showConfirmDialog(this, "Help!  I need somebody.");
	}

	/**
	 * Parses the input according to the grammar and shows the parse tree.
	 */
	protected synchronized void parseInput() {
		if (this.cfgParser.grammar() == null) {
			checkGrammar();
		}
		// Activates parse tree tab and asks the parser to do its thing.
		this.resultTabs.setSelectedComponent(this.parseResultArea);
		// Decide which parser to use
		Parser ll1Parser = this.driver.getLL1Parser();
		Parser lr1Parser = this.driver.getLR1Parser();
		if (ll1Parser.isParseable() && lr1Parser.isParseable()) {
			Object[] options = { ll1Parser.getName(), lr1Parser.getName() };
			int n = JOptionPane.showOptionDialog(this,
					"Which parser would you like to use?",
					"Select Parsing Method", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
			if (n == JOptionPane.YES_OPTION) {
				this.driver.parse(ll1Parser);
			} else {
				this.driver.parse(lr1Parser);
			}
		} else if (ll1Parser.isParseable()) {
			this.driver.parse(ll1Parser);
		} else if (lr1Parser.isParseable()) {
			this.driver.parse(lr1Parser);
		}
	}

	/**
	 * Shows nullable, first, and follow sets, plus whether the grammar is
	 * backtrack-free.
	 */
	protected synchronized void checkGrammar() {
		// Activates grammar results tab and asks the parser to do its thing.
		this.resultTabs.setSelectedComponent(this.grammarResultArea);
		this.cfgParser.checkGrammar();
		this.parseButton.setEnabled(this.driver.getLL1Parser().isParseable()
				|| this.driver.getLR1Parser().isParseable());
	}

	/**
	 * Initializes GUI.
	 */
	public static void start() {
		new CFGExperimentFrame().setVisible(true);
	}

	private abstract class ActionHandler implements ActionListener {

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent
		 * )
		 */
		public void actionPerformed(final ActionEvent arg0) {
			Runnable r = new Runnable() {

				public void run() {
					ActionHandler.this.handleAction(arg0);
				}
			};
			new Thread(r).run();
		}

		/**
		 * Called in new thread to handle action of action listener.
		 * 
		 * @param ev
		 */
		protected abstract void handleAction(ActionEvent ev);

	}

	@Override
	public void reset() {
		this.parseButton.setEnabled(false);
	}
}
