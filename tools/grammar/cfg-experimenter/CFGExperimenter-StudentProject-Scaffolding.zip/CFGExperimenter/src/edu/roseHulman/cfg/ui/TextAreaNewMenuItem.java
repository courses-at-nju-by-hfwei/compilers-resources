/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import javax.swing.JOptionPane;

/**
 * This class implements a menu item and handler for clearing a text area and
 * disassociating it from any files.
 * 
 * @author cclifton
 */
public class TextAreaNewMenuItem extends TextAreaMenuItem {

	private static final long serialVersionUID = 1L;

	/**
	 * Creates a menu item labeled New label.
	 * 
	 * @param textArea
	 * @param label
	 */
	public TextAreaNewMenuItem(DirtiableTextArea textArea, String label) {
		super(textArea, "New ", label, "");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.TextAreaMenuItem#doMenuAction()
	 */
	@Override
	protected boolean doMenuAction() {
		// Prompts first
		if (textArea.isDirty()) {
			int result = JOptionPane.showConfirmDialog(this.textArea, new String[] {
					this.label + " has been changed.",
					"Do you really want to overwrite the contents?" }, this.label + " Changed",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
			if (result == JOptionPane.NO_OPTION) {
				return false;
			}
		}
		
		this.textArea.setFile(null);
		this.textArea.silentSetText("");
		return true;
	}

}
