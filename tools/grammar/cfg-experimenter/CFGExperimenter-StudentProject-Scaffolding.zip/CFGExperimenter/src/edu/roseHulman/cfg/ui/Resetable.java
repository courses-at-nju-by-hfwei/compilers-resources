/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

/**
 * This is the common type for display features that should be reset when the
 * input areas change.
 * 
 * @author cclifton
 */
public interface Resetable {
	/**
	 * Reset the display feature.
	 */
	public void reset();
}
