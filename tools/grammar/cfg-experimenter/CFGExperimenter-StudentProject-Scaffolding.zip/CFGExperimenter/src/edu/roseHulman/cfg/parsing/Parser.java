/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import edu.roseHulman.cfg.Grammar;

/**
 * The interface used to abstract parsing from the actual method used. 
 * 
 * @author kelleybt
 */
public interface Parser {

	/**
	 * @return the name of the parsing method
	 */
	public String getName();

	/**
	 * @return the grammar this parser parses
	 */
	public Grammar grammar();

	/**
	 * @return Whether or not this parser is capable of parsing the grammar
	 */
	public boolean isParseable();

	/**
	 * Invokes the implementation's parsing loop. Always returns a ParseTree
	 * instance; no exceptions are thrown. Errors are handled by the ParseTree
	 * model.
	 * @param scanner The input from which to read tokens to parse
	 * @return A ParseTree model object representing the hierarchical
	 * organization of the token stream.
	 */
	public ParseTree parse(StringInputScanner scanner);
}
