/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg;

/**
 * This utility class represents an immutable pair of objects. Note that the
 * objects themselves may or may not be mutable.
 * 
 * @author cclifton
 * @author kelleybt
 * @param <F>
 *            the type of the first element
 * @param <S>
 *            the type of the second element
 */
public class Pair<F extends Comparable<? super F>, S extends Comparable<? super S>>
		implements Comparable<Pair<F, S>> {
	private final F first;

	private final S second;

	/**
	 * Constructs a pair with the given elements. Requires that neither element
	 * is null.
	 * 
	 * @param first
	 * @param second
	 */
	public Pair(F first, S second) {
		super();
		this.first = first;
		this.second = second;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object other) {
		Pair<F, S> otherPair = (Pair<F, S>) other;
		return this.first.equals(otherPair.first)
				&& this.second.equals(otherPair.second);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return this.first.hashCode() * 13 + this.second.hashCode();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "<" + first.toString() + "," + second.toString() + ">";
	}

	/**
	 * Compares this pair to another using first comparison of the first
	 * elements of the pairs, then using comparison of the second elements to
	 * break ties.
	 * 
	 * @param other
	 * @return -1 if this is less than other, 0 if they are equal, or 1 if this
	 *         is greater than other
	 */
	public int compareTo(Pair<F, S> other) {
		int firstComparison = this.first.compareTo(other.first);
		if (firstComparison != 0) {
			return firstComparison;
		}
		return this.second.compareTo(other.second);
	}

	/**
	 * @return the first element in the pair
	 */
	public F getFirst() {
		return this.first;
	}

	/**
	 * @return the second element in the pair
	 */
	public S getSecond() {
		return this.second;
	}
}
