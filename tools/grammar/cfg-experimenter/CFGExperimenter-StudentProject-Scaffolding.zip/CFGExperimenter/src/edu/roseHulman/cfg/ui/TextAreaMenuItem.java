/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JMenuItem;

/**
 * A parent class for classes that implement menu items for opening and saving text area contents.
 * @author cclifton
 */
public abstract class TextAreaMenuItem extends JMenuItem implements ActionListener {

	private static final long serialVersionUID = 2749127899329997897L;

	/**
	 * The label for associated menu items.
	 */
	protected String label;
	
	/**
	 * The associated textArea.
	 */
	protected DirtiableTextArea textArea;
	
	/**
	 * The last directory browsed with one of the file choosers.
	 */
	protected static File currentDirectory = new File("/Users/cclifton/Documents/Rose/Workspace/CFGExperimenter/tests/edu/roseHulman/cfg");

	/**
	 * Constructs a menu item for the given text area with the given label. 
	 * @param textArea 
	 * @param labelPrefix string to precede label in menu item
	 * @param label
	 * @param labelSuffix string to follow label in menu item
	 */
	public TextAreaMenuItem(DirtiableTextArea textArea, String labelPrefix, String label, String labelSuffix) {
		super(labelPrefix + label + labelSuffix);
		this.label = label;
		this.textArea = textArea;
		this.addActionListener(this);
	}

	/**
	 * Called in new thread to perform the action of this menu item.
	 * @return true if the action was completed normally, false if cancelled or otherwise aborted
	 */
	protected abstract boolean doMenuAction();

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public final void actionPerformed(ActionEvent arg0) {
		synchronized (this.textArea) {
			doMenuAction();
		}
	}


}
