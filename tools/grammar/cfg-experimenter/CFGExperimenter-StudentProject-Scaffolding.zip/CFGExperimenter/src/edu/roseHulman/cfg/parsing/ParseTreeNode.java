/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * Represents a node in the parse tree. Could be either a non-terminal or a
 * terminal symbol. Records child nodes to maintain the structure of the parse
 * tree.
 * 
 * @author kelleybt
 * @author clifton
 */
public final class ParseTreeNode {

	/**
	 * The production for which this node is the left-hand side. May be null if
	 * token is a terminal symbol.
	 */
	private Production production;

	/** The token labeling this node. */
	private Token token;

	/**
	 * The parent node of this one in the parse tree. May be null if this node
	 * is the root of the parse tree. May be (temporarily) null if this node is
	 * the root of a subtree in the forest of partial parse trees for a
	 * bottom-up parse. In that case it will be set when the subtree is included
	 * in a reduction.
	 */
	private ParseTreeNode parent;

	/** The child nodes of this one. */
	private List<ParseTreeNode> children;

	/** Records whether this node represents a parse error. */
	private boolean isError;

	private ParseTreeNode(ParseTreeNode parent) {
		this.parent = parent;
		this.isError = false;
	}

	/**
	 * Constructs a new parse tree node representing the left-hand side of the
	 * given production.
	 * 
	 * @param parent
	 *            the parent node of the new node, or null during a bottom-up
	 *            parse
	 * @param production
	 */
	public ParseTreeNode(ParseTreeNode parent, Production production) {
		this(parent);
		this.production = production;
		this.token = production.leftHandSide();
		this.children = new ArrayList<ParseTreeNode>();
		if (parent != null) {
			parent.addChild(this);
		}
	}

	/**
	 * Constructs a new parse tree node representing the given token. Assumes
	 * the token is a terminal symbol.
	 * 
	 * FIXME: or the pseudo-token representing the empty string?
	 * 
	 * @param parent
	 *            the parent node of the new node, or null during a bottom-up
	 *            parse
	 * @param token
	 */
	public ParseTreeNode(ParseTreeNode parent, Token token) {
		this(parent);
		// FIXME: strange treatment of empty string
		if (!(token.isTerminal() || token.isEmptyString()))
			System.err.println("expected token " + token
					+ " to be a terminal symbol or empty string token");
		this.production = null;
		this.token = token;
		this.children = null;
		if (parent != null) {
			parent.addChild(this);
		}
	}

	/*
	 * Tree Hierarchy Methods
	 */

	/**
	 * Adds a ParseTreeNode to the end of this node's children
	 * 
	 * @param child
	 *            The ParseTreeNode child to append.
	 */
	public void addChild(ParseTreeNode child) {
		this.children.add(child);
		child.parent = this;
	}

	/**
	 * Inserts a ParseTreeNode to the beginning of this node's children
	 * 
	 * @param child
	 *            The ParseTreeNode child to insert.
	 */
	public void insertChild(ParseTreeNode child) {
		this.children.add(0, child);
		child.parent = this;
	}

	/**
	 * @return The ParseTreeNode to which this node is a child, or null if this
	 *         node has no parent.
	 */
	public ParseTreeNode getParent() {
		return this.parent;
	}

	/*
	 * Properties
	 */

	/**
	 * @return true if the number of child nodes is equal to the number of
	 *         tokens on the right-hand-side of this node's production.
	 */
	public boolean isFullyParsed() {
		return this.production == null
				|| this.children.size() == this.production.rightHandSide()
						.size();
	}

	/**
	 * @return Gets the Production associated with this node.
	 */
	public Production getProduction() {
		return this.production;
	}

	/**
	 * @return The number of children of this node. Returns 0 even if this node
	 *         cannot contain children (e.g. is a Terminal node).
	 */
	public int getChildCount() {
		if (this.children != null) {
			return this.children.size();
		}
		return 0;
	}

	/**
	 * @return An immutable list containing this node's children.
	 */
	public List<ParseTreeNode> getChildren() {
		if (this.children == null) {
			return Collections.emptyList();
		}
		return Collections.unmodifiableList(this.children);
	}

	/**
	 * Returns whether this node represents an error. The user interface can use
	 * this property to render error nodes differently.
	 * 
	 * @return true if this node represents an error, otherwise false.
	 */
	public boolean getIsError() {
		return this.isError;
	}

	/**
	 * Sets whether this node represents an error node, i.e. a node that is not
	 * part of the original grammar.
	 * 
	 * @param isError
	 *            true to draw as an error, otherwise false
	 */
	public void setIsError(boolean isError) {
		this.isError = isError;
	}

	/**
	 * @return The Token this node represents.
	 */
	public Token getToken() {
		return this.token;
	}

	/**
	 * @return the root node of the parse tree to which this node belongs
	 */
	public ParseTreeNode getRoot() {
		if (this.parent == null) {
			return this;
		}
		return this.parent.getRoot();
	}

	@Override
	public String toString() {
		if (this.production != null) {
			return this.production.toString();
		} else {
			return this.token.toString();
		}
	}

}
