/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.NonTerminalToken;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * The algorithms used to realize the structure/hierarchical of tokens returned
 * by an LR(1) parser.
 * 
 * @author kelleybt
 * @author clifton
 */
class BottomUpParseTree extends ParseTree {

	/**
	 * Constructs a empty, bottom-up parse tree.
	 * 
	 * @param isLeftToRight
	 *            whether the parse tree adds nodes from left to right
	 */
	BottomUpParseTree(boolean isLeftToRight) {
		super(false, isLeftToRight);
	}

	/*
	 * Parsing
	 */

	@Override
	public void parsedToken(final Token token) {
		this.actionTrace.add(new ParseAction("parsedToken", token));
		addParseTreeNode(new ParseTreeNode(null, token));
	}

	/*
	 * LL(1) Parsing Methods
	 */

	@Override
	public void willParseProduction(Production prod) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void errorExpandingTopOfStack(Token token) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void errorLookingForTopOfStack(Token token) {
		throw new UnsupportedOperationException();
	}

	/*
	 * LR(1) Parsing Methods
	 */

	@Override
	public void parsedProduction(final Production prod) {
		this.actionTrace.add(new ParseAction("parsedProduction", prod));
		if (prod.goesToEpsilon()) {
			parsedToken(prod.rightHandSide().get(0));
		}
		ParseTreeNode node = new ParseTreeNode(null, prod);
		List<ParseTreeNode> upperFrontier = getUpperFrontier();
		int prodLength = prod.rightHandSide().size();
		int ufLength = upperFrontier.size();
		for (int nodeIndex = ufLength - prodLength, prodIndex = 0; prodIndex < prodLength
				&& nodeIndex < ufLength; nodeIndex++) {
			ParseTreeNode candidateChildNode = upperFrontier.get(nodeIndex);
			if (candidateChildNode.getToken().compareTo(
					prod.rightHandSide().get(prodIndex)) == 0) {
				node.insertChild(candidateChildNode);
				prodIndex++;
			}
		}
		addParseTreeNode(node);
	}

	@Override
	public void reportSyntaxError(final Token token) {
		this.actionTrace.add(new ParseAction("reportSyntaxError", token));
		final NonTerminalToken errorNodeToken = new NonTerminalToken(token
				.toString());
		ParseTreeNode errorNode = new ParseTreeNode(null, new Production() {

			@Override
			public NonTerminalToken leftHandSide() {
				return errorNodeToken;
			}

			@Override
			public List<Token> rightHandSide() {
				return Collections.emptyList();
			}

			@Override
			public boolean goesToEpsilon() {
				return false;
			}

			@Override
			public boolean isGoalProduction() {
				return false;
			}

			@Override
			public int compareTo(Production o) {
				throw new IllegalStateException(
						"error productions are incomparable");
			}

			@Override
			public Grammar grammar() {
				return null;
			}

			@Override
			public int productionNumber() {
				return -1;
			}
			
			@Override
			public String toString() {
				return "dummy syntax error production";
			}
		});
		errorNode.setIsError(true);
		for (ParseTreeNode node : getUpperFrontier()) {
			errorNode.insertChild(node);
		}
		addParseTreeNode(errorNode);
		finishConstruction();
	}

	/*
	 * Common Methods
	 */

	@Override
	public ParseTreeNode getRootNode() {
		finishConstruction();
		List<ParseTreeNode> nodes = getParsedNodeList();
		return nodes.get(nodes.size() - 1);
	}

	@Override
	protected void finish() {
		/*
		 * Adds a final production to the top of the tree from a (hidden) <Goal>
		 * node to the last (and only, for a successful parse) root node
		 * remaining in the forest of partial parse trees.
		 */
		List<ParseTreeNode> nodes = getParsedNodeList();
		final List<Token> childNode = new ArrayList<Token>(1);
		childNode.add(nodes.get(nodes.size() - 1).getToken());
		Production dummyGoalProduction = new Production() {

			@Override
			public NonTerminalToken leftHandSide() {
				return Grammar.GOAL_SYMBOL;
			}

			@Override
			public List<Token> rightHandSide() {
				return childNode;
			}

			@Override
			public boolean goesToEpsilon() {
				return false;
			}

			@Override
			public boolean isGoalProduction() {
				return true;
			}

			@Override
			public int compareTo(Production o) {
				throw new IllegalStateException(
						"dummy goal productions are incomparable");
			}

			@Override
			public Grammar grammar() {
				return null;
			}

			@Override
			public int productionNumber() {
				return -1;
			}

			@Override
			public String toString() {
				return "dummy goal production";
			}
		};
		parsedProduction(dummyGoalProduction);
	}
}
