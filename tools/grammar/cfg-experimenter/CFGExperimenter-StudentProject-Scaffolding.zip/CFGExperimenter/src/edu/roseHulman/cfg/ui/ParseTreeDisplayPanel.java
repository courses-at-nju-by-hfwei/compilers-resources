/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * A panel for displaying a parse tree.
 * 
 * @author kelleybt
 * @author cclifton
 */
public class ParseTreeDisplayPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/** Storage for the ScrollPane property */
	private JScrollPane scrollPane;

	/** Storage for the ParseTreeDisplayer property */
	private ParseTreeDisplayer displayer;

	private final ParseResultsPanel parentPanel;

	/**
	 * Constructs a new panel for displaying a parse tree.
	 * 
	 * @param parent
	 *            the display panel in which this tree display panel is embedded
	 */
	public ParseTreeDisplayPanel(ParseResultsPanel parent) {
		super();
		this.parentPanel = parent;
	}

	@Override
	public void setSize(Dimension d) {
		super.setSize(d);
		if (this.displayer != null) {
			displayer.resetOffsets(this);
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (this.displayer != null) {
			this.displayer.drawTree(g);
		}
	}

	/*
	 * Properties
	 */

	/**
	 * Sets the preferred size for this panel.
	 * 
	 * @param preferredSize
	 */
	public void setDisplaySize(Dimension preferredSize) {
		super.setPreferredSize(preferredSize);
		scrollPane.revalidate();
	}

	/**
	 * @return the ParseTreeDisplayer that displays the ParseTree in this panel
	 */
	public ParseTreeDisplayer getParseTreeDisplayer() {
		return this.displayer;
	}

	/**
	 * Sets the ParseTreeDisplayer to use when painting a tree
	 * 
	 * @param displayer
	 *            The new ParseTreeDisplayer
	 */
	public void setParseTreeDisplayer(ParseTreeDisplayer displayer) {
		if (displayer != null) {
			displayer.determineLayout(this);
		}
		this.displayer = displayer;
		if (displayer != null) {
			this.parentPanel.setParseActionText(this.displayer.getActionTraceText());
		} else {
			this.parentPanel.setParseActionText("");
		}
		repaint();
	}

	/**
	 * Sets that contains this panel.
	 * 
	 * @param scrollPane
	 */
	public void setScrollPane(JScrollPane scrollPane) {
		this.scrollPane = scrollPane;
	}

	/**
	 * @return the dimensions of the containing JScrollPane
	 */
	public Dimension getScrollPaneSize() {
		return this.scrollPane.getSize();
	}
}
