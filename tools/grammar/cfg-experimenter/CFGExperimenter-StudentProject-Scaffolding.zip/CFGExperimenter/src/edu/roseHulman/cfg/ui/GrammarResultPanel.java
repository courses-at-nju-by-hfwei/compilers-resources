/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import edu.roseHulman.cfg.parsing.Parser;

/**
 * This class implements a panel for displaying the results of a grammar
 * analysis.
 * 
 * @author cclifton
 * @author kelleybt
 */
public class GrammarResultPanel extends JPanel implements Resetable {

	private static final long serialVersionUID = 8977312480233398681L;

	private JTextArea messageArea;

	private JPanel messagePanel;

	/**
	 * Creates a new panel for displaying grammar analysis resutls.
	 */
	public GrammarResultPanel() {
		super();
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.messageArea = new JTextArea();
		this.messageArea.setEditable(false);
		this.messageArea.setLineWrap(true);
		this.messageArea.setWrapStyleWord(true);
		this.messageArea.setFont(new Font("Monospaced", Font.PLAIN,
				CFGExperimentFrame.FONT_SIZE));
		JScrollPane sp = new JScrollPane(this.messageArea);
		messagePanel = new JPanel();
		messagePanel.setLayout(new GridLayout(1, 1));
		messagePanel.add(sp);
		messagePanel.setBorder(BorderFactory.createTitledBorder("Messages"));
		this.add(messagePanel);
	}

	/**
	 * Displays the given exception.
	 * 
	 * @param e
	 */
	public void displayError(Exception e) {
		// CONSIDER: make the text area be formatted and make errors red, see
		// JTextPane
		this.messageArea.append(e.getMessage() + "\n");
	}

	/**
	 * Displays the given string.
	 * 
	 * @param string
	 */
	public void display(String string) {
		this.messageArea.append(string);
	}

	/**
	 * Resets the results panel to a pristine state.
	 */
	public void reset() {
		this.messageArea.setText("");
	}

	/**
	 * Displays the given string as a heading.
	 * 
	 * @param string
	 */
	public void displayHeading(String string) {
		// CONSIDER: format as heading
		this.messageArea.append("--------------------------\n");
		this.messageArea.append(string + "\n");
	}

	/**
	 * Adds a panel for displaying the given set, with updating.
	 * 
	 * @param set
	 * @param heading
	 */
	public void displaySet(Set<? extends Object> set, String heading) {
		displayHeading(heading);
		// CONSIDER: Do we need concurrency here?
		for (Object item : set) {
			display(item.toString());
			display("\n");
		}
	}

	/**
	 * Displays the given map on the given panel with the given label.
	 * 
	 * @param map
	 * @param label
	 */
	public void displayMap(Map<? extends Object, ? extends Object> map, String label) {
		displayHeading(label);
		// CONSIDER: Do we need concurrency here?
		for (Object key : map.keySet()) {
			StringBuffer sb = new StringBuffer();
			sb.append(key.toString());
			sb.append(" = ");
			sb.append(map.get(key).toString());
			display(sb.toString() + '\n');
		}
	}

	/**
	 * Adds a panel for displaying the given list, with updating.
	 * 
	 * @param list
	 * @param heading
	 */
	public void displayList(List<? extends Object> list, String heading) {
		displayHeading(heading);
		List<? extends Object> c = new ArrayList<Object>(list);
		for (int i = 0; i < c.size(); i++) {
			display(i + ": ");
			display(c.get(i).toString());
			display("\n");
		}
	}

	/**
	 * Displays whether the grammar is parseable with the given parser
	 * 
	 * @param p
	 */
	public void displayParseability(Parser p) {
		displayHeading(p.getName() + " Parseability");
		if (p.isParseable()) {
			display("This grammar is " + p.getName() + " parseable.\n");
		} else {
			display("This grammar is not " + p.getName() + " parseable.\n");
		}
	}
}
