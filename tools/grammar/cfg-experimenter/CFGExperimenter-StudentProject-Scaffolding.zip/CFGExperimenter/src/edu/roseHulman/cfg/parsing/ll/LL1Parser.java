/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.ll;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.Stack;
import java.util.TreeMap;

import edu.roseHulman.cfg.EOFToken;
import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.NonTerminalToken;
import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.TerminalToken;
import edu.roseHulman.cfg.Token;
import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.Parser;
import edu.roseHulman.cfg.parsing.StringInputScanner;

/**
 * Represents an LL(1) parser, including its table and does the parsing.
 * 
 * @author kelleybt
 */
public class LL1Parser implements Parser {

	private Grammar grammar;

	/**
	 * This is Table[X,y] from section 3.3 of Engineering a Compiler, by Cooper
	 * and Torczon.
	 */
	private TreeMap<Pair<NonTerminalToken, Token>, Production> table;

	/**
	 * Creates a new LL1Parser by constructing the table
	 * 
	 * @param g
	 *            The grammar to parse by LL(1)
	 */
	public LL1Parser(Grammar g) {
		this.grammar = g;
		/*
		 * Uses a tree map to ensure a consistent order. Slower but easier to
		 * test.
		 */
		this.table = new TreeMap<Pair<NonTerminalToken, Token>, Production>();

		// TODO 04: Build the LL(1) Parser Table (consider using a helper method)
	}

	public ParseTree parse(StringInputScanner scanner) {
		ParseTree parseTree = ParseTree.createParseTree(true, true);
		// TODO 06: Implement the LL(1) Parsing Loop
		/*
		 * To get the animation to work, you will need to call the following
		 * methods on the parseTree object at the appropriate points in your
		 * parsing loop:
		 * 
		 * - parseTree.parsedToken();
		 * 
		 * - parseTree.errorLookingForTopOfStack();
		 * 
		 * - parseTree.willParseProduction();
		 * 
		 * The parseTree object "remembers" the order in which these methods are
		 * called and uses that information to do the animation.
		 */

		// Note: You may have multiple exit points from this method.
		return parseTree;
	}

	/**
	 * Returns an immutable version of the table for driving this parser. This
	 * is Table[X,y] from section 3.3 of Engineering a Compiler, by Cooper and
	 * Torczon. This method is provided for unit testing.
	 * 
	 * @return an immutable version of the table for driving this parser
	 */
	Map<Pair<NonTerminalToken, Token>, Production> getTable() {
		return Collections.unmodifiableSortedMap(this.table);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#name(edu.roseHulman.cfg.Parser)
	 */
	public String getName() {
		return "LL(1)";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#grammar(edu.roseHulman.cfg.Parser)
	 */
	public Grammar grammar() {
		return this.grammar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#isParseable(edu.roseHulman.cfg.Parser)
	 */
	public boolean isParseable() {
		// TODO 05: Decide if the grammar is LL(1) Parseable.
		// You will want to make this decision while building the table and just
		// return the result here.
		return false;
	}
}
