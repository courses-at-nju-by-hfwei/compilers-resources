/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.NonTerminalToken;
import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Token;

/**
 * This class represents the action and goto tables for an LR(1) parser.
 * 
 * @author clifton. Created Mar 18, 2007.
 * @author kelleybt
 */
public class ActionAndGotoTables {

	private final Grammar grammar;

	private final CanonicalCollection canonicalCollection;

	private final Map<Pair<Integer, Token>, Action> actionTable;

	private final Map<Pair<Integer, NonTerminalToken>, Integer> gotoTable;

	private final List<ActionTableConflict> conflicts;

	/**
	 * Constructs the action and goto tables for the given grammar and canonical
	 * collection of LR(1) items.
	 * 
	 * @param grammar
	 * @param canonicalCollection
	 */
	public ActionAndGotoTables(Grammar grammar,
			CanonicalCollection canonicalCollection) {
		this.grammar = grammar;
		this.canonicalCollection = canonicalCollection;

		/*
		 * Uses tree maps to ensure a consistent order. Slower but easier to
		 * test.
		 */
		TreeMap<Pair<Integer, Token>, Action> actionTable = new TreeMap<Pair<Integer, Token>, Action>();
		TreeMap<Pair<Integer, NonTerminalToken>, Integer> gotoTable = new TreeMap<Pair<Integer, NonTerminalToken>, Integer>();
		ArrayList<ActionTableConflict> conflicts = new ArrayList<ActionTableConflict>();

		// TODO 10: Populate Action and Goto Tables

		// ---------------------------------------------------------------------

		/*
		 * Stores immutable versions of the tables and conflicts list. This
		 * helps us avoid introducing bugs later by mutating things we
		 * shouldn't.
		 */
		this.actionTable = Collections.unmodifiableSortedMap(actionTable);
		this.gotoTable = Collections.unmodifiableSortedMap(gotoTable);
		this.conflicts = Collections.unmodifiableList(conflicts);
	}

	/**
	 * @return an immutable version of the action table
	 */
	public Map<Pair<Integer, Token>, Action> getActionTable() {
		return Collections.unmodifiableMap(this.actionTable);
	}

	/**
	 * @return an immutable version of the goto table
	 */
	public Map<Pair<Integer, NonTerminalToken>, Integer> getGotoTable() {
		return Collections.unmodifiableMap(this.gotoTable);
	}

	/**
	 * @return an immutable list of all the conflicts in the action table. If
	 *         there are no conflicts, returns an empty list.
	 */
	public List<ActionTableConflict> getConflicts() {
		return Collections.unmodifiableList(this.conflicts);
	}
}
