/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

/**
 * This class represents an accept action in the Action Table.
 *
 * @author clifton.
 *         Created Mar 18, 2007.
 */
public class AcceptAction extends Action {

	@Override
	public String toString() {
		return "accept";
	}

}
