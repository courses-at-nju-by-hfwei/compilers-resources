/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * This class implements a menu item and handler for saving files from an
 * associated text area, prompting for a name.
 * 
 * @author cclifton
 */
public class TextAreaSaveAsMenuItem extends TextAreaMenuItem {

	private static final long serialVersionUID = -6969311203095657798L;

	/**
	 * Creates a menu item labeled Save label File As.
	 * 
	 * @param textArea
	 * @param label
	 */
	public TextAreaSaveAsMenuItem(DirtiableTextArea textArea, String label) {
		super(textArea, "Save ", label, " File As...");
	}

	/**
	 * This is a pass-through constructor used by subclasses that need to
	 * override part of the behavior of this class.
	 * 
	 * @param textArea
	 * @param labelPrefix
	 * @param label
	 * @param labelSuffix
	 */
	protected TextAreaSaveAsMenuItem(DirtiableTextArea textArea, String labelPrefix, String label,
			String labelSuffix) {
		super(textArea, labelPrefix, label, labelSuffix);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.TextAreaMenuItem#doMenuAction()
	 */
	@Override
	protected boolean doMenuAction() {
		// Gets file
		JFileChooser chooser = new JFileChooser(currentDirectory);
		int result = chooser.showSaveDialog(textArea);
		if (result == JFileChooser.CANCEL_OPTION) {
			return false;
		}

		// Opens file
		File theFile = chooser.getSelectedFile();
		currentDirectory = theFile.getParentFile();
		// CONSIDER: track current directory across launches

		return saveTo(theFile);
	}

	/**
	 * Saves the text of the text area to the given file.
	 * 
	 * @param theFile
	 * @return true if the save is successful
	 */
	protected final boolean saveTo(File theFile) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(theFile));
			writer.write(this.textArea.getText());
			writer.close();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(textArea, new String[] {
					"Problem writing file " + theFile.getName(), "File not saved." },
					"Error Writing File", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		this.textArea.setFile(theFile);
		this.textArea.markClean();
		return true;
	}

}
