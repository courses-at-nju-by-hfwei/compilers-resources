/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import java.io.IOException;
import java.util.Stack;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;
import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.Parser;
import edu.roseHulman.cfg.parsing.StringInputScanner;

/**
 * Represents an LR(1) parser, including its table and does the parsing.
 * 
 * @author kelleybt
 */
public class LR1Parser implements Parser {

	private final Grammar grammar;

	private final CanonicalCollection canonicalCollection;

	private final ActionAndGotoTables tables;

	/**
	 * Initializes the LR(1) parser
	 * 
	 * @param g
	 *            The grammar to parse by LR(1)
	 * @param tables
	 */
	public LR1Parser(Grammar g) {
		this.grammar = g;
		this.canonicalCollection = new CanonicalCollection(g, g.firstSets());
		this.tables = new ActionAndGotoTables(g, this.canonicalCollection);
	}

	public ParseTree parse(StringInputScanner scanner) {
		ParseTree parseTree = ParseTree.createParseTree(false, false);

		// TODO 11: Implement LR(1) Parsing Algorithm

		// Note: This method may have multiple exit points.
		return parseTree;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#name(edu.roseHulman.cfg.Parser)
	 */
	public String getName() {
		return "LR(1)";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#grammar(edu.roseHulman.cfg.Parser)
	 */
	public Grammar grammar() {
		return this.grammar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.Parser#isParseable(edu.roseHulman.cfg.Parser)
	 */
	public boolean isParseable() {
		return this.tables.getConflicts().size() == 0;
	}

	/**
	 * @return the canonical collection of LR-1 items for the grammar used to
	 *         instantiate this parser
	 */
	public CanonicalCollection getCanonicalCollection() {
		return this.canonicalCollection;
	}

	/**
	 * @return the action and goto tables for the grammar used to instantiate
	 *         this parser
	 */
	public ActionAndGotoTables getActionAndGotoTables() {
		return this.tables;
	}
}
