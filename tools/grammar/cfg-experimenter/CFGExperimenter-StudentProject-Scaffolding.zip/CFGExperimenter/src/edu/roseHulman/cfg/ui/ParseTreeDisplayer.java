/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.ParseTreeNode;
import edu.roseHulman.cfg.parsing.ParseTreeNodeListIterator;
import edu.roseHulman.cfg.parsing.ParseTree.ParseAction;

/**
 * Iterates a ParseTree to determine how to lay it out in a
 * ParseTreeDisplayPanel. Sets the appropriate sizes for ParseTreeDisplayPanel
 * and renders the ParseTree in it.
 * 
 * @author kelleybt
 * @author cclifton
 */
public class ParseTreeDisplayer {

	/*
	 * Layout Constants
	 */

	/** The number of pixels between nodes that are horizontally spaced. */
	private static final int HORIZONTAL_NODE_PADDING = 6;

	/** The number of pixels between nodes that are vertically spaced. */
	private static final int VERTICAL_NODE_PADDING = 16;

	/**
	 * The number of pixels on either the left or right side of terminal text
	 * and the border.
	 */
	private static final int TERMINAL_TEXT_PADDING = 2;

	/**
	 * The number of pixels on either the top or bottom of any text and its
	 * border.
	 */
	private static final int VERTICAL_TEXT_PADDING = 2;

	/*
	 * Drawing Constants
	 */

	/** The number of steps to fade from FADED_DARKNESS to FINAL_DARKNESS */
	public static final int FADE_IN_STEPS = 10;

	/** The gray shade to draw when the node has not yet been parsed */
	private static final float FADED_DARKNESS = 0.75f;

	/** The gray shade to draw when the node has been completely parsed */
	private static final float FINAL_DARKESS = 0.0f;

	/** The incremental amount of gray to add for each step */
	private static final float DARKNESS_PER_STEP = (FADED_DARKNESS - FINAL_DARKESS)
			/ FADE_IN_STEPS;

	/*
	 * Tree Properties
	 */

	/** The ParseTree displayed by this class */
	private ParseTree tree;

	/** The properties for each node necessary to draw it */
	private Map<ParseTreeNode, NodeDrawingProperties> properties;

	/** The number of ticks in the slider; includes steps for fading-in */
	protected int numberOfSteps;

	/** The step to draw (i.e. the darkness and fade-in settings */
	private int currentStep;

	/*
	 * Tree Size Properties
	 */

	/** The height of text, as determined by the Graphics object */
	private int textHeight;

	/** The maximum width occupied by this ParseTree */
	private int maxWidth;

	/** The maximum height occupied by this ParseTree */
	private int maxHeight;

	/*
	 * Tree Layout Properties
	 */

	/** The amount to add to x to center in the frame */
	private int xOffset;

	/** The amount to add to y to center in the frame */
	private int yOffset;

	/**
	 * Constructs a displayer for the given parse tree.
	 * 
	 * @param tree
	 */
	public ParseTreeDisplayer(ParseTree tree) {
		this.tree = tree;
		this.properties = new HashMap<ParseTreeNode, NodeDrawingProperties>();
		this.numberOfSteps = 0;
		this.currentStep = 0;

		this.textHeight = 0;
		this.maxWidth = 0;
		this.maxHeight = 0;

		this.xOffset = 0;
		this.yOffset = 0;
	}

	/*
	 * Layout Determination Methods
	 */

	/**
	 * Calculates the offsets, if needed, to center the tree in the panel
	 * 
	 * @param panel
	 */
	public void resetOffsets(ParseTreeDisplayPanel panel) {
		Dimension panelSize = panel.getScrollPaneSize();
		this.xOffset = (this.maxWidth > panelSize.width) ? (0)
				: ((panelSize.width - this.maxWidth) / 2);
		this.yOffset = (this.maxHeight > panelSize.height) ? (0)
				: ((panelSize.height - this.maxHeight) / 2);
		panel.setDisplaySize(new Dimension(this.maxWidth, this.maxHeight));
	}

	/**
	 * Calculates the dimensions and coordinates for each node to display the
	 * parse tree.
	 * 
	 * @param panel
	 *            The panel in which the tree will be drawn.
	 */
	public void determineLayout(ParseTreeDisplayPanel panel) {
		Graphics g = panel.getGraphics();
		ParseTreeNode root = tree.getRootNode();

		this.textHeight = g.getFontMetrics().getHeight();
		determineSizeForNode(g, root);

		this.numberOfSteps = 0;
		determineLayoutForRootNode(g, root);
		this.numberOfSteps *= FADE_IN_STEPS;
		resetOffsets(panel);
	}

	/**
	 * The root node is a special case since we don't actually display it. This
	 * method is a special case of the general determineLayoutForNode
	 */
	private void determineLayoutForRootNode(Graphics g, ParseTreeNode root) {
		if (root.getChildCount() > 0) {
			Iterator<ParseTreeNode> iterator = new ParseTreeNodeListIterator(
					root.getChildren(), this.tree.isTopDown());
			NodeDrawingProperties props = propertiesForNode(root);
			int childX = props.left - props.xAdjust;
			while (iterator.hasNext()) {
				ParseTreeNode child = iterator.next();
				NodeDrawingProperties childProps = propertiesForNode(child);
				childX += childProps.left;
				determineLayoutForNode(g, childX, 0, child);
				childX += childProps.right;
			}
		}
	}

	/**
	 * Iterates the tree to determine where to place each node.
	 */
	private void determineLayoutForNode(Graphics g, int x, int y,
			ParseTreeNode node) {
		this.numberOfSteps++;
		NodeDrawingProperties props = propertiesForNode(node);
		props.point = new Point(x, y);
		int totalHeight = this.textHeight + (2 * VERTICAL_TEXT_PADDING)
				+ VERTICAL_NODE_PADDING;
		if (node.getChildCount() > 0) {
			int childX = x - props.xAdjust;
			int childY = y + totalHeight;
			Iterator<ParseTreeNode> iterator = new ParseTreeNodeListIterator(
					node.getChildren(), this.tree.isTopDown());
			while (iterator.hasNext()) {
				ParseTreeNode child = iterator.next();
				NodeDrawingProperties childProps = propertiesForNode(child);
				childX += childProps.left;
				determineLayoutForNode(g, childX, childY, child);
				childX += childProps.right;
			}
		}
		checkWidth(props.point.x + (props.nodeWidth / 2) + 1/*
															 * in case / 2
															 * rounds down
															 */);
		checkHeight(props.point.y + totalHeight);
	}

	/**
	 * Checks the provided width for determining the total width of the tree.
	 * 
	 * @param width
	 */
	private void checkWidth(int width) {
		if (width > this.maxWidth) {
			this.maxWidth = width;
		}
	}

	/**
	 * Checks the provided height for determining the total height of the tree.
	 */
	private void checkHeight(int height) {
		if (height > this.maxHeight) {
			this.maxHeight = height;
		}
	}

	/*
	 * Size Determination Methods
	 */

	/**
	 * Determines the size of a node and how to draw it in regard to its
	 * children.
	 */
	private void determineSizeForNode(Graphics g, ParseTreeNode node) {
		NodeDrawingProperties props = propertiesForNode(node);
		props.textWidth = g.getFontMetrics().stringWidth(
				node.getToken().toString());
		props.nodeWidth = props.textWidth;

		if (node.getToken().isTerminal() || node.getToken().isEmptyString()) {
			// Terminal nodes are easy: the size is the text width + padding and
			// it's centered
			props.nodeWidth += 2 * TERMINAL_TEXT_PADDING;
			props.left = props.nodeWidth / 2 + HORIZONTAL_NODE_PADDING;
			props.right = props.nodeWidth - props.left + 2
					* HORIZONTAL_NODE_PADDING;
		} else if (node.getToken().isNonTerminal()) {
			props.nodeWidth += textHeight; /* diameter for the rounded corners */
			Iterator<ParseTreeNode> iterator = new ParseTreeNodeListIterator(
					node.getChildren(), this.tree.isTopDown());

			int left1 = 0; /* the left property of the first child node */
			int nodeWidth1 = 0; /* The width of the first child node */
			int rightN = 0; /* The right of the last child node */
			int nodeWidthN = 0; /* The width of the last child node */
			int sum = 0; /* The sum of all the children's left and right */

			while (iterator.hasNext()) {
				ParseTreeNode child = iterator.next();
				NodeDrawingProperties childProps = propertiesForNode(child);
				determineSizeForNode(g, child);
				if (left1 == 0) {
					left1 = childProps.left;
				}
				if (nodeWidth1 == 0) {
					nodeWidth1 = childProps.nodeWidth;
				}
				rightN = childProps.left;
				nodeWidthN = childProps.nodeWidth;
				sum += childProps.left + childProps.right;
			}
			/*
			 * The childNodeWith is the sum minus (the far left and the far
			 * right) so this node is centered between the text of its children.
			 * We add half the width of each so that the parent is centered over
			 * the left edge of the right node and the right edge of the right
			 * node instead of the width of their subtrees.
			 */
			int childNodeWidth = sum - left1 - rightN + nodeWidth1 / 2
					+ nodeWidthN / 2;
			props.left = left1 + (childNodeWidth / 2) - (nodeWidth1 / 2);
			props.xAdjust = props.left;
			int minimumCenterOffset = (props.nodeWidth / 2)
					+ HORIZONTAL_NODE_PADDING;
			if (props.left < minimumCenterOffset) {
				props.left = minimumCenterOffset;
			}
			props.right = sum - props.left;
			if (props.right < minimumCenterOffset) {
				props.right = minimumCenterOffset;
			}
		}
	}

	/*
	 * Tree Drawing Methods
	 */

	/**
	 * Draws the parse tree with which this class was constructed with the
	 * specified Graphics object.
	 * 
	 * @param g
	 */
	public void drawTree(Graphics g) {
		try {
			Iterator<ParseTreeNode> iterator = this.tree.getParsedNodeList()
					.iterator();
			if (this.tree.isTopDown()) {
				// Skip drawing the <Goal> Production
				iterator.next();
			}
			/*
			 * Iterate over all the nodes. Start at FADE_IN_STEPS so that
			 * drawingStep is greater than the currentStep, which gives us 0 for
			 * the initial fadeInStep.
			 */
			for (int drawingStep = FADE_IN_STEPS; iterator.hasNext();) {
				ParseTreeNode node = iterator.next();
				if (!this.tree.isTopDown() && !iterator.hasNext()) {
					/*
					 * Don't draw the <Goal> Production, which will be the last
					 * node in a bottom-up tree.
					 */
					break;
				}
				int fadeInSteps = FADE_IN_STEPS
						- (drawingStep - this.currentStep);
				if (drawingStep <= this.currentStep) {
					drawNode(g, FINAL_DARKESS, node);
					drawingStep += FADE_IN_STEPS;
				} else if (fadeInSteps >= 0) {
					drawNode(g, FADED_DARKNESS - DARKNESS_PER_STEP
							* fadeInSteps, node);
					drawingStep += fadeInSteps;
					if (this.tree.isTopDown()) {
						// Skip the children to draw its siblings
						if (node.getToken().isNonTerminal()) {
							skipChildren(iterator, node);
						}
					} else {
						// Stop drawing because we don't know what comes next
						break;
					}
				}
			}
		} catch (Exception e) {
			// Try some error reporting
			System.err.println("Something horrible happened:");
			outputActionTrace();
			throw new RuntimeException("Danger Will Robinson", e);
		}
	}

	private void outputActionTrace() {
		System.err.println("Action Trace:");
		List<ParseAction> actionsList = this.tree.actionsList();
		for (ParseAction action : actionsList) {
			System.err.println(action);
		}
	}

	/**
	 * Skips through all the children of a specified node.
	 * 
	 * @param iterator
	 *            The Iterator to advance
	 * @param node
	 *            The node for which to iterate through the children
	 */
	private void skipChildren(Iterator<ParseTreeNode> iterator,
			ParseTreeNode node) {
		for (int i = 0; i < node.getChildCount(); i++) {
			ParseTreeNode child = iterator.next();
			if (child.getToken().isNonTerminal()) {
				skipChildren(iterator, child);
			}
		}
	}

	/**
	 * Draws a ParseTreeNode using the provided Graphics object
	 * 
	 * @param g
	 *            The Graphics with which to draw the node
	 * @param darkness
	 *            The shade of gray [0..1] to render the node
	 * @param node
	 *            The ParseTreeNode to draw
	 */
	private void drawNode(Graphics g, float darkness, ParseTreeNode node) {
		NodeDrawingProperties props = propertiesForNode(node);
		if (node.getIsError()) {
			/*
			 * Convert the gray to a shade of red by approaching 1. Add the
			 * ((difference between FADED_DARKNESS and 1) times (percentage of
			 * darkness as it approaches 0)) to FADED_DARKNESS so that it
			 * approaches 1 as a percentage of it approaching black.
			 */
			g.setColor(new Color(FADED_DARKNESS + (1f - FADED_DARKNESS)
					* ((FADED_DARKNESS - darkness) / FADED_DARKNESS), darkness,
					darkness));
		} else {
			g.setColor(new Color(darkness, darkness, darkness));
		}

		int x = this.xOffset + props.point.x;
		int y = this.yOffset + props.point.y;
		if (node.getToken().isTerminal()) {
			g.drawRect(x - (props.nodeWidth / 2), y, props.nodeWidth,
					this.textHeight + 2 * VERTICAL_TEXT_PADDING);
		} else if (node.getToken().isNonTerminal()) {
			g.drawRoundRect(x - (props.nodeWidth / 2), y, props.nodeWidth,
					this.textHeight + 2 * VERTICAL_TEXT_PADDING,
					this.textHeight, this.textHeight);
		} else if (node.getToken().isEmptyString()) {
			/*
			 * Diamonds are hard. This is a hacked version to make it look right
			 * for the string "e" which is the only time the diamond is drawn,
			 * and even that is a special case.
			 */
			int nodeHeight = this.textHeight + 2 * VERTICAL_TEXT_PADDING;
			int xPoints[] = { x - props.nodeWidth + 1, x,
					x + props.nodeWidth - 1, x };
			int yPoints[] = { y + (nodeHeight / 2), y, y + (nodeHeight / 2),
					y + nodeHeight };
			g.drawPolygon(xPoints, yPoints, 4);
			y -= 2;
		}
		g.drawString(node.getToken().toString(), x - (props.textWidth / 2), y
				+ this.textHeight);

		if (this.tree.isTopDown()) {
			if (node.getParent() != null
					&& propertiesForNode(node.getParent()).point != null) {
				connectNodes(g, node.getParent(), node);
			}
		} else {
			if (node.getChildCount() != 0) {
				for (ParseTreeNode child : node.getChildren()) {
					connectNodes(g, node, child);
				}
			}
		}
	}

	/**
	 * Draws a line connecting two nodes.
	 * 
	 * @param g
	 *            The Graphics with which to draw.
	 * @param top
	 *            The node with the smaller y coordinate
	 * @param bottom
	 *            The node with the larger y coordinate
	 */
	private void connectNodes(Graphics g, ParseTreeNode top,
			ParseTreeNode bottom) {
		NodeDrawingProperties topProps = propertiesForNode(top);
		NodeDrawingProperties bottomProps = propertiesForNode(bottom);
		g.drawLine(this.xOffset + topProps.point.x, this.yOffset
				+ topProps.point.y + this.textHeight + 2
				* VERTICAL_TEXT_PADDING + 1, xOffset + bottomProps.point.x,
				yOffset + bottomProps.point.y);
	}

	/*
	 * Drawing Step Properties
	 */

	/**
	 * @return the total number of steps, including the fade-in steps, from
	 *         start to finish in drawing the tree.
	 */
	public int getNumberOfSteps() {
		return this.numberOfSteps;
	}

	/**
	 * @return the drawing step at which the tree is currently being drawn.
	 */
	public int getCurrentStep() {
		return this.currentStep;
	}

	/**
	 * Sets the step (including fade-in) at which to draw the tree.
	 * 
	 * @param currentStep
	 */
	public void setCurrentStep(int currentStep) {
		this.currentStep = currentStep;
	}

	/*
	 * ParseTreeNode Drawing Properties
	 */

	/**
	 * @return the drawing properties for the specified node, which are created
	 *         if necessary.
	 */
	private NodeDrawingProperties propertiesForNode(ParseTreeNode node) {
		if (!properties.containsKey(node)) {
			NodeDrawingProperties props = new NodeDrawingProperties();
			properties.put(node, props);
			return props;
		}
		return properties.get(node);
	}

	private class NodeDrawingProperties {

		/*
		 * ParseTreeNode Size Properties
		 */

		/**
		 * The distance from the left-hand side of the ParseTreeNode (including
		 * its children) to the center of the node's text.
		 */
		public int left;

		/**
		 * The distance from the right-hand side of the ParseTreeNode (including
		 * its children) to the center of the node's text.
		 */
		public int right;

		/**
		 * The value subtracted from the X provided (which is the center point)
		 * to get the left-hand side X coordinate.
		 */
		public int xAdjust;

		/**
		 * The width of the node's text.
		 */
		public int textWidth;

		/**
		 * The total width of the node, including all padding.
		 */
		public int nodeWidth;

		/*
		 * ParseTreeNode Layout Properties
		 */

		/**
		 * The point at which to draw the node. X is the center point and Y is
		 * the top of the node.
		 */
		public Point point;
	}

	/**
	 * @return a string listing all the actions taken to arrive at the parse
	 *         tree displayed by this
	 */
	public String getActionTraceText() {
		StringBuilder sb = new StringBuilder();
		for (ParseAction action : this.tree.actionsList()) {
			String actionString = action.toString();
			sb.append(actionString);
			sb.append("\n");
		}
		return sb.toString();
	}
}
