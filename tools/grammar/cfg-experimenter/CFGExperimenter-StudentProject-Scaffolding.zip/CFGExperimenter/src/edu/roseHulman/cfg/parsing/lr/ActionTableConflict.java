/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Token;

/**
 * This class represents a table entry conflict for an LR(1) action table
 * 
 * @author kelleybt
 */
public class ActionTableConflict {

	private Pair<Integer, Token> stateToken;

	private Action action1;

	private Action action2;

	/**
	 * Constructs an immutable class representing an action table conflict for
	 * and LR(1) parse table.
	 * 
	 * @param stateToken The state and token combination with conflicting actions
	 * @param action1 The action in the LR(1) action table
	 * @param action2 The action that was to be added to the LR(1) action table
	 */
	public ActionTableConflict(Pair<Integer, Token> stateToken, Action action1, Action action2) {
		this.stateToken = stateToken;
		this.action1 = (action1 instanceof ShiftAction) ? (action1) : (action2);
		this.action2 = (this.action1 == action1) ? (action2) : (action1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object anObject) {
		if (anObject instanceof ActionTableConflict) {
			ActionTableConflict other = (ActionTableConflict)anObject;
			return this.stateToken.equals(other.stateToken) &&
				((this.action1.equals(other.action1) &&
				  this.action2.equals(other.action2)) ||
				 (this.action1.equals(other.action2) &&
				  this.action2.equals(other.action1)));
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString(java.lang.Object)
	 */
	@Override
	public String toString() {
		return "'" + this.action1.toString() + "'-'" + this.action2.toString() +
			"' conflict for '" + this.stateToken + "'";
	}
}
