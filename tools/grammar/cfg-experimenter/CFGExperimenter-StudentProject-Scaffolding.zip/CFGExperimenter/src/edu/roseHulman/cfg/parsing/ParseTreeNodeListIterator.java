/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import java.util.Iterator;
import java.util.List;



public class ParseTreeNodeListIterator implements Iterator<ParseTreeNode> {

	private final List<ParseTreeNode> children;
	private final boolean isTopDown;
	private int index;

	/**
	 * Constructs an iterator over the given list of nodes, adjusting the
	 * direction of iteration based on whether the nodes were part of a top-down
	 * parse.
	 * 
	 * @param children
	 * @param isTopDown
	 */
	public ParseTreeNodeListIterator(final List<ParseTreeNode> children,
			final boolean isTopDown) {
		this.children = children;
		this.isTopDown = isTopDown;
		this.index = (isTopDown) ? (0) : (children.size() - 1);
	}

	public boolean hasNext() {
		return (this.isTopDown) ? (this.index < this.children.size())
				: (this.index >= 0);
	}

	public ParseTreeNode next() {
		if (this.index < 0 || this.index >= this.children.size()) {
			return null;
		}
		ParseTreeNode node = this.children.get(this.index);
		this.index += (this.isTopDown) ? (1) : (-1);
		return node;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}
}