/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import java.util.ArrayList;
import java.util.List;

import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * This class represents an LR(1) item.
 * 
 * @author cclifton
 */
public class LR1Item implements Comparable<LR1Item> {

	/**
	 * This production upon with this item is based.
	 */
	final Production production;

	private final int position;

	/**
	 * The lookahead token for this item.
	 */
	final Token lookahead;

	/**
	 * Constructs a new LR(1) item for the given data.
	 * 
	 * @param production
	 * @param position
	 *            the token in the right-hand side of production <strong>before</strong>
	 *            which the position marker should appear
	 * @param lookahead
	 */
	public LR1Item(Production production, int position, Token lookahead) {
		this.production = production;
		// Skip over lone epsilons on the right hand side
		if (production.goesToEpsilon()) {
			this.position = position + 1;
		} else {
			this.position = position;
		}
		this.lookahead = lookahead;
	}

	/**
	 * @return the token following position in this item's production, or null
	 *         if position is at the right end
	 */
	public Token getNextToken() {
		List<Token> rhs = production.rightHandSide();
		if (position >= rhs.size()) {
			return null;
		}
		return rhs.get(position);
	}

	/**
	 * @return the sequence of tokens following position in this items production
	 */
	public List<Token> getRest() {
		List<Token> rhs = production.rightHandSide();
		return new ArrayList<Token>(rhs.subList(position, rhs.size()));
	}

	/**
	 * @return a new LR(1) item with the position advanced
	 */
	public LR1Item advance() {
		return new LR1Item(this.production, this.position + 1, this.lookahead);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer result = new StringBuffer();
		result.append("[");
		result.append(this.production.leftHandSide());
		result.append(" ::=");
		final List<Token> rhs = this.production.rightHandSide();
		for (int i = 0; i < rhs.size(); i++) {
			if (i == this.position) {
				result.append(" *");
			}
			result.append(' ');
			result.append(rhs.get(i));
		}
		if (this.position >= rhs.size()) {
			result.append(" *");
		}
		result.append(", ");
		result.append(this.lookahead);
		result.append("]");
		return result.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object other) {
		LR1Item otherLR1Item = (LR1Item) other;
		return this.production.equals(otherLR1Item.production) &&
		this.position == otherLR1Item.position &&
		this.lookahead.equals(otherLR1Item.lookahead);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return this.production.hashCode() * 169 + this.position * 13 + this.lookahead.hashCode();
	}

	public int compareTo(LR1Item o) {
		int comparison = this.production.compareTo(o.production);
		if (comparison != 0) {
			return comparison;
		}
		comparison = this.position - o.position;
		if (comparison != 0) {
			return comparison;
		}
		return this.lookahead.compareTo(o.lookahead);
	}
	
}
