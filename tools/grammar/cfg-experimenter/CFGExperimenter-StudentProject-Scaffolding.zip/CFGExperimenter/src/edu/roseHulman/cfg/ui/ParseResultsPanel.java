/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * This panel provides support for drawing and animating parse trees. It
 * includes the actual tree display, plus the slider and buttons for moving
 * through the animation.
 * 
 * @author cclifton
 * @author kelleybt
 */
public class ParseResultsPanel extends JPanel implements Resetable,
		ActionListener, ChangeListener {

	private static final long serialVersionUID = 1L;

	private static final int DURATION_PER_NODE = 1000;

	private static final Dimension PREFERRED_SCROLL_PANE_SIZE = new Dimension(
			1200, 1200);

	private ParseTreeDisplayPanel treeView;

	private JButton reset;

	private JButton stop;

	private JButton play;

	private JSlider slider;

	private volatile boolean isUpdating;

	private boolean shouldAbort;

	private final JTextArea parseActionTextArea;

	/**
	 * Constructs a new instance of ParseTreePanel ready to display nodes found
	 * from any parser.
	 */
	public ParseResultsPanel() {
		this.isUpdating = true;
		setLayout(new BorderLayout(10, 10));

		this.treeView = new ParseTreeDisplayPanel(this);
		this.treeView.setAlignmentX(LEFT_ALIGNMENT);
		this.treeView.setAlignmentY(TOP_ALIGNMENT);
		this.treeView.setBorder(BorderFactory.createTitledBorder("Parse Tree"));
		JScrollPane treeScrollPane = new JScrollPane(treeView);
		treeScrollPane.getHorizontalScrollBar().setUnitIncrement(20);
		treeScrollPane.getVerticalScrollBar().setUnitIncrement(20);
		this.treeView.setScrollPane(treeScrollPane);
		// add(scrollPane);

		JPanel parseActionPanel = new JPanel();
		parseActionPanel.setBorder(BorderFactory
				.createTitledBorder("Parse Actions"));
		parseActionPanel.setLayout(new GridLayout(1, 1));
		this.parseActionTextArea = new JTextArea();
		this.parseActionTextArea.setAlignmentX(LEFT_ALIGNMENT);
		this.parseActionTextArea.setAlignmentY(TOP_ALIGNMENT);
		JScrollPane parseActionScroller = new JScrollPane(this.parseActionTextArea,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		parseActionPanel.add(parseActionScroller);

		parseActionScroller.setPreferredSize(PREFERRED_SCROLL_PANE_SIZE);

		JSplitPane splitter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				treeScrollPane, parseActionPanel);
		splitter.setResizeWeight(0.5);
		splitter.setAlignmentX(LEFT_ALIGNMENT);
		splitter.setAlignmentY(TOP_ALIGNMENT);
		splitter.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		add(splitter);

		JPanel sliderAndButtonsPanel = new JPanel();
		sliderAndButtonsPanel.setLayout(new BoxLayout(sliderAndButtonsPanel,
				BoxLayout.PAGE_AXIS));
		this.slider = new JSlider();
		this.slider.setSnapToTicks(true);
		this.slider.addChangeListener(this);
		sliderAndButtonsPanel.add(this.slider);

		JPanel controls = new JPanel();
		controls.setLayout(new BoxLayout(controls, BoxLayout.LINE_AXIS));

		reset = new JButton("Reset");
		controls.add(reset);
		reset.addActionListener(this);

		stop = new JButton("Stop");
		controls.add(stop);
		stop.addActionListener(this);

		play = new JButton("Play");
		controls.add(play);
		play.addActionListener(this);

		sliderAndButtonsPanel.add(controls);
		this.add(sliderAndButtonsPanel, BorderLayout.PAGE_END);

		this.shouldAbort = false;
		this.isUpdating = false;
	}

	/**
	 * Associates this panel with the tree displayer so that the animation
	 * controls can adjust the tree display.
	 * 
	 * @param displayer
	 */
	public void setParseTreeDisplayer(ParseTreeDisplayer displayer) {
		this.treeView.setParseTreeDisplayer(displayer);
		synchronized (this) {
			this.isUpdating = true;
		}
		this.slider.setValue(0);
		this.slider.setMaximum(displayer.getNumberOfSteps());
		synchronized (this) {
			this.isUpdating = false;
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == reset) {
			this.slider.setValue(0);
		} else if (e.getSource() == stop) {
			synchronized (this) {
				this.shouldAbort = true;
			}
		} else if (e.getSource() == play) {
			if (slider.getValue() == slider.getMaximum()) {
				slider.setValue(0);
			}
			synchronized (this) {
				this.shouldAbort = false;
			}
			final ParseResultsPanel syncRoot = this;
			(new Thread() {
				public void run() {
					boolean shouldQuitLoop = false;
					while (slider.getValue() < slider.getMaximum()
							&& !shouldQuitLoop) {
						slider.setValue(slider.getValue() + 1);
						try {
							Thread.sleep(ParseResultsPanel.DURATION_PER_NODE
									/ ParseTreeDisplayer.FADE_IN_STEPS);
						} catch (InterruptedException e) {
						}
						synchronized (syncRoot) {
							shouldQuitLoop = shouldAbort;
						}
					}
				}
			}).start();
		}
	}

	public void stateChanged(ChangeEvent e) {
		boolean updating;
		synchronized (this) {
			updating = this.isUpdating;
		}
		if (!updating && this.treeView.getParseTreeDisplayer() != null) {
			this.treeView.getParseTreeDisplayer().setCurrentStep(
					this.slider.getValue());
			this.treeView.repaint();
		}
	}

	public void reset() {
		treeView.setParseTreeDisplayer(null);
	}

	/**
	 * Sets the text to be displayed in the parse action panel.
	 * 
	 * @param actionTraceText
	 */
	public void setParseActionText(String actionTraceText) {
		this.parseActionTextArea.setText(actionTraceText);
	}
}
