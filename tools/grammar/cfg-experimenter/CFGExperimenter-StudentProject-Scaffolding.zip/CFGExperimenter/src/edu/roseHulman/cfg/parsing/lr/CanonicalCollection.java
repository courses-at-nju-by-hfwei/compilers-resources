/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import edu.roseHulman.cfg.EOFToken;
import edu.roseHulman.cfg.FirstSets;
import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * This immutable class represents a canonical collection of sets of LR(1) items
 * for some grammar, along with the transition function over the collection.
 * 
 * @author cclifton
 */
public class CanonicalCollection {
	/**
	 * A list of sets of LR(1) items.
	 */
	private final List<Set<LR1Item>> cc;

	/**
	 * A map from <{LR(1) items}, Token> --> {LR(1) items} where the sets of
	 * LR(1) items are specified by indexes into <code>cc</code>.
	 */
	private final Map<Pair<Integer, Token>, Integer> transitionFunction;

	/**
	 * Constructs a new canonical collection of LR(1) items for the given
	 * grammar with the given firstSets.
	 * 
	 * @param grammar
	 * @param firstSets
	 */
	public CanonicalCollection(Grammar grammar, FirstSets firstSets) {
		super();
		List<Set<LR1Item>> cc = new ArrayList<Set<LR1Item>>();
		/*
		 * Uses a tree map to ensure a consistent order. Slower but easier to
		 * test.
		 */
		TreeMap<Pair<Integer, Token>, Integer> transitionFunction = new TreeMap<Pair<Integer, Token>, Integer>();

		// TODO 09: Construct Canonical Collection (calling closure and gotoSet
		// as needed) by adding information to cc and transitionFunction.

		// ---------------------------------------------------------------------

		/*
		 * Stores immutable versions of the canonical collection and transition
		 * function. This helps us avoid introducing bugs later by mutating
		 * things we shouldn't.
		 */
		this.cc = Collections.unmodifiableList(cc);
		this.transitionFunction = Collections
				.unmodifiableSortedMap(transitionFunction);
	}

	/**
	 * Returns the set of LR(1) items reachable by an x-transition from the
	 * given set. This is non-private to facilitate unit testing.
	 * 
	 * @param s
	 * @param x
	 * @param grammar
	 * @param firstSets
	 * @return the set of LR(1) items reachable by an x-transition from the
	 *         given set
	 */
	static Set<LR1Item> gotoSet(Set<LR1Item> s, Token x, Grammar grammar,
			FirstSets firstSets) {
		// Uses a tree set so the LR1Items are sorted. This is less efficient
		// but facilitates comparison.
		Set<LR1Item> moved = new TreeSet<LR1Item>();

		// TODO 08: Implement goto set algorithm (calling closure as needed)
		return null;
	}

	/**
	 * Calculates the closure of the given set of LR(1) items, mutating s. This
	 * is non-private to facilitate unit testing.
	 * 
	 * @param s
	 * @param grammar
	 * @param firstSets
	 * @return the mutated s
	 */
	static Set<LR1Item> closure(Set<LR1Item> s, Grammar grammar,
			FirstSets firstSets) {
		// TODO 07: Implement Closure Algorithm 
		return null;
	}

	/**
	 * @return an immutable representation of the CC sets
	 */
	public List<Set<LR1Item>> getSets() {
		return Collections.unmodifiableList(this.cc);
	}

	/**
	 * @return an immutable representation of the transition function
	 */
	public Map<Pair<Integer, Token>, Integer> getTransitionFunction() {
		return Collections.unmodifiableMap(this.transitionFunction);
	}

	/**
	 * Returns the next state, as an index into the list of sets of LR1 items,
	 * if the given token were recognized next on the input; or returns null if
	 * no valid transition is found. This function is equivalent to the usual
	 * goto(currentState,nextToken) function after this object is initialized.
	 * 
	 * @param currentState
	 * @param nextToken
	 * @return the next state
	 */
	public Integer nextState(int currentState, Token nextToken) {
		return this.transitionFunction.get(new Pair<Integer, Token>(
				currentState, nextToken));
	}

	@Override
	public String toString() {
		return "CC Sets: " + this.cc + " Transition function: "
				+ this.transitionFunction;
	}

}
