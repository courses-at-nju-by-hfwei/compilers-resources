/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import edu.roseHulman.cfg.Production;

/**
 * This immutable class represents a reduce action in the Action Table.
 *
 * @author clifton.
 *         Created Mar 18, 2007.
 * @action kelleybt
 */
public class ReduceAction extends Action {

	private final Production production;

	/**
	 * Constructs a reduce action for the given production.
	 *
	 * @param production
	 */
	public ReduceAction(Production production) {
		this.production = production;
	}

	@Override
	public String toString() {
		return "reduce " + this.production;
	}

	/**
	 * @return the production by which this action reduces
	 */
	public Production getProduction() {
		return this.production;
	}
}
