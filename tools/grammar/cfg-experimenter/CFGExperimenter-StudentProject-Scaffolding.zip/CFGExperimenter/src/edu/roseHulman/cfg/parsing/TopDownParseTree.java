/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing;

import java.util.ArrayList;
import java.util.List;

import edu.roseHulman.cfg.EOFToken;
import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.NonTerminalToken;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;

/**
 * The algorithms used to realize the structure/hierarchical of tokens returned
 * by an LL(1) parser.
 * 
 * @author kelleybt
 */
class TopDownParseTree extends ParseTree {

	/**
	 * A list of productions in the order they were to be parsed. Used mainly to
	 * select a ParseTreeNode to which the next parsed token should be added.
	 */
	private List<ParseTreeNode> recentProductions;

	/**
	 * Constructs a empty, top-down parse tree.
	 * 
	 * @param isLeftToRight whether the parse tree adds nodes from left to right
	 */
	TopDownParseTree(boolean isLeftToRight) {
		super(true, isLeftToRight);
		this.recentProductions = new ArrayList<ParseTreeNode>();
	}

	/*
	 * Parsing
	 */

	@Override
	public void parsedToken(final Token token) {
		this.actionTrace.add(new ParseAction("parsedToken",token));
		addParsedTokenToNode(token, mostRecentNotFullyParsedNode());
	}

	/**
	 * Creates a new ParseTreeNode for the specified token and inserts it into
	 * the appropriate data structures.
	 * 
	 * @param token
	 *            The Token from the grammar
	 * @param parent
	 *            The ParseTreeNode whose NonTerminalSymbol is used to derive
	 *            this node. May be <code>null</code>.
	 * @return The ParseTreeNode that was added to the parsed node list
	 */
	private ParseTreeNode addParsedTokenToNode(Token token, ParseTreeNode parent) {
		ParseTreeNode node = new ParseTreeNode(parent, token);
		addParseTreeNode(node);
		return node;
	}

	/*
	 * LL(1) Parsing Methods
	 */

	@Override
	public void willParseProduction(final Production prod) {
		this.actionTrace.add(new ParseAction("willParseProduction",prod));
		ParseTreeNode node = new ParseTreeNode(mostRecentNotFullyParsedNode(),
				prod);
		this.recentProductions.add(node);
		addParseTreeNode(node);
		/*
		 * e is a special case. If the production goes to epsilon, we just add
		 * it to the tree here so the parser does not have to handle this case.
		 */
		if (prod.goesToEpsilon()) {
			parsedToken(prod.rightHandSide().get(0));
		}
	}

	@Override
	public void errorExpandingTopOfStack(final Token token) {
		this.actionTrace.add(new ParseAction("errorExpandingTopOfStack",token));
		ParseTreeNode node = mostRecentNotFullyParsedNode();
		if (node == null) {
			/*
			 * If there's an error right off the bat, handling it in the UI is a
			 * mess. Since we don't draw the <Goal> production, we have to
			 * create a dummy node to act as the <Goal> production. We can't use
			 * the regular Token constructor because it must have children.
			 * After we create the dummy node, we add the <Goal> production to
			 * it, so it is displayed in red to the user.
			 */
			final List<Token> childNode = new ArrayList<Token>(1);
			childNode.add(new NonTerminalToken("Error"));
			Production dummyGoalProduction = new Production() {

				@Override
				public NonTerminalToken leftHandSide() {
					return Grammar.GOAL_SYMBOL;
				}

				@Override
				public List<Token> rightHandSide() {
					return childNode;
				}

				@Override
				public boolean goesToEpsilon() {
					return false;
				}

				@Override
				public boolean isGoalProduction() {
					return true;
				}

				@Override
				public int compareTo(Production o) {
					throw new IllegalStateException(
							"error productions are incomparable");
				}

				@Override
				public Grammar grammar() {
					return null;
				}

				@Override
				public int productionNumber() {
					return -1;
				}
				
				@Override
				public String toString() {
					return "dummy stack top invalid production";
				}
			};
			node = new ParseTreeNode(null, dummyGoalProduction);
			node.setIsError(true);
			this.recentProductions.add(node);
			addParseTreeNode(node);
		}
		node = addParsedTokenToNode(token, node);
		node.setIsError(true);
		finishConstruction();
	}

	@Override
	public void errorLookingForTopOfStack(final Token token) {
		this.actionTrace.add(new ParseAction("errorLookingForTopOfStack", token));
		ParseTreeNode node = mostRecentNotFullyParsedNode();
		if (node == null) {
			this.recentProductions.get(this.recentProductions.size() - 1)
					.setIsError(true);
		} else {
			addParsedTokenToNode(token, node).setIsError(true);
		}
		finishConstruction();
	}

	/*
	 * LR(1) Parsing Methods
	 */

	@Override
	public void parsedProduction(Production prod) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reportSyntaxError(Token token) {
		throw new UnsupportedOperationException();
	}

	/*
	 * Common Methods
	 */

	@Override
	public ParseTreeNode getRootNode() {
		if (getParsedNodeList().size() > 0) {
			return getParsedNodeList().get(0);
		}
		return null;
	}

	@Override
	protected void finish() {
		if (getParsedNodeList().size() == 0) {
			addParsedTokenToNode(EOFToken.getInstance(), null);
		}
	}

	/**
	 * @return The most recent production from willParseProduction() that does
	 *         not have a child for every token which it derives.
	 */
	private ParseTreeNode mostRecentNotFullyParsedNode() {
		for (int i = recentProductions.size() - 1; i >= 0; i--) {
			if (!recentProductions.get(i).isFullyParsed()) {
				return recentProductions.get(i);
			}
		}
		return null;
	}
}
