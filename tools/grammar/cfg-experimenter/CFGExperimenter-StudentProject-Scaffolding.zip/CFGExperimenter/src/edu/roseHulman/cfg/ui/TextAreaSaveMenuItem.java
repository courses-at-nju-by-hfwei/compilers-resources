/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.ui;

import java.io.File;

import javax.swing.JOptionPane;

/**
 * This class implements a menu item and handler for saving files from an
 * associated text area.
 * 
 * @author cclifton
 */
public class TextAreaSaveMenuItem extends TextAreaSaveAsMenuItem {

	private static final long serialVersionUID = -6969311203095657798L;

	/**
	 * Creates a menu item labeled Save label File.
	 * 
	 * @param textArea
	 * @param label
	 */
	public TextAreaSaveMenuItem(DirtiableTextArea textArea, String label) {
		super(textArea, "Save ", label, " File");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.roseHulman.cfg.TextAreaMenuItem#doMenuAction()
	 */
	@Override
	protected boolean doMenuAction() {
		if (!this.textArea.isDirty()) {
			return true;
		}
		File theFile = this.textArea.getFile();
		if (theFile == null) {
			return super.doMenuAction();
		}
		return saveTo(theFile);
	}

	/**
	 * Checks for dirty status and prompts to save, ignore, or cancel.
	 * 
	 * @return true if it is OK to proceed with closing
	 */
	public boolean willClose() {
		if (!this.textArea.isDirty()) {
			return true;
		}
		int result = JOptionPane.showConfirmDialog(this.textArea, new String[] {
				"The " + this.label + " has unsaved changes.", "Save changes before closing?" },
				"Unsaved Changes", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
		if (result == JOptionPane.CANCEL_OPTION) {
			return false;
		} else if (result == JOptionPane.NO_OPTION) {
			return true;
		}
		File theFile = this.textArea.getFile();
		if (theFile == null) {
			return super.doMenuAction();
		}
		return saveTo(theFile);
	}

}
