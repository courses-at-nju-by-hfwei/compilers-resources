/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

/**
 * This class represents an action stored in the action table.
 * 
 * @author clifton. Created Mar 18, 2007.
 * @author kelleybt
 */
public class Action {
	// CONSIDER: perhaps this should be an interface, waiting to see what code is needed
	// to implement bottom-up parsing

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object anObject) {
		return toString().equals(anObject.toString());
	}
}
