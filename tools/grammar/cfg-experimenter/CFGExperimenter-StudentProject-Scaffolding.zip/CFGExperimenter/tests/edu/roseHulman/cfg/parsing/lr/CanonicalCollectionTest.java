/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

import edu.roseHulman.cfg.EOFToken;
import edu.roseHulman.cfg.FirstSets;
import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Grammars;
import edu.roseHulman.cfg.Token;
import edu.roseHulman.cfg.CFGParser.SyntaxError;

/**
 * Tests canonical collections of LR-1 items.
 * 
 * @author cclifton
 * 
 */
public class CanonicalCollectionTest {
	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_NothingButNothing() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Start>, <<EOF>>]",
				"[<Start> ::= e *, <<EOF>>]" };
		checkClosure(expected, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_SheepNoise() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <S>, <<EOF>>]",
				"[<S> ::= * baa <S>, <<EOF>>]", "[<S> ::= e *, <<EOF>>]" };
		checkClosure(expected, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_Expression1() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Expr>, <<EOF>>]",
				"[<Expr> ::= * <Term> <Expr'>, <<EOF>>]",
				"[<Term> ::= * num, +]", "[<Term> ::= * num, -]",
				"[<Term> ::= * num, <<EOF>>]" };
		checkClosure(expected, Grammars.Expression1);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_Quiz7() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Term>, <<EOF>>]",
				"[<Term> ::= * <Factor> <Term'>, <<EOF>>]",
				"[<Factor> ::= * num, *]", "[<Factor> ::= * num, /]",
				"[<Factor> ::= * num, <<EOF>>]" };
		checkClosure(expected, Grammars.Quiz7);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_Quiz15() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * { <Stmt> }, <<EOF>>]",
				"[<Stmt> ::= * null;, <<EOF>>]" };
		checkClosure(expected, Grammars.Quiz15);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_Parens() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Parens>, <<EOF>>]",
				"[<Parens> ::= * ( <Parens> ), (]",
				"[<Parens> ::= * ( <Parens> ), x]",
				"[<Parens> ::= * ( <Parens> ), <<EOF>>]",
				"[<Parens> ::= * <Parens> <Parens>, (]",
				"[<Parens> ::= * <Parens> <Parens>, x]",
				"[<Parens> ::= * <Parens> <Parens>, <<EOF>>]",
				"[<Parens> ::= * x, (]", "[<Parens> ::= * x, x]",
				"[<Parens> ::= * x, <<EOF>>]" };
		checkClosure(expected, Grammars.Parens);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_IfThenElse1() throws IOException, SyntaxError {
		String[] expected = { "[<Goal> ::= * <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if expr then <Stmt> else <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if expr then <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * assign, <<EOF>>]" };
		checkClosure(expected, Grammars.IfThenElse1);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_IfThenElse1withoutAmbig() throws IOException,
			SyntaxError {
		String[] expected = { "[<Goal> ::= * <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if expr then <WithElse> else <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if expr then <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * assn, <<EOF>>]" };
		checkClosure(expected, Grammars.IfThenElse1withoutAmbig);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_IfThenElse1leftFactored() throws IOException,
			SyntaxError {
		String[] expected = { "[<Goal> ::= * <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if expr then <IfRest>, <<EOF>>]",
				"[<Stmt> ::= * assn, <<EOF>>]" };
		checkClosure(expected, Grammars.IfThenElse1leftFactored);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testClosure_IfThenElse2() throws IOException, SyntaxError {
		String[] expected = {
				"[<Goal> ::= * <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if <Expr> then <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * if <Expr> then <WithElse> else <Stmt>, <<EOF>>]",
				"[<Stmt> ::= * <Assn>, <<EOF>>]",
				"[<Assn> ::= * assn, <<EOF>>]",
				"[<Assn> ::= * lcb <Stmt> rcb, <<EOF>>]" };
		checkClosure(expected, Grammars.IfThenElse2);
	}

	private void checkClosure(String[] expectedCC0, String inputGrammar)
			throws IOException, SyntaxError {
		String expected = Arrays.toString(expectedCC0);
		Grammar g = Grammars.getGrammarFrom(inputGrammar);
		g.finalizeGrammar();
		FirstSets fs = g.firstSets();
		Set<LR1Item> cc0 = new TreeSet<LR1Item>();
		cc0.add(new LR1Item(g.getGoalProduction(), 0, EOFToken.getInstance()));
		Set<LR1Item> returnedSet = CanonicalCollection.closure(cc0, g, fs);
		assertEquals(expected, cc0.toString());
		assertSame("set returned by closure() must be the same set passed in",
				cc0, returnedSet);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_NothingButNothing() throws IOException, SyntaxError {
		// Nothing to do here
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_SheepNoise() throws IOException, SyntaxError {
		String[] expected = { "[<S> ::= * baa <S>, <<EOF>>]",
				"[<S> ::= baa * <S>, <<EOF>>]", "[<S> ::= e *, <<EOF>>]" };
		checkGoto(expected, "baa", Grammars.SheepNoise);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_Expression1_1() throws IOException, SyntaxError {
		String[] expected = { "[<Term> ::= num *, +]", "[<Term> ::= num *, -]",
				"[<Term> ::= num *, <<EOF>>]" };
		checkGoto(expected, "num", Grammars.Expression1);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_Quiz7() throws IOException, SyntaxError {
		String[] expected = { "[<Factor> ::= num *, *]",
				"[<Factor> ::= num *, /]", "[<Factor> ::= num *, <<EOF>>]" };
		checkGoto(expected, "num", Grammars.Quiz7);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_Quiz15() throws IOException, SyntaxError {
		String[] expected = { "[<Stmt> ::= * { <Stmt> }, }]",
				"[<Stmt> ::= { * <Stmt> }, <<EOF>>]", "[<Stmt> ::= * null;, }]" };
		checkGoto(expected, "{", Grammars.Quiz15);
		expected = new String[] { "[<Stmt> ::= null; *, <<EOF>>]" };
		checkGoto(expected, "null;", Grammars.Quiz15);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_Parens() throws IOException, SyntaxError {
		String[] expected = { "[<Parens> ::= * ( <Parens> ), (]",
				"[<Parens> ::= * ( <Parens> ), )]",
				"[<Parens> ::= * ( <Parens> ), x]",
				"[<Parens> ::= ( * <Parens> ), (]",
				"[<Parens> ::= ( * <Parens> ), x]",
				"[<Parens> ::= ( * <Parens> ), <<EOF>>]",
				"[<Parens> ::= * <Parens> <Parens>, (]",
				"[<Parens> ::= * <Parens> <Parens>, )]",
				"[<Parens> ::= * <Parens> <Parens>, x]",
				"[<Parens> ::= * x, (]", "[<Parens> ::= * x, )]",
				"[<Parens> ::= * x, x]" };
		checkGoto(expected, "(", Grammars.Parens);
		expected = new String[] { "[<Parens> ::= x *, (]",
				"[<Parens> ::= x *, x]", "[<Parens> ::= x *, <<EOF>>]" };
		checkGoto(expected, "x", Grammars.Parens);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_IfThenElse1() throws IOException, SyntaxError {
		String[] expected = {
				"[<Stmt> ::= if * expr then <Stmt> else <Stmt>, <<EOF>>]",
				"[<Stmt> ::= if * expr then <Stmt>, <<EOF>>]" };
		checkGoto(expected, "if", Grammars.IfThenElse1);
		expected = new String[] { "[<Stmt> ::= assign *, <<EOF>>]" };
		checkGoto(expected, "assign", Grammars.IfThenElse1);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_IfThenElse1withoutAmbig() throws IOException,
			SyntaxError {
		String[] expected = {
				"[<Stmt> ::= if * expr then <WithElse> else <Stmt>, <<EOF>>]",
				"[<Stmt> ::= if * expr then <Stmt>, <<EOF>>]" };
		checkGoto(expected, "if", Grammars.IfThenElse1withoutAmbig);
		expected = new String[] { "[<Stmt> ::= assn *, <<EOF>>]" };
		checkGoto(expected, "assn", Grammars.IfThenElse1withoutAmbig);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_IfThenElse1leftFactored() throws IOException,
			SyntaxError {
		String[] expected = { "[<Stmt> ::= if * expr then <IfRest>, <<EOF>>]" };
		checkGoto(expected, "if", Grammars.IfThenElse1leftFactored);
		expected = new String[] { "[<Stmt> ::= assn *, <<EOF>>]" };
		checkGoto(expected, "assn", Grammars.IfThenElse1leftFactored);
	}

	/**
	 * Test.
	 * 
	 * @throws IOException
	 * @throws SyntaxError
	 */
	@Test
	public void testGoto_IfThenElse2() throws IOException, SyntaxError {
		String[] expected = {
				"[<Stmt> ::= if * <Expr> then <Stmt>, <<EOF>>]",
				"[<Stmt> ::= if * <Expr> then <WithElse> else <Stmt>, <<EOF>>]",
				"[<Expr> ::= * true, then]", "[<Expr> ::= * false, then]" };
		checkGoto(expected, "if", Grammars.IfThenElse2);
		expected = new String[] { "[<Assn> ::= assn *, <<EOF>>]" };
		checkGoto(expected, "assn", Grammars.IfThenElse2);
		expected = new String[] { "[<Stmt> ::= * if <Expr> then <Stmt>, rcb]",
				"[<Stmt> ::= * if <Expr> then <WithElse> else <Stmt>, rcb]",
				"[<Stmt> ::= * <Assn>, rcb]", "[<Assn> ::= * assn, rcb]",
				"[<Assn> ::= * lcb <Stmt> rcb, rcb]",
				"[<Assn> ::= lcb * <Stmt> rcb, <<EOF>>]" };
		checkGoto(expected, "lcb", Grammars.IfThenElse2);
	}

	private void checkGoto(String[] gotoSet, String tokenString,
			String inputGrammar) throws IOException, SyntaxError {
		String expected = Arrays.toString(gotoSet);
		Grammar g = Grammars.getGrammarFrom(inputGrammar);
		g.finalizeGrammar();
		FirstSets fs = g.firstSets();
		Set<LR1Item> cc0 = new TreeSet<LR1Item>();
		cc0.add(new LR1Item(g.getGoalProduction(), 0, EOFToken.getInstance()));
		CanonicalCollection.closure(cc0, g, fs);

		Token token = Grammars.tokenFromString(tokenString);
		Set<LR1Item> result = CanonicalCollection.gotoSet(cc0, token, g, fs);
		assertEquals(expected, result.toString());
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingCanonicalCollection() {
		String[][] expectedCC = {
				{ "[<Goal> ::= * <Start>, <<EOF>>]",
						"[<Start> ::= e *, <<EOF>>]" },
				{ "[<Goal> ::= <Start> *, <<EOF>>]" } };
		String[] expectedTF = { "<0,<Start>>=1" };
		checkCanonicalCollection(expectedCC, expectedTF,
				Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseCanonicalCollection() {
		String[][] expectedCC = {
				{ "[<Goal> ::= * <S>, <<EOF>>]",
						"[<S> ::= * baa <S>, <<EOF>>]",
						"[<S> ::= e *, <<EOF>>]" },
				{ "[<Goal> ::= <S> *, <<EOF>>]" },
				{ "[<S> ::= * baa <S>, <<EOF>>]",
						"[<S> ::= baa * <S>, <<EOF>>]",
						"[<S> ::= e *, <<EOF>>]" },
				{ "[<S> ::= baa <S> *, <<EOF>>]" } };
		String[] expectedTF = { "<0,<S>>=1", "<0,baa>=2", "<2,<S>>=3",
				"<2,baa>=2" };
		checkCanonicalCollection(expectedCC, expectedTF, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1CanonicalCollection() {
		String[][] expectedCC = {
				{ "[<Goal> ::= * <Expr>, <<EOF>>]",
						"[<Expr> ::= * <Term> <Expr'>, <<EOF>>]",
						"[<Term> ::= * num, +]", "[<Term> ::= * num, -]",
						"[<Term> ::= * num, <<EOF>>]" },
				{ "[<Goal> ::= <Expr> *, <<EOF>>]" },
				{ "[<Expr> ::= <Term> * <Expr'>, <<EOF>>]",
						"[<Expr'> ::= * + <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= * - <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= e *, <<EOF>>]" },
				{ "[<Term> ::= num *, +]", "[<Term> ::= num *, -]",
						"[<Term> ::= num *, <<EOF>>]" },
				{ "[<Expr> ::= <Term> <Expr'> *, <<EOF>>]" },
				{ "[<Expr'> ::= + * <Term> <Expr'>, <<EOF>>]",
						"[<Term> ::= * num, +]", "[<Term> ::= * num, -]",
						"[<Term> ::= * num, <<EOF>>]" },
				{ "[<Expr'> ::= - * <Term> <Expr'>, <<EOF>>]",
						"[<Term> ::= * num, +]", "[<Term> ::= * num, -]",
						"[<Term> ::= * num, <<EOF>>]" },
				{ "[<Expr'> ::= * + <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= + <Term> * <Expr'>, <<EOF>>]",
						"[<Expr'> ::= * - <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= e *, <<EOF>>]" },
				{ "[<Expr'> ::= * + <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= * - <Term> <Expr'>, <<EOF>>]",
						"[<Expr'> ::= - <Term> * <Expr'>, <<EOF>>]",
						"[<Expr'> ::= e *, <<EOF>>]" },
				{ "[<Expr'> ::= + <Term> <Expr'> *, <<EOF>>]" },
				{ "[<Expr'> ::= - <Term> <Expr'> *, <<EOF>>]" } };
		String[] expectedTF = { "<0,<Expr>>=1", "<0,<Term>>=2", "<0,num>=3",
				"<2,<Expr'>>=4", "<2,+>=5", "<2,->=6", "<5,<Term>>=7",
				"<5,num>=3", "<6,<Term>>=8", "<6,num>=3", "<7,<Expr'>>=9",
				"<7,+>=5", "<7,->=6", "<8,<Expr'>>=10", "<8,+>=5", "<8,->=6" };
		checkCanonicalCollection(expectedCC, expectedTF, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7CanonicalCollection() {
		String[][] expectedCC = {
				{ "[<Goal> ::= * <Term>, <<EOF>>]",
						"[<Term> ::= * <Factor> <Term'>, <<EOF>>]",
						"[<Factor> ::= * num, *]", "[<Factor> ::= * num, /]",
						"[<Factor> ::= * num, <<EOF>>]" },
				{ "[<Goal> ::= <Term> *, <<EOF>>]" },
				{ "[<Term> ::= <Factor> * <Term'>, <<EOF>>]",
						"[<Term'> ::= * * <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= * / <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= e *, <<EOF>>]" },
				{ "[<Factor> ::= num *, *]", "[<Factor> ::= num *, /]",
						"[<Factor> ::= num *, <<EOF>>]" },
				{ "[<Term> ::= <Factor> <Term'> *, <<EOF>>]" },
				{ "[<Term'> ::= * * <Factor> <Term'>, <<EOF>>]",
						"[<Factor> ::= * num, *]", "[<Factor> ::= * num, /]",
						"[<Factor> ::= * num, <<EOF>>]" },
				{ "[<Term'> ::= / * <Factor> <Term'>, <<EOF>>]",
						"[<Factor> ::= * num, *]", "[<Factor> ::= * num, /]",
						"[<Factor> ::= * num, <<EOF>>]" },
				{ "[<Term'> ::= * * <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= * <Factor> * <Term'>, <<EOF>>]",
						"[<Term'> ::= * / <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= e *, <<EOF>>]" },
				{ "[<Term'> ::= * * <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= * / <Factor> <Term'>, <<EOF>>]",
						"[<Term'> ::= / <Factor> * <Term'>, <<EOF>>]",
						"[<Term'> ::= e *, <<EOF>>]" },
				{ "[<Term'> ::= * <Factor> <Term'> *, <<EOF>>]" },
				{ "[<Term'> ::= / <Factor> <Term'> *, <<EOF>>]" } };
		String[] expectedTF = { "<0,<Factor>>=2", "<0,<Term>>=1", "<0,num>=3",
				"<2,<Term'>>=4", "<2,*>=5", "<2,/>=6", "<5,<Factor>>=7",
				"<5,num>=3", "<6,<Factor>>=8", "<6,num>=3", "<7,<Term'>>=9",
				"<7,*>=5", "<7,/>=6", "<8,<Term'>>=10", "<8,*>=5", "<8,/>=6" };
		checkCanonicalCollection(expectedCC, expectedTF, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15CanonicalCollection() {
		String[][] expectedCC = {
				{ "[<Goal> ::= * <Stmt>, <<EOF>>]",
						"[<Stmt> ::= * { <Stmt> }, <<EOF>>]",
						"[<Stmt> ::= * null;, <<EOF>>]" },
				{ "[<Goal> ::= <Stmt> *, <<EOF>>]" },
				{ "[<Stmt> ::= * { <Stmt> }, }]",
						"[<Stmt> ::= { * <Stmt> }, <<EOF>>]",
						"[<Stmt> ::= * null;, }]" },
				{ "[<Stmt> ::= null; *, <<EOF>>]" },
				{ "[<Stmt> ::= * { <Stmt> }, }]",
						"[<Stmt> ::= { * <Stmt> }, }]",
						"[<Stmt> ::= * null;, }]" },
				{ "[<Stmt> ::= { <Stmt> * }, <<EOF>>]" },
				{ "[<Stmt> ::= null; *, }]" },
				{ "[<Stmt> ::= { <Stmt> * }, }]" },
				{ "[<Stmt> ::= { <Stmt> } *, <<EOF>>]" },
				{ "[<Stmt> ::= { <Stmt> } *, }]" } };
		String[] expectedTF = { "<0,<Stmt>>=1", "<0,null;>=3", "<0,{>=2",
				"<2,<Stmt>>=5", "<2,null;>=6", "<2,{>=4", "<4,<Stmt>>=7",
				"<4,null;>=6", "<4,{>=4", "<5,}>=8", "<7,}>=9" };
		checkCanonicalCollection(expectedCC, expectedTF, Grammars.Quiz15);
	}

	private void checkCanonicalCollection(String[][] expectedCCSets,
			String[] expectedTF, String inputGrammar) {
		CanonicalCollection c = constructCanonicalCollection(inputGrammar);
		String expected = Arrays.deepToString(expectedCCSets);
		assertEquals(expected, c.getSets().toString());
		expected = Grammars.toStringWithCurlies(expectedTF);
		assertEquals(expected, c.getTransitionFunction().toString());
	}

	private static CanonicalCollection constructCanonicalCollection(
			String inputGrammar) {
		Grammar g;
		try {
			g = Grammars.getGrammarFrom(inputGrammar);
		} catch (Exception e) {
			throw new RuntimeException("Softening exception building grammar",
					e);
		}
		g.finalizeGrammar();
		CanonicalCollection c = new CanonicalCollection(g, g.firstSets());
		return c;
	}

}
