/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Grammars;
import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.StringInputScanner;
import edu.roseHulman.cfg.parsing.ParseTree.ParseAction;

/**
 * Tests LL-1 parser.
 * 
 * @author cclifton
 * 
 */
public class LR1ParserTest {

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingIsParseable() {
		checkIsParseable(true, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingParsing0() {
		String inputGrammar = Grammars.NothingButNothing;
		String inputString = "";
		String[] expectedActions = { "parsedProduction: <Start> ::= e",
				"parsedToken: e", "finishConstruction",
				"parsedProduction: dummy goal production" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseIsParseable() {
		checkIsParseable(true, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing0() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "";
		String[] expectedActions = { "parsedProduction: <S> ::= e",
				"parsedToken: e", "finishConstruction",
				"parsedProduction: dummy goal production" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing1() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "baa";
		String[] expectedActions = { "parsedToken: baa",
				"parsedProduction: <S> ::= e", "parsedToken: e",
				"parsedProduction: <S> ::= baa <S>", "finishConstruction",
				"parsedProduction: dummy goal production" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing2() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "baa baa";
		String[] expectedActions = { "parsedToken: baa", "parsedToken: baa",
				"parsedProduction: <S> ::= e", "parsedToken: e",
				"parsedProduction: <S> ::= baa <S>",
				"parsedProduction: <S> ::= baa <S>", "finishConstruction",
				"parsedProduction: dummy goal production" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1IsParseable() {
		checkIsParseable(true, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7IsParseable() {
		checkIsParseable(true, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15IsParseable() {
		checkIsParseable(true, Grammars.Quiz15);
	}

	/**
	 * Test.
	 */
	@Test
	public void testParensIsParseable() {
		checkIsParseable(false, Grammars.Parens);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1IsParseable() {
		checkIsParseable(false, Grammars.IfThenElse1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1withoutAmbigIsParseable() {
		checkIsParseable(true, Grammars.IfThenElse1withoutAmbig);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1leftFactoredIsParseable() {
		checkIsParseable(true, Grammars.IfThenElse1leftFactored);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse2IsParseable() {
		checkIsParseable(true, Grammars.IfThenElse2);
	}

	private LR1Parser getParser(String inputGrammar) {
		Grammar g;
		try {
			g = Grammars.getGrammarFrom(inputGrammar);
		} catch (Exception e) {
			throw new RuntimeException("Softening exception building grammar",
					e);
		}
		g.finalizeGrammar();
		return new LR1Parser(g);
	}

	private void checkIsParseable(boolean expectParseable, String inputGrammar) {
		LR1Parser p = getParser(inputGrammar);
		if (expectParseable) {
			assertTrue(p.isParseable());
		} else {
			assertFalse(p.isParseable());
		}
	}

	private void checkParse(String inputGrammar, String inputString,
			String[] expectedActions) {
		LR1Parser p = getParser(inputGrammar);
		StringInputScanner sip = new StringInputScanner(new StringReader(
				inputString));
		ParseTree parseResult = p.parse(sip);
		List<ParseAction> actionsList = parseResult.actionsList();
		String eaString = Arrays.toString(expectedActions);
		assertEquals(eaString, actionsList.toString());
	}

}
