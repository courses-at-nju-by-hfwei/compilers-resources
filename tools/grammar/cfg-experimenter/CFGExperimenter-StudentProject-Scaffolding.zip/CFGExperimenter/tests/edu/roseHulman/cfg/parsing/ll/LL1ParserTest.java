/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.ll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Grammars;
import edu.roseHulman.cfg.NonTerminalToken;
import edu.roseHulman.cfg.Pair;
import edu.roseHulman.cfg.Production;
import edu.roseHulman.cfg.Token;
import edu.roseHulman.cfg.parsing.ParseTree;
import edu.roseHulman.cfg.parsing.StringInputScanner;
import edu.roseHulman.cfg.parsing.ParseTree.ParseAction;

/**
 * Tests LL-1 parser.
 * 
 * @author cclifton
 * 
 */
public class LL1ParserTest {

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingGetTable() {
		String[] expected = { "<<Goal>,<<EOF>>>=<Goal> ::= <Start>",
				"<<Start>,<<EOF>>>=<Start> ::= e" };
		checkGetTable(expected, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingIsParseable() {
		checkIsParseable(true, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingParsing0() {
		String inputGrammar = Grammars.NothingButNothing;
		String inputString = "";
		String[] expectedActions = { "willParseProduction: <Goal> ::= <Start>",
				"willParseProduction: <Start> ::= e", "parsedToken: e" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseGetTable() {
		String[] expected = { "<<Goal>,baa>=<Goal> ::= <S>",
				"<<Goal>,<<EOF>>>=<Goal> ::= <S>", "<<S>,baa>=<S> ::= baa <S>",
				"<<S>,<<EOF>>>=<S> ::= e" };
		checkGetTable(expected, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseIsParseable() {
		checkIsParseable(true, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing0() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "";
		String[] expectedActions = { "willParseProduction: <Goal> ::= <S>",
				"willParseProduction: <S> ::= e", "parsedToken: e" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing1() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "baa";
		String[] expectedActions = { "willParseProduction: <Goal> ::= <S>",
				"willParseProduction: <S> ::= baa <S>", "parsedToken: baa",
				"willParseProduction: <S> ::= e", "parsedToken: e" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseParsing2() {
		String inputGrammar = Grammars.SheepNoise;
		String inputString = "baa baa";
		String[] expectedActions = { "willParseProduction: <Goal> ::= <S>",
				"willParseProduction: <S> ::= baa <S>", "parsedToken: baa",
				"willParseProduction: <S> ::= baa <S>", "parsedToken: baa",
				"willParseProduction: <S> ::= e", "parsedToken: e" };
		checkParse(inputGrammar, inputString, expectedActions);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1GetTable() {
		String[] expected = { "<<Expr'>,+>=<Expr'> ::= + <Term> <Expr'>",
				"<<Expr'>,->=<Expr'> ::= - <Term> <Expr'>",
				"<<Expr'>,<<EOF>>>=<Expr'> ::= e",
				"<<Expr>,num>=<Expr> ::= <Term> <Expr'>",
				"<<Goal>,num>=<Goal> ::= <Expr>", "<<Term>,num>=<Term> ::= num" };
		checkGetTable(expected, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1IsParseable() {
		checkIsParseable(true, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7GetTable() {
		String[] expected = { "<<Factor>,num>=<Factor> ::= num",
				"<<Goal>,num>=<Goal> ::= <Term>",
				"<<Term'>,*>=<Term'> ::= * <Factor> <Term'>",
				"<<Term'>,/>=<Term'> ::= / <Factor> <Term'>",
				"<<Term'>,<<EOF>>>=<Term'> ::= e",
				"<<Term>,num>=<Term> ::= <Factor> <Term'>" };
		checkGetTable(expected, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7IsParseable() {
		checkIsParseable(true, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15GetTable() {
		String[] expected = { "<<Goal>,null;>=<Goal> ::= <Stmt>",
				"<<Goal>,{>=<Goal> ::= <Stmt>",
				"<<Stmt>,null;>=<Stmt> ::= null;",
				"<<Stmt>,{>=<Stmt> ::= { <Stmt> }" };
		checkGetTable(expected, Grammars.Quiz15);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15IsParseable() {
		checkIsParseable(true, Grammars.Quiz15);
	}

	/**
	 * Test.
	 */
	@Test
	public void testParens() {
		checkIsParseable(false, Grammars.Parens);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1() {
		checkIsParseable(false, Grammars.IfThenElse1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1withoutAmbig() {
		checkIsParseable(false, Grammars.IfThenElse1withoutAmbig);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1leftFactored() {
		checkIsParseable(false, Grammars.IfThenElse1leftFactored);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse2() {
		checkIsParseable(false, Grammars.IfThenElse2);
	}

	private LL1Parser getParser(String inputGrammar) {
		Grammar g;
		try {
			g = Grammars.getGrammarFrom(inputGrammar);
		} catch (Exception e) {
			throw new RuntimeException("Softening exception building grammar",
					e);
		}
		g.finalizeGrammar();
		return new LL1Parser(g);
	}

	private void checkGetTable(String[] expectedTableContents,
			String inputGrammar) {
		LL1Parser p = getParser(inputGrammar);
		Map<Pair<NonTerminalToken, Token>, Production> actualTable = p
				.getTable();
		String expected = Grammars.toStringWithCurlies(expectedTableContents);
		assertEquals(expected, actualTable.toString());
	}

	private void checkIsParseable(boolean expectParseable, String inputGrammar) {
		LL1Parser p = getParser(inputGrammar);
		if (expectParseable) {
			assertTrue(p.isParseable());
		} else {
			assertFalse(p.isParseable());
		}
	}

	private void checkParse(String inputGrammar, String inputString,
			String[] expectedActions) {
		LL1Parser p = getParser(inputGrammar);
		StringInputScanner sip = new StringInputScanner(new StringReader(
				inputString));
		ParseTree parseResult = p.parse(sip);
		List<ParseAction> actionsList = parseResult.actionsList();
		String eaString = Arrays.toString(expectedActions);
		assertEquals(eaString, actionsList.toString());
	}

}
