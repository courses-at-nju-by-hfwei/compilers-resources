/*
 * Copyright � 2007�2010, Curtis Clifton and Brian T. Kelley
 * 
 * All rights reserved.
 * 
 * See license.txt for details.
 */

package edu.roseHulman.cfg.parsing.lr;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

import edu.roseHulman.cfg.Grammar;
import edu.roseHulman.cfg.Grammars;

/**
 * Tests for {@link ActionAndGotoTables}.
 * 
 * @author cclifton
 */
public class ActionAndGotoTablesTest {

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingActionTable() {
		String[] expected = { "<0,<<EOF>>>=reduce <Start> ::= e", "<1,<<EOF>>>=accept" };
		checkActionTable(expected, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseActionTable() {
		String[] expected = { "<0,baa>=shift 2",
				"<0,<<EOF>>>=reduce <S> ::= e", "<1,<<EOF>>>=accept",
				"<2,baa>=shift 2", "<2,<<EOF>>>=reduce <S> ::= e",
				"<3,<<EOF>>>=reduce <S> ::= baa <S>" };
		checkActionTable(expected, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1ActionTable() {
		String[] expected = { "<0,num>=shift 3", "<1,<<EOF>>>=accept",
				"<2,+>=shift 5", "<2,->=shift 6",
				"<2,<<EOF>>>=reduce <Expr'> ::= e",
				"<3,+>=reduce <Term> ::= num", "<3,->=reduce <Term> ::= num",
				"<3,<<EOF>>>=reduce <Term> ::= num",
				"<4,<<EOF>>>=reduce <Expr> ::= <Term> <Expr'>",
				"<5,num>=shift 3", "<6,num>=shift 3", "<7,+>=shift 5",
				"<7,->=shift 6", "<7,<<EOF>>>=reduce <Expr'> ::= e",
				"<8,+>=shift 5", "<8,->=shift 6",
				"<8,<<EOF>>>=reduce <Expr'> ::= e",
				"<9,<<EOF>>>=reduce <Expr'> ::= + <Term> <Expr'>",
				"<10,<<EOF>>>=reduce <Expr'> ::= - <Term> <Expr'>" };
		checkActionTable(expected, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7ActionTable() {
		String[] expected = { "<0,num>=shift 3", "<1,<<EOF>>>=accept",
				"<2,*>=shift 5", "<2,/>=shift 6",
				"<2,<<EOF>>>=reduce <Term'> ::= e",
				"<3,*>=reduce <Factor> ::= num",
				"<3,/>=reduce <Factor> ::= num",
				"<3,<<EOF>>>=reduce <Factor> ::= num",
				"<4,<<EOF>>>=reduce <Term> ::= <Factor> <Term'>",
				"<5,num>=shift 3", "<6,num>=shift 3", "<7,*>=shift 5",
				"<7,/>=shift 6", "<7,<<EOF>>>=reduce <Term'> ::= e",
				"<8,*>=shift 5", "<8,/>=shift 6",
				"<8,<<EOF>>>=reduce <Term'> ::= e",
				"<9,<<EOF>>>=reduce <Term'> ::= * <Factor> <Term'>",
				"<10,<<EOF>>>=reduce <Term'> ::= / <Factor> <Term'>" };
		checkActionTable(expected, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15ActionTable() {
		String[] expected = { "<0,null;>=shift 3", "<0,{>=shift 2",
				"<1,<<EOF>>>=accept", "<2,null;>=shift 6", "<2,{>=shift 4",
				"<3,<<EOF>>>=reduce <Stmt> ::= null;", "<4,null;>=shift 6",
				"<4,{>=shift 4", "<5,}>=shift 8",
				"<6,}>=reduce <Stmt> ::= null;", "<7,}>=shift 9",
				"<8,<<EOF>>>=reduce <Stmt> ::= { <Stmt> }",
				"<9,}>=reduce <Stmt> ::= { <Stmt> }" };
		checkActionTable(expected, Grammars.Quiz15);
	}

	private void checkActionTable(String[] expectedActionTable,
			String inputGrammar) {
		ActionAndGotoTables tables = constructActionAndGotoTables(inputGrammar);
		String expected = Grammars.toStringWithCurlies(expectedActionTable);
		assertEquals(expected, tables.getActionTable().toString());
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingGotoTable() {
		String[] expected = { "<0,<Start>>=1" };
		checkGotoTable(expected, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseGotoTable() {
		String[] expected = { "<0,<S>>=1", "<2,<S>>=3" };
		checkGotoTable(expected, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1GotoTable() {
		String[] expected = { "<0,<Expr>>=1", "<0,<Term>>=2", "<2,<Expr'>>=4",
				"<5,<Term>>=7", "<6,<Term>>=8", "<7,<Expr'>>=9",
				"<8,<Expr'>>=10" };
		checkGotoTable(expected, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7GotoTable() {
		String[] expected = { "<0,<Factor>>=2", "<0,<Term>>=1",
				"<2,<Term'>>=4", "<5,<Factor>>=7", "<6,<Factor>>=8",
				"<7,<Term'>>=9", "<8,<Term'>>=10" };
		checkGotoTable(expected, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15GotoTable() {
		String[] expected = { "<0,<Stmt>>=1", "<2,<Stmt>>=5", "<4,<Stmt>>=7" };
		checkGotoTable(expected, Grammars.Quiz15);
	}

	private void checkGotoTable(String[] expectedGotoTable, String inputGrammar) {
		ActionAndGotoTables tables = constructActionAndGotoTables(inputGrammar);
		String expected = Grammars.toStringWithCurlies(expectedGotoTable);
		assertEquals(expected, tables.getGotoTable().toString());
	}

	/**
	 * Test.
	 */
	@Test
	public void testNothingButNothingConflicts() {
		String[] expected = {};
		checkConflicts(expected, Grammars.NothingButNothing);
	}

	/**
	 * Test.
	 */
	@Test
	public void testSheepNoiseConflicts() {
		String[] expected = {};
		checkConflicts(expected, Grammars.SheepNoise);
	}

	/**
	 * Test.
	 */
	@Test
	public void testExpression1Conflicts() {
		String[] expected = {};
		checkConflicts(expected, Grammars.Expression1);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz7Conflicts() {
		String[] expected = {};
		checkConflicts(expected, Grammars.Quiz7);
	}

	/**
	 * Test.
	 */
	@Test
	public void testQuiz15Conflicts() {
		String[] expected = {};
		checkConflicts(expected, Grammars.Quiz15);
	}

	/**
	 * Test.
	 */
	@Test
	public void testParensConflicts() {
		String[] expected = {
				"'shift 2'-'reduce <Parens> ::= <Parens> <Parens>' conflict for '<4,(>'",
				"'shift 3'-'reduce <Parens> ::= <Parens> <Parens>' conflict for '<4,x>'",
				"'shift 5'-'reduce <Parens> ::= <Parens> <Parens>' conflict for '<10,(>'",
				"'shift 7'-'reduce <Parens> ::= <Parens> <Parens>' conflict for '<10,x>'" };
		checkConflicts(expected, Grammars.Parens);
	}

	/**
	 * Test.
	 */
	@Test
	public void testIfThenElse1Conflicts() {
		String[] expected = { "'shift 14'-'reduce <Stmt> ::= if expr then <Stmt>' conflict for '<13,else>'" };
		checkConflicts(expected, Grammars.IfThenElse1);
	}

	private void checkConflicts(String[] expectedConflicts, String inputGrammar) {
		ActionAndGotoTables tables = constructActionAndGotoTables(inputGrammar);
		String expected = Arrays.toString(expectedConflicts);
		assertEquals(expected, tables.getConflicts().toString());
	}

	private static ActionAndGotoTables constructActionAndGotoTables(
			String inputGrammar) {
		Grammar g;
		try {
			g = Grammars.getGrammarFrom(inputGrammar);
		} catch (Exception e) {
			throw new RuntimeException("Softening exception building grammar",
					e);
		}
		g.finalizeGrammar();
		CanonicalCollection c = new CanonicalCollection(g, g.firstSets());
		return new ActionAndGotoTables(g, c);
	}

}
